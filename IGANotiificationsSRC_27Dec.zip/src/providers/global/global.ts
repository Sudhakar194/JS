//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class GlobalProvider {

public gLocale: boolean;

  constructor() {
    console.log('Hello GlobalProvider Provider');
    
    // english = true , arabic = flase
    this.gLocale = true;	



  }

  



}
