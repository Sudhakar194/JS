import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { TabsPage } from '../../pages/tabs/tabs';

@Component({
  selector: 'page-sidemenu',
  templateUrl: 'sidemenu.html',
})

export class SidemenuPage {

 rootPage: any = TabsPage;


  constructor(public navCtrl: NavController, public navParams: NavParams) {
    // used for an example of ngFor and navigation
    
  }


}
