import { Component } from '@angular/core';
import { App, NavController, NavParams } from 'ionic-angular';

import { CallserverProvider } from './../../providers/callserver/callserver';
import { GlobalProvider } from './../../providers/global/global';

import { TabsPage } from '../../pages/tabs/tabs';
import { SidemenuPage } from '../../pages/sidemenu/sidemenu';

import {FormControl, FormGroup, Validators} from '@angular/forms';

import { LoadingController } from 'ionic-angular';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})


export class HomePage {

  private userData = { "idnumber": "", "password": "","confirmpassword": "", "emailid":"","mobile":""};

  // form groups for validations only 
    loginForm: FormGroup;
    regForm: FormGroup;
    forgotForm: FormGroup;

  // to hide locale buttons 
     localeAR: boolean;
     localeEN: boolean;

  // to enable form fields 
     loginFormHidden: boolean;
     newUserFormHidden: boolean;
     forgotDetailsFormHidden: boolean;
   
   //click to redirect to another form 
     loginButtonHidden: boolean;
     newUserButtonHidden: boolean;   
     forgotDetailsButtonHidden: boolean;
   
   // for otp
     otpHidden: boolean;
     disableServerMessageBoolean: boolean;

   loader: any ;

  constructor(public navCtrl: NavController, public navParams: NavParams,public callserver: CallserverProvider, public appObject: App, public loadingCtrl: LoadingController, public g: GlobalProvider) {  

   console.log('HomePage#constructor this.g.gLocale : '+ this.g.gLocale);

        this.loginFormHidden = false;
        this.newUserFormHidden = true;
        this.forgotDetailsFormHidden = true;
        this.loginButtonHidden = true;
        this.newUserButtonHidden = false;
        this.forgotDetailsButtonHidden = false;
        this.disableServerMessageBoolean = false;

        this.otpHidden = true;
  }

   presentLoading() {
      console.log('Home # presentLoading start: ' );
    
      this.loader = this.loadingCtrl.create({
           // spinner: 'hide',
          // content: '<div class="custom-spinner-container"><div class="custom-spinner-box"></div></div>',      
          content: "Please wait...",
          //  duration: 3000
      });
      
      this.loader.present();

      this.loader.onDidDismiss(() => {
          console.log('Home # Dismissed loading');
      });
        
      setTimeout(() => {
          //this.nav.push(Page2);
          console.log('Home # setTimeout close: ' );
          this.loader.dismiss();        
          // add boolean variable , to check varibale to load the response 
      }, 5000);

      console.log('Home # presentLoading close: ' );
  }



  ngOnInit() {
      let EMAILPATTERN = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
      
      //this.formBuilder.group
      this.loginForm = new FormGroup({
         idnumber: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]),
         password: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
       });

       this.regForm = new FormGroup({
         idnumber: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]),
         password: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
         confirmpassword: new FormControl('',[Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
         emailid: new FormControl('',[Validators.required, Validators.pattern(EMAILPATTERN)]),
         mobile: new FormControl('',[Validators.required]),
       });


       this.forgotForm = new FormGroup({
         idnumber: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]),   
         emailid: new FormControl('',[Validators.required, Validators.pattern(EMAILPATTERN)]),
       });

  }//ngOnInit



 showForm (showForm){
        console.log('Home # showForm : ' + showForm);
      if (showForm == 'loginUser'){         
         this.loginFormHidden = false;
         this.newUserFormHidden = true;
         this.forgotDetailsFormHidden = true;
            this.loginButtonHidden = true;
            this.newUserButtonHidden = false;
            this.forgotDetailsButtonHidden = false;
      }else if (showForm == 'forgotDetails'){    
          this.loginFormHidden = true;
          this.newUserFormHidden = true;
          this.forgotDetailsFormHidden = false;
              this.loginButtonHidden = false;
              this.newUserButtonHidden = false;
              this.forgotDetailsButtonHidden = true;
      }else if (showForm == 'newUser'){    
          this.loginFormHidden = true;
          this.newUserFormHidden = false;
          this.forgotDetailsFormHidden = true;
              this.loginButtonHidden = false;
              this.newUserButtonHidden = true;
              this.forgotDetailsButtonHidden = false;
      }
  } //showForm



  loginUser(loginForm){
  	  console.log('HomePage logForm # 1 : ');
      console.log('HomePage logForm # 1 : ' + loginForm.get('idnumber').value);
      console.log('HomePage logForm # 1 : ' + loginForm.valid);
      // [class.error1]="!loginForm.controls.idnumber.valid && signupform.controls.idnumber.dirty"
      console.log('HomePage logForm # 1 : ' + loginForm.controls.idnumber.valid);
   
    this.presentLoading();

    this.callserver.callServerGet ('/action/login').subscribe(
           data => {
               console.log('CallserverProvider Entry # 5 DATA STATUS: ' +  data.status);
          }, err => {
               console.log('CallserverProvider Entry # 4 ERROR STATUS: ' +  err.status);
               console.log('CallserverProvider Entry # 4 ERROR: ' +  err);
              // this.toast.presentToast("Check internet connection");
              
               // if any validation error from server 
                  if (loginForm.get('idnumber').value == 11){
                      this.disableServerMessageBoolean = true;
                      loginForm.controls.error = true;
                      loginForm.controls.error_stringEn = "Invalid ID Number and Password";
                      loginForm.controls.error_stringAr = "رقم الهوية غير صالح وكلمة المرور";
                   }else{                     
                      this.appObject.getRootNav().push(SidemenuPage);               
                   }
                  

                   console.log('CallserverProvider Entry # 4 loader.dismiss: ');
                   this.loader.dismiss();     


            /**   if (err.status = "1000"){
                    console.log('CallserverProvider Entry # 4 push toTabsPage : ');
                    // That's right, we're pushing to ourselves!
                    this.appObject.getRootNav().push(TabsPage);
               }else{
                    console.log('CallserverProvider Entry # 4 display error message: ');
               } */
          });
  } //close logForm
   

  newUser (newUserForm){
    console.log('HomePage logForm #  2 newUserForm : ');
      this.loginFormHidden = true;
      this.newUserFormHidden = true;
      this.forgotDetailsFormHidden = true;
      this.loginButtonHidden = true;
      this.newUserButtonHidden = true;
      this.forgotDetailsButtonHidden = true;
      this.otpHidden = false; 
  }


  forgotDetails (forgotDetailsForm){
      console.log('HomePage logForm #  3 forgotDetailsForm : ');
  }

  next(otp){  
    //otp.setFocus();
  }

  submitRegistrationOTP(){
     console.log('HomePage logForm #  9 submitRegistrationOTP : ');
  } //submitRegistrationOTP
      

  closeOTP(){
      this.otpHidden = true;
      this.loginFormHidden = true;
      this.newUserFormHidden = false;
      this.forgotDetailsFormHidden = true;
      this.loginButtonHidden = false;
      this.newUserButtonHidden = true;
      this.forgotDetailsButtonHidden = false;  
  }//closeOTP


  // header
  localeChange(){
      if (this.g.gLocale) {
        this.g.gLocale=false;
      } else{
        this.g.gLocale=true;
      }
     console.log('HomePage#localeChange this.g.gLocale : '+ this.g.gLocale);
  } //localeChange


 /** isValidNumber(event){  
     // console.log('HomePage logForm #  9 submitRegistrationOTP : '+ event.keyCode);
     // console.log('HomePage logForm #  9 submitRegistrationOTP : '+ event.key);
  } */


  disableServerMessage(loginForm){
    console.log('HomePage logForm #  9 disableServerMessageBoolean : '+ this.disableServerMessageBoolean);
    if (this.disableServerMessageBoolean){
          this.disableServerMessageBoolean = false;
          loginForm.controls.error = false;
    }
  }
  


} //  Close Home
