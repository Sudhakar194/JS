
//npm install easy-soap-request  - use this one 
//https://medium.com/@caleblemoine/how-to-perform-soap-requests-with-node-js-4a9627070eb6


//npm install soap 
const axios = require('axios');
const url = 'http://stg-gdtesb.gov.bh/cio-gdt-esb/svc/GDTService.svc';
const xml = '';
const headers = {
		'user-agent': 'sample',
		'Content-Type': 'text/xml;charset=UTF-8',
		'soapAction': 'getVehicleRequestDetail',		
	}

soapRequest(url,headers,xml)


function soapRequest(url, headers, xml, timeout=1000){

	return new Promise((resolve, reject) =>{
		axios({			
			  method: 'post',
		      url,
		      headers,
		      data: xml,
		      timeout,
			
			
		}).then((response) => {
			resolve({
				response:{
					body: response.data,
					statusCode: response.status,
					
				},
			});
			
		}).catch((error) => {
			if (error.response){
				console.log(error.response);
				reject(error.response.data);
			}else{
				console.log(error);
				reject(error);
			}
			
		});
		
		
		
		
	}) ;
		
};



/*
 * 
 * 
 * const soap = require('easy-soap-request');







//usage of module
(async () => {
  const { response } = await soapRequest(url, headers, xml, 1000);
  const { body, statusCode } = response;
  console.log(body);
  console.log(statusCode);

});

**/


