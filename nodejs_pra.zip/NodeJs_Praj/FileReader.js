const log = require('./log_mod');
//const getFileList = require('./file_mod');
var fs = require('fs');

//if (process.argv.length <=2 ){
//	console.log('get corrent file directory : ' , __filename);
//}
//var path = process.argv[2];


//var maindir = 'F:/Study/PlayingCards/Nodejs-test/';
var maindir = '\\10.11.6.51\NGI_logs';
var localdir = [] ; // initialized empty array
var localdirFiles = [] ; // initialized empty array 
var tempPath  = '';		
var n = 0;
var m = 0;

getFileList(maindir);

setTimeout(function(){
	log(localdirFiles);	
	log(localdir);	
   
},1000);

log('test');	


function getFileList(maindir){
	
	fs.readdir(maindir, function(err, items) {
		
		    if(err){
		    	console.log(err);
		    }
		
		    for (var i=0; i<items.length; i++) {       
		    	tempPath = maindir + items[i];
		    	//log('path'+ tempPath);
		    	status(tempPath);
		    } 		    		    
	});

}


function status(tempPath){
	
		fs.stat(tempPath, (err,stats) => {
			  //  console.log('tempPath : '+ tempPath);
	    		if (stats.isDirectory()){
	    			localdir[n] = tempPath + '/';
	    		//	log('dir' + n + ': '+ localdir[n]);    			
	    			getFileListTemp(localdir[n]);
	    			n = n + 1;
	    		 } 
	    		
	    		if (stats.isFile()){
	    			localdirFiles[m] = tempPath;
	    			log('file' + m + ': '+ localdirFiles[m]);
	    			m = m + 1;
	    		}
	    			    		
		});
	
		
	
}





function getFileListTemp(maindir){	
	fs.readdir(maindir, function(err, items) {
	    for (var i=0; i<items.length; i++) {       
	    	tempPath = maindir + items[i];
	    	//log('path'+ tempPath);
	    	status(tempPath);
	    }    
	});		
}
