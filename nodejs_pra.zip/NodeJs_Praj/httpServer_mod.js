// 
// server running ar http://localhost:7501/
// run command :  $ node GDT.js
http.createServer(function(req,res){
  res.writeHead(200, {'Content-Type' : 'text/plain'});
  res.end('Hello User ');	
}).listen(7501);