function log(message){
	console.log(message);
}

module.exports = log;

/**
function test1(name){
	console.log('Hi, Hello :' + name);

}
test1('sudhan');

// define a fundction in global scope
var test2 = function(){
	console.log ('Global function test2')
}//window.test2();

*/