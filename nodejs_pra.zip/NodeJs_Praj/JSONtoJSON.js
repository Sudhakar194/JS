var url = 'http://10.11.29.18/ScService/restful/sc/api/v1/lookup/item/country';
var http = require("http");
var https = require("https");
//var tryjson = require('tryjson');

var optionsGET = {
		    host: '10.11.29.18',
		    port: 80,
		    path: '/ScService/restful/sc/api/v1/lookup/item/country',
		    method: 'GET',
		    headers: {
		        accept: 'application/json'
		    }
};


//Call backend 
http.get(optionsGET , function(res){
	console.log('statusCode: ${res.statusCode} ' + res.statusCode);
	var body= '';
	res.on('data',function(data){
		console.log('res start: ' , data);
		body = body + data;		
	});
	
	res.on('end',function(){
		if (res.statusCode === 200){
		//	var data = JSON.parse(body);	
			var data = body;
			console.log( 'res end: ',  data);
		} else{
			console.log( 'res status code : ',  res.statusCode);
			console.log( 'res end: ',  body);
		}		
	});
	
	
}).on ('error',function(err){
	console.log('error invoking backend : ', err);
	
});


// error error invoking backend :  { Error: connect ETIMEDOUT 10.11.29.19:80
//at TCPConnectWrap.afterConnect [as oncomplete] (net.js:1117:14)
//errno: 'ETIMEDOUT',
//code: 'ETIMEDOUT',
//syscall: 'connect',
//address: '10.11.29.19',
//port: 80 }


const data = JSON.stringify({"smartcardUpdate":{"cprNumber":741304228}})

//const data = '{"smartcardUpdate":{"cprNumber":741304228}}';

var optionsPOST = {
    host: '10.11.29.18',
    port: 80,
    path: '/ScService/restful/sc/api/v1/person/is/valid/request/new/',
    method: 'POST',
    headers: {
    	'Content-Type': 'application/json',
        'Content-Length': data.length,
        accept: 'application/json'
    }
};


//Call backend 
var req = http.request(optionsPOST , (res) => {
	console.log('statusCode: ${res.statusCode} ' + res.statusCode);
	var body= '';
	res.on('data',function(data){
		//console.log('res start: ' , data);
		body = body + data;		
	});
	
	res.on('end',function(){
		if (res.statusCode === 200){
			var data = JSON.parse(body);	
			//var data = body;
			console.log( 'res end: ',  data);
		} else{
			console.log( 'res status code : ',  res.statusCode);
			console.log( 'res end: ',  body);
		}		
	});

}).on ('error',function(err){
	console.log('error invoking backend : ', err);

});


req.write(data);
req.end();

