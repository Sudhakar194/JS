package com.main;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MainServlet
 */
//@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainServlet() {
        super();
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 System.out.println( "getRequestURI ::" + request.getRequestURI()); // /Cards_Server/MainServlet
		 System.out.println( "getServletPath ::" + request.getServletPath()); //  /MainServlet
		 
		 //response.setContentType("text/plain");
		 //response.sendRedirect("login.html");
		 //RequestDispatcher view = request.getRequestDispatcher("/login.html");
		//view.forward(request, response);
			 
		 response.getWriter().append("Served at: ").append(request.getContextPath() + request.getParameterNames());		
	}
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 System.out.println( "getRequestURI ::" + request.getRequestURI()); // /Cards_Server/MainServlet
		 String action = request.getPathInfo();
		 System.out.println( "action ::" + action); // /Cards_Server/MainServlet
		 System.out.println( "param ::" + request.getParameter("param") );
		 
		 
		 if (action.equals("/countryList")){
			 response.getWriter().append("INDIA:444:91~PAK:445:92");
	     
		 }else if (action.equals("/notifications")){			
			 response.setContentType("text/json");
			 response.setCharacterEncoding("UTF-8");

			 
			 response.setStatus(200);														 
			 /* response.getWriter().append("{\"errorCode\":200"
			 		+ ",\"errorMsgEn\":\"\""
			 		+ ", \"errorMsgAr\":\"\""
			 		+", \"dataUpdated\":\"\""
			 		+ ",\"responseObject\":["
			 		+ " {\"code\":\"MOT\",\"date\":\"22-12-2018 12:15 PM\",\"headlineEN\":\"Notification Headline1 en\",\"headlineAR\":\"Notification Headline1 ar\",\"messageEN\":\"You can renew your identity card one month before the expiration date. Note that it ends on 15/04/2018 \",\"messageAR\":\"You can renew your identity card one month before the expiration date. Note that it ends ar\"}"
			 		+ ",{\"code\":\"MOT\",\"date\":\"22-12-2018 12:15 PM\",\"headlineEN\":\"Notification Headline2 en\",\"headlineAR\":\"Notification Headline2 ar\",\"messageEN\":\"You can renew your identity card one month before the expiration date. Note that it ends on 15/04/2018 \",\"messageAR\":\"You can renew your identity card one month before the expiration date. Note that it ends ar\"}"
			 		+ ",{\"code\":\"MOJ\",\"date\":\"22-12-2018 12:15 PM\",\"headlineEN\":\"Notification Headline3 en\",\"headlineAR\":\"Notification Headline3 ar\",\"messageEN\":\"You can renew your identity card one month before the expiration date. Note that it ends on 15/04/2018 \",\"messageAR\":\"You can renew your identity card one month before the expiration date. Note that it ends ar\"}"
			 		+ ",{\"code\":\"IAE\",\"date\":\"22-12-2018 12:15 PM\",\"headlineEN\":\"Notification Headline4 en\",\"headlineAR\":\"Notification Headline4 ar\",\"messageEN\":\"You can renew your identity card one month before the expiration date. Note that it ends on 15/04/2018 \",\"messageAR\":\"You can renew your identity card one month before the expiration date. Note that it ends ar\"}"
			 		+ ",{\"code\":\"IAE\",\"date\":\"22-12-2018 12:15 PM\",\"headlineEN\":\"Notification Headline5 en\",\"headlineAR\":\"Notification Headline5 ar\",\"messageEN\":\"You can renew your identity card one month before the expiration date. Note that it ends on 15/04/2018 \",\"messageAR\":\"You can renew your identity card one month before the expiration date. Note that it ends ar\"}"
			 		+ ",{\"code\":\"IAE\",\"date\":\"22-12-2018 12:15 PM\",\"headlineEN\":\"Notification Headline6 en\",\"headlineAR\":\"Notification Headline6 ar\",\"messageEN\":\"You can renew your identity card one month before the expiration date. Note that it ends on 15/04/2018 \",\"messageAR\":\"You can renew your identity card one month before the expiration date. Note that it ends ar\"}"
			 		+ "]}");*/
			 
			 
			       String data = ""; 
			       BufferedReader  filereader = new BufferedReader(new InputStreamReader(new FileInputStream("D:/Sudhakar/WorkSpace - Java/ministryNotifications.txt"), "UTF8"));
				   String line ="";
				  
				   while ((line = filereader.readLine()) != null) {
					   data = data +  line; 
					   
				   }
				   
				 // String arabicWord = URLDecoder.decode(response.getHeader("Info"), "UTF-8"); 
			    response.getWriter().append(data) ;
			 			 
		 }else if (action.equals("/ministryList")){			
			 response.setContentType("text/json");
			 response.setCharacterEncoding("UTF-8");
			 response.setStatus(200);														 
			/* response.getWriter().append("{\"errorCode\":200"
			 		+ ",\"errorMsgEn\":\"\""
			 		+ ", \"errorMsgAr\":\"\""
			 		+", \"dataUpdated\":\"\""
			 		+ ",\"responseObject\":[{\"code\":\"MOT\",\"nameEN\":\"Minister of Education en\",\"nameAR\":\"Minister of Education ar\"}"
			 		+ ",{\"code\":\"MOE\",\"nameEN\":\"Minister of Electricity and Water Affairs\",\"nameAR\":\"Minister of Electricity and Water Affairs ar\"}"
			 		+ ",{\"code\":\"MOJ\",\"nameEN\":\"Minister of Justice en\",\"nameAR\":\"Minister of Justice ar\"}"
			 		+ ",{\"code\":\"IAE\",\"nameEN\":\"Islamic Affairs and Endowment en\",\"nameAR\":\"Islamic Affairs and Endowment ar\"}"
			 		+ ",{\"code\":\"MIA\",\"nameEN\":\"Minister of Information Affairs en\",\"nameAR\":\"Minister of Information Affairs ar\"}"
			 		+ ",{\"code\":\"MOO\",\"nameEN\":\"Minister of Oil en\",\"nameAR\":\"Minister of Oil ar\"}]}");*/
			 
			    String data = ""; 
			       BufferedReader  filereader = new BufferedReader(new InputStreamReader(new FileInputStream("D:/Sudhakar/WorkSpace - Java/ministryList.txt"), "UTF8"));
				   String line ="";
				  
				   while ((line = filereader.readLine()) != null) {
					   data = data +  line; 
					   
				   }
			 
			   response.getWriter().append(data) ;
			 			 
		 }else if (action.equals("/login")){				
			 response.setStatus(200);	
			 response.getWriter().append("{\"errorCode\":200"
				 		+ ",\"errorMsgEn\":\"\", \"error message\":\"\"}");
			 //response.getWriter().append("[{\"errorCode\":1234,\"lname\":2345}]");
			 			 
		 }else if (action.equals("/reg")){
			 try{
		    	  String[] paramArray = request.getParameter("param").split("~");
		    	 
		    	 /* var param =  
		    	    00 $("#unameFID").val() + '~' +
		            01 $("#unameLID").val() + '~' + 
		            02 $("#countryID").val() + '~' + 
		            03 $("#mobCodeID").val() + '~' +
		            04 $("#mobID").val() + '~' +
		            05 $("#emailID").val();*/
		    	  DBBeans dbBeans = new DBBeans();
		    	  dbBeans.setSerReq("userReg");
		    	  dbBeans.setuNameF(paramArray[0]);
		    	  dbBeans.setuNameL(paramArray[1]);
		    	  dbBeans.setuName(paramArray[0] + " " + paramArray[1] );
		    	  dbBeans.setUCountryCode(paramArray[2]);
		    	  dbBeans.setuMobCode(paramArray[3]);
		    	  dbBeans.setuMob(paramArray[4]);
		    	  dbBeans.setuEmail(paramArray[5]);
		    	  
		    	 /* DBController dbcontroller = new DBController();
		    	  dbcontroller.openDB();
		    	  dbcontroller.insertData(dbBeans);
		    	  dbcontroller.closeDB();*/
		    	  
		    	  
		    	  response.getWriter().append("000");
		    	  
				}catch (Exception e) {
		          System.out.println("Error while writing data into file : " + e.getMessage()); 
		          e.printStackTrace();
				}
		 }else if (action.equals("/login")){
			 System.out.println("inside login : "); 
			 try{
		    	  String[] paramArray = request.getParameter("param").split("~");
		    	 
		    	  DBController dbcontroller = new DBController();
		    	  dbcontroller.openDB();
		    	  
		    	  
		    	  int result  = dbcontroller.validateLoginUser(paramArray);
		    	  
		    	  dbcontroller.closeDB();
		    	  
		    	  System.out.println("inside result : " + result);
		    	  
		    	  response.getWriter().append(""+result);
		    	  
				}catch (Exception e) {
		          System.out.println("Error while writing data into file : " + e.getMessage()); 
		          e.printStackTrace();
				}
		 }else{
			 response.setStatus(200);			
			 response.getWriter().append("[{\"fname\":1234,\"lname\":2345}]");
		 }
		 
		
		 
		 //response.setContentType("text/plain");
		 //response.sendRedirect("login.html");
		 //RequestDispatcher view = request.getRequestDispatcher("/login.html");
		 //view.forward(request, response);			 
		 //response.getWriter().append("Served at: ").append(request.getContextPath() + request.getParameterNames());
		 
	}
	
	
	
	
}






