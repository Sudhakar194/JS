package com.main;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;

public class DBController {
	
	 // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    static final String DB_URL      = "jdbc:mysql://localhost/playstore";
    
    // Database credentials
    static final String USER = "root";
    static final String PASS = "root";
    
    Connection dbCon = null;
    
    // Open a connection
    protected int openDB(){
    	try{
	    	Class.forName("com.mysql.jdbc.Driver");
	    	dbCon = DriverManager.getConnection(DB_URL, USER, PASS);
    	}catch (Exception e) {
    		System.out.println("Exception in DBController - openDB ::: " + e.getMessage());
			e.printStackTrace();
			return 0;
		}
    	return 1;
    }
    
	
    protected void closeDB(){
    	try{
    		if(dbCon!=null)
    			dbCon.close();
    	}catch (Exception e) {
    		System.out.println("Exception in DBController - closeDB ::: " + e.getMessage());
			e.printStackTrace();
		}
    }
    
    
	public int insertData(DBBeans dbbeansobj) throws SQLException {
		String serReq = dbbeansobj.getSerReq();
		
		if (serReq.equals("userReg")){
			 String uNameF  = dbbeansobj.getuNameF();
			 String uNameL  = dbbeansobj.getuNameL();
			 String uName   = dbbeansobj.getuName();
			 String uCountryCode   = dbbeansobj.getUCountryCode();
			 String uMobCode    = dbbeansobj.getuMobCode();
			 String uMob    = dbbeansobj.getuMob();
			 String uEmail  = dbbeansobj.getuEmail();

			 Date dateCreate ;
			 String uniqueid = dbbeansobj.getuUniqueID();
			
			// the mysql insert statement -- date_updated,req_for_update
		    String query = "insert into USERPROFILE (user_id,"
		    		+ "USER_FIRST_NAME,"
		    		+ "USER_LAST_NAME,"
		    		+ "USER_NAME,"
		    		+ "USER_COUNTRY_CODE,"
		    		+ "USER_MOB_CODE,"
		    		+ "USER_MOBILE,"
		    		+ "USER_EMAIL,"		    	
		    		+ "DATE_CREATED,"
		    		+ "USER_UNIQUE_ID)" + " values (?, ?, ?, ?, ?, ?, ?, ?,?)";
		    
		    // create a sql date object so we can use it in our INSERT statement
		    Calendar calendar = Calendar.getInstance();
		    dateCreate = new java.sql.Date(calendar.getTime().getTime());
		    
		    System.out.println("Exception in DBController - insertData ::: " + dateCreate);
		    
	        // create the mysql insert preparedstatement
	        PreparedStatement preparedStmt = dbCon.prepareStatement(query);
	        preparedStmt.setString    (1, uNameF);
	        preparedStmt.setString    (2, uNameL);
	        preparedStmt.setString    (3, uName);
	        preparedStmt.setString    (4, uCountryCode);
	        preparedStmt.setString    (5, uMobCode);
	        preparedStmt.setString    (6, uMob);
	        preparedStmt.setString    (7, uEmail);
	        preparedStmt.setDate      (8, dateCreate);
	        preparedStmt.setString    (9, uniqueid);

	        // execute the preparedstatement
	        boolean result = preparedStmt.execute();
	        preparedStmt.close();
	        
	        if (result) return 000;
	        else return 001;
	        
	       
		}
		return 001;
	}
	
	public int validateLoginUser(String req[]) throws SQLException{
		ResultSet rs = null;
		Statement stmt = null;
		try{
		        // Execute SQL query
		        stmt = dbCon.createStatement();
		        String sql = "SELECT USER_PASSWORD,USER_UNIQUE_ID,ID FROM USERPROFILE WHERE USER_ID = \"" + req[0] + "\"";
		        rs = stmt.executeQuery(sql);
		
		        // Extract data from result set
		        String pwd = "";
		        while(rs.next()){
		           //Retrieve by column name
		            pwd  = rs.getString("USER_PASSWORD");

		            //Display values
		           System.out.println("pwd : " + pwd );
		        }
				if (pwd.equals(""))	{
					return 002; // Invalid user name
				}else if (pwd.equals(req[1])){
					return 003; // Incorrect password
				}
		}catch (Exception e) {
			System.out.println("Exception in DBController - insertData ::: " + e.getMessage());
			e.printStackTrace();
		}finally{
	        rs.close();
	        stmt.close();
		}
		
		return 001; // exception from database
	}
	
	
	public int retrieveData(String req){
		try{
			if (req.equals("")){
		        // Execute SQL query
		        Statement stmt = dbCon.createStatement();
		        String sql;
		        sql = "SELECT id, mob FROM test";
		        ResultSet rs = stmt.executeQuery(sql);
		
		        // Extract data from result set
		        while(rs.next()){
		           //Retrieve by column name
		           int id  = rs.getInt("id");
		           int age = rs.getInt("mob");
		
		           //Display values
		           System.out.println("ID: " + id + "<br>");
		           System.out.println(", Age: " + age + "<br>");
		        }
			}
		}catch (Exception e) {
			System.out.println("Exception in DBController - insertData ::: " + e.getMessage());
			e.printStackTrace();
		}finally{
			// Clean-up environment
	       // rs.close();
	        //stmt.close();
		}
		
		return 1;
	}
		
		
}
	
	
	
