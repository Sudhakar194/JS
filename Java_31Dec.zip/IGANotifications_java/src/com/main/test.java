package com.main;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class test {

	public static void main(String[] args) throws Exception {
		String data = ""; 
	    //data = new String(Files.readAllBytes(Paths.get("D:/Sudhakar/WorkSpace - Java/ministryNotifications.txt"))); 
	   System.out.println(" data :: "  +data);
	   
	   BufferedReader  filereader = new BufferedReader(new InputStreamReader(new FileInputStream("D:/Sudhakar/WorkSpace - Java/ministryNotifications.txt"), "UTF8"));
	   String line ="";
	  
	   while ((line = filereader.readLine()) != null) {
		   data = data +  line; 
		   
	   }
	   
	   System.out.println(" data :: "  + new String(data.getBytes(),"UTF-8"));
	   
	}

}
