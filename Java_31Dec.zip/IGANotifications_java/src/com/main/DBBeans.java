package com.main;

public class DBBeans {
	
	private String serReq;
	private String uID;  
	private String uNameF;
	private String uNameL;
	private String uName;
	private String uMob;
	private String uEmail;
	private String uPwd;
	private String uDateCreate;
	private String uDateUpdate;
	private String UCountryCode;
	private String uMobCode;
	private String uUniqueID;
	
	
	public String getuUniqueID() {
		return uUniqueID;
	}
	public void setuUniqueID(String uUniqueID) {
		this.uUniqueID = uUniqueID;
	}
	public String getUCountryCode() {
		return UCountryCode;
	}
	public void setUCountryCode(String uCountryCode) {
		UCountryCode = uCountryCode;
	}
	public String getuMobCode() {
		return uMobCode;
	}
	public void setuMobCode(String uMobCode) {
		this.uMobCode = uMobCode;
	}

	//userReg, userPwdUpd
	public String getSerReq() {
		return serReq;
	}
	public void setSerReq(String serReq) {
		this.serReq = serReq;
	}
	public String getuID() {
		return uID;
	}
	public void setuID(String uID) {
		this.uID = uID;
	}
	public String getuNameF() {
		return uNameF;
	}
	public void setuNameF(String uNameF) {
		this.uNameF = uNameF;
	}
	public String getuNameL() {
		return uNameL;
	}
	public void setuNameL(String uNameL) {
		this.uNameL = uNameL;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuMob() {
		return uMob;
	}
	public void setuMob(String uMob) {
		this.uMob = uMob;
	}
	public String getuEmail() {
		return uEmail;
	}
	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}
	public String getuPwd() {
		return uPwd;
	}
	public void setuPwd(String uPwd) {
		this.uPwd = uPwd;
	}
	

}
