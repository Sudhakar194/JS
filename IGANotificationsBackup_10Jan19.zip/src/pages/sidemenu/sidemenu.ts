import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';

import { GlobalProvider } from './../../providers/global/global';

import { TabsPage } from '../../pages/tabs/tabs';
import { OptionsPage } from '../../pages/options/options';
import { HomePage } from '../../pages/home/home';

@Component({
  selector: 'page-sidemenu',
  templateUrl: 'sidemenu.html',
})

export class SidemenuPage {

	//	rootPage: any = TabsPage;

		constructor(public navCtrl: NavController, public navParams: NavParams,public g: GlobalProvider, public platform: Platform) {
		    // used for an example of ngFor and navigation
      
       g.rootPage = TabsPage;

		}
        
         callAction(action: string) {            
              if (action === 'home'){
                 this.g.rootPage = TabsPage;              
              }else if (action === 'logout' ){
                 this.g.rootPage = HomePage;
              }else { //  chanepassword,allownotifications,aboutapp,updatedetails
                  this.g.rootPage = OptionsPage;
                  this.g.gActionOnSidemenuPage = action ;
              }



         }


}
