import { Component } from '@angular/core';
import { App, NavController, NavParams } from 'ionic-angular';

import { CallserverProvider } from './../../providers/callserver/callserver';
import { GlobalProvider } from './../../providers/global/global';

import { TabsPage } from '../../pages/tabs/tabs';
import { SidemenuPage } from '../../pages/sidemenu/sidemenu';

import {FormControl, FormGroup, Validators} from '@angular/forms';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})


export class HomePage {

  //private userData = { "idnumber": "", "password": "","confirmpassword": "", "emailid":"","mobile":""};

  idnumber: string ;
  password: string ;
  confirmpassword: string ;
  emailid: string ;
  mobile: string ;
  gcccitizen: boolean;
  gcclist: string;

  // form groups for validations only 
    loginForm: FormGroup;
    regForm: FormGroup;
    forgotForm: FormGroup;

  // to enable form fields 
     loginFormHidden: boolean;
     newUserFormHidden: boolean;
     forgotDetailsFormHidden: boolean;
   
   //click to redirect to another form 
     loginButtonHidden: boolean;
     newUserButtonHidden: boolean;   
     forgotDetailsButtonHidden: boolean;
   
   // for otp
     otpHidden: boolean;
     disableServerMessageBoolean: boolean;

     gccListHide: boolean = true;
     
     loader: any ;


    public gccList: Array<{code:String, nameEN: String, nameAR:String}>;   
    public callingCountryCodes: Array<{code:String, nameEN: String, nameAR:String}>;   
    code: string [];
    nameEN: string [];
    nameAR: string [];

  constructor(public navCtrl: NavController, public navParams: NavParams,public callserver: CallserverProvider, public appObject: App, public g: GlobalProvider) {  

   console.log('HomePage#constructor') ;

        this.loginFormHidden = false;
        this.newUserFormHidden = true;
        this.forgotDetailsFormHidden = true;
        this.loginButtonHidden = true;
        this.newUserButtonHidden = false;
        this.forgotDetailsButtonHidden = false;
        this.gcccitizen = true;
        
        this.disableServerMessageBoolean = false;

        this.otpHidden = true;  

         this.getGCCList();  
         this.getCallingCountryCode();  

  }


getGCCList(){
     this.callserver.getLocaldata('assets/data/gcclist.json').subscribe(
        data => {      

                 this.gccList = [];
                   for (let i = 0;  i< data.responseObject.length; i++){                     
                       this.gccList.push({
                         code: data.responseObject[i].code,
                         nameEN:  data.responseObject[i].nameEN,
                         nameAR:  data.responseObject[i].nameAR
                       });

                    }

                 
                 }, err => {
                     console.log('getGCCList ERROR STATUS: ' +  err.status);
                     console.log('getGCCList ERROR: ' +  err);        
              });   

}


getCallingCountryCode(){
    this.callserver.getLocaldata('assets/data/callingCountryCode.json').subscribe(
        data => {      

                      this.callingCountryCodes = [];
                         for (let i = 0;  i< data.responseObject.length; i++){                     
                             this.callingCountryCodes.push({
                               code: data.responseObject[i].code,
                               nameEN:  data.responseObject[i].nameEN,
                               nameAR:  data.responseObject[i].nameAR
                             });

                        }
                 
                 }, err => {
                       console.log('getGCCList ERROR STATUS: ' +  err.status);
                       console.log('getGCCList ERROR: ' +  err);        
               });   
}




// load the form validation and lookups 
  ngOnInit() {
      let EMAILPATTERN = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
      
      //this.formBuilder.group
      this.loginForm = new FormGroup({
         idnumber: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]),
         password: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
       });

       this.regForm = new FormGroup({
         idnumber: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]),
         password: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
         confirmpassword: new FormControl('',[Validators.required, Validators.pattern('[a-zA-Z0-9!@#$%^&*()]*')]),
         emailid: new FormControl('',[Validators.required, Validators.pattern(EMAILPATTERN)]),
         mobile: new FormControl('',[Validators.required]),
       });


       this.forgotForm = new FormGroup({
         idnumber: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]),   
         emailid: new FormControl('',[Validators.required, Validators.pattern(EMAILPATTERN)]),
       });

  }//ngOnInit



 showForm (showForm){
        console.log('Home # showForm : ' + showForm);
      if (showForm == 'loginUser'){         
         this.loginFormHidden = false;
         this.newUserFormHidden = true;
         this.forgotDetailsFormHidden = true;
            this.loginButtonHidden = true;
            this.newUserButtonHidden = false;
            this.forgotDetailsButtonHidden = false;
      }else if (showForm == 'forgotDetails'){    
          this.loginFormHidden = true;
          this.newUserFormHidden = true;
          this.forgotDetailsFormHidden = false;
              this.loginButtonHidden = false;
              this.newUserButtonHidden = false;
              this.forgotDetailsButtonHidden = true;
      }else if (showForm == 'newUser'){    
          this.loginFormHidden = true;
          this.newUserFormHidden = false;
          this.forgotDetailsFormHidden = true;
              this.loginButtonHidden = false;
              this.newUserButtonHidden = true;
              this.forgotDetailsButtonHidden = false;
      }
  } //showForm



  loginUser(loginForm){
  	   console.log('HomePage logForm # 1 : ');
       //console.log('HomePage logForm # 1 : ' + loginForm.get('idnumber').value);
       // console.log('HomePage logForm # 1 : ' + loginForm.valid);
       // [class.error1]="!loginForm.controls.idnumber.valid && signupform.controls.idnumber.dirty"
       // console.log('HomePage logForm # 1 : ' + loginForm.controls.idnumber.valid);
   
      this.g.presentLoading("Pleas Wait...");

       this.g.loadMinistryListLocal();
       this.g.getNotificationsListLocal();
       this.g.getFavNotificationsListLocal();

       this.appObject.getRootNav().push(SidemenuPage);  
       this.g.dismissLoader();   


   /**
      this.callserver.callServer_Get ('/action/login').subscribe(
             data => {
                 console.log('HomePage#loginUser DATA STATUS: ' +  data.status);
                 console.log('HomePage#loginUser DATA STATUS: ' +  data.errorCode);      

                   if (data.errorCode == 200){   

                       this.g.loadMinistryList();
                       this.g.getNotificationsList();

                       this.appObject.getRootNav().push(SidemenuPage);  
                       this.g.dismissLoader();                    

                    }else if (data.errorCode == 1001){
                        this.disableServerMessageBoolean = true;
                        loginForm.controls.error = true;
                        loginForm.controls.error_stringEn = "Invalid ID Number and Password";
                        loginForm.controls.error_stringAr = "رقم الهوية غير صالح وكلمة المرور";
                     }

            }, err => {
                 console.log('HomePage#loginUser ERROR STATUS: ' +  err.status);
                 console.log('HomePage#loginUser ERROR: ' +  err);                            
                        // this.toast.presentToast("Check internet connection");                                                          
            });

            */

  } //close logForm
   

  newUser (regForm){
      console.log('HomePage# regForm : ');
      this.loginFormHidden = true;
      this.newUserFormHidden = true;
      this.forgotDetailsFormHidden = true;
      this.loginButtonHidden = true;
      this.newUserButtonHidden = true;
      this.forgotDetailsButtonHidden = true;
      this.otpHidden = false; 

      this.appObject.getRootNav().push(SidemenuPage);  

  }


  forgotDetails (forgotDetailsForm){
      console.log('HomePage logForm #  3 forgotDetailsForm : ');
  }



/** OTP validation & logic start *********************************************************************************** */

  next(otp){  
    //otp.setFocus();
  }

  submitRegistrationOTP(){
     console.log('HomePage logForm #  9 submitRegistrationOTP : ');
  } //submitRegistrationOTP
      

  closeOTP(){
      this.otpHidden = true;
      this.loginFormHidden = true;
      this.newUserFormHidden = false;
      this.forgotDetailsFormHidden = true;
      this.loginButtonHidden = false;
      this.newUserButtonHidden = true;
      this.forgotDetailsButtonHidden = false;  
  }//closeOTP

/** OTP validation & logic end *********************************************************************************** */



  // header
  changeLanguage(){
     this.g.gchangeLanguage();
     console.log('HomePage#localeChange this.g.gLocale : '+ this.g.gLocale);
  } //localeChange


 /** isValidNumber(event){  
     // console.log('HomePage logForm #  9 submitRegistrationOTP : '+ event.keyCode);
     // console.log('HomePage logForm #  9 submitRegistrationOTP : '+ event.key);
  } */


// KeyDown function to disable Server Message Item
  disableServerMessage(loginForm){
    console.log('HomePage logForm #  9 disableServerMessageBoolean : '+ this.disableServerMessageBoolean);
    if (this.disableServerMessageBoolean){
          this.disableServerMessageBoolean = false;
          loginForm.controls.error = false;
    }
  }


  GCCCitizen(gcccitizen){
        console.log('HomePage GCCCitizen # : '+ gcccitizen.checked);
        if(this.gccListHide){
              this.gccListHide = false;
        }else{
              this.gccListHide = true;
        }

  }
  


} //  Close Home

