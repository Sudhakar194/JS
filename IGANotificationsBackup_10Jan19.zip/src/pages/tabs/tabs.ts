import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';

import { FavNotificationPage } from '../fav-notification/fav-notification';
import { MinstrylistPage } from '../minstrylist/minstrylist';


import { GlobalProvider } from './../../providers/global/global';

import 'rxjs/add/operator/debounceTime';

import { OptionsPage } from '../../pages/options/options';



@Component({
	   selector: 'page-tabs',
     templateUrl: 'tabs.html'
})


export class TabsPage {
      searchTerm: string; 
      searchControl: FormControl;

      minstryPagTab = MinstrylistPage;
      mainFavPageTab = FavNotificationPage;

      findtab: string;
     
      constructor(public g: GlobalProvider) {
          this.searchControl = new FormControl();
      }


     // header - localeChange
      changeLanguage(){
         this.g.gchangeLanguage();
      }


      ionViewDidLoad() {     
           console.log( 'ionViewDidLoad');        
           this.searchControl.valueChanges.debounceTime(700).subscribe(search => {
              this.setFilteredItems();
          });       
      }

      

      setFilteredItems(){
           console.log( 'setFilteredItems ' + this.searchTerm);   
            this.g.filterItems(this.searchTerm);      
         /**  if (this.findtab === 'minstryPage')  {
              this.g.filterItems_ministrypage(this.searchTerm);
           }elseif(this.findtab === 'mainFavPage'){
              this.g.filterItems_mainFavPage(this.searchTerm);
           }*/   

       }


       OpenNotifications (){
           console.log( 'TabsPage#OpenNotifications');   
           this.g.rootPage = OptionsPage;
           this.g.gActionOnSidemenuPage = 'New notification page';
       }




/** 

     minstryPage(){
          console.log('minstryPage ');
          this.findtab = 'minstryPage';        
          this.searchTerm = '';
          

     }

     mainFavPage(){
         console.log( 'mainFavPage ');
         if ( this.searchTerm === ''){
         }else{
            this.setFilteredItems();              
         }

         this.findtab = 'mainFavPage';
         

         this.searchTerm = '';
        
     } */


     minstryPage(){
     }


     mainFavPage(){


     }

}
