import { Component } from '@angular/core'; //ViewChild
import { NavController, NavParams } from 'ionic-angular';
import { PopoverController } from 'ionic-angular';

import { PopupcardPage } from '../popupcard/popupcard';


import { CallserverProvider } from './../../providers/callserver/callserver';
import { GlobalProvider } from './../../providers/global/global';

@Component({
  selector: 'page-fav-notification',
  templateUrl: 'fav-notification.html',
})


export class FavNotificationPage {


  constructor(public navCtrl: NavController, public navParams: NavParams, public popoverCtrl: PopoverController, public callserver: CallserverProvider, public g: GlobalProvider) {
    

  }



 extractMessage(item){
          console.log('NotificationPage#extractMessage ' + item.hideMessage);
          if (item.hideMessage) {
              item.hideMessage = false;
          }else{
              item.hideMessage = true;
          }
  }
    


  favorite(item){


  }

  share(item){
  	
  	
  }


}
