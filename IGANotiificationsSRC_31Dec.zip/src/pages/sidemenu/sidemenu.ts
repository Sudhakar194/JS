import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';

import { GlobalProvider } from './../../providers/global/global';

import { TabsPage } from '../../pages/tabs/tabs';

@Component({
  selector: 'page-sidemenu',
  templateUrl: 'sidemenu.html',
})

export class SidemenuPage {

		 rootPage: any = TabsPage;


		constructor(public navCtrl: NavController, public navParams: NavParams,public g: GlobalProvider, public platform: Platform) {
		// used for an example of ngFor and navigation

		}


}
