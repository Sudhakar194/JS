import { Component } from '@angular/core';

import { FavNotificationPage } from '../fav-notification/fav-notification';
import { MinstrylistPage } from '../minstrylist/minstrylist';


import { GlobalProvider } from './../../providers/global/global';




@Component({
	 selector: 'page-tabs',
     templateUrl: 'tabs.html'
})


export class TabsPage {

  langChangeArHidden: boolean;
  langChangeEnHidden: boolean;


  minstryPagTab = MinstrylistPage;
  mainFavPageTab = FavNotificationPage;
 
 // tab3Root = ContactPage;

  constructor(public g: GlobalProvider) {

    this.langChangeEnHidden = true;
    this.langChangeArHidden = false;

  }


 // header
  changeLanguage(){
     this.g.gchangeLanguage();
  } //localeChange



}
