//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { LoadingController, Platform  } from 'ionic-angular';
import { CallserverProvider } from './../../providers/callserver/callserver';



@Injectable()
export class GlobalProvider {

	    public gLocale: boolean;
	    public gSearch: boolean;

	    loader: any ;

	    public ministryList: Array<{code:String, nameEN: String, nameAR:String}>;   
        code: string [];
		nameEN: string [];
		nameAR: string [];

		public notificationsList: Array<{code: string, date: string, headlineEN:string, headlineAR: string, messageEN: string, messageAR: string, hideMessage: boolean}>		
		date: string [];
		headlineEN: string [];
	    headlineAR: string [];
	    messageEN: string [];
	    messageAR: string [];
	    hideMessage: boolean[];

		 constructor(public loadingCtrl: LoadingController, public callserver: CallserverProvider, public platform: Platform) {
		    console.log('Hello GlobalProvider Provider');
		    
			    // english = true , arabic = false
			    // by default english 
			    this.gLocale = true;	
			    this.platform.setDir('ltr', true);

			    // hide search for ID cards
			    // not using remove *******			    
			    this.gSearch = false;

		  }



/** Loading controler  start *************************************************************************** */

		 presentLoading(loadingMsg: string) {
		      console.log('Home # presentLoading start: '  + loadingMsg);
		    
		      this.loader = this.loadingCtrl.create({
		           // spinner: 'hide',
		           // content: '<div class="custom-spinner-container"><div class="custom-spinner-box"></div></div>',      
		          content: loadingMsg,
		          //  duration: 3000
		      });
		      
		      this.loader.present();

		      this.loader.onDidDismiss(() => {
		         // console.log('Home # Dismissed loading');
		      });
		        

		       // need to handle later  
		      /** setTimeout(() => {
		          //this.nav.push(Page2);
		          console.log('Home # setTimeout close: ' );
		          this.loader.dismiss();        
		          // add boolean variable , to check varibale to load the response 
		      }, 5000); */
		     
		}

              
        dismissLoader(){
 			 this.loader.dismiss();    
        }

/** Loading controler end *************************************************************************** */



     loadMinistryList(){
	      console.log('GlobalProvider#loadMinistryList ');	      

	      this.callserver.callServerGet ('/action/ministryList').subscribe(
            data => {
                 console.log('GlobalProvider#loadMinistryList DATA STATUS: ' +  data.status);

                   console.log('CallserverProvider Entry # 5 : ' +  data.errorCode);       
				   console.log('CallserverProvider Entry # 5 : ' +  data.errorMsgEn);
				   console.log('CallserverProvider Entry # 5 : ' +  data.responseObject);
				   console.log('CallserverProvider Entry # 5 : ' +  data.responseObject.length);

                   this.ministryList = [];
				   for (let i = 0;  i< data.responseObject.length; i++){
				       console.log('CallserverProvider Entry # 5 : ' +  data.responseObject[i].nameEN);       
				       console.log('CallserverProvider Entry # 6 : ' +  data.responseObject[i].nameAR);
				       this.ministryList.push({
					       code: data.responseObject[i].code,
					       nameEN:  data.responseObject[i].nameEN,
					       nameAR:  data.responseObject[i].nameAR
				       });

				    }

				  
            }, err => {
                 console.log('GlobalProvider#loadMinistryList ERROR STATUS: ' +  err.status);
                 console.log('GlobalProvider#loadMinistryList ERROR: ' +  err);                                 
                    // this.toast.presentToast("Check internet connection");                                               
	        });
    }


/**  *************************************************************************** */

    getNotificationsList(){
          console.log('GlobalProvider#getNotificationsList ');        

          this.callserver.callServerGet ('/action/notifications').subscribe(
              data => {
	                   console.log('GlobalProvider#loadMinistryList DATA STATUS: ' +  data.status);

	                   console.log('CallserverProvider Entry # 7 : ' +  data.errorCode);       
	                   console.log('CallserverProvider Entry # 7 : ' +  data.errorMsgEn);
	                   console.log('CallserverProvider Entry # 7 : ' +  data.responseObject);
	                   console.log('CallserverProvider Entry # 7 : ' +  data.responseObject.length);
                       
                  	   this.notificationsList = [];

	                   for (let i = 0;  i< data.responseObject.length; i++){
	                       console.log('CallserverProvider Entry # 8 : ' +  data.responseObject[i].code);                              
	                      
	                       this.notificationsList.push({
	                          code: data.responseObject[i].code,
	                          date: data.responseObject[i].date,
	                          headlineEN: data.responseObject[i].headlineEN,
	                          headlineAR: data.responseObject[i].headlineAR,
	                          messageEN: data.responseObject[i].messageEN,
	                          messageAR: data.responseObject[i].messageAR,
	                          hideMessage: true
	                        });                      
	                    }

                  
                    }, err => {
                         console.log('GlobalProvider#loadMinistryList ERROR STATUS: ' +  err.status);
                         console.log('GlobalProvider#loadMinistryList ERROR: ' +  err);                                 
                            // this.toast.presentToast("Check internet connection");                                               
                  });

    }



/**  *************************************************************************** */

 // header
  gchangeLanguage(){
   	  console.log('HomePage#localeChange this.g.gLocale : '+ this.gLocale);
      if (this.gLocale) { // change english to arbic
        this.gLocale=false;
 		this.platform.setDir('rtl', true);
      } else{   // change arbic to english 
        this.gLocale=true;
        this.platform.setDir('ltr', true);
      }
    
  } //localeChange



}
