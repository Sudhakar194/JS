
 // loginValidate 
function loginValidate(reqtype,resObj) {    
    if (reqtype== "req"){
              console.log("loginValidate");
              var uname = $("input[type='text']").val();
              var pwd = $("input[type='password']").val();
              var validation = true;
              if (uname.length == 0){
                    $("input[type='text']").attr("placeholder", "*Enter User name / Mobile number ");
                    $("input[type='text']").addClass('inputplaceholder'); 
                    validation = false;
                 }
              
              if (pwd.length == 0){                  
                     $("input[type='password']").attr("placeholder", "*Enter Password ");
                     $("input[type='password']").addClass('inputplaceholder');  
                     validation = false;
                 } 
    
             if (validation){ 
                 var param = {uname:uname,pwd:pwd};
                 callserver("loginValidate","user/login/",param);
             }
             
    }
    
   if (reqtype== "res"){
        console.log("loginValidate resObj " + resObj.ecode);
        if(resObj.ecode == 0){ // redirect to confirmation page       
            window.location.href = "4home_bashboard.html";              
         }else{ // display  error message on same screen 
             
             
         }
    
    }
    
    
 }


// registration - validation 
function registration(reqtype,resObj) { 
    if (reqtype== "req"){
         console.log("registration");
         var uname = $("#unameid").val();
         var eid   = $("#emailid").val();
         var mob   = $("#mobid").val();
         var pwd   = $("#pwdid").val();
         var cpwd  = $("#cpwdid").val();
        
         var validation = true;
         if (uname.length == 0){
                $("#unameid").attr("placeholder", "*Enter User name");
                $("#unameid").addClass('inputplaceholder'); 
                validation = false;
          }if (eid.length == 0){                  
                 $("#emailid").attr("placeholder", "*Enter Email id");
                 $("#emailid").addClass('inputplaceholder');  
                 validation = false;
          }if (mob.length == 0){                  
                 $("#mobid").attr("placeholder", "*Enter Mobile number ");
                 $("#mobid").addClass('inputplaceholder');  
                 validation = false;
          } 
        
          if (pwd.length == 0){                  
                 $("#pwdid").attr("placeholder", "*Enter New password [allowed 0-9,a-Z] ");
                 $("#pwdid").addClass('inputplaceholder');  
                 validation = false;
          } 
        
          if (cpwd.length == 0){                  
                 $("#cpwdid").attr("placeholder", "*Enter Confirm password");
                 $("#cpwdid").addClass('inputplaceholder');                
                 validation = false;
          } else if (validation && cpwd != pwd ){
                 $("#pwdid").attr("placeholder", "*password mismatch, re-enter[allowed 0-9,a-Z] ");
                 $("#pwdid").addClass('inputplaceholder');  
              
                 $("#cpwdid").attr("placeholder", "*password mismatch, re-enter");
                 $("#cpwdid").addClass('inputplaceholder');                
                 validation = false;              
          }


          if (validation){ 
             var param = {uname:uname,eid:eid,mob:mob,pwd:pwd,cpwd:cpwd};
             callserver("registration","user/registration/",param);
          }
        
    }
    
    if (reqtype== "res"){  
         console.log("registration resObj " + resObj.ecode);
         if (resObj.ecode == 0){ // redirect to confirmation page       
            window.location.href = "3.2confirmregistration.html";              
         }else{ // display  error message on same screen 
             
             
         }
             
        
    }
 

}


 /* loginValidate */
function callserver(method,url,param) { 
   var result1;

   console.log("callserver");
   console.log("method  = " + method);
     console.log("url  = " + url);
   console.log("param  = " + param);
    
    $.ajax({                               
            url: "http://10.71.13.62:7080/"+ url,                         
            type: "post", 
            contentType: "application/json; charset=utf-8",
            datatype: "json", 
            timeout: 3000, // adjust the limit. currently its 3 seconds
            data: JSON.stringify(param),
            success: function(result,statusMsg,statusObj){
                console.log("success status " + statusObj.status);  
                result1 = result;
                if (method == "loginValidate") {
                    loginValidate("res",result1);                    
                }else if (method == "registration"){
                    registration("res",result1);            
                }
            }, error: function(result){   //net::ERR_CONNECTION_REFUSED
               console.log(" error " + result);  

            }   


        });

    
 }