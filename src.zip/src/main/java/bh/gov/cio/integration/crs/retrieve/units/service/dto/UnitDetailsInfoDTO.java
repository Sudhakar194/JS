package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author cspomlh
 * 
 */
@XmlType(name = "UnitDetails", propOrder = { "unitNumber", "unitArabicName", "unitEnglishName", "ownerArabicName",
		"ownerEnglishName", "unitMainActivity", "unitAddress", "noOfBranches", "branchesDetails" })
public class UnitDetailsInfoDTO {
	private Integer unitNumber;
	private String unitArabicName;
	private String unitEnglishName;
	private String ownerArabicName;
	private String ownerEnglishName;
	private UnitAddressInfoDTO unitAddress;
	private ArrayList<UnitMainActivityDTO> unitMainActivity;
	private Integer noOfBranches;
	private ArrayList<UnitBrancheDTO> branchesDetails;

	public UnitDetailsInfoDTO(Integer unitNumber, String unitArabicName, String unitEnglishName, String ownerArabicName,
			String ownerEnglishName, UnitAddressInfoDTO unitAddress,
			ArrayList<UnitMainActivityDTO> unitMainActivity, Integer noOfBranches,
			ArrayList<UnitBrancheDTO> branchesDetails) {
		super();
		this.unitNumber = unitNumber;
		this.unitArabicName = unitArabicName;
		this.unitEnglishName = unitEnglishName;
		this.ownerArabicName = ownerArabicName;
		this.ownerEnglishName = ownerEnglishName;
		this.unitAddress = unitAddress;
		this.unitMainActivity = unitMainActivity;
		this.noOfBranches = noOfBranches;
		this.branchesDetails = branchesDetails;
	}

	public UnitDetailsInfoDTO() {
		super();
	}

	@XmlElement(name = "unitNumber", required = true)
	public Integer getUnitNumber() {
		return unitNumber;
	}

	public void setUnitNumber(Integer unitNumber) {
		this.unitNumber = unitNumber;
	}

	@XmlElement(name = "unitArabicName", required = true)
	public String getUnitArabicName() {
		return unitArabicName;
	}

	public void setUnitArabicName(String unitArabicName) {
		this.unitArabicName = unitArabicName;
	}

	@XmlElement(name = "unitEnglishName", required = true)
	public String getUnitEnglishName() {
		return unitEnglishName;
	}

	public void setUnitEnglishName(String unitEnglishName) {
		this.unitEnglishName = unitEnglishName;
	}

	@XmlElement(name = "ownerArabicName", required = true)
	public String getOwnerArabicName() {
		return ownerArabicName;
	}

	public void setOwnerArabicName(String ownerArabicName) {
		this.ownerArabicName = ownerArabicName;
	}

	@XmlElement(name = "ownerEnglishName", required = true)
	public String getOwnerEnglishName() {
		return ownerEnglishName;
	}

	public void setOwnerEnglishName(String ownerEnglishName) {
		this.ownerEnglishName = ownerEnglishName;
	}

	@XmlElement(name = "unitAddress", required = true)
	public UnitAddressInfoDTO getUnitAddress() {
		return unitAddress;
	}

	public void setUnitAddress(UnitAddressInfoDTO unitAddress) {
		this.unitAddress = unitAddress;
	}

	@XmlElement(name = "unitMainActivity", required = true)
	public ArrayList<UnitMainActivityDTO> getUnitMainActivity() {
		return unitMainActivity;
	}

	public void setUnitMainActivity(ArrayList<UnitMainActivityDTO> unitMainActivity) {
		this.unitMainActivity = unitMainActivity;
	}

	@XmlElement(name = "noOfBranches", required = true)
	public Integer getNoOfBranches() {
		return noOfBranches;
	}

	public void setNoOfBranches(Integer noOfBranches) {
		this.noOfBranches = noOfBranches;
	}

	@XmlElement(name = "branchesDetails", required = true)
	public ArrayList<UnitBrancheDTO> getBranchesDetails() {
		return branchesDetails;
	}

	public void setBranchesDeatils(ArrayList<UnitBrancheDTO> branchesDetails) {
		this.branchesDetails = branchesDetails;
	}

}
