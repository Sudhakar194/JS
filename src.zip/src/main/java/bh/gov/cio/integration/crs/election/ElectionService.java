package bh.gov.cio.integration.crs.election;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.List;

import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.BiometricService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.common.admin.model.User;
import bh.gov.cio.integration.crs.election.dto.ElectionDTO;
import bh.gov.cio.integration.crs.election.dto.ErrorResponse;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

@Controller
public class ElectionService {

	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(ElectionService.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Autowired
	private ValidationServiceImpl validationService;

	@RequestMapping(value = "/rest/{cprNumber}/{blockNumber}/{cprExpiry}/electionEnquiry.service", method = RequestMethod.GET)
	@ResponseBody
	@Secured({ "ROLE_getElectionData" })
	public ElectionDTO getElectionData(@PathVariable("cprNumber") Integer cprNumber,
			@PathVariable("cprExpiry") String cprExpiry, @PathVariable("blockNumber") Integer blockNumber

	) throws Exception {
		PersonService ps = crsService.getPersonServiceRef();
		PersonBasicInfo pbi = ps.getPersonBasicInfo(cprNumber);
		PersonSummary psu = ps.getPersonSummary(cprNumber);

		Long longDate = Long.parseLong(cprExpiry);
		Date cardExpiryDate = new Date(longDate);

		if (!validationService.isValidCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Not Valid",
					new ApplicationException("CPR Number Not Valid", "006"));
		}
		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "003"));
		}
		if (!pbi.getIsActive().equalsIgnoreCase("T")) {
			throw new ApplicationExceptionInfo("CPR Number Not Active",
					new ApplicationException("CPR Number Not Active", "004"));
		}
		if (psu.isDead()) {
			throw new ApplicationExceptionInfo("Person is Dead", new ApplicationException("Person is Dead", "005"));
		}
		if (!validationService.hasValidBlock(cprNumber, blockNumber)) {
			throw new ApplicationExceptionInfo("Wrong Block Number",
					new ApplicationException("Wrong Block Number", "001"));
		}
		if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate)) {
			throw new ApplicationExceptionInfo("Wrong Expiry Date",
					new ApplicationException("Wrong Expiry Date", "002"));
		}
		ElectionDTO electionData = getElectionData(cprNumber);
		return electionData;
	}

	@RequestMapping(value = "/rest/{cprNumber}/electionEnquiryByCPR.service", method = RequestMethod.GET)
	@ResponseBody
	@Secured({ "ROLE_getElectionData" })
	public ElectionDTO getElectionData(@PathVariable("cprNumber") Integer cprNumber) throws Exception {
		PersonService ps = crsService.getPersonServiceRef();
		BiometricService bioService = crsService.getBiometricServiceRef();
		PersonBasicInfo pbi = ps.getPersonBasicInfo(cprNumber);
		ElectionDTO electionData = new ElectionDTO();
		PersonSummary psu = ps.getPersonSummary(cprNumber);
		if (!validationService.isValidCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Not Valid",
					new ApplicationException("CPR Number Not Valid", "006"));
		}
		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "003"));
		}
		if (!pbi.getIsActive().equalsIgnoreCase("T")) {
			throw new ApplicationExceptionInfo("CPR Number Not Active",
					new ApplicationException("CPR Number Not Active", "004"));
		}
		if (psu.isDead()) {
			throw new ApplicationExceptionInfo("Person is Dead", new ApplicationException("Person is Dead", "005"));
		}
		// retrieve card expiry date
		Long cardExpiryDate = validationService.getCPRNumberExpiry(cprNumber) != null
				? validationService.getCPRNumberExpiry(cprNumber).getTime() : null;
		logger.debug("Card Expiry Date : {}",DateServiceImpl.formatDateAsString(new Date(cardExpiryDate)));
		logger.debug("Card Expiry Date AS Long: {}",validationService.getCPRNumberExpiry(cprNumber).getTime());
				
		String arabicName = pbi.getArabicName();
		String englishName = pbi.getEnglishName();
		CommonTypes.Nationality nationalityType = validationService.isBahraini(pbi.getNationalityCode())
				? CommonTypes.Nationality.Bahraini : CommonTypes.Nationality.Other;

		byte[] photo = bioService.getPersonPhoto(cprNumber);
		CommonTypes.Gender gender = pbi.getGender().equalsIgnoreCase("m") ? CommonTypes.Gender.M : CommonTypes.Gender.F;
		Long birthDate = (pbi != null && pbi.getDateOfBirth() != null) ? pbi.getDateOfBirth().getTime() : null;
		logger.debug("Date Of Birth : {}",DateServiceImpl.formatDateAsString(new Date(birthDate)));
		logger.debug("Date Of Birth AS Long: {}",birthDate);
		Integer blockNumber = 0;

		// retrieve address information
		final List<Address> personAddress = getCrsService().getAddressServiceRef().getAddressDetails(cprNumber);
		for (final Address pAddress : personAddress) {
			// if (pAddress.getIsMain() == "T") {
			blockNumber = pAddress.getBlockNumber();
			// }
		}

		electionData = new ElectionDTO(cprNumber, cardExpiryDate, arabicName, englishName, nationalityType, photo,
				gender, birthDate, blockNumber);
		return electionData;
	}

	boolean verifyToken(String password, String hash) throws NoSuchAlgorithmException {

		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(password.getBytes());
		byte[] digest = md.digest();
		String myHash = DatatypeConverter.printHexBinary(digest).toUpperCase();
		logger.debug("digest:" + DatatypeConverter.printHexBinary(digest));
		return myHash.equals(hash);
	}

	@ExceptionHandler(ApplicationExceptionInfo.class)
	public ResponseEntity<ErrorResponse> handle(ApplicationExceptionInfo ex) {
		logger.debug("ResponseEntity<ErrorResponse> handle(ApplicationExceptionInfo ex) - start");
		logger.debug("Exception :" + ex.getFaultInfo().getCode());
		logger.debug("Exception :" + ex.getMessage());
		ErrorResponse errorResponse = new ErrorResponse(ex.getFaultInfo().getCode(), ex.getMessage());
		logger.debug("errorResponse :" + errorResponse);
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	public ValidationServiceImpl getValidationService() {
		return validationService;
	}
}
