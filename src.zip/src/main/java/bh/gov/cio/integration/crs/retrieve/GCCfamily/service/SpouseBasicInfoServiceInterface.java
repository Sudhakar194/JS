package bh.gov.cio.integration.crs.retrieve.GCCfamily.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.DivorcesBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.SpouseBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto.WidowBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GCCSpouseBasicInfoService", targetNamespace = "http://service.family.retrieve.crs.integration.cio.gov.bh/")
public interface SpouseBasicInfoServiceInterface
{
	@WebMethod(operationName = "getAllDivorcesBasicInfo")
	DivorcesBasicInfoDTO getAllDivorcesBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getAllDivorcesBasicInfoByCPR")
	DivorcesBasicInfoDTO getAllDivorcesBasicInfoByCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getAllSpouseBasicInfo")
	SpouseBasicInfoDTO getAllSpouseBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getAllWidowBasicInfo")
	WidowBasicInfoDTO getAllWidowBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getAllWidowBasicInfoByCPR")
	WidowBasicInfoDTO getAllWidowBasicInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getSpouseBasicInfo")
	SpouseBasicInfoDTO getSpouseBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebMethod(operationName = "getSpouseBasicInfoByCPR")
	SpouseBasicInfoDTO getSpouseBasicInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;
}
