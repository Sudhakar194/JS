package bh.gov.cio.integration.crs.retrieve.employment.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.employment.service.dto.EmploymentServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonEmploymentBasicInfoService", targetNamespace = "http://service.employment.retrieve.crs.integration.cio.gov.bh/")
public interface PersonEmploymentBasicInfoServiceInterface
{
	@WebResult(name = "EmploymentBasicInformatoin")
	@WebMethod(operationName = "getPersonEmploymentBasicInfo")
	EmploymentServiceBasicInfoDTO[] getPersonEmploymentBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber, @WebParam(
			name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "EmploymentBasicInformatoin")
	@WebMethod(operationName = "getPersonEmploymentBasicInfoByCPR")
	EmploymentServiceBasicInfoDTO[] getPersonEmploymentBasicInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber)
			throws ApplicationExceptionInfo;
}
