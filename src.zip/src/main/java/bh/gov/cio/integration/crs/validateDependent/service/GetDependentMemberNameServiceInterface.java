package bh.gov.cio.integration.crs.validateDependent.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.validateDependent.dto.GetDependentMemberNameDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GetDependentMemberNameService", targetNamespace = "http://service.egov.crs.integration.gov.bh/")
public interface GetDependentMemberNameServiceInterface {
	@WebResult(name = "GetDependentMemberNameDTO")
	@WebMethod(operationName = "ValidateDependentMemder")
	GetDependentMemberNameDTO ValidateDependentMemder(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "dependentIdNumber") @XmlElement(required = true) String dependentIdNumber)
			throws ApplicationExceptionInfo;
			
}

