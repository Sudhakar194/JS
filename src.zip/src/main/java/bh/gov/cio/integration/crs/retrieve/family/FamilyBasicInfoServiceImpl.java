package bh.gov.cio.integration.crs.retrieve.family;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.cr.CRDetails;
import bh.gov.cio.crs.model.person.Family;
import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.unit.UnitEntity;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.service.UnitService;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.family.service.FamilyBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.CheckCROwnerRelationDTO;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.ChildrenFamilyTreeDTO;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.FamilyTreeInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.SpouseFamilyTreeDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "FamilyBasicInfoService", targetNamespace = "http://service.family.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "FamilyBasicInfoService"
public class FamilyBasicInfoServiceImpl implements FamilyBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(FamilyBasicInfoServiceImpl.class);
	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Override
	@Secured(
	{ "ROLE_CheckCROwnerRelationDTO" })
	@WebMethod(operationName = "CheckCROwnerRelationDTO")
	public ArrayList<CheckCROwnerRelationDTO> checkCROwnerRelation(SecurityTagObject security, Integer cprNumber, Integer crNumber)
			throws ApplicationExceptionInfo
	{
		UnitService unitService = crsService.getUnitServiceRef();
		PersonService ps = crsService.getPersonServiceRef();
		CRDetails crDetails;
		ArrayList<Integer> spouses, childrens = null;
		ArrayList<CheckCROwnerRelationDTO> checkCROwnerRelationDTOList = new ArrayList<CheckCROwnerRelationDTO>();
		try
		{
			crDetails = unitService.getCrBasicInfo(crNumber);
			List<UnitEntity> owners = crDetails.getOwnersList();
			for (UnitEntity unitEntity2 : owners)
			{
				UnitEntity unitEntity = unitEntity2;
				if (unitEntity != null && unitEntity.getEntityType().equalsIgnoreCase("P"))
				{
					Integer ownerCPR = unitEntity.getEntityNumber();
					// Check Father
					PersonSummary pbi = ps.getPersonSummary(ownerCPR);
					spouses = getSpouses(ownerCPR);
					childrens = getChildrens(ownerCPR);

					if (logger.isDebugEnabled())
					{
						logger.debug("checkCROwnerRelation() -  : spouses = " + spouses + ", childrens = " + childrens);
					}

					if (pbi != null && pbi.getFatherCprNumber() != null && pbi.getFatherCprNumber().equals(ownerCPR))
					{
						CheckCROwnerRelationDTO checkCROwnerRelationDTO = new CheckCROwnerRelationDTO(false, false, true, false);
						checkCROwnerRelationDTOList.add(checkCROwnerRelationDTO);
					}

					// Check Mother
					else if (pbi != null && pbi.getMotherCprNumber() != null && pbi.getMotherCprNumber().equals(ownerCPR))
					{
						CheckCROwnerRelationDTO checkCROwnerRelationDTO = new CheckCROwnerRelationDTO(false, false, false, true);
						checkCROwnerRelationDTOList.add(checkCROwnerRelationDTO);
					}

					// check Spouse
					else if (spouses != null)
					{
						for (Integer integer : spouses)
						{
							Integer spouseCPR = integer;
							if (spouseCPR.equals(cprNumber))
							{
								CheckCROwnerRelationDTO checkCROwnerRelationDTO = new CheckCROwnerRelationDTO(false, true, false, false);
								checkCROwnerRelationDTOList.add(checkCROwnerRelationDTO);
							}
						}
					}

					// Check Childrens
					else if (childrens != null)
					{
						for (Integer integer : childrens)
						{
							Integer childCPR = integer;
							if (childCPR.equals(cprNumber))
							{
								CheckCROwnerRelationDTO checkCROwnerRelationDTO = new CheckCROwnerRelationDTO(true, false, false, false);
								checkCROwnerRelationDTOList.add(checkCROwnerRelationDTO);
							}
						}
					}
				}
			}

		}
		catch (bh.gov.cio.crs.util.exception.ApplicationException exception)
		{
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Problem Getting Results", new ApplicationException(exception.getMessage()));
		}
		catch (BusinessException exception)
		{
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Problem Getting Results", new ApplicationException(exception.getMessage()));
		}

		return checkCROwnerRelationDTOList;
	}

//	@Override
//	@Secured(
//	{ "ROLE_getAllFamilyBasicInfo" })
//	@WebMethod(operationName = "getAllFamilyBasicInfo")
//	public FamilyBasicInfoDTO getAllFamilyBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
//			throws ApplicationExceptionInfo
//	{
//		if (logger.isDebugEnabled())
//		{
//			logger.debug("getFamilyBasicInfo(Integer, Integer, Date) - start");
//		}
//
//		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
//		{
//			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
//		}
//		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
//		{
//			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
//		}
//		// if (validationUtil.isMilitaryCpr(cprNumber))
//		// {
//		// throw new ApplicationExceptionInfo("UNAUTHORIZED",
//		// new ApplicationException("UNAUTHORIZED"));
//		// }
//		if (validationUtil.isDeletedCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//		}
//		FamilyBasicInfoDTO familyServiceMarriageBasicInfoDTO = null;
//		try
//		{
//			FamilyService fs = getCrsService().getFamilyServiceRef();
//			final Family maritalStatus = fs.getPersonMaritalStatus(cprNumber);
//			final IndMarriageDivorce indMarriageDivorce = fs.getPersonLastActionDetails(cprNumber);
//			final String marriageDivorceIndicator = indMarriageDivorce.getActionType();
//			final String marriageDivorceDate = DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
//			final Integer partenerCprNumber = indMarriageDivorce.getPartnerCprNumber();
//			final String partenerFullName = indMarriageDivorce.getPartnerFullName();
//			final String maritalStatusCode = maritalStatus.getMaritalStatusCode();
//			String partenerCprNumberStr = "";
//			if (partenerCprNumber != null)
//			{
//				partenerCprNumberStr = partenerCprNumber + "";
//			}
//			familyServiceMarriageBasicInfoDTO = new FamilyBasicInfoDTO(maritalStatusCode, partenerCprNumberStr, marriageDivorceIndicator,
//					marriageDivorceDate, partenerFullName);
//
//			if (logger.isDebugEnabled())
//			{
//				logger.debug("getFamilyBasicInfo(Integer, Integer, Date) - end");
//			}
//		}
//		catch (final Exception exception)
//		{
//			if (logger.isDebugEnabled())
//			{
//				logger.error("getFamilyBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Family Basic Details Not found", new ApplicationException(exception.getMessage()));
//		}
//		return familyServiceMarriageBasicInfoDTO;
//	}
//
	ArrayList<Integer> getChildrens(Integer cprNumber)
	{
		ArrayList<Integer> childrens = new ArrayList<Integer>();
		try
		{
			final FamilyService familyService = getCrsService().getFamilyServiceRef();
			final HashMap<Integer, List<PersonSummary>> hm = familyService.getPersonChildrenBySpouse(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonDetails() -  No Of Wives = " + hm);
			}
			final Collection<List<PersonSummary>> wivesList = hm.values();
			int currentChild = 0;
			for (final List<PersonSummary> list : wivesList)
			{
				final List<PersonSummary> childrenList = list;
				for (final PersonSummary personSummary : childrenList)
				{
					childrens.add(personSummary.getCprNumber());
					currentChild++;

				}
			}
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
		}
		return childrens;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

//	@Override
//	@Secured(
//	{ "ROLE_getFamilyBasicInfo" })
//	@WebMethod(operationName = "getFamilyBasicInfo")
//	public FamilyBasicInfoDTO getFamilyBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
//			throws ApplicationExceptionInfo
//	{
//		if (logger.isDebugEnabled())
//		{
//			logger.debug("getFamilyBasicInfo(Integer, Integer, Date) - start");
//		}
//
//		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
//		{
//			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
//		}
//		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
//		{
//			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
//		}
//		if (validationUtil.isMilitaryCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
//		}
//		if (validationUtil.isDeletedCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//		}
//		FamilyBasicInfoDTO familyServiceMarriageBasicInfoDTO = null;
//		try
//		{
//			final Family maritalStatus = getCrsService().getFamilyServiceRef().getPersonMaritalStatus(cprNumber);
//			final IndMarriageDivorce indMarriageDivorce = getCrsService().getFamilyServiceRef().getPersonLastActionDetails(cprNumber);
//			final String marriageDivorceIndicator = indMarriageDivorce.getActionType();
//			final String marriageDivorceDate = DateServiceImpl.formatDate(indMarriageDivorce.getMarriageDivorceDate());
//			final Integer partenerCprNumber = indMarriageDivorce.getPartnerCprNumber();
//			final String partenerFullName = indMarriageDivorce.getPartnerFullName();
//			final String maritalStatusCode = maritalStatus.getMaritalStatusCode();
//			String partenerCprNumberStr = "";
//			if (partenerCprNumber != null)
//			{
//				partenerCprNumberStr = partenerCprNumber + "";
//			}
//			familyServiceMarriageBasicInfoDTO = new FamilyBasicInfoDTO(maritalStatusCode, partenerCprNumberStr, marriageDivorceIndicator,
//					marriageDivorceDate, partenerFullName);
//
//			if (logger.isDebugEnabled())
//			{
//				logger.debug("getFamilyBasicInfo(Integer, Integer, Date) - end");
//			}
//		}
//		catch (final Exception exception)
//		{
//			if (logger.isDebugEnabled())
//			{
//				logger.error("getFamilyBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Family Basic Details Not found", new ApplicationException(exception.getMessage()));
//		}
//		return familyServiceMarriageBasicInfoDTO;
//	}

	/**
	 * This method used to return family member tree
	 * 
	 * @return FamilyTreeInfoDTO
	 * @author csdvsbu
	 * */
	@Override
	@Secured(
	{ "ROLE_getFamilyTreeInfo" })
	@WebMethod(operationName = "getFamilyTreeInfo")
	public FamilyTreeInfoDTO getFamilyTreeInfo(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{

		FamilyTreeInfoDTO familyTreeInfoDTO = new FamilyTreeInfoDTO();
		try
		{
			PersonBasicInfo personBasicInfo = new PersonBasicInfo();
			PersonBasicInfo fatherBasicInfo = new PersonBasicInfo();
			PersonBasicInfo motherBasicInfo = new PersonBasicInfo();
			PersonBasicInfo fatherFatherBasicInfo = new PersonBasicInfo();
			PersonBasicInfo fatherMotherBasicInfo = new PersonBasicInfo();
			PersonBasicInfo motherFatherBasicInfo = new PersonBasicInfo();
			PersonBasicInfo motherMotherBasicInfo = new PersonBasicInfo();

			FamilyService familyRef = null;

			/*
			 * ****************** PERSON DETAILS ********************
			 */

			// try
			// {
			personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);

			if (personBasicInfo != null)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("getFamilyTreeInfo(Integer) CPR Number:" + personBasicInfo.getCprString() + " Name:"
							+ personBasicInfo.getEnglishName());
				}

				familyTreeInfoDTO.setPersonCPR(personBasicInfo.getCprString());
				familyTreeInfoDTO.setPersonArabicName(personBasicInfo.getArabicName());
				familyTreeInfoDTO.setPersonEnglishName(personBasicInfo.getEnglishName());
			}

			/*
			 * ****************** MOTHER AND FATHER DETAILS ********************
			 */
			familyRef = getCrsService().getFamilyServiceRef();

			if (familyRef != null)
			{
				Family motherFather = familyRef.getFamilyDetails(cprNumber);
				if (motherFather != null)
				{
					if (logger.isDebugEnabled())
					{
						logger.debug("getFamilyTreeInfo(Integer) he/she has family recored" + " Mother CPR:" + motherFather.getMotherCprNumber()
								+ " --Father CPR:" + motherFather.getFatherCprNumber());
					}

					fatherBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(motherFather.getFatherCprNumber());
					motherBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(motherFather.getMotherCprNumber());

					/*
					 * ****************** FATHER DETAILS ********************
					 */

					if (fatherBasicInfo != null)
					{
						// / father details
						familyTreeInfoDTO.setFatherCPR(fatherBasicInfo.getCprString());
						familyTreeInfoDTO.setFatherArabicName(fatherBasicInfo.getArabicName());
						familyTreeInfoDTO.setFatherEnglishName(fatherBasicInfo.getEnglishName());

						/*
						 * ****************** FATHER DETAILS********************
						 * *********** HIS MOTHER AND FATHE DETAILS********
						 */
						try
						{

							final Family motherFatherOfFather = getCrsService().getFamilyServiceRef().getPersonFatherMother(
									fatherBasicInfo.getCprNumber());
							if (motherFatherOfFather != null)
							{
								fatherFatherBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(
										motherFatherOfFather.getFatherCprNumber());
								motherFatherBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(
										motherFatherOfFather.getMotherCprNumber());

								if (fatherFatherBasicInfo != null)
								{
									familyTreeInfoDTO.setFatherFatherCPR(fatherFatherBasicInfo.getCprString());
									familyTreeInfoDTO.setFatherFatherArabicName(fatherFatherBasicInfo.getArabicName());
									familyTreeInfoDTO.setFatherFatherEnglishName(fatherFatherBasicInfo.getEnglishName());

								}

								if (motherFatherBasicInfo != null)
								{
									familyTreeInfoDTO.setMotherFatherCPR(motherFatherBasicInfo.getCprString());
									familyTreeInfoDTO.setMotherFatherArabicName(motherFatherBasicInfo.getArabicName());
									familyTreeInfoDTO.setMotherFatherEnglishName(motherFatherBasicInfo.getEnglishName());
								}

							}// END FATHER (MOTHER AND FATHER)
						}
						catch (Exception e)
						{
							if (logger.isDebugEnabled())
							{
								logger.error("getFamilyTreeInfo(Integer) No details for grand father or mother Error: " + e.getMessage());
							}
						}

					}// END FATHER DETAILS

					/*
					 * ****************** MOTHER DETAILS********************
					 */

					if (motherBasicInfo != null)
					{
						familyTreeInfoDTO.setMotherCPR(motherBasicInfo.getCprString());
						familyTreeInfoDTO.setMotherArabicName(motherBasicInfo.getArabicName());
						familyTreeInfoDTO.setMotherEnglishName(motherBasicInfo.getEnglishName());

						/*
						 * ****************** MOTHER DETAILS********************
						 * *********** HER MOTHER AND FATHE DETAILS********
						 */
						try
						{

							final Family motherFatherOfMother = getCrsService().getFamilyServiceRef().getPersonFatherMother(
									motherBasicInfo.getCprNumber());
							if (motherFatherOfMother != null)
							{
								fatherMotherBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(
										motherFatherOfMother.getFatherCprNumber());
								motherMotherBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(
										motherFatherOfMother.getMotherCprNumber());

								if (fatherMotherBasicInfo != null)
								{
									familyTreeInfoDTO.setFatherMotherCPR(fatherMotherBasicInfo.getCprString());
									familyTreeInfoDTO.setFatherMotherArabicName(fatherMotherBasicInfo.getArabicName());
									familyTreeInfoDTO.setFatherMotherEnglishName(fatherMotherBasicInfo.getEnglishName());

								}

								if (motherMotherBasicInfo != null)
								{
									familyTreeInfoDTO.setMotherMotherCPR(motherMotherBasicInfo.getCprString());
									familyTreeInfoDTO.setMotherMotherArabicName(motherMotherBasicInfo.getArabicName());
									familyTreeInfoDTO.setMotherMotherEnglishName(motherMotherBasicInfo.getEnglishName());
								}

							}// END MOTHER: FATHER AND MOTHER
						}
						catch (Exception e)
						{
							if (logger.isDebugEnabled())
							{
								logger.error("getFamilyTreeInfo(Integer) No details for grand father or mother Error: " + e.getMessage());
							}
						}

					}// END MOTHER DETAILS

				}
			}

			else
			// Family recored not Exists
			{
				throw new ApplicationExceptionInfo("Father and Mother details not found", new ApplicationException(" No father or mother details"));
			}

			/*
			 * ****************** PERSON SPOUSES DETAILS********************
			 */

			final List<Marriage> hm = getCrsService().getFamilyServiceRef().getPersonMarriageDivorceList(cprNumber);

			if (logger.isDebugEnabled())
			{
				logger.debug("getFamilyTreeInfo() - familyService.getPersonMarriageDivorceList(cprNumber) = " + hm);
			}
			final ArrayList<SpouseFamilyTreeDTO> spouseDetailDTOList = new ArrayList<SpouseFamilyTreeDTO>();

			int count = 0;
			if (hm != null)
			{
				for (final Marriage marriage : hm)
				{
					final Marriage spouse = marriage;

					PersonBasicInfo spousePersonBasicInfo = new PersonBasicInfo();

					if (spouse.getPartnerCprNumber() != null)
					{
						spousePersonBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(spouse.getPartnerCprNumber());

					}
					if (logger.isDebugEnabled())
					{
						logger.debug("getFamilyTreeInfo()" + spouse.getPartnerCprNumber() + " -  spouse = " + spouse.getLastActionWithPartner());
					}
					logger.debug("spousePersonBasicInfo:" + spousePersonBasicInfo);
					if (spouse != null && spouse.getLastActionWithPartner().equals("MARRIAGE"))
					{
						spouseDetailDTOList.add(new SpouseFamilyTreeDTO(spousePersonBasicInfo.getCprNumber(), spousePersonBasicInfo.getArabicName(),
								spousePersonBasicInfo.getEnglishName()));

					}
					count++;
				}
			}
			familyTreeInfoDTO.setSpouseDetails(spouseDetailDTOList);

			/*
			 * ****************** PERSON CHILDREN DETAILS********************
			 */

			final HashMap<Integer, List<PersonSummary>> wifeList = getCrsService().getFamilyServiceRef().getPersonChildrenBySpouse(cprNumber);
			if (logger.isDebugEnabled())
			{
				logger.debug("getFamilyTreeInfo() -  No Of Wives = " + wifeList);
			}
			final Collection<List<PersonSummary>> wivesList = wifeList.values();
			final ArrayList<ChildrenFamilyTreeDTO> childrenDetailDTOList = new ArrayList<ChildrenFamilyTreeDTO>();

			int currentChild = 0;
			if (wifeList != null)
			{

				for (final List<PersonSummary> list : wivesList)
				{
					final List<PersonSummary> childrenList = list;
					for (final PersonSummary personSummary : childrenList)
					{
						final PersonSummary childrenSummary = personSummary;

						final PersonBasicInfo childrenPersonBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(
								childrenSummary.getCprNumber());

						childrenDetailDTOList.add(new ChildrenFamilyTreeDTO(childrenPersonBasicInfo.getCprNumber(), childrenPersonBasicInfo
								.getArabicName(), childrenPersonBasicInfo.getEnglishName()));

						currentChild++;

					}
				}
			}
			familyTreeInfoDTO.setChildrenDetails(childrenDetailDTOList);
		}

		catch (Exception e)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getFamilyTreeInfo(Integer) Error: " + e.getMessage());
			}
			e.printStackTrace();
			throw new ApplicationExceptionInfo("Family Basic Details Not found", new ApplicationException(e.getMessage()));
		}

		return familyTreeInfoDTO;
	}

	ArrayList<Integer> getSpouses(Integer cprNumber)
	{
		ArrayList<Integer> spouses = new ArrayList<Integer>();
		final FamilyService familyService = getCrsService().getFamilyServiceRef();
		Integer spouseRecord = null;
		List<Marriage> hm = null;
		try
		{
			spouseRecord = familyService.getPersonPrimarySpouse(cprNumber);
			hm = familyService.getPersonMarriageDivorceList(cprNumber);
		}
		catch (bh.gov.cio.crs.util.exception.ApplicationException exception)
		{
			// TODO Auto-generated catch block
			exception.printStackTrace();
		}
		catch (BusinessException exception)
		{
			// TODO Auto-generated catch block
			exception.printStackTrace();
		}
		if (logger.isDebugEnabled())
		{
			logger.debug("getSpouses() - familyService.getPersonPrimarySpouse(cprNumber) = " + spouseRecord);
		}
		if (logger.isDebugEnabled())
		{
			logger.debug("getSpouses() - familyService.getPersonMarriageDivorceList(cprNumber) = " + hm);
		}
		boolean isSpouseFoundInMarriageDivorceList = false;
		if (spouseRecord == null)
		{
			isSpouseFoundInMarriageDivorceList = true;
		}
		int count = 0;
		if (hm != null)
		{
			for (final Marriage marriage : hm)
			{
				final Marriage spouse = marriage;
				if (spouse != null && spouse.getPartnerCprNumber() != null && spouse.getPartnerCprNumber().equals(spouseRecord))
				{
					isSpouseFoundInMarriageDivorceList = true;
				}
				if (spouse != null && spouse.getPartnerCprNumber() != null && !spouse.getLastActionWithPartner().equals("DIVORCE"))
				{
					spouses.add(spouse.getPartnerCprNumber());
				}
				count++;
			}
		}
		if (!isSpouseFoundInMarriageDivorceList)
		{
			spouses.add(spouseRecord);
		}
		return spouses;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
