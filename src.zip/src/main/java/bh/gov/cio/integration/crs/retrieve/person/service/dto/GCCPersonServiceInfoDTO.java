package bh.gov.cio.integration.crs.retrieve.person.service.dto;

public class GCCPersonServiceInfoDTO
{
	private int		age;
	private String	arabicName;
	private Integer	cprNumber;
	private String	birthDate;
	private String	englishName;
	private String	gender;
	private String	nationalityCode;
	private String	personDisplayName;
	private String	religionCode;

	public GCCPersonServiceInfoDTO()
	{
		super();
	}

	public GCCPersonServiceInfoDTO(int age, String arabicName,
			Integer cprNumber, String birthDate, String englishName,
			String gender, String nationalityCode, String personDisplayName,
			String religionCode)
	{
		super();
		setAge(age);
		setArabicName(arabicName);
		setBirthDate(birthDate);
		setCprNumber(cprNumber);
		setEnglishName(englishName);
		setGender(gender);
		setNationalityCode(nationalityCode);
		setPersonDisplayName(personDisplayName);
		setReligionCode(religionCode);
	}

	public int getAge()
	{
		return age;
	}

	public String getArabicName()
	{
		return arabicName;
	}

	public java.lang.String getBirthDate()
	{
		return birthDate;
	}

	public Integer getCprNumber()
	{
		return cprNumber;
	}

	public String getEnglishName()
	{
		return englishName;
	}

	public String getGender()
	{
		return gender;
	}

	public String getNationalityCode()
	{
		return nationalityCode;
	}

	public String getPersonDisplayName()
	{
		return personDisplayName;
	}

	public String getReligionCode()
	{
		return religionCode;
	}

	public void setAge(int age)
	{
		this.age = age;
	}

	public void setArabicName(String arabicName)
	{
		this.arabicName = arabicName;
	}

	public void setBirthDate(java.lang.String birthDate)
	{
		this.birthDate = birthDate;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setEnglishName(String englishName)
	{
		this.englishName = englishName;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public void setNationalityCode(String nationalityCode)
	{
		this.nationalityCode = nationalityCode;
	}

	public void setPersonDisplayName(String personDisplayName)
	{
		this.personDisplayName = personDisplayName;
	}

	public void setReligionCode(String religionCode)
	{
		this.religionCode = religionCode;
	}

}
