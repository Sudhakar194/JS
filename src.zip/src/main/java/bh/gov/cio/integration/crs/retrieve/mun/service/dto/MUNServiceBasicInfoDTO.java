package bh.gov.cio.integration.crs.retrieve.mun.service.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;

@XmlType(name = "MUNBasicInformatoin", propOrder = {

		"idNumber", "arabicName", "englishName", "nationalityArabicName", "nationalityEnglishName", "inOutStatus",
		"block", "roadNumber", "roadArabicName", "roadEnglishName", "buildingNumber", "flat" })
public class MUNServiceBasicInfoDTO implements Serializable, CommonTypes {


	/**
	 * 
	 */
	private static final long serialVersionUID = 291347554637634310L;

	public MUNServiceBasicInfoDTO(String idNumber, String arabicName, String englishName,
			String nationalityArabicName, String nationalityEnglishName, String inOutStatus, String block,
			String roadNumber, String roadArabicName, String roadEnglishName, String buildingNumber, String flat) {
		super();
		this.idNumber = idNumber;
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.nationalityArabicName = nationalityArabicName;
		this.nationalityEnglishName = nationalityEnglishName;
		this.inOutStatus = inOutStatus;
		this.block = block;
		this.roadNumber = roadNumber;
		this.roadArabicName = roadArabicName;
		this.roadEnglishName = roadEnglishName;
		this.buildingNumber = buildingNumber;
		this.flat = flat;
	}

	private String idNumber,arabicName, englishName, nationalityArabicName, nationalityEnglishName, inOutStatus, block,
			roadNumber, roadArabicName, roadEnglishName, buildingNumber, flat;

	public MUNServiceBasicInfoDTO() {
		super();
	}

	public String getidNumber() {
		return idNumber;
	}

	public void setidNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public String getNationalityArabicName() {
		return nationalityArabicName;
	}

	public void setNationalityArabicName(String nationalityArabicName) {
		this.nationalityArabicName = nationalityArabicName;
	}

	public String getNationalityEnglishName() {
		return nationalityEnglishName;
	}

	public void setNationalityEnglishName(String nationalityEnglishName) {
		this.nationalityEnglishName = nationalityEnglishName;
	}

	public String getInOutStatus() {
		return inOutStatus;
	}

	public void setInOutStatus(String inOutStatus) {
		this.inOutStatus = inOutStatus;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public String getRoadArabicName() {
		return roadArabicName;
	}

	public void setRoadArabicName(String roadArabicName) {
		this.roadArabicName = roadArabicName;
	}

	public String getRoadEnglishName() {
		return roadEnglishName;
	}

	public void setRoadEnglishName(String roadEnglishName) {
		this.roadEnglishName = roadEnglishName;
	}

	public String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getFlat() {
		return flat;
	}

	public void setFlat(String flat) {
		this.flat = flat;
	}

}
