package bh.gov.cio.integration.crs.retrieve.nhi;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.nhi.service.NHIBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.nhi.service.dto.NHIBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NHIBasicInfoService", targetNamespace = "http://service.nhi.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "NHIBasicInfoService"
public class NHIBasicInfoServiceImpl implements NHIBasicInfoServiceInterface, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(NHIBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationService;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getNHIBasicInfo" })
	@WebMethod(operationName = "getNHIBasicInfo")
	public NHIBasicInfoDTO getNHIBasicInfo(SecurityTagObject security, String idNumber, String nationalityCode)
			throws ApplicationExceptionInfo {
		NHIBasicInfoDTO nhiBasicInfo = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getMOHDemographicInfo(Integer, Integer, Date) - start");
		}

		if (nationalityCode == null || "".equals(nationalityCode.trim())) {
			nationalityCode = "499";
		}

		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, nationalityCode);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid","001"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted","002"));
		}
		boolean isExpired = false;
		try {
			Date cardExpiry = validationService.getCPRNumberExpiry(cprNumber);
			isExpired = cardExpiry.before(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		PersonService ps = crsService.getPersonServiceRef();
		PersonBasicInfo pbi = null;
		PersonSummary psu = null;
		boolean isDead = false;
		try {
			pbi = ps.getPersonBasicInfo(cprNumber);
			psu = ps.getPersonSummary(cprNumber);
			isDead = psu.isDead();
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getNHIBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("getNHIBasicInfo  Not found",
					new ApplicationException(exception.getMessage()));
		}
		if (!pbi.getIsActive().equalsIgnoreCase("T")) {
			throw new ApplicationExceptionInfo("CPR Number Not Active",
					new ApplicationException("CPR Number Not Active", "003"));
		}
		String natCode = psu.getNationalityCountryCode().trim();
		CommonTypes.Nationality nationalityType = validationService.getNationalityCategory(natCode);

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		nhiBasicInfo = new NHIBasicInfoDTO(idNumber, pbi.getArabicName(), pbi.getEnglishName(),
				nationalityType, !isDead, psu.getGender(), sdf.format(psu.getDateOfBirth()), !isExpired);

		if (logger.isDebugEnabled()) {
			logger.debug("getNHIBasicInfo(Integer, Integer, Date) - end");
		}
		return nhiBasicInfo;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationService;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationService) {
		this.validationService = validationService;
	}
}
