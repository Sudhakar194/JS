package bh.gov.cio.integration.crs.retrieve.person;

import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.CRSEntity;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.SWDPersonSummeryServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.SWDPersonServiceSummaryDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "SWDPersonSummeryService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "SWDPersonSummeryService"
public class SWDPersonSummeryServiceImpl implements SWDPersonSummeryServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(SWDPersonSummeryServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getSWDPersonSummeryDetails" })
	@WebMethod(operationName = "getSWDPersonSummeryDetails")
	public SWDPersonServiceSummaryDTO getSWDPersonSummeryDetails(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("getSWDPersonSummeryDetails(Integer, Integer, Date) - start");
		}
		if (validationUtil.isMilitaryCpr(cprNumber))
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));

		SWDPersonServiceSummaryDTO swdPersonServiceSummaryDTO = new SWDPersonServiceSummaryDTO();
		try {
			PersonService ps = crsService.getPersonServiceRef();
			PersonBasicInfo pbi = ps.getPersonBasicInfo(cprNumber);
			PersonSummary personSummary = ps.getPersonSummary(cprNumber);
			List<CRSEntity> ownedCRs =ps.getPersonOwnedCRs(cprNumber);
			boolean hasCR = (ownedCRs != null &&  ownedCRs.size () > 0 ) ? true : false;

			String arabicName;
			Date deathDate;
			String englishName;
			String ioStatus;
			String labourForceParticipation;
			String maritalStatus;
			Integer numberOfCRs;
			
			arabicName = pbi.getArabicName();
			deathDate = personSummary.getDateOfDeath();
			englishName = pbi.getEnglishName();
			ioStatus = personSummary.getIoStatusCode();
			labourForceParticipation = personSummary.getLabourParticipationTypeCode();
			maritalStatus = personSummary.getMaritalStatusCode();
			numberOfCRs = ownedCRs != null ? ownedCRs.size() : 0;

			swdPersonServiceSummaryDTO.setArabicName(arabicName);
			swdPersonServiceSummaryDTO.setDeathDate(deathDate);
			swdPersonServiceSummaryDTO.setEnglishName(englishName);
			swdPersonServiceSummaryDTO.setHasCR(hasCR);
			swdPersonServiceSummaryDTO.setIoStatus(ioStatus);
			swdPersonServiceSummaryDTO.setLabourForceParticipation(labourForceParticipation);
			swdPersonServiceSummaryDTO.setMaritalStatus(maritalStatus);
			swdPersonServiceSummaryDTO.setNumberOfCRs(numberOfCRs);
			
		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getPersonSummery(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Summary Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return swdPersonServiceSummaryDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

}
