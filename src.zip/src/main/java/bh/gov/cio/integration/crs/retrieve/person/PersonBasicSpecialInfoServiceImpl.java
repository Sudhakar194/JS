package bh.gov.cio.integration.crs.retrieve.person;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonBasicSpecialInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonBasicSpecialInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")

public class PersonBasicSpecialInfoServiceImpl implements PersonBasicSpecialInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonBasicSpecialInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonBasicSpecialInfo" })
	@WebMethod(operationName = "getPersonBasicSpecialInfo")
	public PersonServiceBasicInfoDTO getPersonBasicSpecialInfo(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		PersonServiceBasicInfoDTO personBasicInfoDTO = null;
		try
		{
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499") || personSummeryInfo.getNationalityCountryCode()
					.equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			personBasicInfoDTO = new PersonServiceBasicInfoDTO(personBasicInfo.getAge() + "", personBasicInfo.getArabicName(),
					personBasicInfo.getCprNumber() + "", DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()),
					DateServiceImpl.formatDate(personSummeryInfo.getDateOfDeath()), personBasicInfo.getEnglishName(), personBasicInfo.getGender(),
					nationality, personBasicInfo.getPersonDisplayName(), personBasicInfo.getReligionCode(), personSummeryInfo.getMaritalStatusCode());
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonBasicSpecialInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Special Details Not found", new ApplicationException(exception.getMessage()));

		}
		return personBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
