package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonServiceSummary", propOrder =
{ "cprNumber", "dateOfBirth", "dateOfBirthOld", "nationality",
		"birthCountryCode", "dateOfDeath", "deathCountryCode",
		"arabicFullName", "arabicFirstName", "arabicMiddleName1",
		"arabicMiddleName2", "arabicMiddleName3", "arabicMiddleName4",
		"arabicFamilyName", "englishFullName", "englishFirstName",
		"englishMiddleName1", "englishMiddleName2", "englishMiddleName3",
		"englishMiddleName4", "englishFamilyName", "gender",
		"sponsorIndicator", "employerIndicator", "isStudent",
		"isClearingAgent", "isWatchlisted",/* "isLostCard", "isDeleted", */
		"isPrisoner", "isSmartcard",/* "isNationalityConfirmed", */
		"contactPhone", "birthPlaceArabic", "birthPlaceEnglish",
		"fatherCprNumber", "motherCprNumber", "spouseCpr", "religionCode",
		"labourParticipationTypeCode", "labourParticipationTypeArabicName",
		"labourParticipationTypeEnglishName", "highestLevelAchievedCode",
		"maritalStatusCode", "employmentStatusCode", "ioStatusCode" })
public class PersonServiceSummaryDTO
{
	private java.lang.Integer	cprNumber;
	private java.lang.String	dateOfBirth;
	private java.lang.String	dateOfBirthOld;
	private java.lang.String	nationality;
	private java.lang.String	birthCountryCode;
	private java.lang.String	dateOfDeath;
	private java.lang.String	deathCountryCode;
	private java.lang.String	arabicFullName;
	private java.lang.String	arabicFirstName;
	private java.lang.String	arabicMiddleName1;
	private java.lang.String	arabicMiddleName2;
	private java.lang.String	arabicMiddleName3;
	private java.lang.String	arabicMiddleName4;
	private java.lang.String	arabicFamilyName;
	private java.lang.String	englishFullName;
	private java.lang.String	englishFirstName;
	private java.lang.String	englishMiddleName1;
	private java.lang.String	englishMiddleName2;
	private java.lang.String	englishMiddleName3;
	private java.lang.String	englishMiddleName4;
	private java.lang.String	englishFamilyName;
	private java.lang.String	gender;
	private java.lang.Integer	sponsorIndicator;
	private java.lang.Integer	employerIndicator;
	private java.lang.String	isStudent;
	private java.lang.String	isClearingAgent;
	private java.lang.String	isWatchlisted;
	// private java.lang.String isLostCard;
	// private java.lang.String isDeleted;
	private java.lang.String	isPrisoner;
	private java.lang.String	isSmartcard;
	// private java.lang.String isNationalityConfirmed;
	private java.lang.String	contactPhone;
	private java.lang.String	birthPlaceArabic;
	private java.lang.String	birthPlaceEnglish;
	private java.lang.Integer	fatherCprNumber;
	private java.lang.Integer	motherCprNumber;
	private java.lang.Integer	spouseCpr;
	private java.lang.String	religionCode;
	private java.lang.String	labourParticipationTypeCode;
	private java.lang.String	labourParticipationTypeArabicName;
	private java.lang.String	labourParticipationTypeEnglishName;
	private java.lang.String	highestLevelAchievedCode;
	private java.lang.String	maritalStatusCode;
	private java.lang.String	employmentStatusCode;
	private java.lang.String	ioStatusCode;

	public PersonServiceSummaryDTO()
	{
		super();
	}

	public PersonServiceSummaryDTO(Integer cprNumber, String dateOfBirth,
			String dateOfBirthOld, String nationality, String birthCountryCode,
			String dateOfDeath, String deathCountryCode, String arabicFullName,
			String arabicFirstName, String arabicMiddleName1,
			String arabicMiddleName2, String arabicMiddleName3,
			String arabicMiddleName4, String arabicFamilyName,
			String englishFullName, String englishFirstName,
			String englishMiddleName1, String englishMiddleName2,
			String englishMiddleName3, String englishMiddleName4,
			String englishFamilyName, String gender, Integer sponsorIndicator,
			Integer employerIndicator, String isStudent,
			String isClearingAgent, String isWatchlisted, /*
														 * String isLostCard, String isDeleted,
														 */String isPrisoner,
			String isSmartcard,
			/* String isNationalityConfirmed, */String contactPhone,
			String birthPlaceArabic, String birthPlaceEnglish,
			Integer fatherCprNumber, Integer motherCprNumber,
			Integer spouseCpr, String religionCode,
			String labourParticipationTypeCode,
			String labourParticipationTypeArabicName,
			String labourParticipationTypeEnglishName,
			String highestLevelAchievedCode, String maritalStatusCode,
			String employmentStatusCode, String ioStatusCode)
	{
		super();
		this.cprNumber = cprNumber;
		this.dateOfBirth = dateOfBirth;
		this.dateOfBirthOld = dateOfBirthOld;
		this.nationality = nationality;
		this.birthCountryCode = birthCountryCode;
		this.dateOfDeath = dateOfDeath;
		this.deathCountryCode = deathCountryCode;
		this.arabicFullName = arabicFullName;
		this.arabicFirstName = arabicFirstName;
		this.arabicMiddleName1 = arabicMiddleName1;
		this.arabicMiddleName2 = arabicMiddleName2;
		this.arabicMiddleName3 = arabicMiddleName3;
		this.arabicMiddleName4 = arabicMiddleName4;
		this.arabicFamilyName = arabicFamilyName;
		this.englishFullName = englishFullName;
		this.englishFirstName = englishFirstName;
		this.englishMiddleName1 = englishMiddleName1;
		this.englishMiddleName2 = englishMiddleName2;
		this.englishMiddleName3 = englishMiddleName3;
		this.englishMiddleName4 = englishMiddleName4;
		this.englishFamilyName = englishFamilyName;
		this.gender = gender;
		this.sponsorIndicator = sponsorIndicator;
		this.employerIndicator = employerIndicator;
		this.isStudent = isStudent;
		this.isClearingAgent = isClearingAgent;
		this.isWatchlisted = isWatchlisted;
		// this.isLostCard = isLostCard;
		// this.isDeleted = isDeleted;
		this.isPrisoner = isPrisoner;
		this.isSmartcard = isSmartcard;
		// this.isNationalityConfirmed = isNationalityConfirmed;
		this.contactPhone = contactPhone;
		this.birthPlaceArabic = birthPlaceArabic;
		this.birthPlaceEnglish = birthPlaceEnglish;
		this.fatherCprNumber = fatherCprNumber;
		this.motherCprNumber = motherCprNumber;
		this.spouseCpr = spouseCpr;
		this.religionCode = religionCode;
		this.labourParticipationTypeCode = labourParticipationTypeCode;
		this.labourParticipationTypeArabicName = labourParticipationTypeArabicName;
		this.labourParticipationTypeEnglishName = labourParticipationTypeEnglishName;
		this.highestLevelAchievedCode = highestLevelAchievedCode;
		this.maritalStatusCode = maritalStatusCode;
		this.employmentStatusCode = employmentStatusCode;
		this.ioStatusCode = ioStatusCode;
	}

	@XmlElement(name = "ArabicFamilyName", required = true)
	public java.lang.String getArabicFamilyName()
	{
		return arabicFamilyName;
	}

	@XmlElement(name = "ArabicFirstName", required = true)
	public java.lang.String getArabicFirstName()
	{
		return arabicFirstName;
	}

	@XmlElement(name = "ArabicFullName", required = true)
	public java.lang.String getArabicFullName()
	{
		return arabicFullName;
	}

	@XmlElement(name = "ArabicMiddleName1", required = true)
	public java.lang.String getArabicMiddleName1()
	{
		return arabicMiddleName1;
	}

	@XmlElement(name = "ArabicMiddleName2", required = true)
	public java.lang.String getArabicMiddleName2()
	{
		return arabicMiddleName2;
	}

	@XmlElement(name = "ArabicMiddleName3", required = true)
	public java.lang.String getArabicMiddleName3()
	{
		return arabicMiddleName3;
	}

	@XmlElement(name = "ArabicMiddleName4", required = true)
	public java.lang.String getArabicMiddleName4()
	{
		return arabicMiddleName4;
	}

	@XmlElement(name = "BirthCountryCode", required = true)
	public java.lang.String getBirthCountryCode()
	{
		return birthCountryCode;
	}

	@XmlElement(name = "BirthPlaceArabic", required = true)
	public java.lang.String getBirthPlaceArabic()
	{
		return birthPlaceArabic;
	}

	@XmlElement(name = "BirthPlaceEnglish", required = true)
	public java.lang.String getBirthPlaceEnglish()
	{
		return birthPlaceEnglish;
	}

	@XmlElement(name = "ContactPhone", required = true)
	public java.lang.String getContactPhone()
	{
		return contactPhone;
	}

	@XmlElement(name = "CprNumber", required = true)
	public java.lang.Integer getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(name = "DateOfBirth", required = true)
	public java.lang.String getDateOfBirth()
	{
		return dateOfBirth;
	}

	@XmlElement(name = "DateOfBirthOld", required = true)
	public java.lang.String getDateOfBirthOld()
	{
		return dateOfBirthOld;
	}

	@XmlElement(name = "DateOfDeath", required = true)
	public java.lang.String getDateOfDeath()
	{
		return dateOfDeath;
	}

	@XmlElement(name = "DeathCountryCode", required = true)
	public java.lang.String getDeathCountryCode()
	{
		return deathCountryCode;
	}

	@XmlElement(name = "EmployerIndicator", required = true)
	public java.lang.Integer getEmployerIndicator()
	{
		return employerIndicator;
	}

	@XmlElement(name = "EmploymentStatusCode", required = true)
	public java.lang.String getEmploymentStatusCode()
	{
		return employmentStatusCode;
	}

	@XmlElement(name = "EnglishFamilyName", required = true)
	public java.lang.String getEnglishFamilyName()
	{
		return englishFamilyName;
	}

	@XmlElement(name = "EnglishFirstName", required = true)
	public java.lang.String getEnglishFirstName()
	{
		return englishFirstName;
	}

	@XmlElement(name = "EnglishFullName", required = true)
	public java.lang.String getEnglishFullName()
	{
		return englishFullName;
	}

	@XmlElement(name = "EnglishMiddleName1", required = true)
	public java.lang.String getEnglishMiddleName1()
	{
		return englishMiddleName1;
	}

	@XmlElement(name = "EnglishMiddleName2", required = true)
	public java.lang.String getEnglishMiddleName2()
	{
		return englishMiddleName2;
	}

	@XmlElement(name = "EnglishMiddleName3", required = true)
	public java.lang.String getEnglishMiddleName3()
	{
		return englishMiddleName3;
	}

	@XmlElement(name = "EnglishMiddleName4", required = true)
	public java.lang.String getEnglishMiddleName4()
	{
		return englishMiddleName4;
	}

	@XmlElement(name = "FatherCprNumber", required = true)
	public java.lang.Integer getFatherCprNumber()
	{
		return fatherCprNumber;
	}

	@XmlElement(name = "Gender", required = true)
	public java.lang.String getGender()
	{
		return gender;
	}

	@XmlElement(name = "HighestLevelAchievedCode", required = true)
	public java.lang.String getHighestLevelAchievedCode()
	{
		return highestLevelAchievedCode;
	}

	@XmlElement(name = "IoStatusCode", required = true)
	public java.lang.String getIoStatusCode()
	{
		return ioStatusCode;
	}

	@XmlElement(name = "IsClearingAgent", required = true)
	public java.lang.String getIsClearingAgent()
	{
		return isClearingAgent;
	}

	// @XmlElement(name = "IsDeleted", required = true)
	// public java.lang.String getIsDeleted()
	// {
	// return isDeleted;
	// }

	// @XmlElement(name = "IsLostCard()", required = true)
	// public java.lang.String getIsLostCard()
	// {
	// return isLostCard;
	// }

	// @XmlElement(name = "IsNationalityConfirmed()", required = true)
	// public java.lang.String getIsNationalityConfirmed()
	// {
	// return isNationalityConfirmed;
	// }

	@XmlElement(name = "IsPrisoner", required = true)
	public java.lang.String getIsPrisoner()
	{
		return isPrisoner;
	}

	@XmlElement(name = "IsSmartcard", required = true)
	public java.lang.String getIsSmartcard()
	{
		return isSmartcard;
	}

	@XmlElement(name = "IsStudent", required = true)
	public java.lang.String getIsStudent()
	{
		return isStudent;
	}

	@XmlElement(name = "IsWatchlisted", required = true)
	public java.lang.String getIsWatchlisted()
	{
		return isWatchlisted;
	}

	@XmlElement(name = "LabourParticipationTypeArabicName", required = true)
	public java.lang.String getLabourParticipationTypeArabicName()
	{
		return labourParticipationTypeArabicName;
	}

	@XmlElement(name = "LabourParticipationTypeCode", required = true)
	public java.lang.String getLabourParticipationTypeCode()
	{
		return labourParticipationTypeCode;
	}

	@XmlElement(name = "LabourParticipationTypeEnglishName", required = true)
	public java.lang.String getLabourParticipationTypeEnglishName()
	{
		return labourParticipationTypeEnglishName;
	}

	@XmlElement(name = "MaritalStatusCode", required = true)
	public java.lang.String getMaritalStatusCode()
	{
		return maritalStatusCode;
	}

	@XmlElement(name = "MotherCprNumber", required = true)
	public java.lang.Integer getMotherCprNumber()
	{
		return motherCprNumber;
	}

	@XmlElement(name = "Nationality", required = true)
	public java.lang.String getNationality()
	{
		return nationality;
	}

	@XmlElement(name = "ReligionCode", required = true)
	public java.lang.String getReligionCode()
	{
		return religionCode;
	}

	@XmlElement(name = "SponsorIndicator", required = true)
	public java.lang.Integer getSponsorIndicator()
	{
		return sponsorIndicator;
	}

	@XmlElement(name = "SpouseCpr", required = true)
	public java.lang.Integer getSpouseCpr()
	{
		return spouseCpr;
	}

	public void setArabicFamilyName(java.lang.String arabicFamilyName)
	{
		this.arabicFamilyName = arabicFamilyName;
	}

	public void setArabicFirstName(java.lang.String arabicFirstName)
	{
		this.arabicFirstName = arabicFirstName;
	}

	public void setArabicFullName(java.lang.String arabicFullName)
	{
		this.arabicFullName = arabicFullName;
	}

	public void setArabicMiddleName1(java.lang.String arabicMiddleName1)
	{
		this.arabicMiddleName1 = arabicMiddleName1;
	}

	public void setArabicMiddleName2(java.lang.String arabicMiddleName2)
	{
		this.arabicMiddleName2 = arabicMiddleName2;
	}

	public void setArabicMiddleName3(java.lang.String arabicMiddleName3)
	{
		this.arabicMiddleName3 = arabicMiddleName3;
	}

	public void setArabicMiddleName4(java.lang.String arabicMiddleName4)
	{
		this.arabicMiddleName4 = arabicMiddleName4;
	}

	public void setBirthCountryCode(java.lang.String birthCountryCode)
	{
		this.birthCountryCode = birthCountryCode;
	}

	public void setBirthPlaceArabic(java.lang.String birthPlaceArabic)
	{
		this.birthPlaceArabic = birthPlaceArabic;
	}

	public void setBirthPlaceEnglish(java.lang.String birthPlaceEnglish)
	{
		this.birthPlaceEnglish = birthPlaceEnglish;
	}

	public void setContactPhone(java.lang.String contactPhone)
	{
		this.contactPhone = contactPhone;
	}

	public void setCprNumber(java.lang.Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDateOfBirth(java.lang.String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public void setDateOfBirthOld(java.lang.String dateOfBirthOld)
	{
		this.dateOfBirthOld = dateOfBirthOld;
	}

	public void setDateOfDeath(java.lang.String dateOfDeath)
	{
		this.dateOfDeath = dateOfDeath;
	}

	public void setDeathCountryCode(java.lang.String deathCountryCode)
	{
		this.deathCountryCode = deathCountryCode;
	}

	public void setEmployerIndicator(java.lang.Integer employerIndicator)
	{
		this.employerIndicator = employerIndicator;
	}

	public void setEmploymentStatusCode(java.lang.String employmentStatusCode)
	{
		this.employmentStatusCode = employmentStatusCode;
	}

	public void setEnglishFamilyName(java.lang.String englishFamilyName)
	{
		this.englishFamilyName = englishFamilyName;
	}

	public void setEnglishFirstName(java.lang.String englishFirstName)
	{
		this.englishFirstName = englishFirstName;
	}

	public void setEnglishFullName(java.lang.String englishFullName)
	{
		this.englishFullName = englishFullName;
	}

	public void setEnglishMiddleName1(java.lang.String englishMiddleName1)
	{
		this.englishMiddleName1 = englishMiddleName1;
	}

	public void setEnglishMiddleName2(java.lang.String englishMiddleName2)
	{
		this.englishMiddleName2 = englishMiddleName2;
	}

	public void setEnglishMiddleName3(java.lang.String englishMiddleName3)
	{
		this.englishMiddleName3 = englishMiddleName3;
	}

	public void setEnglishMiddleName4(java.lang.String englishMiddleName4)
	{
		this.englishMiddleName4 = englishMiddleName4;
	}

	public void setFatherCprNumber(java.lang.Integer fatherCprNumber)
	{
		this.fatherCprNumber = fatherCprNumber;
	}

	public void setGender(java.lang.String gender)
	{
		this.gender = gender;
	}

	public void setHighestLevelAchievedCode(
			java.lang.String highestLevelAchievedCode)
	{
		this.highestLevelAchievedCode = highestLevelAchievedCode;
	}

	public void setIoStatusCode(java.lang.String ioStatusCode)
	{
		this.ioStatusCode = ioStatusCode;
	}

	public void setIsClearingAgent(java.lang.String isClearingAgent)
	{
		this.isClearingAgent = isClearingAgent;
	}

	// public void setIsDeleted(java.lang.String isDeleted)
	// {
	// this.isDeleted = isDeleted;
	// }
	//
	// public void setIsLostCard(java.lang.String isLostCard)
	// {
	// this.isLostCard = isLostCard;
	// }
	//
	// public void setIsNationalityConfirmed(
	// java.lang.String isNationalityConfirmed)
	// {
	// this.isNationalityConfirmed = isNationalityConfirmed;
	// }

	public void setIsPrisoner(java.lang.String isPrisoner)
	{
		this.isPrisoner = isPrisoner;
	}

	public void setIsSmartcard(java.lang.String isSmartcard)
	{
		this.isSmartcard = isSmartcard;
	}

	public void setIsStudent(java.lang.String isStudent)
	{
		this.isStudent = isStudent;
	}

	public void setIsWatchlisted(java.lang.String isWatchlisted)
	{
		this.isWatchlisted = isWatchlisted;
	}

	public void setLabourParticipationTypeArabicName(
			java.lang.String labourParticipationTypeArabicName)
	{
		this.labourParticipationTypeArabicName = labourParticipationTypeArabicName;
	}

	public void setLabourParticipationTypeCode(
			java.lang.String labourParticipationTypeCode)
	{
		this.labourParticipationTypeCode = labourParticipationTypeCode;
	}

	public void setLabourParticipationTypeEnglishName(
			java.lang.String labourParticipationTypeEnglishName)
	{
		this.labourParticipationTypeEnglishName = labourParticipationTypeEnglishName;
	}

	public void setMaritalStatusCode(java.lang.String maritalStatusCode)
	{
		this.maritalStatusCode = maritalStatusCode;
	}

	public void setMotherCprNumber(java.lang.Integer motherCprNumber)
	{
		this.motherCprNumber = motherCprNumber;
	}

	public void setNationalityCountryCode(java.lang.String nationality)
	{
		this.nationality = nationality;
	}

	public void setReligionCode(java.lang.String religionCode)
	{
		this.religionCode = religionCode;
	}

	public void setSponsorIndicator(java.lang.Integer sponsorIndicator)
	{
		this.sponsorIndicator = sponsorIndicator;
	}

	public void setSpouseCpr(java.lang.Integer spouseCpr)
	{
		this.spouseCpr = spouseCpr;
	}

	@Override
	public String toString()
	{
		return "PersonServiceSummaryDTO [cprNumber=" + cprNumber
				+ ", dateOfBirth=" + dateOfBirth + ", dateOfBirthOld="
				+ dateOfBirthOld + ", nationalityCountryCode=" + nationality
				+ ", birthCountryCode=" + birthCountryCode + ", dateOfDeath="
				+ dateOfDeath + ", deathCountryCode=" + deathCountryCode
				+ ", arabicFullName=" + arabicFullName + ", arabicFirstName="
				+ arabicFirstName + ", arabicMiddleName1=" + arabicMiddleName1
				+ ", arabicMiddleName2=" + arabicMiddleName2
				+ ", arabicMiddleName3=" + arabicMiddleName3
				+ ", arabicMiddleName4=" + arabicMiddleName4
				+ ", arabicFamilyName=" + arabicFamilyName
				+ ", englishFullName=" + englishFullName
				+ ", englishFirstName=" + englishFirstName
				+ ", englishMiddleName1=" + englishMiddleName1
				+ ", englishMiddleName2=" + englishMiddleName2
				+ ", englishMiddleName3=" + englishMiddleName3
				+ ", englishMiddleName4=" + englishMiddleName4
				+ ", englishFamilyName=" + englishFamilyName + ", gender="
				+ gender + ", sponsorIndicator=" + sponsorIndicator
				+ ", employerIndicator=" + employerIndicator + ", isStudent="
				+ isStudent + ", isClearingAgent=" + isClearingAgent
				+ ", isWatchlisted=" + isWatchlisted + /*
														 * ", isLostCard=" + isLostCard + ", isDeleted=" + isDeleted +
														 */", isPrisoner="
				+ isPrisoner + ", isSmartcard=" + isSmartcard
				+ /*
				 * ", isNationalityConfirmed=" + isNationalityConfirmed +
				 */", contactPhone=" + contactPhone + ", birthPlaceArabic="
				+ birthPlaceArabic + ", birthPlaceEnglish=" + birthPlaceEnglish
				+ ", fatherCprNumber=" + fatherCprNumber + ", motherCprNumber="
				+ motherCprNumber + ", spouseCpr=" + spouseCpr
				+ ", religionCode=" + religionCode
				+ ", labourParticipationTypeCode="
				+ labourParticipationTypeCode
				+ ", labourParticipationTypeArabicName="
				+ labourParticipationTypeArabicName
				+ ", labourParticipationTypeEnglishName="
				+ labourParticipationTypeEnglishName
				+ ", highestLevelAchievedCode=" + highestLevelAchievedCode
				+ ", maritalStatusCode=" + maritalStatusCode
				+ ", employmentStatusCode=" + employmentStatusCode
				+ ", ioStatusCode=" + ioStatusCode + "]";
	}
}
