package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonServicePassportInfo", propOrder =
{ "passportNumber", "englishPlaceOfBirth", "arabicPlaceOfBirth", "issueDate",
		"expiryDate" })
public class PersonServicePassportInfoDTO
{
	private String	passportNumber;
	private String	issueDate;
	private String	expiryDate;
	private String	arabicPlaceOfBirth;
	private String	englishPlaceOfBirth;

	public PersonServicePassportInfoDTO()
	{
		super();
	}

	public PersonServicePassportInfoDTO(String passportNumber,
			String issueDate, String expiryDate, String arabicPlaceOfBirth,
			String englishPlaceOfBirth)
	{
		super();
		if (passportNumber != null)
			setPassportNumber(passportNumber);
		else
			setPassportNumber("");

		if (issueDate != null)
			setIssueDate(issueDate);
		else
			setIssueDate("");

		if (expiryDate != null)
			setExpiryDate(expiryDate);
		else
			setExpiryDate("");

		if (arabicPlaceOfBirth != null)
			setArabicPlaceOfBirth(arabicPlaceOfBirth);
		else
			setArabicPlaceOfBirth("");

		if (englishPlaceOfBirth != null)
			setEnglishPlaceOfBirth(englishPlaceOfBirth);
		else
			setEnglishPlaceOfBirth("");
	}

	@XmlElement(name = "ArabicPlaceOfBirth", required = true)
	public String getArabicPlaceOfBirth()
	{
		return arabicPlaceOfBirth;
	}

	@XmlElement(name = "EnglishPlaceOfBirth", required = true)
	public String getEnglishPlaceOfBirth()
	{
		return englishPlaceOfBirth;
	}

	@XmlElement(name = "ExpiryDate", required = true)
	public String getExpiryDate()
	{
		return expiryDate;
	}

	@XmlElement(name = "IssueDate", required = true)
	public String getIssueDate()
	{
		return issueDate;
	}

	@XmlElement(name = "PassportNumber", required = true)
	public String getPassportNumber()
	{
		return passportNumber;
	}

	public void setArabicPlaceOfBirth(String arabicPlaceOfBirth)
	{
		this.arabicPlaceOfBirth = arabicPlaceOfBirth;
	}

	public void setEnglishPlaceOfBirth(String englishPlaceOfBirth)
	{
		this.englishPlaceOfBirth = englishPlaceOfBirth;
	}

	public void setExpiryDate(String expiryDate)
	{
		this.expiryDate = expiryDate;
	}

	public void setIssueDate(String issueDate)
	{
		this.issueDate = issueDate;
	}

	public void setPassportNumber(String passportNumber)
	{
		this.passportNumber = passportNumber;
	}

}
