package bh.gov.cio.integration.crs.gis.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.gis.service.dto.CRBasicInfoWithAddressDTO;
import bh.gov.cio.integration.crs.gis.service.dto.GISPersonDataDTO;
import bh.gov.cio.integration.crs.gis.service.dto.UnitBasicInfoWithAddressDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GISDataService", targetNamespace = "http://service.gis.crs.integration.cio.gov.bh/")
public interface GISDataInterface {

	@WebResult(name = "GISPersonDataDTO")
	@WebMethod(operationName = "checkPersonData")
	GISPersonDataDTO checkPersonData(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

	@WebResult(name = "UnitBasicInfo")
	@WebMethod(operationName = "GetUnitBasicInfoWithAddress")
	UnitBasicInfoWithAddressDTO getUnitBasicInfoWithAddress(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security, @WebParam(name = "unitNumber") @XmlElement(required = true) Integer unitNumber)
			throws ApplicationExceptionInfo;

	@WebResult(name = "CRBasicInfo")
	@WebMethod(operationName = "getCRBasicInfoWithAddress")
	CRBasicInfoWithAddressDTO getCRBasicInfoWithAddress(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security, @WebParam(name = "crNumber") @XmlElement(required = true) Integer crNumber)
			throws ApplicationExceptionInfo;


	

}
