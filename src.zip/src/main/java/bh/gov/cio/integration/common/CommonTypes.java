package bh.gov.cio.integration.common;

public interface CommonTypes {
	enum Gender {M , F};
	enum Nationality {GCC , Bahraini , Other };
	enum IDType { CR , CPR};
	enum AgeGroup {Child , Elder , Youth};
	enum GCC {UAE,KWT,OMN,QTR,KSA,NON};
	enum EstablishmentType { U , C};
}
