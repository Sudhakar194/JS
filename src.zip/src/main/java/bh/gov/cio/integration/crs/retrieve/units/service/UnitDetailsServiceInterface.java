package bh.gov.cio.integration.crs.retrieve.units.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitDetailsInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "UnitDetailsService", targetNamespace = "http://service.units.retrieve.crs.integration.cio.gov.bh/")
public interface UnitDetailsServiceInterface
{
	@WebResult(name = "UnitDetails")
	@WebMethod(operationName = "GetUnitDetails")
	UnitDetailsInfoDTO getUnitDetails(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security, @WebParam(name = "unitNumber") @XmlElement(required = true) Integer unitNumber ,  @WebParam(name = "unitOwnerNumber") @XmlElement(required = false) Integer unitOwnerNumber)
			throws ApplicationExceptionInfo;

}
