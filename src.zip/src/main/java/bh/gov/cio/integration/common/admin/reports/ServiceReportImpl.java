package bh.gov.cio.integration.common.admin.reports;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.integration.common.admin.dao.AdminDao;
import bh.gov.cio.integration.common.admin.reports.service.ServiceReportInterface;
import bh.gov.cio.integration.common.admin.reports.service.dto.ServiceDetailsInfoDTO;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "ServiceReportService", targetNamespace = "http://reports.admin.common.integration.cio.gov.bh/")
public class ServiceReportImpl implements ServiceReportInterface {

	@Autowired
	protected AdminDao adminDao;

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getServiceInformationByMinistry")
	public ArrayList<ServiceDetailsInfoDTO> getServiceInformationByMinistry(SecurityTagObject security, String ministry) {
		ArrayList<ServiceDetailsInfoDTO> serviceInfoList = adminDao.getServiceInformationByMinistry(ministry);
		return serviceInfoList;
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getNumberOfServiceByMinistry")
	public Integer getNumberOfServiceByMinistry(SecurityTagObject security, String ministry) {
		return adminDao.getNumberOfServiceByMinistry(ministry);
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getTotalNumberOfService")
	public Integer getTotalNumberOfService(SecurityTagObject security) {
		return adminDao.getTotalNumberOfServiceByMinistry();
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getTotalNumberOfServiceByYear")
	public Integer getTotalNumberOfServiceByYear(SecurityTagObject security, String year) {
		return adminDao.getTotalNumberOfServiceByYear(year);
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getTotalNumberOfServiceByYearMonth")
	public Integer getTotalNumberOfServiceByYearMonth(SecurityTagObject security, String year, String month) {
		return adminDao.getTotalNumberOfServiceByYearMonth(year, month);
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getNumberOfHits")
	public Integer getNumberOfHits(SecurityTagObject security, String serviceName) {
		return adminDao.getNumberOfHits(serviceName);
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getAllServiceInformationByMinistry")
	public ArrayList<ServiceDetailsInfoDTO> getAllServiceInformationByMinistry(SecurityTagObject security) {
		return adminDao.getAllServicesName();
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getMinstriesInformation")
	public ArrayList<String> getMinstriesInformation(SecurityTagObject security) {
		return adminDao.getAllMinistriesName();
	}

	@Override
	@Secured({ "ROLE_getServiceInformation" })
	@WebMethod(operationName = "getServicesInformationByName")
	public ArrayList<ServiceDetailsInfoDTO> getServicesInformationByName(SecurityTagObject security,
			String serviceName) {
		return adminDao.getServicesInformationByName(serviceName);
	}

}
