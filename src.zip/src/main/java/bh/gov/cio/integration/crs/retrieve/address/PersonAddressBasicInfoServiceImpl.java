package bh.gov.cio.integration.crs.retrieve.address;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.address.service.PersonAddressBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonAddressBasicInfoService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
// @InInterceptors(
// interceptors =
// { /* "bh.gov.cio.integration.security.SoapHeaderModifierInterceptor"
// "bh.gov.cio.integration.security.AbstractHeaderModifier"
// */"bh.gov.cio.integration.security.WSDLGetInterceptor" })
public class PersonAddressBasicInfoServiceImpl implements PersonAddressBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonAddressBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonAddressBasicInfo" })
	@WebMethod(operationName = "getPersonAddressBasicInfo")
	public AddressServiceBasicInfoDTO getPersonAddressBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber,
			Date cardExpiryDate) throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonAddressBasicInfo(Integer, Integer, Date) - start");
		}

		AddressServiceBasicInfoDTO returnedAddress = null;
		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		if (validationUtil.isMilitaryCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try
		{
			List<Integer> cprList = new ArrayList<Integer>();
			cprList.add(cprNumber);
			final List<bh.gov.cio.crs.model.nas.Address> addresses = getCrsService().getAddressServiceRef().getAddressForListCprNumber(cprList);
			if (addresses.size() == 0)
			{
				throw new ApplicationExceptionInfo("Address Basic Details Not found", new ApplicationException("Address Basic Details Not found"));
			}

			if (addresses != null)
			{
				final bh.gov.cio.crs.model.nas.Address returnedAddressRow = addresses.get(addresses.size() - 1);
				returnedAddress = new AddressServiceBasicInfoDTO(returnedAddressRow.getBlockNumber(), returnedAddressRow.getBlockNameArabic(),
						returnedAddressRow.getBuildingNumber(), returnedAddressRow.getNameAlphaEnglish(), returnedAddressRow.getNameAlphaArabic(),
						returnedAddressRow.getBuildingNameArabic(), returnedAddressRow.getBuildingNameEnglish(),
						returnedAddressRow.getBlockNameEnglish(), returnedAddressRow.getRoadNumber(), returnedAddressRow.getRoadNameArabic(),
						returnedAddressRow.getRoadNameEnglish(), returnedAddressRow.getAreaCode(), returnedAddressRow.getAreaNameArabic(),
						returnedAddressRow.getAreaNameEnglish(), returnedAddressRow.getFlatNumber(), returnedAddressRow.getRegionNameArabic(),
						returnedAddressRow.getRegionNameEnglish(), returnedAddressRow.getGovernorateNameArabic(),
						returnedAddressRow.getGovernorateNameEnglish(), returnedAddressRow.getAddressTypeCode());
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonAddressBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Address Basic Details Not found", new ApplicationException("Address Basic Details Not found"));
		}

		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonAddressBasicInfo(Integer, Integer, Date) - end");
		}
		return returnedAddress;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonAddressBasicInfoByCPR" })
	@WebMethod(operationName = "getPersonAddressBasicInfoByCPR")
	public AddressServiceBasicInfoDTO getPersonAddressBasicInfoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonAddressBasicInfo(Integer, Integer, Date) - start");
		}

		AddressServiceBasicInfoDTO returnedAddress = null;

		if (validationUtil.isMilitaryCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Data Problem", new ApplicationException("CPR Data Problem"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try
		{
			List<Integer> cprList = new ArrayList<Integer>();
			cprList.add(cprNumber);
			final List<bh.gov.cio.crs.model.nas.Address> addresses = getCrsService().getAddressServiceRef().getAddressForListCprNumber(cprList);
			if (addresses.size() == 0)
			{
				throw new ApplicationExceptionInfo("Address Basic Details Not found", new ApplicationException("Address Basic Details Not found"));
			}

			if (addresses != null)
			{

				
				
	
				final bh.gov.cio.crs.model.nas.Address returnedAddressRow = addresses.get(addresses.size() - 1);
				final bh.gov.cio.crs.model.nas.Address addresses2 = getCrsService().getAddressServiceRef().getPersonAddress(returnedAddressRow.getFlatNumber(),returnedAddressRow.getBuildingNumber(),returnedAddressRow.getNameAlphaEnglish(),returnedAddressRow.getRoadNumber(),returnedAddressRow.getBlockNumber());
				
				returnedAddress = new AddressServiceBasicInfoDTO(returnedAddressRow.getBlockNumber(), returnedAddressRow.getBlockNameArabic(),
						returnedAddressRow.getBuildingNumber(), returnedAddressRow.getNameAlphaEnglish(), returnedAddressRow.getNameAlphaArabic(),
						returnedAddressRow.getBuildingNameArabic(), returnedAddressRow.getBuildingNameEnglish(),
						returnedAddressRow.getBlockNameEnglish(), returnedAddressRow.getRoadNumber(), returnedAddressRow.getRoadNameArabic(),
						returnedAddressRow.getRoadNameEnglish(), addresses2.getAreaCode(), returnedAddressRow.getAreaNameArabic(),
						returnedAddressRow.getAreaNameEnglish(), returnedAddressRow.getFlatNumber(), addresses2.getRegionNameArabic(),
						addresses2.getRegionNameEnglish(), returnedAddressRow.getGovernorateNameArabic(),
						returnedAddressRow.getGovernorateNameEnglish(), returnedAddressRow.getAddressTypeCode());
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonAddressBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Address Basic Details Not found", new ApplicationException("Address Basic Details Not found"));
		}

		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonAddressBasicInfo(Integer, Integer, Date) - end");
		}
		return returnedAddress;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
