package bh.gov.cio.integration.crs.retrieve.family;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

@Controller
public class MOJDeathReportForMinorsServiceImpl {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(MOJDeathReportForMinorsServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@RequestMapping("/service/deathCasesEnquiry.service")
	@ResponseBody
	@Secured({ "ROLE_deathCasesEnquiry" })
	public String getDeath(@RequestParam(value = "startDate", required = true) String startDate,
			@RequestParam(value = "endDate", required = true) String endDate) throws ApplicationExceptionInfo {
		PersonService ps = getCrsService().getPersonServiceRef();
		ArrayList<Integer> deadCprs = null;
		String returned = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			Date  fromDate = sdf.parse(startDate);
			Date  toDate = sdf.parse(endDate);
			long diffTime = toDate.getTime() - fromDate.getTime();
			long diffDays = diffTime / (1000 * 60 * 60 * 24);
			logger.debug("diffTime:"+diffTime);
			logger.debug("diffDays:"+diffDays);
			if (diffDays < 0)
			{
				returned = "fromDate must be greater than toDate";
			}
			else
			if (diffDays > 30)
			{
				returned = "Could't select more than one month";
			}
			else
			{
				deadCprs = (ArrayList<Integer>) ps.getDeadWithMinorChildrenWithinPeriod(fromDate,toDate );
				returned = deadCprs.toString();
			}
			logger.debug(returned);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ApplicationExceptionInfo(e.getMessage(),
					new bh.gov.cio.integration.exception.ApplicationException(e.getMessage(), "001"));
		}
		return returned;

	}

	@RequestMapping("/service/deathMinorEnquiry.service")
	@ResponseBody
	@Secured({ "ROLE_deathMinorEnquiry" })
	public String getDeathMinorDetails(@RequestParam(value = "deadCPR", required = true) Integer cprNumber)
			throws ApplicationExceptionInfo {
		PersonService ps = getCrsService().getPersonServiceRef();
		ArrayList<Integer> minorCprs = null;
		try {
			minorCprs = (ArrayList<Integer>) ps.getResidentMinorChildrenWithDeadParent(cprNumber);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ApplicationExceptionInfo(e.getMessage(),
					new bh.gov.cio.integration.exception.ApplicationException(e.getMessage(), "001"));
		}
		return minorCprs.toString();

	}
}
