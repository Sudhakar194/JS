package bh.gov.cio.integration.crs.egov.gdt.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "ValidateBasicCRInfoService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public interface ValidateBasicCRInfoServiceInterface {

	
	
	
	@WebResult(name = "ValidateCRBasicInformation")
	@WebMethod(operationName = "validateBasicCRInfo")
	Boolean validateCRBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "crNumber") @XmlElement(required = true) Integer crNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "crExpiryDate") @XmlElement(required = true) Date crExpiryDate) throws ApplicationExceptionInfo;
}
