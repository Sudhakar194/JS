package bh.gov.cio.integration.crs.egov.gdt;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.egov.gdt.service.AddressVerificationServiceInterface;
import bh.gov.cio.integration.crs.egov.gdt.service.dto.AddressVerificationDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "AddressVerificationService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public class AddressVerificationServiceImpl implements AddressVerificationServiceInterface{

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}
	
	@Override
	@Secured({ "ROLE_ValidateAddress" })
	@WebMethod(operationName = "validateAddress")
	public AddressVerificationDTO validateAddress(SecurityTagObject security,
			Integer flatNumber, Integer buildingNumber, String buildingAlpha,
			Integer roadNumber, Integer blockNumber) throws ApplicationExceptionInfo{
		// TODO Auto-generated method stub
		
		AddressVerificationDTO addressVerificationDTO = new AddressVerificationDTO();
		

		if (flatNumber == null || flatNumber.intValue() < 0)
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		if (roadNumber == null || roadNumber.intValue() <= 0)
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		if (buildingNumber == null || buildingNumber.intValue() <= 0)
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		if (blockNumber == null || blockNumber.intValue() <= 0)
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		
		addressVerificationDTO.setFlatNumber(flatNumber);
		addressVerificationDTO.setBuildingNumber(buildingNumber);
		addressVerificationDTO.setBuildingAlpha(buildingAlpha);
		addressVerificationDTO.setRoadNumber(roadNumber);
		addressVerificationDTO.setBlockNumber(blockNumber);
		
		
		try {
		
			
			List<Address> addresses =crsService.getAddressServiceRef().getAddressesListFromAddressField(flatNumber, buildingNumber, buildingAlpha, roadNumber, blockNumber);
	
			if(addresses == null || addresses.isEmpty()){
				addressVerificationDTO.setIsValid("F");
			}else{
				addressVerificationDTO.setIsValid("T");
			}
		
		
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			addressVerificationDTO.setIsValid("F");
			e.printStackTrace();
		}
		
		
		return addressVerificationDTO;
	}
	
	
	
}
