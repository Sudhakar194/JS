package bh.gov.cio.integration.crs.retrieve.cr.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "CRActivityDetails", propOrder =
{ "activityCode", "activityArNm", "activityEnNm" })
public class CRActivityInfoDTO
{

	private String activityCode;
	private String activityArNm;
	private String activityEnNm;

	public CRActivityInfoDTO()
	{
		super();

	}

	public CRActivityInfoDTO(String activityCode, String activityArNm, String activityEnNm)
	{
		super();

		if (activityCode != null)
		{
			setActivityCode(activityCode);
		}
		else
		{
			setActivityCode("");
		}

		if (activityArNm != null)
		{
			setActivityArNm(activityArNm);
		}
		else
		{
			setActivityArNm("");
		}

		if (activityEnNm != null)
		{
			setActivityEnNm(activityEnNm);
		}
		else
		{
			setActivityEnNm("");
		}

	}

	@XmlElement(name = "ActivityArabicName", required = true)
	public String getActivityArNm()
	{
		return activityArNm;
	}

	@XmlElement(name = "ActivityCode", required = true)
	public String getActivityCode()
	{
		return activityCode;
	}

	@XmlElement(name = "ActivityEnglishName", required = true)
	public String getActivityEnNm()
	{
		return activityEnNm;
	}

	public void setActivityArNm(String activityArNm)
	{
		this.activityArNm = activityArNm;
	}

	public void setActivityCode(String activityCode)
	{
		this.activityCode = activityCode;
	}

	public void setActivityEnNm(String activityEnNm)
	{
		this.activityEnNm = activityEnNm;
	}

}
