package bh.gov.cio.integration.crs.egov.gdt;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.gdt.service.ValidateBasicCRInfoServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;



@WebService(name = "ValidateBasicCRInfoService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public class ValidateBasicCRInfoServiceImpl implements ValidateBasicCRInfoServiceInterface{

	
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(ValidateBasicCRInfoServiceImpl.class);
	
	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}
	
	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
	
	
	@Override
	@Secured(
	{ "ROLE_ValidateBasicCRInfo" })
	@WebMethod(operationName = "validateBasicCRInfo")
	public Boolean validateCRBasicInfo(SecurityTagObject security, Integer crNumber, Integer blockNumber, Date crExpiryDate)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("validateCRBasicInfo(Integer, Integer, Date) - start");
		}

		if(blockNumber != null)
		if (!validationUtil.crHasValidBlockData(crNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.crHasValidExpiryData(crNumber, crExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		if (!validationUtil.isCrActive(crNumber))
		{
			throw new ApplicationExceptionInfo("CR is Not Active", new ApplicationException("CR is Not Active"));
		}
	
		
		
		
		return true;
	}
	
	
	
}
