package bh.gov.cio.integration.crs.lmra.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "WifeFalgs", propOrder =
{ "cprNumber", "isBahrainiWife", "isBahrainiWidow", "haveChildren" })
public class IsBahrainiWifeDTO
{

	private String cprNumber;
	private String isBahrainiWife;
	private String isBahrainiWidow;
	private String haveChildren;

	public IsBahrainiWifeDTO()
	{
		super();

	}

	public IsBahrainiWifeDTO(String cprNumber, String isBahrainiWife, String isBahrainiWidow, String haveChildren)
	{
		super();
		this.cprNumber = cprNumber;
		this.isBahrainiWife = isBahrainiWife;
		this.isBahrainiWidow = isBahrainiWidow;
		this.haveChildren = haveChildren;
	}

	@XmlElement(name = "CprNumber", required = true)
	public String getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(name = "HaveChildren", required = true)
	public String getHaveChildren()
	{
		return haveChildren;
	}

	@XmlElement(name = "IsBahrainiWidow", required = true)
	public String getIsBahrainiWidow()
	{
		return isBahrainiWidow;
	}

	@XmlElement(name = "IsBahrainiWife", required = true)
	public String getIsBahrainiWife()
	{
		return isBahrainiWife;
	}

	public void setCprNumber(String cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setHaveChildren(String haveChildren)
	{
		this.haveChildren = haveChildren;
	}

	public void setIsBahrainiWidow(String isBahrainiWidow)
	{
		this.isBahrainiWidow = isBahrainiWidow;
	}

	public void setIsBahrainiWife(String isBahrainiWife)
	{
		this.isBahrainiWife = isBahrainiWife;
	}

}
