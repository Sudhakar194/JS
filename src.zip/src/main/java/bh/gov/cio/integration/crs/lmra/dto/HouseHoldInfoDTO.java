package bh.gov.cio.integration.crs.lmra.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.crs.lmra.service.ChildrenInfoOfHouseholdDTO;

@XmlType(name = "HouseHoldInfo", propOrder =
{ "personCpr", "personArabicName", "personEnglishName", "gender","birthDate","livingStatus","personWorkingStatus","maritalStatus",
		"spouseCpr","spouseWorkingStatus","noOfChildren","noOfChildrenWorking","buildingNumber","buildingAlphaArabic","buildingAlphaEnglish","faltNumber","blockNumber",
		"roadNumber","areaArabicName","areaEnglishName",
		"addressType","maritalStatusCode","noOfWives","childrenInfoOfHouseholds"
		,"applicantArabicName","applicantEnglishName" 
})
public class HouseHoldInfoDTO {
	
private String personCpr;
private String personArabicName;
private String personEnglishName;
private String gender;
private String birthDate;
private String livingStatus;
private String personWorkingStatus;
private String maritalStatus;
private String spouseCpr;
private String spouseWorkingStatus;
private Integer noOfChildren;
private Integer noOfChildrenWorking;
private Integer buildingNumber;
private String buildingAlphaArabic;
private String buildingAlphaEnglish;
private Integer faltNumber;
private Integer blockNumber;
private Integer roadNumber;
private String areaArabicName;
private String areaEnglishName;

private String addressType;
private String maritalStatusCode;
private Integer noOfWives;

private List<ChildrenInfoOfHouseholdDTO> childrenInfoOfHouseholds = new ArrayList<ChildrenInfoOfHouseholdDTO>();


private String applicantArabicName;
private String applicantEnglishName;




public HouseHoldInfoDTO() {
	super();

}




public HouseHoldInfoDTO(String personCpr, String personArabicName,
		String personEnglishName, String gender, String birthDate,
		String livingStatus, String personWorkingStatus, String maritalStatus,
		String spouseCpr, String spouseWorkingStatus, Integer noOfChildren,
		Integer noOfChildrenWorking, Integer buildingNumber,
		String buildingAlphaArabic, String buildingAlphaEnglish,
		Integer faltNumber, Integer blockNumber, Integer roadNumber,
		String areaArabicName, String areaEnglishName, String addressType,
		String maritalStatusCode, String maritalStatusLabel,
		Integer noOfWives,
		List<ChildrenInfoOfHouseholdDTO> childrenInfoOfHouseholds,
		String applicantArabicName, String applicantEnglishName) {
	super();
	this.personCpr =  personCpr != null ? personCpr : "";
	this.personArabicName = personArabicName != null ? personArabicName : "";
	this.personEnglishName = personEnglishName != null ? personEnglishName : "";
	this.gender = gender != null ? gender : "";
	this.birthDate = birthDate != null ? birthDate : "";
	this.livingStatus = livingStatus != null ? livingStatus : "";
	this.personWorkingStatus = personWorkingStatus != null ? personWorkingStatus : "";
	this.maritalStatus = maritalStatus != null ? maritalStatus : "";
	this.spouseCpr = spouseCpr != null ? spouseCpr : "";
	this.spouseWorkingStatus = personWorkingStatus != null ? personWorkingStatus : "";
	this.noOfChildren = noOfChildren != null ? noOfChildren :0;
	this.noOfChildrenWorking = noOfChildrenWorking != null ? noOfChildrenWorking :0;
	
	this.buildingNumber =noOfChildrenWorking != null ? noOfChildrenWorking :0;
	this.buildingAlphaArabic = buildingAlphaArabic != null ? buildingAlphaArabic : "";
	this.buildingAlphaEnglish = buildingAlphaEnglish != null ? buildingAlphaEnglish : "";
	this.faltNumber = faltNumber != null ? faltNumber :0;
	this.blockNumber = blockNumber != null ? blockNumber :0;	
	this.roadNumber = roadNumber != null ? roadNumber :0;
	this.areaArabicName = areaArabicName != null ? areaArabicName : "";
	this.areaEnglishName = areaEnglishName != null ? areaEnglishName : "";	
	this.addressType = addressType != null ? addressType : "";
	this.maritalStatusCode = maritalStatusCode != null ? maritalStatusCode : "";
	this.noOfWives = noOfWives != null ? noOfWives :0;
	this.childrenInfoOfHouseholds = childrenInfoOfHouseholds;

	
	
	this.applicantArabicName = applicantArabicName != null ? applicantArabicName : "";
	this.applicantEnglishName = applicantEnglishName != null ? applicantEnglishName : "";
}




public HouseHoldInfoDTO(String personCpr, String personArabicName,
		String personEnglishName, String gender, String birthDate,
		String livingStatus, String personWorkingStatus, String maritalStatus,
		String spouseCpr, String spouseWorkingStatus, Integer noOfChildren,
		Integer noOfChildrenWorking, Integer buildingNumber,
		String buildingAlpha, Integer faltNumber, Integer blockNumber,
		Integer roadNumber, String areaArabicName, String areaEnglishName,
		String applicantArabicName, String applicantEnglishName) {
	super();
	this.personCpr =  personCpr != null ? personCpr : "";
	this.personArabicName = personArabicName != null ? personArabicName : "";
	this.personEnglishName = personEnglishName != null ? personEnglishName : "";
	this.gender = gender != null ? gender : "";
	this.birthDate = birthDate != null ? birthDate : "";
	this.livingStatus = livingStatus != null ? livingStatus : "";
	this.personWorkingStatus = personWorkingStatus != null ? personWorkingStatus : "";
	this.maritalStatus = maritalStatus != null ? maritalStatus : "";
	this.spouseCpr = spouseCpr != null ? spouseCpr : "";
	this.spouseWorkingStatus = personWorkingStatus != null ? personWorkingStatus : "";
	this.noOfChildren = noOfChildren != null ? noOfChildren :0;
	this.noOfChildrenWorking = noOfChildrenWorking != null ? noOfChildrenWorking :0;
	
	this.buildingNumber =noOfChildrenWorking != null ? noOfChildrenWorking :0;
	this.buildingAlphaArabic = buildingAlphaArabic != null ? buildingAlphaArabic : "";
	this.buildingAlphaEnglish = buildingAlphaEnglish != null ? buildingAlphaEnglish : "";
	this.faltNumber = faltNumber != null ? faltNumber :0;
	this.blockNumber = blockNumber != null ? blockNumber :0;	
	this.roadNumber = roadNumber != null ? roadNumber :0;
	this.areaArabicName = areaArabicName != null ? areaArabicName : "";
	this.areaEnglishName = areaEnglishName != null ? areaEnglishName : "";	
	this.applicantArabicName = applicantArabicName != null ? applicantArabicName : "";
	this.applicantEnglishName = applicantEnglishName != null ? applicantEnglishName : "";
}




public String getPersonCpr() {
	return personCpr;
}




public String getPersonArabicName() {
	return personArabicName;
}




public String getPersonEnglishName() {
	return personEnglishName;
}




public String getGender() {
	return gender;
}




public String getBirthDate() {
	return birthDate;
}




public String getLivingStatus() {
	return livingStatus;
}




public String getPersonWorkingStatus() {
	return personWorkingStatus;
}




public String getMaritalStatus() {
	return maritalStatus;
}




public String getSpouseCpr() {
	return spouseCpr;
}




public String getSpouseWorkingStatus() {
	return spouseWorkingStatus;
}




public Integer getNoOfChildren() {
	return noOfChildren;
}




public Integer getNoOfChildrenWorking() {
	return noOfChildrenWorking;
}




public Integer getBuildingNumber() {
	return buildingNumber;
}




public String getBuildingAlphaArabic() {
	return buildingAlphaArabic;
}




public String getBuildingAlphaEnglish() {
	return buildingAlphaEnglish;
}




public Integer getFaltNumber() {
	return faltNumber;
}




public Integer getBlockNumber() {
	return blockNumber;
}




public Integer getRoadNumber() {
	return roadNumber;
}




public String getAreaArabicName() {
	return areaArabicName;
}




public String getAreaEnglishName() {
	return areaEnglishName;
}




public String getApplicantArabicName() {
	return applicantArabicName;
}




public String getApplicantEnglishName() {
	return applicantEnglishName;
}




public void setPersonCpr(String personCpr) {
	this.personCpr = personCpr;
}




public void setPersonArabicName(String personArabicName) {
	this.personArabicName = personArabicName;
}




public void setPersonEnglishName(String personEnglishName) {
	this.personEnglishName = personEnglishName;
}




public void setGender(String gender) {
	this.gender = gender;
}




public void setBirthDate(String birthDate) {
	this.birthDate = birthDate;
}




public void setLivingStatus(String livingStatus) {
	this.livingStatus = livingStatus;
}




public void setPersonWorkingStatus(String personWorkingStatus) {
	this.personWorkingStatus = personWorkingStatus;
}




public void setMaritalStatus(String maritalStatus) {
	this.maritalStatus = maritalStatus;
}




public void setSpouseCpr(String spouseCpr) {
	this.spouseCpr = spouseCpr;
}




public void setSpouseWorkingStatus(String spouseWorkingStatus) {
	this.spouseWorkingStatus = spouseWorkingStatus;
}




public void setNoOfChildren(Integer noOfChildren) {
	this.noOfChildren = noOfChildren;
}




public void setNoOfChildrenWorking(Integer noOfChildrenWorking) {
	this.noOfChildrenWorking = noOfChildrenWorking;
}




public void setBuildingNumber(Integer buildingNumber) {
	this.buildingNumber = buildingNumber;
}




public void setBuildingAlphaArabic(String buildingAlphaArabic) {
	this.buildingAlphaArabic = buildingAlphaArabic;
}




public void setBuildingAlphaEnglish(String buildingAlphaEnglish) {
	this.buildingAlphaEnglish = buildingAlphaEnglish;
}




public void setFaltNumber(Integer faltNumber) {
	this.faltNumber = faltNumber;
}




public void setBlockNumber(Integer blockNumber) {
	this.blockNumber = blockNumber;
}




public void setRoadNumber(Integer roadNumber) {
	this.roadNumber = roadNumber;
}




public void setAreaArabicName(String areaArabicName) {
	this.areaArabicName = areaArabicName;
}




public void setAreaEnglishName(String areaEnglishName) {
	this.areaEnglishName = areaEnglishName;
}




public void setApplicantArabicName(String applicantArabicName) {
	this.applicantArabicName = applicantArabicName;
}




public void setApplicantEnglishName(String applicantEnglishName) {
	this.applicantEnglishName = applicantEnglishName;
}




public String getAddressType() {
	return addressType;
}




public void setAddressType(String addressType) {
	this.addressType = addressType;
}




public String getMaritalStatusCode() {
	return maritalStatusCode;
}




public void setMaritalStatusCode(String maritalStatusCode) {
	this.maritalStatusCode = maritalStatusCode;
}







public Integer getNoOfWives() {
	return noOfWives;
}




public void setNoOfWives(Integer noOfWives) {
	this.noOfWives = noOfWives;
}




public List<ChildrenInfoOfHouseholdDTO> getChildrenInfoOfHouseholds() {
	return childrenInfoOfHouseholds;
}




public void setChildrenInfoOfHouseholds(
		List<ChildrenInfoOfHouseholdDTO> childrenInfoOfHouseholds) {
	this.childrenInfoOfHouseholds = childrenInfoOfHouseholds;
}






}
