package bh.gov.cio.integration.crs.retrieve.GCCfamily.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(
		propOrder =
		{ "cprNumber", "arabicName", "englishName", "arab", "GCC", "bahraini",
				"gender" ,"divorceDate"})
public class DivorcesDetailDTO
{
	private String	cprNumber;
	private String	arabicName;
	private String	englishName;
	private boolean	isArab;
	private boolean	isGCC;
	private boolean	isBahraini;
	private String	gender;
	private String	divorceDate;

	public DivorcesDetailDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public DivorcesDetailDTO(String cprNumber, String arabicName,
			String englishName, boolean isArab, boolean isGCC,
			boolean isBahraini, String gender,String divorceDate)
	{
		super();
		this.cprNumber = cprNumber != null ? cprNumber : "";
		this.arabicName = arabicName != null ? arabicName : "";
		this.englishName = englishName != null ? englishName : "";
		this.gender = gender != null ? gender : "";
		this.isArab = isArab;
		this.isGCC = isGCC;
		this.isBahraini = isBahraini;
		this.divorceDate = divorceDate;
	}

	@XmlElement(required = true)
	public String getArabicName()
	{
		return arabicName;
	}

	@XmlElement(required = true)
	public String getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(required = true)
	public String getEnglishName()
	{
		return englishName;
	}

	@XmlElement(required = true)
	public String getGender()
	{
		return gender;
	}

	@XmlElement(required = true)
	public boolean isArab()
	{
		return isArab;
	}

	@XmlElement(required = true)
	public boolean isBahraini()
	{
		return isBahraini;
	}

	@XmlElement(required = true)
	public boolean isGCC()
	{
		return isGCC;
	}

	public void setArab(boolean isArab)
	{
		this.isArab = isArab;
	}

	public void setArabicName(String arabicName)
	{
		this.arabicName = arabicName;
	}

	public void setBahraini(boolean isBahraini)
	{
		this.isBahraini = isBahraini;
	}

	public void setCprNumber(String cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setEnglishName(String englishName)
	{
		this.englishName = englishName;
	}

	public void setGCC(boolean isGCC)
	{
		this.isGCC = isGCC;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public void setDivorceDate(String divorceDate)
	{
		this.divorceDate = divorceDate;
	}

	public String getDivorceDate()
	{
		return divorceDate;
	}

}
