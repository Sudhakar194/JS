package bh.gov.cio.integration.crs.retrieve.person.service.dto;

public class PersonOwnedCRDTO
{
	private java.lang.Integer	crNumber;
	private java.lang.String	arabicFullName;
	private java.lang.String	englishFullName;

	public PersonOwnedCRDTO()
	{
		super();
	}

	public PersonOwnedCRDTO(Integer crNumber, String arabicFullName,
			String englishFullName)
	{
		super();
		this.crNumber = crNumber;
		this.arabicFullName = arabicFullName;
		this.englishFullName = englishFullName;
	}

	public java.lang.String getArabicFullName()
	{
		return arabicFullName;
	}

	public java.lang.Integer getCrNumber()
	{
		return crNumber;
	}

	public java.lang.String getEnglishFullName()
	{
		return englishFullName;
	}

	public void setArabicFullName(java.lang.String arabicFullName)
	{
		this.arabicFullName = arabicFullName;
	}

	public void setCrNumber(java.lang.Integer crNumber)
	{
		this.crNumber = crNumber;
	}

	public void setEnglishFullName(java.lang.String englishFullName)
	{
		this.englishFullName = englishFullName;
	}

}
