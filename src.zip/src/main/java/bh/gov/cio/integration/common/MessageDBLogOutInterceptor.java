/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package bh.gov.cio.integration.common;

import java.io.OutputStream;
import java.net.UnknownHostException;
import java.util.UUID;

import javax.xml.namespace.QName;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CacheAndWriteOutputStream;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.io.CachedOutputStreamCallback;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

import bh.gov.cio.integration.common.dao.LogDao;

/**
 * 
 */
@Configuration(value = "MessageDBLogOutInterceptor")
public class MessageDBLogOutInterceptor extends AbstractPhaseInterceptor<Message>
{
	/**
	 * Logger for this class
	 */
	private static final Logger	logger	= LoggerFactory.getLogger(MessageDBLogOutInterceptor.class);

	@Autowired
	protected LogDao			logLoaderDao;

	public MessageDBLogOutInterceptor()
	{
		super(Phase.PRE_STREAM);
		// getAfter().add(SAAJInInterceptor.class.getName());
	}

	@Override
	public void handleMessage(Message message) throws Fault
	{
		String IN_OR_OUT = "OUT";
		String IS_ERROR_MESSAGE = "F";
		String USERNAME = "";
		String MESSAGE_PAYLOAD = "";
		String REMARKS = "";
		String TARGET_APP = "";
		String WEBSERVICE_URL = "";
		String CLIENT_IP = "";
		UUID MESSAGE_ID = null;
		Integer CPR_NUMBER = null;
		try
		{
			Exchange exchange = message != null ? message.getExchange() : null;
			// Message inMessage = exchange != null ? exchange.getInMessage() : null;
			Message outMessage = exchange != null ? exchange.getOutMessage() : null;
			// Message inFaultMessage = exchange != null ? message.getExchange().getInFaultMessage() : null;
			Message outFaultMessage = exchange != null ? message.getExchange().getOutFaultMessage() : null;
			TARGET_APP = (String) exchange.get("MESSAGE.TARGET_APP");
			WEBSERVICE_URL = exchange.get(Message.WSDL_SERVICE) != null ? ((QName) exchange.get(Message.WSDL_SERVICE)).getLocalPart() : "";
			USERNAME = (String) exchange.get("MESSAGE.USERNAME");
			CLIENT_IP = (String) exchange.get("MESSAGE.REQUESTIP");
			MESSAGE_ID = (UUID) exchange.get("MESSAGE.ID");
			logger.debug("USERNAME : {}", USERNAME);
			logger.debug("CLIENT_IP : {}" , CLIENT_IP);

			Exception exception = message.getContent(Exception.class);
			if (exception != null)

			{
				REMARKS = ExceptionUtils.getStackTrace(exception);
			}

			if (message == outFaultMessage && outFaultMessage != null)
			{
				IS_ERROR_MESSAGE = "T";
				IN_OR_OUT = "OUT";
			}

			if (message == outMessage && outMessage != null)
			{
				IN_OR_OUT = "OUT";
			}

		}
		catch (final RuntimeException ex)
		{
			REMARKS = ExceptionUtils.getStackTrace(ex);
			logger.error("handleMessage(SoapMessage)", ex);
			throw ex;
		}
		catch (Exception e)
		{
			REMARKS = ExceptionUtils.getStackTrace(e);

		}
		finally
		{
			OutputStream out = message.getContent(OutputStream.class);
			if (out != null)
			{
				final CacheAndWriteOutputStream newOut = new CacheAndWriteOutputStream(out);
				newOut.registerCallback(new LoggingCallback(message, out, IN_OR_OUT, IS_ERROR_MESSAGE, USERNAME, MESSAGE_PAYLOAD, REMARKS,
						TARGET_APP, WEBSERVICE_URL, CLIENT_IP, MESSAGE_ID, CPR_NUMBER));
				message.setContent(OutputStream.class, newOut);
			}
		}

		if (logger.isDebugEnabled())
			logger.debug("handleMessage(SoapMessage) - end");

	}

	private void logToDB(String IN_OR_OUT, String MESSAGE_PAYLOAD, String REMARKS, String IS_ERROR_MESSAGE, String USERNAME, String TARGET_APP,
			String WEBSERVICE_URL, String CLIENT_IP, String MESSAGE_ID, Integer CPR_NUMBER)
	{

		try
		{
			 logger.debug("log to db :\n IN_OR_OUT :" + IN_OR_OUT + "\n IS_ERROR_MESSAGE" + IS_ERROR_MESSAGE + "\n USERNAME" + USERNAME
			 + "\n MESSAGE_PAYLOAD" + MESSAGE_PAYLOAD + "\n REMARKS" + REMARKS + "\n TARGET_APP" + TARGET_APP + "\n WEBSERVICE_URL"
			 + WEBSERVICE_URL + "\n CLIENT_IP" + CLIENT_IP + "\n MESSAGE_ID" + MESSAGE_ID);
			logLoaderDao.CreateLogRecord(IN_OR_OUT, MESSAGE_PAYLOAD, REMARKS, IS_ERROR_MESSAGE, USERNAME, TARGET_APP, WEBSERVICE_URL, CLIENT_IP,
					MESSAGE_ID, CPR_NUMBER);
		}
		catch (CannotGetJdbcConnectionException exception)
		{
//			exception.printStackTrace();
			logger.error("handleMessage(SoapMessage) - CannotGetJdbcConnectionException", exception);
		}
		catch (UnknownHostException exception)
		{
//			exception.printStackTrace();
			logger.error("handleMessage(SoapMessage) - UnknownHostException", exception);
		}
		catch (Exception exception)
		{
//			exception.printStackTrace();
			logger.error("handleMessage(SoapMessage)", exception);
		}
	}

	public class LoggingCallback implements CachedOutputStreamCallback
	{
		private final Message		message;
		private final OutputStream	origStream;
		private String				IN_OR_OUT;
		private String				IS_ERROR_MESSAGE;
		private String				USERNAME;
		private String				MESSAGE_PAYLOAD;
		private String				REMARKS;
		private String				TARGET_APP;
		private String				WEBSERVICE_URL;
		private String				CLIENT_IP;
		private UUID				MESSAGE_ID;
		private Integer				CPR_NUMBER;

		public LoggingCallback(final Message msg, final OutputStream os, String IN_OR_OUT, String IS_ERROR_MESSAGE, String USERNAME,
				String MESSAGE_PAYLOAD, String REMARKS, String TARGET_APP, String WEBSERVICE_URL, String CLIENT_IP, UUID MESSAGE_ID,
				Integer CPR_NUMBER)
		{
			this.message = msg;
			this.origStream = os;
			this.IN_OR_OUT = IN_OR_OUT;
			this.IS_ERROR_MESSAGE = IS_ERROR_MESSAGE;
			this.USERNAME = USERNAME;
			this.MESSAGE_PAYLOAD = MESSAGE_PAYLOAD;
			this.REMARKS = REMARKS;
			this.TARGET_APP = TARGET_APP;
			this.WEBSERVICE_URL = WEBSERVICE_URL;
			this.CLIENT_IP = CLIENT_IP;
			this.MESSAGE_ID = MESSAGE_ID;
		}

		public void onFlush(CachedOutputStream cos)
		{
		}

		public void onClose(CachedOutputStream cos)
		{
			try
			{
				StringBuilder builder = new StringBuilder();
				cos.writeCacheTo(builder);
				MESSAGE_PAYLOAD = builder.toString();
				logToDB(IN_OR_OUT, MESSAGE_PAYLOAD, REMARKS, IS_ERROR_MESSAGE, USERNAME, TARGET_APP, WEBSERVICE_URL, CLIENT_IP,
						MESSAGE_ID.toString(), CPR_NUMBER);
				message.setContent(OutputStream.class, origStream);
			}
			catch (Exception e)
			{
//				e.printStackTrace();
				logger.error("error:",e);
			}
		}

	}

}
