package bh.gov.cio.integration.common;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XMLServiceImpl 
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(XMLServiceImpl.class);

	/* (non-Javadoc)
	 * @see bh.gov.cio.integration.cio.basic.XMLServiceInterface#getXMLTagValueByName(java.lang.String, java.lang.String)
	 */
	public static String getXMLTagValueByName(String xmlString,String nodeTagName) 
	{
		if (logger.isDebugEnabled()) {
			logger.debug("getXMLTagValueByName(String, String) - start");
		}

		String xmlTagValue = "";
		HashMap<String,String> hm = getXMLDocumentElements(xmlString);
		xmlTagValue = hm.get(nodeTagName)!= null ? hm.get(nodeTagName) : "0";
		
		if (logger.isDebugEnabled()) {
			logger.debug("getXMLTagValueByName() -  : xmlTagValue = " + xmlTagValue + ", hm = " + hm);

			logger.debug("getXMLTagValueByName(String, String) - end");
		}
		return xmlTagValue;
	}
   /* (non-Javadoc)
 * @see bh.gov.cio.integration.cio.basic.XMLServiceInterface#getXMLDocumentElements(java.lang.String)
 */
public static HashMap<String, String> getXMLDocumentElements(String xmlString)
   {
	  HashMap<String, String> nodeTree = new HashMap<String, String>(); 
	  if (xmlString != null && !xmlString.equals(""))
	  {
		try 
		{
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db;
			db = dbf.newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xmlString));
		
			Document doc;
			doc = db.parse(is);
			doc.normalize();
			NodeList nl = doc.getElementsByTagName("*");
			Element e;
			int len;
			len = nl.getLength();
			for (int j=0; j < len; j++)
			{
				e = (Element)nl.item(j);
				if (e.hasChildNodes())
				{
					logger.info(e.getTagName() + ":"+e.getFirstChild().getNodeValue());
					nodeTree.put(e.getTagName(), e.getFirstChild().getNodeValue());
				}
			}
				
		}catch (ParserConfigurationException e1)
		{
			logger.error("getXMLTagValueByName(String, String)", e1);
		}catch (SAXException e2)
		{
			logger.error("getXMLTagValueByName(String, String)", e2);
		}catch (IOException e3)
		{
			logger.error("getXMLTagValueByName(String, String)", e3);
		}catch (Exception e4)
		{
			logger.error("getXMLTagValueByName(String, String)", e4);
		}
	  }
	  return nodeTree;
   }
public static void main(String[] args) {

//    	String cprNumber = "90909",PassportNumber = "A2323",NationalityCode="399";
      String msgRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
      		"<NAJIMTXN>\r\n" + 
      		"	<BasicHeader>\r\n" + 
      		"		<Sender>GDNPR-OS390</Sender>\r\n" + 
      		"		<Receiver>NAJIM-MOI</Receiver>\r\n" + 
      		"		<OriginationTimestamp>20060626104905</OriginationTimestamp>\r\n" + 
      		"		<TransmissionTimestamp>20060626104905</TransmissionTimestamp>\r\n" + 
      		"	</BasicHeader>\r\n" + 
      		"	<ApplicationHeader>\r\n" + 
      		"		<TransmissionMode>A</TransmissionMode>\r\n" + 
      		"		<TransactionType>RESPONSE</TransactionType>\r\n" + 
      		"		<TransactionCode>NAJIMMOI10</TransactionCode>\r\n" + 
      		"		<TransactionDesc>Get IO Status</TransactionDesc>\r\n" + 
      		"		<MessageIdentifier></MessageIdentifier>\r\n" + 
      		"	</ApplicationHeader>\r\n" + 
      		"	<Response>\r\n" + 
      		"		<StatusCode>0</StatusCode>\r\n" + 
      		"		<StatusMessage>0</StatusMessage>\r\n" + 
      		"		<ErrorCode/>\r\n" + 
      		"		<Remarks/>\r\n" + 
      		"	</Response>\r\n" + 
      		"	<Body>\r\n" + 
      		"		<CPRNumber>505505404</CPRNumber>\r\n" + 
      		"		<PassportNumber>A884321</PassportNumber>\r\n" + 
      		"		<Nationality></Nationality>\r\n" + 
      		"		<ArabicName>ccc</ArabicName>\r\n" + 
      		"		<EnglishName></EnglishName>\r\n" + 
      		"		<ArrivalDate></ArrivalDate>\r\n" + 
      		"		<DepartureDate></DepartureDate>\r\n" + 
      		"		<IOStatus>I</IOStatus>\r\n" + 
      		"	</Body>\r\n" + 
      		"</NAJIMTXN>\r\n" + 
      		"";    
      logger.debug(getXMLTagValueByName(msgRequest,"ArabicName"));
}
}
