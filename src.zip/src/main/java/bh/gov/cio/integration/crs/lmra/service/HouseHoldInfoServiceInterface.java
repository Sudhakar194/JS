package bh.gov.cio.integration.crs.lmra.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.lmra.dto.HouseHoldInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "HouseHoldInfoService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public interface HouseHoldInfoServiceInterface {
	@WebResult(name = "HouseHoldInfo")
	@WebMethod(operationName = "getHouseHoldInfo")
	
	HouseHoldInfoDTO getHouseHoldInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "nationalityCode") @XmlElement(required = true) String nationalityCode,
			@WebParam(name = "applicantIdNumber") @XmlElement(required = true) String applicantIdNumber,
			@WebParam(name = "applicantNationalityCode") @XmlElement(required = true) String applicantNationalityCode) throws ApplicationExceptionInfo;

}
