package bh.gov.cio.integration.crs.validateDependent;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonFinancialSupportInfoDTO;
import bh.gov.cio.integration.crs.validateDependent.dto.GetDependentMemberNameDTO;
import bh.gov.cio.integration.crs.validateDependent.service.GetDependentMemberNameServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "GetDependentMemberNameService", targetNamespace = "http://service.egov.crs.integration.gov.bh/")
public class GetDependentMemberNameServiceImpl implements GetDependentMemberNameServiceInterface {
	
	private static final Logger logger = LoggerFactory.getLogger(GetDependentMemberNameServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationService;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;
	@Autowired
	private PropertyServiceImpl				propImpl;
	
	
	@Override
	@Secured({ "ROLE_ValidateDependentMemder" })
	@WebMethod(operationName = "ValidateDependentMemder")
	public GetDependentMemberNameDTO ValidateDependentMemder(SecurityTagObject security, String idNumber,
			String dependentIdNumber) throws ApplicationExceptionInfo {
		PersonService ps = crsService.getPersonServiceRef();
		PersonBasicInfo dpi;
		PersonSummary psummary,dsummary;
		FamilyService dFamilyDetails;
		
		Integer dCPR = new Integer(dependentIdNumber);
		Integer pCPR = new Integer(idNumber);
		try{
			psummary = ps.getPersonSummary(pCPR);
			dpi = ps.getPersonBasicInfo(dCPR);
			dsummary = ps.getPersonSummary(dCPR);
			
			
		}catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("RetrieveEmploymentBasicDetails(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Retrieving Data",
					new ApplicationException("Error Retrieving Data From Backend", "004"));
		}
		
		
		
		
			
		return null;
	}
	
	

	

}
