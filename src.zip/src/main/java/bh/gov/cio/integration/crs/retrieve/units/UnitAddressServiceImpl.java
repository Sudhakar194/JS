package bh.gov.cio.integration.crs.retrieve.units;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.util.exception.ApplicationException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.crs.util.exception.UnitException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.units.service.UnitAddressServiceInterface;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitAddressServiceBasicInfoDTO;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(
		name = "UnitAddressService",
		targetNamespace = "http://service.units.retrieve.crs.integration.cio.gov.bh/")
//serviceName = "UnitAddressService",
public class UnitAddressServiceImpl implements UnitAddressServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(UnitAddressServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getUnitAddress" })
	@WebMethod(operationName = "getUnitAddress")
	public UnitAddressServiceBasicInfoDTO getUnitAddress(
			SecurityTagObject security, Integer unitNumber)
			throws ApplicationException, UnitException
	{
		if (logger.isDebugEnabled())
			logger.debug("getUnitAddress(Integer) - start");

		UnitAddressServiceBasicInfoDTO returnedAddress = null;
		try
		{
			final List<bh.gov.cio.crs.model.unit.UnitAddress> addresses = getCrsService()
					.getUnitServiceRef().getUnitAddresses(unitNumber);
			if (addresses.size() == 0)
				throw new BusinessException("Unit Address Details Not found");

			if (addresses != null)
			{
				final bh.gov.cio.crs.model.unit.UnitAddress returnedAddressRow = addresses
						.get(addresses.size() - 1);
				returnedAddress = new UnitAddressServiceBasicInfoDTO(
						returnedAddressRow.getBlockNumber(),
						returnedAddressRow.getBlockArName(),
						returnedAddressRow.getBuildingNumber(),
						returnedAddressRow.getAlpha(),
						returnedAddressRow.getAlpha(),
						returnedAddressRow.getBuildingArName(),
						returnedAddressRow.getBuildingEnName(),
						returnedAddressRow.getBlockEnName(),
						returnedAddressRow.getRoadNumber(),
						returnedAddressRow.getRoadArName(),
						returnedAddressRow.getRoadEnName(), 0/*
															 * returnedAddressRow.getAreaCode ()
															 */, ""/*
																	 * returnedAddressRow. getAreaNameArabic()
																	 */,
						"" /*
							 * returnedAddressRow . getAreaNameEnglish ()
							 */, returnedAddressRow.getFlatNumber(),
						returnedAddressRow.getRegionArName(),
						returnedAddressRow.getRegionEnName());
			}

			if (logger.isDebugEnabled())
				logger.debug("getUnitAddress(Integer) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonSpecialContact(Integer, Integer, Date) Error: "
						+ exception.getMessage());
			throw new UnitException("Unit Address Details Not found");
		}
		return returnedAddress;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
