package bh.gov.cio.integration.crs.egov.gdt.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "ValidateBasicPersonInfoService", targetNamespace = "http://service.gdt.egov.crs.integration.cio.gov.bh/")
public interface ValidateBasicPersonInfoServiceInterface {

	
	
	
	@WebResult(name = "ValidatePersonBasicInformation")
	@WebMethod(operationName = "validateBasicPersonInfo")
	Boolean validatePersonBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;
}
