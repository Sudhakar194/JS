package bh.gov.cio.integration.crs.lmra.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "ForeignerEmployer", propOrder =
{  "employerNumber" , "employerNameAr" , "employerNameEn" })
public class GetForeignerEmployerDTO
{

	private long employerNumber;
	private String employerNameAr;
	private String employerNameEn;

	public GetForeignerEmployerDTO()
	{
		super();

	}





	public GetForeignerEmployerDTO(long employerNumber, String employerNameAr,
			String employerNameEn) {
		super();
		this.employerNumber = employerNumber;
		this.employerNameAr = employerNameAr;
		this.employerNameEn = employerNameEn;
	}







	@XmlElement(name = "employerNumber", required = true)
	public long getEmployerNumber() {
		return employerNumber;
	}


	public void setEmployerNumber(long employerNumber) {
		this.employerNumber = employerNumber;
	}




	@XmlElement(name = "employerNameAr", required = true)
	public String getEmployerNameAr() {
		return employerNameAr;
	}





	public void setEmployerNameAr(String employerNameAr) {
		this.employerNameAr = employerNameAr;
	}




	@XmlElement(name = "employerNameEn", required = true)
	public String getEmployerNameEn() {
		return employerNameEn;
	}





	public void setEmployerNameEn(String employerNameEn) {
		this.employerNameEn = employerNameEn;
	}
	
	

	
}
