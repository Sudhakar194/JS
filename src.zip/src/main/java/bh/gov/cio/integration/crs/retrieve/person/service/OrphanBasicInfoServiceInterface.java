package bh.gov.cio.integration.crs.retrieve.person.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.OrphanServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "OrphanBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface OrphanBasicInfoServiceInterface
{

	@WebResult(name = "OrphanBasicInformation")
	@WebMethod(operationName = "getOrphanBasicInfoByCPR")
	OrphanServiceBasicInfoDTO getOrphanBasicInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber, @WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "OrphanBasicInformation")
	@WebMethod(operationName = "getOrphanBasicInfoByMotherCPR")
	OrphanServiceBasicInfoDTO getOrphanBasicInfoByMotherCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "MotherCPRNumber") @XmlElement(required = true) Integer motherCPRNumber, @WebParam(name = "FatherCPRNumber") @XmlElement(required = true) Integer fatherCPRNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber, @WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate)
			throws ApplicationExceptionInfo;

}
