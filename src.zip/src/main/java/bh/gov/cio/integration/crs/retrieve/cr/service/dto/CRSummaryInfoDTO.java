package bh.gov.cio.integration.crs.retrieve.cr.service.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "CRDetails", propOrder =
{ "crNumber", "crArabicName", "crEnglishName", "companyStatusCode", "licenseExpiryDate", "countryArNm", "countryEnNm", "operationStartDate",
		"operationEndDate", "crActivitiesList", "crOwnersList", "crLegalStatusCode", "crLegalArName", "crLegalEnName", "crSectorCode",
		"crSectorArName", "crSectorEnName", "authorizedCapital", "paidCapital", "issuedCapital" })
public class CRSummaryInfoDTO
{

	private Integer crNumber;
	private String crArabicName;
	private String crEnglishName;
	private String companyStatusCode;
	private String licenseExpiryDate;
	private String countryArNm;
	private String countryEnNm;
	private String operationEndDate;
	private String operationStartDate;
	private String crLegalStatusCode;
	private String crLegalArName;
	private String crLegalEnName;
	private String crSectorCode;
	private String crSectorArName;
	private String crSectorEnName;
	private int authorizedCapital;
	private int paidCapital;
	private int issuedCapital;
	private List<CRActivityTypeInfoDTO> crActivitiesList;
	private List<CROwnerInfoDTO> crOwnersList;

	public CRSummaryInfoDTO()
	{
		super();

	}

	public CRSummaryInfoDTO(Integer crNumber, String crArabicName, String crEnglishName, String companyStatusCode, String licenseExpiryDate,
			String countryArNm, String countryEnNm, String operationEndDate, String operationStartDate, String crLegalStatusCode,
			String crLegalArName, String crLegalEnName, String crSectorCode, String crSectorArName, String crSectorEnName, int authorizedCapital,
			int paidCapital, int issuedCapital, List<CRActivityTypeInfoDTO> crActivitiesList, List<CROwnerInfoDTO> crOwnersList)
	{
		super();
		this.crNumber = crNumber;
		this.crArabicName = crArabicName;
		this.crEnglishName = crEnglishName;
		this.companyStatusCode = companyStatusCode;
		this.licenseExpiryDate = licenseExpiryDate;
		this.countryArNm = countryArNm;
		this.countryEnNm = countryEnNm;
		this.operationEndDate = operationEndDate;
		this.operationStartDate = operationStartDate;
		this.crLegalStatusCode = crLegalStatusCode;
		this.crLegalArName = crLegalArName;
		this.crLegalEnName = crLegalEnName;
		this.crSectorCode = crSectorCode;
		this.crSectorArName = crSectorArName;
		this.crSectorEnName = crSectorEnName;
		this.authorizedCapital = authorizedCapital;
		this.paidCapital = paidCapital;
		this.issuedCapital = issuedCapital;
		this.crActivitiesList = crActivitiesList;
		this.crOwnersList = crOwnersList;
	}

	@XmlElement(name = "AuthorizedCapital", required = true)
	public int getAuthorizedCapital()
	{
		return authorizedCapital;
	}

	@XmlElement(name = "CompanyStatusCode", required = true)
	public String getCompanyStatusCode()
	{
		return companyStatusCode;
	}

	@XmlElement(name = "CountryArName", required = true)
	public String getCountryArNm()
	{
		return countryArNm;
	}

	@XmlElement(name = "CountryEnName", required = true)
	public String getCountryEnNm()
	{
		return countryEnNm;
	}

	@XmlElement(name = "ActivityDetails", required = true)
	public List<CRActivityTypeInfoDTO> getCrActivitiesList()
	{
		return crActivitiesList;
	}

	@XmlElement(name = "CrArabicName", required = true)
	public String getCrArabicName()
	{
		return crArabicName;
	}

	@XmlElement(name = "CrEnglishName", required = true)
	public String getCrEnglishName()
	{
		return crEnglishName;
	}

	@XmlElement(name = "CrLegalStatusArName", required = true)
	public String getCrLegalArName()
	{
		return crLegalArName;
	}

	@XmlElement(name = "CrLegalStatusEnName", required = true)
	public String getCrLegalEnName()
	{
		return crLegalEnName;
	}

	@XmlElement(name = "CrLegalStatusCode", required = true)
	public String getCrLegalStatusCode()
	{
		return crLegalStatusCode;
	}

	@XmlElement(name = "CrNumber", required = true)
	public Integer getCrNumber()
	{
		return crNumber;
	}

	@XmlElement(name = "CrOwnerDetails", required = true)
	public List<CROwnerInfoDTO> getCrOwnersList()
	{
		return crOwnersList;
	}

	@XmlElement(name = "CrSectorArName", required = true)
	public String getCrSectorArName()
	{
		return crSectorArName;
	}

	@XmlElement(name = "CrSectorCode", required = true)
	public String getCrSectorCode()
	{
		return crSectorCode;
	}

	@XmlElement(name = "CrSectorEnName", required = true)
	public String getCrSectorEnName()
	{
		return crSectorEnName;
	}

	@XmlElement(name = "IssuedCapital", required = true)
	public int getIssuedCapital()
	{
		return issuedCapital;
	}

	@XmlElement(name = "LicenseExpiryDate", required = true)
	public String getLicenseExpiryDate()
	{
		return licenseExpiryDate;
	}

	@XmlElement(name = "OperationEndDate", required = true)
	public String getOperationEndDate()
	{
		return operationEndDate;
	}

	@XmlElement(name = "OperationStartDate", required = true)
	public String getOperationStartDate()
	{
		return operationStartDate;
	}

	@XmlElement(name = "PaidCapital", required = true)
	public int getPaidCapital()
	{
		return paidCapital;
	}

	public void setAuthorizedCapital(int authorizedCapital)
	{
		this.authorizedCapital = authorizedCapital;
	}

	public void setCompanyStatusCode(String companyStatusCode)
	{
		this.companyStatusCode = companyStatusCode;
	}

	public void setCountryArNm(String countryArNm)
	{
		this.countryArNm = countryArNm;
	}

	public void setCountryEnNm(String countryEnNm)
	{
		this.countryEnNm = countryEnNm;
	}

	public void setCrActivitiesList(List<CRActivityTypeInfoDTO> crActivitiesList)
	{
		this.crActivitiesList = crActivitiesList;
	}

	public void setCrArabicName(String crArabicName)
	{
		this.crArabicName = crArabicName;
	}

	public void setCrEnglishName(String crEnglishName)
	{
		this.crEnglishName = crEnglishName;
	}

	public void setCrLegalArName(String crLegalArName)
	{
		this.crLegalArName = crLegalArName;
	}

	public void setCrLegalEnName(String crLegalEnName)
	{
		this.crLegalEnName = crLegalEnName;
	}

	public void setCrLegalStatusCode(String crLegalStatusCode)
	{
		this.crLegalStatusCode = crLegalStatusCode;
	}

	public void setCrNumber(Integer crNumber)
	{
		this.crNumber = crNumber;
	}

	public void setCrOwnersList(List<CROwnerInfoDTO> crOwnersList)
	{
		this.crOwnersList = crOwnersList;
	}

	public void setCrSectorArName(String crSectorArName)
	{
		this.crSectorArName = crSectorArName;
	}

	public void setCrSectorCode(String crSectorCode)
	{
		this.crSectorCode = crSectorCode;
	}

	public void setCrSectorEnName(String crSectorEnName)
	{
		this.crSectorEnName = crSectorEnName;
	}

	public void setIssuedCapital(int issuedCapital)
	{
		this.issuedCapital = issuedCapital;
	}

	public void setLicenseExpiryDate(String licenseExpiryDate)
	{
		this.licenseExpiryDate = licenseExpiryDate;
	}

	public void setOperationEndDate(String operationEndDate)
	{
		this.operationEndDate = operationEndDate;
	}

	public void setOperationStartDate(String operationStartDate)
	{
		this.operationStartDate = operationStartDate;
	}

	public void setPaidCapital(int paidCapital)
	{
		this.paidCapital = paidCapital;
	}

}
