package bh.gov.cio.integration.crs.egov.frequences.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "FrequencesInfo", propOrder = { "establishmentNumber","englishName"})
public class FrequencesDTO {

	public FrequencesDTO() {
	}

	private Integer establishmentNumber;
	private String englishName;

	public FrequencesDTO(Integer establishmentNumber, String englishName) {
		super();
		this.establishmentNumber = establishmentNumber;
		this.englishName = englishName;
	}

	@XmlElement(name = "establishmentNumber")
	public Integer getEstablishmentNumber() {
		return establishmentNumber;
	}

	public void setEstablishmentNumber(Integer establishmentNumber) {
		this.establishmentNumber = establishmentNumber;
	}

	@XmlElement(name = "englishName")
	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}


}
