package bh.gov.cio.integration.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class NumberServiceImpl //implements NumberServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(NumberServiceImpl.class);

	/* (non-Javadoc)
	 * @see bh.gov.cio.integration.cio.basic.NumberServiceInterface#getFormattedSixCharactersStringFromInteger(java.lang.Integer)
	 */
	public static String getFormattedSixCharactersStringFromInteger(Integer Code)
	{
		String formattedStr = "0";
		try
		{
			formattedStr = String.format("%06d", Code);
		} catch (Exception e)
		{
			logger.error("getFormattedSixCharactersStringFromInteger(Integer)", e);
		}
		return formattedStr;
	}

}
