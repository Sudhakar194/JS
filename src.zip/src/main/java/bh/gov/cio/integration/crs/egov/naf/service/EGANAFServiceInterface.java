package bh.gov.cio.integration.crs.egov.naf.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.naf.dto.NAFDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NAFSoapService", targetNamespace = "http://service.naf.egov.crs.integration.cio.gov.bh/")
public interface EGANAFServiceInterface
{
	@WebResult(name = "PersonAuthenticationResult")
	@WebMethod(operationName = "checkPersonInfo")
	NAFDTO checkPersonInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "dateOfBirth") @XmlElement(required = true) Date dateOfBirth,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate, 
			@WebParam(name = "cardSerialNumber") @XmlElement(required = true) String cardSerialNumber) throws ApplicationExceptionInfo;
}
