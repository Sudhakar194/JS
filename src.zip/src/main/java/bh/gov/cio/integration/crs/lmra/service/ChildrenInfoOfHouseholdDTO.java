package bh.gov.cio.integration.crs.lmra.service;

public class ChildrenInfoOfHouseholdDTO {
	
	private String gender;
	private Integer age;
	private String workingStatus;
	
	public ChildrenInfoOfHouseholdDTO() {
		// TODO Auto-generated constructor stub
	}

	public ChildrenInfoOfHouseholdDTO(String gender, Integer age,
			String workingStatus) {
		super();
		this.gender =  gender != null ? gender : "";
		this.workingStatus =  workingStatus != null ? workingStatus : "";
		this.age =  age != null ? age : 0;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getWorkingStatus() {
		return workingStatus;
	}

	public void setWorkingStatus(String workingStatus) {
		this.workingStatus = workingStatus;
	}
	
	
	

}
