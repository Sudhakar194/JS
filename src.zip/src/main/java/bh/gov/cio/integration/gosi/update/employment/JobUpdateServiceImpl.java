package bh.gov.cio.integration.gosi.update.employment;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.service.EmploymentService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.gosi.update.employment.service.JobUpdateServiceInterface;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "JobUpdateService",
		targetNamespace = "http://service.employment.update.gosi.integration.cio.gov.bh/")
//, serviceName = "JobUpdateService"
public class JobUpdateServiceImpl implements JobUpdateServiceInterface
{
	private static final Logger	logger	= LoggerFactory.getLogger(JobUpdateServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@Override
	@WebMethod(operationName = "updateJobDetails")
	@Secured(
	{ "ROLE_updateJobDetails" })
	public boolean updateJobDetails(SecurityTagObject security, Integer cprNumber, Integer employerNumber, String occupationCode,
			String occupationType, Date jobStartDate, Date jobEndDate, String employmentStatus) throws ApplicationExceptionInfo
	{
		try
		{
			// Check if record exists
			EmploymentService es = crsService.getEmploymentServiceRef();
			List<Employment> empList = es.getActiveEmployments(cprNumber);
			boolean exists = false;
			for (Iterator<Employment> iterator = empList.iterator(); iterator.hasNext();)
			{
				Employment emp = (Employment) iterator.next();
				logger.debug(""+emp);
			}

			// if (jobEndDate is null) // New
			// Employment empData = new Employment();
			// empData.setEmployer(employerNumber);
			// empData.setOccupationCode(occupationCode);
			// empData.setStartDate(jobStartDate);
			//
			// crsService.getEmploymentServiceRef().updateEmployment(empData, "GOSI");
		}
		catch (Exception exception)
		{
			throw new ApplicationExceptionInfo("Problem Handling Job ", new ApplicationException(exception.getMessage()));
		}
		return true;
	}

}
