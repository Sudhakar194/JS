package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "OrphanApplicantAddress", propOrder =
{ "areaCode", "areaNameArabic", "areaNameEnglish", "flatNumber", "regionNameArabic", "regionNameEnglish", "blockNumber", "blockNameArabic",
		"buildingNumber", "nameAlphaEnglish", "nameAlphaArabic", "buildingNameArabic", "buildingNameEnglish", "blockNameEnglish", "roadNumber",
		"roadNameArabic", "roadNameEnglish", "governorateNameArabic", "governorateNameEnglish","addressTypeCode" })

public class OrphanApplicantAddressDTO
{
	private java.lang.Integer	areaCode;
	private java.lang.String	areaNameArabic;
	private java.lang.String	areaNameEnglish;
	private java.lang.Integer	flatNumber;
	private java.lang.String	regionNameArabic;
	private java.lang.String	regionNameEnglish;
	private java.lang.Integer	blockNumber;
	private java.lang.String	blockNameArabic;
	private java.lang.Integer	buildingNumber;
	private java.lang.String	nameAlphaEnglish;
	private java.lang.String	nameAlphaArabic;
	private java.lang.String	buildingNameArabic;
	private java.lang.String	buildingNameEnglish;
	private java.lang.String	blockNameEnglish;
	private java.lang.Integer	roadNumber;
	private java.lang.String	roadNameArabic;
	private java.lang.String	roadNameEnglish;
	private java.lang.String	governorateNameArabic;
	private java.lang.String	governorateNameEnglish;
	private java.lang.String	addressTypeCode;
	public OrphanApplicantAddressDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public OrphanApplicantAddressDTO(Integer areaCode, String areaNameArabic, String areaNameEnglish, Integer flatNumber, String regionNameArabic, String regionNameEnglish, Integer blockNumber,
			String blockNameArabic, Integer buildingNumber, String nameAlphaEnglish, String nameAlphaArabic, String buildingNameArabic, String buildingNameEnglish, String blockNameEnglish,
			Integer roadNumber, String roadNameArabic, String roadNameEnglish, String governorateNameArabic, String governorateNameEnglish, String addressTypeCode)
	{
		super();
		this.blockNumber = blockNumber != null ? blockNumber : 0;
		this.blockNameArabic = blockNameArabic != null ? blockNameArabic : "";
		this.buildingNumber = buildingNumber != null ? buildingNumber : 0;
		this.nameAlphaEnglish = nameAlphaEnglish != null ? nameAlphaEnglish : "";
		this.nameAlphaArabic = nameAlphaArabic != null ? nameAlphaArabic : "";
		this.buildingNameArabic = buildingNameArabic != null ? buildingNameArabic : "";
		this.buildingNameEnglish = buildingNameEnglish != null ? buildingNameEnglish : "";
		this.blockNameEnglish = blockNameEnglish != null ? blockNameEnglish : "";
		this.roadNumber = roadNumber != null ? roadNumber : 0;
		this.roadNameArabic = roadNameArabic != null ? roadNameArabic : "";
		this.roadNameEnglish = roadNameEnglish != null ? roadNameEnglish : "";
		this.areaCode = areaCode != null ? areaCode : 0;
		this.areaNameArabic = areaNameArabic != null ? areaNameArabic : "";
		this.areaNameEnglish = areaNameEnglish != null ? areaNameEnglish : "";
		this.flatNumber = flatNumber != null ? flatNumber : 0;
		this.regionNameArabic = regionNameArabic != null ? regionNameArabic : "";
		this.regionNameEnglish = regionNameEnglish != null ? regionNameEnglish : "";
		this.governorateNameArabic = governorateNameArabic != null ? governorateNameArabic : "";
		this.governorateNameEnglish = governorateNameEnglish != null ? governorateNameEnglish : "";
		this.addressTypeCode = addressTypeCode != null ? addressTypeCode : "";
	}

	@XmlElement(name = "AreaCode")
	public java.lang.Integer getAreaCode()
	{
		return areaCode;
	}

	@XmlElement(name = "AreaNameArabic")
	public java.lang.String getAreaNameArabic()
	{
		return areaNameArabic;
	}

	@XmlElement(name = "AreaNameEnglish")
	public java.lang.String getAreaNameEnglish()
	{
		return areaNameEnglish;
	}

	@XmlElement(name = "BlockNameArabic")
	public java.lang.String getBlockNameArabic()
	{
		return blockNameArabic;
	}

	@XmlElement(name = "BlockNameEnglish")
	public java.lang.String getBlockNameEnglish()
	{
		return blockNameEnglish;
	}

	@XmlElement(name = "BlockNumber")
	public java.lang.Integer getBlockNumber()
	{
		return blockNumber;
	}

	@XmlElement(name = "BuildingNameArabic")
	public java.lang.String getBuildingNameArabic()
	{
		return buildingNameArabic;
	}

	@XmlElement(name = "BuildingNameEnglish")
	public java.lang.String getBuildingNameEnglish()
	{
		return buildingNameEnglish;
	}

	@XmlElement(name = "BuildingNumber")
	public java.lang.Integer getBuildingNumber()
	{
		return buildingNumber;
	}

	@XmlElement(name = "FlatNumber")
	public java.lang.Integer getFlatNumber()
	{
		return flatNumber;
	}

	@XmlElement(name = "NameAlphaArabic")
	public java.lang.String getNameAlphaArabic()
	{
		return nameAlphaArabic;
	}

	@XmlElement(name = "NameAlphaEnglish")
	public java.lang.String getNameAlphaEnglish()
	{
		return nameAlphaEnglish;
	}

	@XmlElement(name = "RegionNameArabic")
	public java.lang.String getRegionNameArabic()
	{
		return regionNameArabic;
	}

	@XmlElement(name = "RegionNameEnglish")
	public java.lang.String getRegionNameEnglish()
	{
		return regionNameEnglish;
	}

	@XmlElement(name = "RoadNameArabic")
	public java.lang.String getRoadNameArabic()
	{
		return roadNameArabic;
	}

	@XmlElement(name = "RoadNameEnglish")
	public java.lang.String getRoadNameEnglish()
	{
		return roadNameEnglish;
	}

	@XmlElement(name = "RoadNumber")
	public java.lang.Integer getRoadNumber()
	{
		return roadNumber;
	}

	public void setAreaCode(java.lang.Integer areaCode)
	{
		this.areaCode = areaCode;
	}

	public void setAreaNameArabic(java.lang.String areaNameArabic)
	{
		this.areaNameArabic = areaNameArabic;
	}

	public void setAreaNameEnglish(java.lang.String areaNameEnglish)
	{
		this.areaNameEnglish = areaNameEnglish;
	}

	public void setBlockNameArabic(java.lang.String blockNameArabic)
	{
		this.blockNameArabic = blockNameArabic;
	}

	public void setBlockNameEnglish(java.lang.String blockNameEnglish)
	{
		this.blockNameEnglish = blockNameEnglish;
	}

	public void setBlockNumber(java.lang.Integer blockNumber)
	{
		this.blockNumber = blockNumber;
	}

	public void setBuildingNameArabic(java.lang.String buildingNameArabic)
	{
		this.buildingNameArabic = buildingNameArabic;
	}

	public void setBuildingNameEnglish(java.lang.String buildingNameEnglish)
	{
		this.buildingNameEnglish = buildingNameEnglish;
	}

	public void setBuildingNumber(java.lang.Integer buildingNumber)
	{
		this.buildingNumber = buildingNumber;
	}

	public void setFlatNumber(java.lang.Integer flatNumber)
	{
		this.flatNumber = flatNumber;
	}

	public void setNameAlphaArabic(java.lang.String nameAlphaArabic)
	{
		this.nameAlphaArabic = nameAlphaArabic;
	}

	public void setNameAlphaEnglish(java.lang.String nameAlphaEnglish)
	{
		this.nameAlphaEnglish = nameAlphaEnglish;
	}

	public void setRegionNameArabic(java.lang.String regionNameArabic)
	{
		this.regionNameArabic = regionNameArabic;
	}

	public void setRegionNameEnglish(java.lang.String regionNameEnglish)
	{
		this.regionNameEnglish = regionNameEnglish;
	}

	public void setRoadNameArabic(java.lang.String roadNameArabic)
	{
		this.roadNameArabic = roadNameArabic;
	}

	public void setRoadNameEnglish(java.lang.String roadNameEnglish)
	{
		this.roadNameEnglish = roadNameEnglish;
	}

	public void setRoadNumber(java.lang.Integer roadNumber)
	{
		this.roadNumber = roadNumber;
	}

	public java.lang.String getGovernorateNameArabic()
	{
		return governorateNameArabic;
	}

	public void setGovernorateNameArabic(java.lang.String governorateNameArabic)
	{
		this.governorateNameArabic = governorateNameArabic;
	}

	public java.lang.String getGovernorateNameEnglish()
	{
		return governorateNameEnglish;
	}

	public void setGovernorateNameEnglish(java.lang.String governorateNameEnglish)
	{
		this.governorateNameEnglish = governorateNameEnglish;
	}

	public void setAddressTypeCode(java.lang.String addressTypeCode)
	{
		this.addressTypeCode = addressTypeCode;
	}

	public java.lang.String getAddressTypeCode()
	{
		return addressTypeCode;
	}


}
