package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "UnitAddress", propOrder = { "flatNumber", "roadNumber", "buildingNumber", "nameAlphaEnglish",
		"blockNumber" })
public class UnitAddressInfoDTO {

	private Integer blockNumber;
	private Integer buildingNumber;
	private String nameAlphaEnglish;
	private Integer roadNumber;
	private Integer flatNumber;

	public UnitAddressInfoDTO(Integer blockNumber, Integer buildingNumber, String nameAlphaEnglish, Integer roadNumber,
			Integer flatNumber) {
		super();
		this.blockNumber = blockNumber;
		this.buildingNumber = buildingNumber;
		this.nameAlphaEnglish = nameAlphaEnglish;
		this.roadNumber = roadNumber;
		this.flatNumber = flatNumber;
	}

	public UnitAddressInfoDTO() {
		super();
	}

	@XmlElement(name = "blockNumber", required = true)
	public Integer getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}

	@XmlElement(name = "buildingNumber", required = true)
	public Integer getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(Integer buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	@XmlElement(name = "nameAlphaEnglish", required = true)
	public String getNameAlphaEnglish() {
		return nameAlphaEnglish;
	}

	public void setNameAlphaEnglish(String nameAlphaEnglish) {
		this.nameAlphaEnglish = nameAlphaEnglish;
	}

	@XmlElement(name = "roadNumber", required = true)
	public Integer getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(Integer roadNumber) {
		this.roadNumber = roadNumber;
	}

	@XmlElement(name = "flatNumber", required = true)
	public Integer getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(Integer flatNumber) {
		this.flatNumber = flatNumber;
	}

}
