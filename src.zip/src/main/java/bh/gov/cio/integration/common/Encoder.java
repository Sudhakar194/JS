package bh.gov.cio.integration.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Encoder
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Logger	logger	= LoggerFactory.getLogger(CRSServicesProviderServiceImpl.class);
		// StandardPasswordEncoder encoder = new StandardPasswordEncoder();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		System.out.println("hash = '" + encoder.hashCode() + "'");

		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("test") + "' WHERE USERNAME='test';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("3qel3beedeUFjcHLGfd2xDKY0g=") + "' WHERE USERNAME='MoIC';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("ci0g0$i") + "' WHERE USERNAME='gosi';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("E/lT4+kNzi2BQSoVmN/lbEjpfrA=") + "' WHERE USERNAME='MOH';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("eg@soci@lp0rt@l") + "' WHERE USERNAME='ega_social_portal';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("gdt@b0d@bi") + "' WHERE USERNAME='GDTAbuDhabi';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("m0jp@$$w0rd") + "' WHERE USERNAME='moj';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("MDEgfi2SS/ZUZ2XkiV82LO7jtbg=") + "' WHERE USERNAME='MOIPP';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("n@j!m") + "' WHERE USERNAME='Najim';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("PA$$W0RD") + "' WHERE USERNAME='ADMIN';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("RXtYCGW8J5sEnXDox6cURld5ndY=") + "' WHERE USERNAME='mpension';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("XQoJl1z9DKtF5st2Vs9G2ig2TBw=") + "' WHERE USERNAME='lmra';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("Xr5RvmU7rDEeOhLr8hFb5a8Vjc0=") + "' WHERE USERNAME='egate';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("s0ci@l") + "' WHERE USERNAME='social';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("bdfP@$$w0rd") + "' WHERE USERNAME='BDF';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("3AINXhbSHxyD3PodSX/daQ==") + "' WHERE USERNAME='RCO';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("SCWP@$$w0rd") + "' WHERE USERNAME='SCW';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("EGAP@$$PORTP@$$w0rd") + "' WHERE USERNAME='EGAPassport';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("EgaGdtInsp@$$w0rd") + "' WHERE USERNAME='EgaGdtInsp';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("mosdBatchP@$$w0rd") + "' WHERE USERNAME='socialBatch';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("ccpP@$$w0rd") + "' WHERE USERNAME='ccp';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("munP@$$w0rd") + "' WHERE USERNAME='MUN';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("ci0g0$iUpd@te") + "' WHERE USERNAME='gosiUpdateSVC';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("si0p@$$w0rd") + "' WHERE USERNAME='SIO';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("WBET34crUrJ+BT/TDCOiPxPjVXM=") + "' WHERE USERNAME='eGOVMob';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("9NFyi+2Ut5TZCHYnjVsY1HswxNs=") + "' WHERE USERNAME='eGOVPort';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("XnxuNNJvY86439Uc2K2y7kg0Qhc=") + "' WHERE USERNAME='eGOVKio';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("+hAuudWxhEG5iGQbO1B6Zg26/iQ") + "' WHERE USERNAME='eGOVMoe';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("0cgxrAhtkSWiAvJLTBphVqwuqyU=") + "' WHERE USERNAME='GDTLookup';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("egovP@$$w0rd") + "' WHERE USERNAME='egov';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("moi@hrp@$$w0#d") + "' WHERE USERNAME='MOIHR';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("5KIbIHbi29rnxFCcAtPVqQwh2bY=") + "' WHERE USERNAME='SLRB';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("TsopdBH4gfH/l77nS2VzJA==") + "' WHERE USERNAME='BDForces';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("B+0KbHtxN4qRWmEwVGoYnA==") + "' WHERE USERNAME='swd';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("dhNacGP7FC0mQAOZK1NGH+x2bdQ=") + "' WHERE USERNAME='gis';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("dhmKLPSDJGPSJD1NGH+x2bdQ=") + "' WHERE USERNAME='ewa';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("#@FlT4+kNzi2ASFASSVmN/lbEjpfrA=") + "' WHERE USERNAME='MOHPortal';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("B+0KbHtZCHYSFASSVmN/lbEjpfrA=") + "' WHERE USERNAME='NajimWatchListUser';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("B+0bHtCHYSFSSVmN/lbEjpfrA=") + "' WHERE USERNAME='electionUser';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("B+7FC0mQAOZK1NGHVmN/lbEjpfrA=") + "' WHERE USERNAME='tamkeenUser';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("nns@123@system") + "' WHERE USERNAME='NNS';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("XCQebA73hQC3cAhwnm01oitwvTY=") + "' WHERE USERNAME='eGOVBenefit';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("6SczjfYrR5YxvzQ7344O+w==") + "' WHERE USERNAME='csbUser';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("eSEkXSuCICBkBpf1zd4hrA==") + "' WHERE USERNAME='nhraUser';");
		System.out.println("UPDATE ESBDB.USERS SET PASSWORD = '" + encoder.encode("vX66F6eK20q8MA0E1bxj1w==") + "' WHERE USERNAME='bibaUser';");
		
		
//		System.out.println(encoder.matches("s0ci@l", "0f8d0c7b095e7fd70345281853b8118adbe6a8ed7115de6bd0cfaf83304dd1b54e318aec1e1be796"));
//
//		String s = "&#1605;&#1581;&#1605;&#1583;";
//		System.out.println(s);
//		String s1 = Normalizer.normalize(s, Normalizer.Form.NFKD);
//		String regex = Pattern.quote("[\\p{InCombiningDiacriticalMarks}\\p{IsLm}\\p{IsSk}]+");
//
//		String s2;
//		try
//		{
//			final String[] bstrs = "1605&#1581&#1605&#1583".split("&#");
//			final byte[] bytes = new byte[bstrs.length - 1];
//			for (int i = 0; i < bstrs.length - 1; i++)
//				bytes[i] = (byte) ((Integer.parseInt(bstrs[i], 16) << 24) >> 24);
//			System.out.println(new String(bytes, "UNICODE"));
//
//			// s2 = new String(s1.replaceAll(regex, "").getBytes("UNICODE"), "UTF-8");
//			// System.out.println(s2);
//			// System.out.println(s.length() == s2.length());
//		}
//		catch (UnsupportedEncodingException exception)
//		{
//			// TODO Auto-generated catch block
//			exception.printStackinfo();
//		}

	}
}
