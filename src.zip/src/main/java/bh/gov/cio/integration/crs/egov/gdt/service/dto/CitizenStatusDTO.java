package bh.gov.cio.integration.crs.egov.gdt.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "CitizenStatus", propOrder = { "hasSmartcard", "ageLessThan60",
		"GCC", "hasValidRP", "bahraini","sponorName" })
public class CitizenStatusDTO {

	public CitizenStatusDTO() {
	}

	private boolean hasSmartcard;
	private boolean isAgeLessThan60;
	private boolean isGCC;
	private boolean hasValidRP;
	private boolean isBahraini;
	private String sponorName;

	public CitizenStatusDTO(boolean hasSmartcard, boolean isAgeLessThan60,
			boolean isGCC, boolean hasValidRP, boolean isBahraini,String sponorName) {
		super();
		this.hasSmartcard = hasSmartcard;
		this.isAgeLessThan60 = isAgeLessThan60;
		this.isGCC = isGCC;
		this.hasValidRP = hasValidRP;
		this.isBahraini = isBahraini;
		this.sponorName = sponorName;
	}

	@XmlElement(name = "SponorName")
	public String getSponorName() {
		return sponorName;
	}

	public void setSponorName(String sponorName) {
		this.sponorName = sponorName;
	}

	@XmlElement(name = "isBahraini")
	public boolean isBahraini() {
		return isBahraini;
	}

	public void setBahraini(boolean isBahraini) {
		this.isBahraini = isBahraini;
	}

	@XmlElement(name = "HasSmartcard")
	public boolean isHasSmartcard() {
		return hasSmartcard;
	}

	public void setHasSmartcard(boolean hasSmartcard) {
		this.hasSmartcard = hasSmartcard;
	}

	@XmlElement(name = "isAgeLessThan60")
	public boolean isAgeLessThan60() {
		return isAgeLessThan60;
	}

	@XmlElement(name = "isGCC")
	public boolean isGCC() {
		return isGCC;
	}

	public void setAgeLessThan60(boolean isAgeLessThan60) {
		this.isAgeLessThan60 = isAgeLessThan60;
	}

	public void setGCC(boolean isGCC) {
		this.isGCC = isGCC;
	}

	@XmlElement(name = "HasValidRP")
	public boolean isHasValidRP() {
		return hasValidRP;
	}

	public void setHasValidRP(boolean hasValidRP) {
		this.hasValidRP = hasValidRP;
	}

}
