package bh.gov.cio.integration.crs.gis.service.dto;

import javax.xml.bind.annotation.XmlType;


@XmlType(name = "UnitBasicInfo", propOrder =
{ "unitNumber", "unitArabicName", "unitEnglishName", "unitAddress" })
public class UnitBasicInfoWithAddressDTO
{
	private Integer unitNumber;
	private String unitArabicName;
	private String unitEnglishName;
	private UnitAddressInfoDTO unitAddress;

	public UnitBasicInfoWithAddressDTO()
	{
		super();

	}

	public UnitBasicInfoWithAddressDTO(Integer unitNumber, String unitArabicName, String unitEnglishName, UnitAddressInfoDTO unitAddress)
	{
		super();
		this.unitNumber = unitNumber;
		this.unitArabicName = unitArabicName;
		this.unitEnglishName = unitEnglishName;
		this.unitAddress = unitAddress;
	}

	public UnitAddressInfoDTO getUnitActivity()
	{
		return unitAddress;
	}

	public String getUnitArabicName()
	{
		return unitArabicName;
	}

	public String getUnitEnglishName()
	{
		return unitEnglishName;
	}


	public Integer getUnitNumber()
	{
		return unitNumber;
	}


	public void setUnitArabicName(String unitArabicName)
	{
		this.unitArabicName = unitArabicName;
	}

	public void setUnitEnglishName(String unitEnglishName)
	{
		this.unitEnglishName = unitEnglishName;
	}

	public void setUnitNumber(Integer unitNumber)
	{
		this.unitNumber = unitNumber;
	}

	public UnitAddressInfoDTO getUnitAddress() {
		return unitAddress;
	}

	public void setUnitAddress(UnitAddressInfoDTO unitAddress) {
		this.unitAddress = unitAddress;
	}

}
