package bh.gov.cio.integration.crs.lmra.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "IsSpouseService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public interface IsSpouseServiceInterface {
	@WebResult(name = "spouseFalgs")
	@WebMethod(operationName = "IsSpouse")
	boolean IsSpouse(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "oldSpouseEmployer") @XmlElement(required = true) String oldSpouseEmployer,
			@WebParam(name = "oldSpouseEmployerNationality") @XmlElement(required = true) String oldSpouseEmployerNationality,
			@WebParam(name = "newSpouseEmployer") @XmlElement(required = true) String newSpouseEmployer,
			@WebParam(name = "newSpouseEmployerNationality") @XmlElement(required = true) String newSpouseEmployerNationality) throws ApplicationExceptionInfo;
}
