package bh.gov.cio.integration.crs.lmra;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.lmra.dto.IsBahrainiSpouseDTO;
import bh.gov.cio.integration.crs.lmra.service.IsBahrainiSpouseServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsBahrainiSpouseService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public class IsBahrainiSpouseServiceImpl implements IsBahrainiSpouseServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(IsBahrainiSpouseServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_IsBahrainiSpouse" })
	@WebMethod(operationName = "IsBahrainiSpouse")
	public IsBahrainiSpouseDTO IsBahrainiSpouse(SecurityTagObject security,Integer cprNumber) throws ApplicationExceptionInfo {

		IsBahrainiSpouseDTO isBahrainiSpouseDTO = new IsBahrainiSpouseDTO();
		final FamilyService familyService = getCrsService()
				.getFamilyServiceRef();
//		final bh.gov.cio.crs.esb.service.PersonService personService = getCrsService()
//				.getNewPersonServiceRef();
		final PersonService personService = getCrsService()
				.getPersonServiceRef();

		isBahrainiSpouseDTO.setHaveChildren("F");
		isBahrainiSpouseDTO.setIsBahrainiSpouse("F");
		isBahrainiSpouseDTO.setIsBahrainiWidow("F");
		isBahrainiSpouseDTO.setCprNumber(Integer.toString(cprNumber));
		PersonBasicInfo personBasicInfo = null;
		PersonSummary personSum = null;
		List<Marriage> hm = new ArrayList<Marriage>();
		HashMap<Integer, List<PersonSummary>> hm2 = null;
		boolean isMOISponsor = true;
		 Integer spouseCPR= 0;
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("IsBahrainiWife() - started..........");
			}

			personBasicInfo = personService.getPersonBasicInfo(cprNumber);
			personSum =personService.getPersonSummary(cprNumber);
			isMOISponsor = personService.isMOISponsor(cprNumber);
			spouseCPR = familyService.getPersonPrimarySpouse(cprNumber);
			hm = familyService.getPersonMarriageDivorceList(cprNumber);
			hm2 = familyService.getPersonChildrenBySpouse(cprNumber);

		}
		catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.debug("IsBahrainiSpouse() - ended..........");
			}
			e.printStackTrace();
//			 throw new ApplicationExceptionInfo("General Error", new
//			 ApplicationException( " Data Not Found For this CPR Number"));
		} 
		
//		/*********************** check if the cpr sent in the request is Female *******************/
//			if (logger.isDebugEnabled()) {
//				logger.debug("SpousePersonBasicInfo.getGender(): "
//						+ personBasicInfo.getGender());
//			}
//
//			if (personBasicInfo.getGender().equals("F")) {
				/*********************** check if the cpr is *******************/
				final boolean foreignerSpouse = (personSum
						.getNationalityCountryCode().equals("499") || personSum
						.getNationalityCountryCode().equals("900")) ? false
						: true;

				if (foreignerSpouse==true) {

					/********************* Check if Spouse under LMRA employees ************************/


					if (isMOISponsor == false) {

						
						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiSpouse() - familyService.getPersonPrimarySpouse(cprNumber) = "
									+ spouseCPR);
						}
//						final List<Marriage> hm = familyService
//								.getPersonMarriageDivorceList(cprNumber);
						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiSpouse() - familyService.getPersonMarriageDivorceList(cprNumber) = "
									+ hm);
						}

						int count = 0;

						/**************** Check if Spouse married Bahraini or widow bahraini **************/
						if (hm != null) {
							for (final Marriage marriage : hm) {
								final Marriage spouse = marriage;
								
								
								try{
								final PersonSummary spousePersonSummary = personService
										.getPersonSummary(spouse
												.getPartnerCprNumber());
								if (logger.isDebugEnabled()) {
									logger.debug("IsBahrainiSpouse()"
											+ spouse.getPartnerCprNumber()
											+ " -  spouse = "
											+ spouse.getLastActionWithPartner()
											+ "spouse.isAlive() "
											+ spouse.isAlive());
								}

								final boolean isBahraini = (spousePersonSummary
										.getNationalityCountryCode().equals(
												"499") || spousePersonSummary
										.getNationalityCountryCode().equals(
												"900")) ? true : false;

								if (!spouse.getLastActionWithPartner().equals(
										"DIVORCE")) {
									if (isBahraini == true) {
										if (spousePersonSummary
												.getDateOfDeath() != null) {
											isBahrainiSpouseDTO
													.setIsBahrainiWidow("T");
										} else {
											isBahrainiSpouseDTO
													.setIsBahrainiSpouse("T");
										}

									}

									if (isBahraini == false) {

										throw new ApplicationExceptionInfo(
												"Not under LMRA umbrella.",
												new ApplicationException(
														"Not under LMRA umbrella."));

									}

								}

								count++;
							
							}
							catch (Exception e) {
								throw new ApplicationExceptionInfo("Spouse recored not found.",new ApplicationException("Spouse recored not found."));
							}
						}}

						else {
							throw new ApplicationExceptionInfo("Marriage record not found.",new ApplicationException("Marriage record not found."));
						}

						/******************* check if she has bahraini children *********************/
//						final HashMap<Integer, List<PersonSummary>> hm2 = familyService
//								.getPersonChildrenBySpouse(cprNumber);
						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiSpouse() -  No Of Spouses = "
									+ hm2);
						}
						
						if (hm2 != null) {
						final Collection<List<PersonSummary>> wivesList = hm2
								.values();

						int currentChild = 0;
						int noOfBahrainichildren = 0;
						for (final List<PersonSummary> list : wivesList) {
							final List<PersonSummary> childrenList = list;
							for (final PersonSummary personSummary : childrenList) {
								final PersonSummary childrenSummary = personSummary;
								try{
								final PersonSummary childrenPersonSummary = personService
										.getPersonSummary(childrenSummary
												.getCprNumber());

								final boolean isBahraini = (childrenPersonSummary
										.getNationalityCountryCode().equals(
												"499") || childrenPersonSummary
										.getNationalityCountryCode().equals(
												"900")) ? true : false;
								final boolean isNotDead = (childrenPersonSummary
										.getIoStatusCode().equals("1")) ? false
										: true;

								if (isNotDead && isBahraini == true) {
									noOfBahrainichildren = noOfBahrainichildren++;

								}

								currentChild++;

							}
							
						catch (Exception e) {
							throw new ApplicationExceptionInfo(
									"Women with out child.",
									new ApplicationException(
											"Women with out child."));
						}
						}
						

						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiSpouse() -  noOfBahrainichildren= "
									+ noOfBahrainichildren);
						}

						if (noOfBahrainichildren >= 1) {

							isBahrainiSpouseDTO.setHaveChildren("T");
						}
						}
						
					} 
				}
					else {
						throw new ApplicationExceptionInfo(
								"Unauthorized display/insert/update for specified sponsor number or employer number.",
								new ApplicationException(
										"Unauthorized display/insert/update for specified sponsor number or employer number."));
					}

			} 	
				 else {
						throw new ApplicationExceptionInfo("CPR Belongs to a Bahraini",new ApplicationException("CPR Belongs to a Bahraini."));

					}
	
//	}
//			else
//			{
//		
//			throw new ApplicationExceptionInfo("CPR number is not for Female.",new ApplicationException("CPR number is not for Female."));
//
//			}
						
			return isBahrainiSpouseDTO;
			
	}
}
