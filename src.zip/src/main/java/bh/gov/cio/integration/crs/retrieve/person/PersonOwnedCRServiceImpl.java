package bh.gov.cio.integration.crs.retrieve.person;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.CRSEntity;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonOwnedCRServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonOwnedCRDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonOwnedCRService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")

public class PersonOwnedCRServiceImpl implements PersonOwnedCRServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonOwnedCRServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

//	@Override
//	@Secured(
//	{ "ROLE_getPersonOwnedCR" })
//	@WebMethod(operationName = "getPersonOwnedCR")
//	public PersonOwnedCRDTO[] getPersonOwnedCR(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
//			throws ApplicationExceptionInfo
//	{
//		if (logger.isDebugEnabled())
//		{
//			logger.debug("getPersonOwnedCR(Integer, Integer, Date) - start");
//		}
//
//		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
//		{
//			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
//		}
//		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
//		{
//			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
//		}
//		if (validationUtil.isMilitaryCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
//		}
//		if (validationUtil.isDeletedCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//		}
//		PersonOwnedCRDTO[] personOwnedCRDTO = null;
//		try
//		{
//			final List<CRSEntity> ownedCRs = getCrsService().getPersonServiceRef().getPersonOwnedCRs(cprNumber);
//			personOwnedCRDTO = new PersonOwnedCRDTO[ownedCRs.size()];
//			int i = 0;
//			for (final CRSEntity crsEntity : ownedCRs)
//			{
//				final CRSEntity CR = crsEntity;
//				String CREnglishName = CR.getEntityEnglishName();
//				String CRArabicName = CR.getEntityName();
//				if (CREnglishName == null)
//				{
//					CREnglishName = "";
//				}
//				if (CRArabicName == null)
//				{
//					CRArabicName = "";
//				}
//				personOwnedCRDTO[i] = new PersonOwnedCRDTO(CR.getEntityNumber(), CRArabicName, CREnglishName);
//				i++;
//			}
//
//			if (logger.isDebugEnabled())
//			{
//				logger.debug("getPersonOwnedCR(Integer, Integer, Date) - end");
//			}
//		}
//		catch (final Exception exception)
//		{
//			if (logger.isDebugEnabled())
//			{
//				logger.error("getPersonOwnedCR(Integer, Integer, Date) Error: " + exception.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Person Owned CR Details Not found", new ApplicationException(exception.getMessage()));
//		}
//		return personOwnedCRDTO;
//	}

	@Override
	@Secured(
	{ "ROLE_getPersonOwnedCRByCPR" })
	@WebMethod(operationName = "getPersonOwnedCRByCPR")
	public PersonOwnedCRDTO[] getPersonOwnedCRByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonOwnedCRByCPR(Integer - Start");
		}
		PersonOwnedCRDTO[] personOwnedCRDTO = null;
		try
		{
			final List<CRSEntity> ownedCRs = getCrsService().getPersonServiceRef().getPersonOwnedCRs(cprNumber);

			if (logger.isDebugEnabled())
			{
				logger.debug("CRs owned by CPR is:size()" + ownedCRs.size());
			}

			if (ownedCRs.size() < 1)
			{
				throw new ApplicationExceptionInfo("Person Owned CR Not found", new ApplicationException(null));
			}
			personOwnedCRDTO = new PersonOwnedCRDTO[ownedCRs.size()];
			int i = 0;
			for (final CRSEntity crsEntity : ownedCRs)
			{
				final CRSEntity CR = crsEntity;
				String CREnglishName = CR.getEntityEnglishName();
				String CRArabicName = CR.getEntityName();
				if (CREnglishName == null)
				{
					CREnglishName = "";
				}
				if (CRArabicName == null)
				{
					CRArabicName = "";
				}
				personOwnedCRDTO[i] = new PersonOwnedCRDTO(CR.getEntityNumber(), CRArabicName, CREnglishName);
				i++;
			}

			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonOwnedCRByCPR(Integer - end");
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonOwnedCRByCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Owned CR Details Not found", new ApplicationException(exception.getMessage()));
		}
		return personOwnedCRDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
