package bh.gov.cio.integration.crs.egov.frequences;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.cr.CRDetails;
import bh.gov.cio.crs.model.unit.UnitInfo;
import bh.gov.cio.crs.service.UnitService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.frequences.dto.FrequencesDTO;
import bh.gov.cio.integration.crs.egov.frequences.service.FrequencesServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "FrequencesSoapService", targetNamespace = "http://service.frequences.egov.crs.integration.cio.gov.bh/")
public class FrequencesServiceImpl implements FrequencesServiceInterface, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(FrequencesServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Override
	@Secured({ "ROLE_FetchCRUnitInfo" })
	@WebResult(name = "EstablishmentInfo")
	@WebMethod(operationName = "getEstablishmentInfo")
	public FrequencesDTO getEstablishmentInfo(SecurityTagObject security, Integer cr_unit_number,
			CommonTypes.EstablishmentType establishmentType) throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled()) {
			logger.debug("getEstablishmentInfo(Integer) - start");
		}
		String englishName = "";
		UnitService unitService = getCrsService().getUnitServiceRef();
		CRDetails crDetails = null;
		UnitInfo unitDetails = null;
		if (establishmentType == EstablishmentType.C) {
			try {
				crDetails = unitService.getCrBasicInfo(cr_unit_number);
				englishName = crDetails.getCrEnglishName();
			} catch (final Exception exception) {
			}
			if (crDetails!= null && "F".equals(crDetails.getIsActive())) {
				throw new ApplicationExceptionInfo("CR is canceled", new ApplicationException("CR is canceled", "002"));
			}
		}

		if (establishmentType == EstablishmentType.U) {
			if ((cr_unit_number < 79300000 || (cr_unit_number > 79399999 && cr_unit_number < 80000000)
					|| (cr_unit_number >= 80214000 && cr_unit_number <= 80214199) || cr_unit_number > 80999999)) {
				throw new ApplicationExceptionInfo("Unit number out of range ",
						new ApplicationException("Unit number out of range ", "003"));
			} else {
				try {
					unitDetails = unitService.getUnitBasicInfo(cr_unit_number);
					englishName = unitDetails.getUnitEnglishName();
				} catch (Exception e) {
				}
				if (unitDetails != null && unitDetails.getUnitWorkingStatusCode() != null
						&& !unitDetails.getUnitWorkingStatusCode().equals("001")) {
					throw new ApplicationExceptionInfo("Unit is not Active ",
							new ApplicationException("Unit is not Active ", "004"));
				}
			}
		}
		if (crDetails == null && unitDetails == null) {
			throw new ApplicationExceptionInfo("Data Not Found ", new ApplicationException("Data Not Found ", "001"));
		}
		return new FrequencesDTO(cr_unit_number, englishName);
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

}
