package bh.gov.cio.integration.crs.egov.moe.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.moe.service.dto.StudentCertificateDTO;
import bh.gov.cio.integration.crs.egov.moe.service.dto.StudentTransferDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "StudentCertificateService", targetNamespace = "http://service.moe.egov.crs.integration.cio.gov.bh/")
public interface StudentCertificateServiceInterface {
	@WebResult(name = "StudentInformation")
	@WebMethod(operationName = "RetrieveStudentInformation")
	StudentCertificateDTO retrieveStudentInformation(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "IDNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "NationalityCode") @XmlElement(required = true) String nationalityCode,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp)
			throws ApplicationExceptionInfo;

	@WebResult(name = "StudentInTransferformation")
	@WebMethod(operationName = "transferStudentInformation")
	StudentTransferDTO transferStudentInformation(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "applicantIdNumber") @XmlElement(required = true) String applicantIdNumber,
			@WebParam(name = "applicantCardCountry") @XmlElement(required = true) String applicantCardCountry,
			@WebParam(name = "studentIdNumber") @XmlElement(required = true) String studentIdNumber,
			@WebParam(name = "studentCardCountry") @XmlElement(required = true) String studentCardCountry,
			@WebParam(name = "studentBlockNumber") @XmlElement(required = true) Integer studentBlockNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp)
			throws ApplicationExceptionInfo;

}
