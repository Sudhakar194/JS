package bh.gov.cio.integration.crs.update.person;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.EMS006Respose;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.update.person.service.CreateCPRServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CreateCPRService", targetNamespace = "http://service.person.update.crs.integration.cio.gov.bh/")
//, serviceName = "CreateCPRService"
public class CreateCPRServiceImpl implements CreateCPRServiceInterface
{
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;
	@Autowired
	private ValidationServiceImpl validationService;

	@Override 
	@Secured(
	{ "ROLE_createCPR" })
	@WebMethod(operationName = "createCPR")
	public EMS006Respose createCPR(SecurityTagObject security, String expatApplicationID, String cprNumber,
			String englishFirstName, String englishMiddleName1, String englishMiddleName2, String englishMiddleName3,
			String englishMiddleName4, String englishFamilyName, String messageIdentifier, String phoneContact,
			String highestLevelAchievedCode, String labourParticipationTypeCode, String maritalStatusCode,
			String religionCode, String ioStatusCode, String gender, String nationalityCode, String occupationCode,
			String occupationTypeCode, String employerNumber, String employerCardCountryCode, String employerType,
			String employmentStatusCode, String sponsorNumber, String sponsorCardCounryCode, String sponsorType,
			String countryOfBirth, String dateOfBirth, String block, String road, String building, String buildingAlpha,
			String flat, String mailBox, String headOfHouseholdCpr, String headOfHouseholdCardCountryCode, String houseHoldRelationCode,
			String occupancyStatusCode, String residential, String passportNumber, String passportTypeCode,
			String issueDate, String expiryDate, String passportSequenceNumber, String arabicFirstName,
			String arabicMiddleName1, String arabicMiddleName2, String arabicMiddleName3, String arabicMiddleName4,
			String arabicFamilyName, String placeOfBirthArabic, String placeOfBirthEnglish, String specialisationCode,
			String educationLevelCode, String unitNumber, String previousPassportNumber, String passportImage,
			String fatherCprNumber, String motherCprNumber, String spouseCPRNumber, String photo, String photoDate,
			String signatureDate, String signature,Boolean isDomestic) throws ApplicationExceptionInfo {
		EMS006Respose returnString = new EMS006Respose();
		try
		{
			if (employerCardCountryCode != null && !employerCardCountryCode.equals("")
					&& !employerCardCountryCode.equals("499")) {
				employerNumber = validationService.getGCCCpr(employerNumber, employerCardCountryCode) + "";

			}
			if (sponsorCardCounryCode != null && !sponsorCardCounryCode.equals("")
					&& !sponsorCardCounryCode.equals("499")) {
				sponsorNumber = validationService.getGCCCpr(sponsorNumber, sponsorCardCounryCode) + "";

			}
			if (headOfHouseholdCardCountryCode != null && !headOfHouseholdCardCountryCode.equals("")
					&& !headOfHouseholdCardCountryCode.equals("499")) {
				headOfHouseholdCpr = validationService.getGCCCpr(headOfHouseholdCpr, headOfHouseholdCardCountryCode) + "";
				
			}

			String isHeadOfHousehold = "";
			String year = "";
			String month = "";
			String day = "";
			returnString = getCrsService().getPersonServiceRef().handleEMS006Request(expatApplicationID, cprNumber, englishFirstName,
					englishMiddleName1, englishMiddleName2, englishMiddleName3, englishMiddleName4, englishFamilyName, messageIdentifier,
					phoneContact, highestLevelAchievedCode, labourParticipationTypeCode, maritalStatusCode, religionCode, ioStatusCode, gender,
					nationalityCode, occupationCode, occupationTypeCode, employerNumber, employerType, employmentStatusCode, sponsorNumber,
					sponsorType, countryOfBirth, dateOfBirth, year, month, day, block, road, building, buildingAlpha, flat, mailBox,
					isHeadOfHousehold, headOfHouseholdCpr, houseHoldRelationCode,
					occupancyStatusCode,
					residential,
					passportNumber,
					passportTypeCode,
					issueDate,
					expiryDate,
					passportSequenceNumber,
					arabicFirstName,
					arabicMiddleName1,
					arabicMiddleName2,
					arabicMiddleName3,
					arabicMiddleName4,
					arabicFamilyName,
					// isActive,
					// student,
					// clearingAgent,
					// watchlisted,
					// isLostCard,
					// isDeleted,
					// isNameTranslated,
					// isSmartcard,
					// isNationalityConfirmed,
					// immigrationMatch,
					placeOfBirthArabic,
					placeOfBirthEnglish,
					// forCard,
					// isLocked,
					// noc,
					// dateOfBirthOld,
					specialisationCode, educationLevelCode, unitNumber,
					// graduationDate,
					previousPassportNumber, passportImage, fatherCprNumber, motherCprNumber, spouseCPRNumber, photo, photoDate, signatureDate,
					signature);
		}
		catch (Exception e)
		{
			throw new ApplicationExceptionInfo(e.getMessage(), new ApplicationException(e.getMessage()));
		}

		return returnString;
	}
	
	
//	@Override
//	@Secured(
//	{ "ROLE_createCPR" })
//	@WebMethod(operationName = "createID")
//	public EMS006Respose createID(SecurityTagObject security, String expatApplicationID, String cprNumber,
//			String englishFirstName, String englishMiddleName1, String englishMiddleName2, String englishMiddleName3,
//			String englishMiddleName4, String englishFamilyName, String messageIdentifier, String phoneContact,
//			String highestLevelAchievedCode, String labourParticipationTypeCode, String maritalStatusCode,
//			String religionCode, String ioStatusCode, String gender, String nationalityCode, String occupationCode,
//			String occupationTypeCode, String employerNumber, String employerCardCountryCode, String employerType,
//			String employmentStatusCode, String sponsorNumber, String sponsorCardCounryCode, String sponsorType,
//			String countryOfBirth, String dateOfBirth, String block, String road, String building, String buildingAlpha,
//			String flat, String mailBox, String headOfHouseholdCpr, String houseHoldRelationCode,
//			String occupancyStatusCode, String residential, String passportNumber, String passportTypeCode,
//			String issueDate, String expiryDate, String passportSequenceNumber, String arabicFirstName,
//			String arabicMiddleName1, String arabicMiddleName2, String arabicMiddleName3, String arabicMiddleName4,
//			String arabicFamilyName, String placeOfBirthArabic, String placeOfBirthEnglish, String specialisationCode,
//			String educationLevelCode, String unitNumber, String previousPassportNumber, String passportImage,
//			String fatherCprNumber, String motherCprNumber, String spouseCPRNumber, String photo, String photoDate,
//			String signatureDate, String signature) throws ApplicationExceptionInfo {
//
//		EMS006Respose returnString = new EMS006Respose();
//		try
//		{
//			
//			
//			if(employerCardCountryCode!=null && !employerCardCountryCode.equals("")&& !employerCardCountryCode.equals("499")){
//						employerNumber = validationService.getGCCCpr(employerNumber, employerCardCountryCode)+"";
//
//			}
//			if(sponsorCardCounryCode!=null && !sponsorCardCounryCode.equals("")&& !sponsorCardCounryCode.equals("499")){
//				sponsorNumber = validationService.getGCCCpr(sponsorNumber, sponsorCardCounryCode)+"";
//				
//			}
//			
//			String isHeadOfHousehold = "";
//			String year = "";
//			String month = "";
//			String day = "";
//			returnString = getCrsService().getPersonServiceRef().handleEMS006Request(expatApplicationID, cprNumber, englishFirstName,
//					englishMiddleName1, englishMiddleName2, englishMiddleName3, englishMiddleName4, englishFamilyName, messageIdentifier,
//					phoneContact, highestLevelAchievedCode, labourParticipationTypeCode, maritalStatusCode, religionCode, ioStatusCode, gender,
//					nationalityCode, occupationCode, occupationTypeCode, employerNumber, employerType, employmentStatusCode, sponsorNumber,
//					sponsorType, countryOfBirth, dateOfBirth, year, month, day, block, road, building, buildingAlpha, flat, mailBox,
//					isHeadOfHousehold, headOfHouseholdCpr, houseHoldRelationCode,
//					occupancyStatusCode,
//					residential,
//					passportNumber,
//					passportTypeCode,
//					issueDate,
//					expiryDate,
//					passportSequenceNumber,
//					arabicFirstName,
//					arabicMiddleName1,
//					arabicMiddleName2,
//					arabicMiddleName3,
//					arabicMiddleName4,
//					arabicFamilyName,
//					placeOfBirthArabic,
//					placeOfBirthEnglish,
//					specialisationCode, educationLevelCode, unitNumber,
//					previousPassportNumber,
//					passportImage,
//					fatherCprNumber,
//					motherCprNumber,
//					spouseCPRNumber,
//					photo, photoDate, signatureDate,
//					signature);
//		}
//		catch (Exception e)
//		{
//			throw new ApplicationExceptionInfo(e.getMessage(), new ApplicationException(e.getMessage()));
//		}
//
//		return returnString;
//		
//		
//		
//	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

}
