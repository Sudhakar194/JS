package bh.gov.cio.integration.crs.retrieve.units.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.crs.util.exception.ApplicationException;
import bh.gov.cio.crs.util.exception.UnitException;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitAddressServiceBasicInfoDTO;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "UnitAddressService", targetNamespace = "http://service.units.retrieve.crs.integration.cio.gov.bh/")
public interface UnitAddressServiceInterface
{
	@WebResult(name = "UnitAddressBasicInformation")
	@WebMethod(operationName = "getUnitAddress")
	UnitAddressServiceBasicInfoDTO getUnitAddress(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security, @WebParam(name = "unitNumber") @XmlElement(required = true) Integer unitNumber)
			throws ApplicationException, UnitException;

}
