package bh.gov.cio.integration.crs.lmra;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.lmra.service.IsSpouseServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsSpouseService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public class IsSpouseServiceImpl implements IsSpouseServiceInterface{

	
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(IsSpouseServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Autowired
	private ValidationServiceImpl validationUtil;

	@Override
	@Secured({ "ROLE_IsSpouse" })
	@WebMethod(operationName = "IsSpouse")
	public boolean IsSpouse(SecurityTagObject security, String oldSpouseEmployer,String oldSpouseEmployerNationality,
			String newSpouseEmployer,String newSpouseEmployerNationality) throws ApplicationExceptionInfo {
		Integer oldSpouseEmployerCpr = null;
		Integer newSpouseEmployerCpr = null;
		try {
			try {
				oldSpouseEmployerCpr = validationUtil.getGCCCpr(oldSpouseEmployer, oldSpouseEmployerNationality);
			} catch (Exception e) {
				throw new ApplicationExceptionInfo("old Employer Number is not correct.",
						new ApplicationException("old Employer Number is not correct."));
					}
			try {
				newSpouseEmployerCpr = validationUtil.getGCCCpr(newSpouseEmployer, newSpouseEmployerNationality);
			} catch (Exception e) {
				throw new ApplicationExceptionInfo("new Employer Number is not correct.",
						new ApplicationException("new Employer Number is not correct."));
				}
			//try {
			// if ((oldSpouseEmployerNationality != null)
			// && (oldSpouseEmployerNationality.equalsIgnoreCase("411")
			// || oldSpouseEmployerNationality.equalsIgnoreCase("430")
			// || oldSpouseEmployerNationality.equalsIgnoreCase("436")
			// || oldSpouseEmployerNationality.equalsIgnoreCase("440")
			// || oldSpouseEmployerNationality.equalsIgnoreCase("441")
			// || oldSpouseEmployerNationality.equalsIgnoreCase("900")
			// || oldSpouseEmployerNationality.equalsIgnoreCase("930")
			// || oldSpouseEmployerNationality.equalsIgnoreCase("940")))
			// {
			// oldSpouseEmployerCpr =
			// getCrsService().getPersonServiceRef().getGccNationalSn(oldSpouseEmployer,oldSpouseEmployerNationality);
			//
			// }else {
			//
			// PersonBasicInfo oldSpouseInfo=
			// crsService.getPersonServiceRef().getPersonBasicInfo(Integer.parseInt(oldSpouseEmployer));
			//
			// if (oldSpouseInfo!= null)
			// oldSpouseEmployerCpr = Integer.parseInt(oldSpouseEmployer);
			//
			// else{
			// throw new ApplicationExceptionInfo("old Employer Number is not
			// correct.",new ApplicationException("old Employer Number is not
			// correct."));
//			}
			// }
			//// } catch (Exception e) {
			//// throw new ApplicationExceptionInfo("old Employer Number is not
			// correct.",new ApplicationException("old Employer Number is not
			// correct."));
			//// }
			//
			// //try {
			// if ((newSpouseEmployerNationality != null)
			// && (newSpouseEmployerNationality.equalsIgnoreCase("411")
			// || newSpouseEmployerNationality.equalsIgnoreCase("430")
			// || newSpouseEmployerNationality.equalsIgnoreCase("436")
			// || newSpouseEmployerNationality.equalsIgnoreCase("440")
			// || newSpouseEmployerNationality.equalsIgnoreCase("441")
			// || newSpouseEmployerNationality.equalsIgnoreCase("900")
			// || newSpouseEmployerNationality.equalsIgnoreCase("930")
			// || newSpouseEmployerNationality.equalsIgnoreCase("940")))
			// {
			// newSpouseEmployerCpr =
			// getCrsService().getPersonServiceRef().getGccNationalSn(newSpouseEmployer,newSpouseEmployerNationality);
			//
			// }else {
			//
			// PersonBasicInfo newSpouseEmployerInfo=
			// crsService.getPersonServiceRef().getPersonBasicInfo(Integer.parseInt(newSpouseEmployer));
			//
			// if (newSpouseEmployerInfo!= null)
			// newSpouseEmployerCpr = Integer.parseInt(newSpouseEmployer);
			//
			// else{
			//
			// throw new ApplicationExceptionInfo("new Employer Number is not
			// correct.",new ApplicationException("new Employer Number is not
			// correct."));
			//
			// }
			// }
			//
			//// } catch (Exception e) {
			//// throw new ApplicationExceptionInfo("new Employer Number is not
			// correct.",new ApplicationException("new Employer Number is not
			// correct."));
			//// }

			final List<Marriage> marriageDivorceList = getCrsService().getFamilyServiceRef()
					.getPersonMarriageDivorceList(oldSpouseEmployerCpr);

			if (logger.isDebugEnabled()) {
				logger.debug("IsSpouse() - old Employer: " + oldSpouseEmployer + " Marriage list = "
						+ marriageDivorceList.size());
		        }
		        
			if (marriageDivorceList != null) {
				for (final Marriage marriage : marriageDivorceList) {
		                     //final Marriage spouse = marriage;
		
					if (logger.isDebugEnabled()) {
						logger.debug("Ispouse()- spouse partener" + marriage.getPartnerCprNumber() + " -  spouse = "
								+ marriage.getLastActionWithPartner());
					}
					// logger.debug("spousePersonBasicInfo:" +
					// spousePersonBasicInfo);
					if (marriage.getLastActionWithPartner().equals("MARRIAGE")) {
		                    	 if(newSpouseEmployerCpr.equals(marriage.getPartnerCprNumber())){
		                            return true;
		                    	 }
		                    		 return false;
		                    	 }
		                     }
		                     
		              }
		} catch (Exception e) {
			
			throw new ApplicationExceptionInfo(
					"new spouse Employer Number or old spouse Employer Number is not correct.",
					new ApplicationException(
							"new spouse Employer Number or old spouse Employer Number is not correct."));
		}
	return false;
	}
}
