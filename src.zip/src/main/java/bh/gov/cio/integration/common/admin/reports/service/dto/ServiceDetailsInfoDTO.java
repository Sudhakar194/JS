package bh.gov.cio.integration.common.admin.reports.service.dto;

import java.util.Date;

public class ServiceDetailsInfoDTO {
	private String ministry;
	private String serviceName;
	private String serviceStagingURL;
	private String serviceProductionURL;
	private String serviceDevelopmentURL;
	private Date serviceCreationDate;
	
	final String  prodURI="http://crsesb.gov.bh/cio-crs-esb/svc/",stagingURL="http://stg-crsesb.gov.bh/cio-crs-esb/svc/",devURL="http://dev-crsesb.gov.bh/cio-crs-esb/svc/";
	
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public ServiceDetailsInfoDTO() {
		super();
	}
	public String getServiceStagingURL() {
		return stagingURL+serviceStagingURL+".svc?wsdl";
	}
	public void setServiceStagingURL(String serviceStagingURL) {
		this.serviceStagingURL = serviceStagingURL;
	}
	public String getServiceProductionURL() {
		return prodURI+serviceProductionURL+".svc?wsdl";
	}
	public void setServiceProductionURL(String serviceProductionURL) {
		this.serviceProductionURL = serviceProductionURL;
	}
	public String getServiceDevelopmentURL() {
		return devURL+serviceDevelopmentURL+".svc?wsdl";
	}
	public void setServiceDevelopmentURL(String serviceDevelopmentURL) {
		this.serviceDevelopmentURL = serviceDevelopmentURL;
	}
	public Date getServiceCreationDate() {
		return serviceCreationDate;
	}
	public void setServiceCreationDate(Date serviceCreationDate) {
		this.serviceCreationDate = serviceCreationDate;
	}
	public ServiceDetailsInfoDTO(String serviceName, String serviceStagingURL, String serviceProductionURL,
			String serviceDevelopmentURL, Date serviceCreationDate,String ministry) {
		super();
		this.ministry = ministry;
		this.serviceName = serviceName;
		this.serviceStagingURL = serviceStagingURL;
		this.serviceProductionURL = serviceProductionURL;
		this.serviceDevelopmentURL = serviceDevelopmentURL;
		this.serviceCreationDate = serviceCreationDate;
	}
	public String getMinistry() {
		return ministry;
	}
	public void setMinistry(String ministry) {
		this.ministry = ministry;
	}
}
