package bh.gov.cio.integration.crs.retrieve.address.service;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.address.service.dto.CheckActiveBuildingDTO;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.CheckActiveBuildingReturnDTO;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.CheckValidateAddressDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "CheckValidAddressService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
public interface CheckValidAddressServiceInterface {
	@WebResult(name = "governorate")
	@WebMethod(operationName = "checkValidAddress")
	CheckValidateAddressDTO checkValidAddress(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "flatNumber") @XmlElement(required = true) Integer flatNumber,
			@WebParam(name = "buildingNumber") @XmlElement(required = true) Integer buildingNumber,
			@WebParam(name = "buildingAlpha") @XmlElement(required = true) String buildingAlpha,
			@WebParam(name = "roadNumber") @XmlElement(required = true) Integer roadNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber)
			throws ApplicationExceptionInfo;

	@WebResult(name = "BuildingStatus")
	@WebMethod(operationName = "checkActiveBuildingList")
	public ArrayList<CheckActiveBuildingReturnDTO> checkActiveBuildingList(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "Building") @XmlElement(required = true) List<CheckActiveBuildingDTO> bldgList)
			throws ApplicationExceptionInfo;

}
