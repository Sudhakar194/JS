package bh.gov.cio.integration.crs.retrieve.person;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.Contact;
import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.MOHDemographicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.MOHDemographicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "MOHDemographicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "MOHDemographicInfoService"
public class MOHDemographicInfoServiceImpl implements MOHDemographicInfoServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(MOHDemographicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;


	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured(
//	{ "ROLE_getPersonBasicInfoByCPR" })
	{ "ROLE_getMOHDemographicInfo" })
	@WebMethod(operationName = "getMOHDemographicInfo")
	public MOHDemographicInfoDTO getMOHDemographicInfo(SecurityTagObject security, String idNumber,
			String nationalityCode, Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo {
		MOHDemographicInfoDTO mohDemographicInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getMOHDemographicInfo(Integer, Integer, Date) - start");
			logger.debug("getMOHDemographicInfo(idNumber = " + idNumber + ", blockNumber = " + blockNumber
					+ ", cardExpiryDate = " + cardExpiryDate + ")");
		}
		
		if(nationalityCode == null || "".equals(nationalityCode.trim())){
			nationalityCode = "499";
		}
		
		
		Integer cprNumber = 0;
		
		// Integer id = null;
		// try {
		// id = getCrsService().getPersonServiceRef().getGccNationalSn(idNumber,
		// nationalityCode);
		// } catch (Exception e) {
		// // TODO Auto-generated catch block
		// logger.debug("ERROR: "+e.getMessage());
		// }
		//
		// if(id != null){
		// cprNumber = id;
		// }else{
		//
		// try {
		// cprNumber = Integer.parseInt(idNumber);
		// } catch (Exception e) {
		// // TODO: handle exception
		// throw new ApplicationExceptionInfo("Id Number", new
		// ApplicationException("Invalid Id Number"));
		// }
		//
		// // validate only if Card is Bahraini Smartcard
		// if (!validationUtil.hasValidExpiryCardData(cprNumber,
		// cardExpiryDate))
		// {
		// throw new ApplicationExceptionInfo("Expiry Date", new
		// ApplicationException("Wrong Expiry Date"));
		// }
		//
		//
		// }
				
				try {
			cprNumber = validationUtil.getGCCCpr(idNumber, nationalityCode);
				} catch (Exception e) {
					throw new ApplicationExceptionInfo("Id Number", new ApplicationException("Invalid Id Number"));
				}
		if (nationalityCode == null || nationalityCode.equalsIgnoreCase("499")) {
			if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate)) {
					throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
				}
				
			
			}
		if (!validationUtil.hasValidBlock(cprNumber, blockNumber)) {
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}

		if (validationUtil.isMilitaryCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		}
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		
		try {
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final List<Address> personAddressList = getCrsService().getAddressServiceRef().getAddressDetails(cprNumber);
			final Contact personContact = getCrsService().getPersonServiceRef().getPersonContact(cprNumber);
			
			final List<Employment> personEmploymentList = getCrsService().getEmploymentServiceRef()
					.getActiveEmployments(cprNumber);
			Address personAddress = new Address();
			
			if(personAddressList != null && personAddressList.size() > 0){
				personAddress = personAddressList.get(0);
			}
			
			Employment personEmployment = null;
			
			if(personEmploymentList != null && personEmploymentList.size() > 0){
				personEmployment = personEmploymentList.get(0);
				logger.debug(personEmployment.getOccupationCode());
			}else{
				logger.debug("NO EMPLOYMENT FOUND");
				personEmployment = new Employment();
			}
			
			
			String natCode = personSummeryInfo.getNationalityCountryCode().trim();
			
			if( "499".equals(natCode)|| //BAH
				"441".equals(natCode)|| //KSA
				"411".equals(natCode)|| //UAE
				"430".equals(natCode)|| //KUWAIT
				"436".equals(natCode)|| //OMAN
				"440".equals(natCode)){ //QATAR
			
				natCode = ("1");	
			}else{
				natCode = ("0");	
			}
			
			logger.debug("Occupation Desc " + personEmployment.getOccupationANM() + " - "
					+ personEmployment.getOccupationANF());
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); 
			
			mohDemographicInfoDTO = new MOHDemographicInfoDTO(personSummeryInfo.getAge(),
					personSummeryInfo.getArabicFirstName(), personSummeryInfo.getArabicMiddleName1(),
					personSummeryInfo.getArabicMiddleName2(), personSummeryInfo.getArabicMiddleName3(),
					personSummeryInfo.getArabicMiddleName4(), personSummeryInfo.getArabicFamilyName(),
					personSummeryInfo.getEnglishFirstName(), personSummeryInfo.getEnglishMiddleName1(),
					personSummeryInfo.getEnglishMiddleName2(), personSummeryInfo.getEnglishMiddleName3(),
					personSummeryInfo.getEnglishMiddleName4(), personSummeryInfo.getEnglishFamilyName(), idNumber,
					sdf.format(personSummeryInfo.getDateOfBirth()), personSummeryInfo.getGender(), natCode,
					personSummeryInfo.getArabicFullName(), personSummeryInfo.getEnglishFullName(),
					personSummeryInfo.getReligionCode(), personSummeryInfo.getMaritalStatusCode(),
					personEmployment.getOccupationCode(),
					(personSummeryInfo.getGender().equalsIgnoreCase("M") ? personEmployment.getOccupationANM()
							: personEmployment.getOccupationANF()),
					personEmployment.getOccupationEN(),personAddress.getFlatNumber(),
					personAddress.getBuildingNumber(), personAddress.getNameAlphaEnglish(),
					personAddress.getRoadNumber(), personAddress.getBlockNumber(), personAddress.getRoadNameArabic(),
					personAddress.getRoadNameEnglish(),
					(personAddress.getAreaCode() == null? null :""+personAddress.getAreaCode()),
					(personContact.getMobile() == null?personContact.getContactPhone() : personContact.getMobile()),
					personContact.getEmail1());

			if (logger.isDebugEnabled()) {
				logger.debug("getMOHDemographicInfo(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getMOHDemographicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Demographic Info Not found",
					new ApplicationException(exception.getMessage()));
		}
		return mohDemographicInfoDTO;
	}
	
	@Override
	@Secured(
//	{ "ROLE_getPersonBasicInfoByCPR" })
			{ "ROLE_getMOHDemographicInfo" })
	@WebMethod(operationName = "getMOHDemographicInfoByIdNumber")
	public MOHDemographicInfoDTO getMOHDemographicInfoByIdNumber(SecurityTagObject security, String idNumber,
			String nationalityCode) throws ApplicationExceptionInfo {
		MOHDemographicInfoDTO mohDemographicInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getMOHDemographicInfoByIdNumber(Integer, Integer, Date) - start");
			logger.debug("getMOHDemographicInfoByIdNumber(idNumber = " + idNumber + ")");
		}
		
		if(nationalityCode == null || "".equals(nationalityCode.trim())){
			nationalityCode = "499";
		}
		
		
		Integer cprNumber = 0;
		
//		Integer id = null;
//		try {
//			id = getCrsService().getPersonServiceRef().getGccNationalSn(idNumber, nationalityCode);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			logger.debug("ERROR: " + e.getMessage());
//		}
//
//		if (id != null) {
//			cprNumber = id;
//		} else {
//
//			try {
//				cprNumber = Integer.parseInt(idNumber);
//			} catch (Exception e) {
//				// TODO: handle exception
//				throw new ApplicationExceptionInfo("Id Number", new ApplicationException("Invalid Id Number"));
//			}
//
//		}
		try {
			cprNumber = validationUtil.getGCCCpr(idNumber, nationalityCode);
		} catch (Exception e) {
				throw new ApplicationExceptionInfo("Id Number", new ApplicationException("Invalid Id Number"));
			}
			
		if (validationUtil.isMilitaryCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		}
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("ID Number Deleted", new ApplicationException("ID Number Deleted"));
		}
		
		try {
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final List<Address> personAddressList = getCrsService().getAddressServiceRef().getAddressDetails(cprNumber);
			final Contact personContact = getCrsService().getPersonServiceRef().getPersonContact(cprNumber);
			
			final List<Employment> personEmploymentList = getCrsService().getEmploymentServiceRef()
					.getActiveEmployments(cprNumber);
			Address personAddress = new Address();
			
			if(personAddressList != null && personAddressList.size() > 0){
				personAddress = personAddressList.get(0);
			}
			
			Employment personEmployment = null;
			
			if(personEmploymentList != null && personEmploymentList.size() > 0){
				personEmployment = personEmploymentList.get(0);
				logger.debug(personEmployment.getOccupationCode());
			}else{
				logger.debug("NO EMPLOYMENT FOUND");
				personEmployment = new Employment();
			}
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); 
			
			
			
			String natCode = personSummeryInfo.getNationalityCountryCode().trim();
			
			if( "499".equals(natCode)|| //BAH
				"441".equals(natCode)|| //KSA
				"411".equals(natCode)|| //UAE
				"430".equals(natCode)|| //KUWAIT
				"436".equals(natCode)|| //OMAN
				"440".equals(natCode)){ //QATAR
			
				natCode = ("1");	
			}else{
				natCode = ("0");	
			}
			
			
			mohDemographicInfoDTO = new MOHDemographicInfoDTO(personSummeryInfo.getAge(),
					personSummeryInfo.getArabicFirstName(), personSummeryInfo.getArabicMiddleName1(),
					personSummeryInfo.getArabicMiddleName2(), personSummeryInfo.getArabicMiddleName3(),
					personSummeryInfo.getArabicMiddleName4(), personSummeryInfo.getArabicFamilyName(),
					personSummeryInfo.getEnglishFirstName(), personSummeryInfo.getEnglishMiddleName1(),
					personSummeryInfo.getEnglishMiddleName2(), personSummeryInfo.getEnglishMiddleName3(),
					personSummeryInfo.getEnglishMiddleName4(), personSummeryInfo.getEnglishFamilyName(), idNumber,
					sdf.format(personSummeryInfo.getDateOfBirth()), personSummeryInfo.getGender(), natCode,
					personSummeryInfo.getArabicFullName(), personSummeryInfo.getEnglishFullName(),
					personSummeryInfo.getReligionCode(), personSummeryInfo.getMaritalStatusCode(),
					personEmployment.getOccupationCode(),
					(personSummeryInfo.getGender().equalsIgnoreCase("M") ? personEmployment.getOccupationANM()
							: personEmployment.getOccupationANF()),
					personEmployment.getOccupationEN(),personAddress.getFlatNumber(),
					personAddress.getBuildingNumber(), personAddress.getNameAlphaEnglish(),
					personAddress.getRoadNumber(), personAddress.getBlockNumber(), personAddress.getRoadNameArabic(),
					personAddress.getRoadNameEnglish(),
					(personAddress.getAreaCode() == null ? null : "" + personAddress.getAreaCode()),
					(personContact.getContactPhone() != null ? personContact.getContactPhone()
							: personContact.getMobile()),
					personContact.getEmail1());

			if (logger.isDebugEnabled()) {
				logger.debug("getMOHDemographicInfoByIdNumber(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error(
						"getMOHDemographicInfoByIdNumber(Integer, Integer, Date) Error: " + exception.getMessage());
		}
			throw new ApplicationExceptionInfo("Demographic Info Not found",
					new ApplicationException(exception.getMessage()));
		}
		return mohDemographicInfoDTO;
			}


	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}
}
