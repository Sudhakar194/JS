package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "SWDEmployeeInformation", propOrder = { "englishName", "arabicName", "ioStatus", "deathDate",
		"maritalStatus", "labourForceParticipation", "hasCR", "numberOfCRs" })
public class SWDPersonServiceSummaryDTO {
	private String englishName;
	private String arabicName;
	private String ioStatus;
	private Date deathDate;
	private String maritalStatus;
	private String labourForceParticipation;
	private Boolean hasCR;
	private Integer numberOfCRs;

	public SWDPersonServiceSummaryDTO(String englishName, String arabicName, String ioStatus, Date deathDate,
			String maritalStatus, String labourForceParticipation, Boolean hasCR, Integer numberOfCRs) {
		super();
		this.englishName = englishName;
		this.arabicName = arabicName;
		this.ioStatus = ioStatus;
		this.deathDate = deathDate;
		this.maritalStatus = maritalStatus;
		this.labourForceParticipation = labourForceParticipation;
		this.hasCR = hasCR;
		this.numberOfCRs = numberOfCRs;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public SWDPersonServiceSummaryDTO() {
		super();
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getIoStatus() {
		return ioStatus;
	}

	public void setIoStatus(String ioStatus) {
		this.ioStatus = ioStatus;
	}

	public Date getDeathDate() {
		return deathDate;
	}

	public void setDeathDate(Date deathDate) {
		this.deathDate = deathDate;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getLabourForceParticipation() {
		return labourForceParticipation;
	}

	public void setLabourForceParticipation(String labourForceParticipation) {
		this.labourForceParticipation = labourForceParticipation;
	}

	public Boolean getHasCR() {
		return hasCR;
	}

	public void setHasCR(Boolean hasCR) {
		this.hasCR = hasCR;
	}

	public Integer getNumberOfCRs() {
		return numberOfCRs;
	}

	public void setNumberOfCRs(Integer numberOfCRs) {
		this.numberOfCRs = numberOfCRs;
	}
}
