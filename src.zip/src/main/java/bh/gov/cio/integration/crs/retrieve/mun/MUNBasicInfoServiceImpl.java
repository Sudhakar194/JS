package bh.gov.cio.integration.crs.retrieve.mun;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.cr.CRDetails;
import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.unit.UnitInfo;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.service.UnitService;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.mun.service.MUNBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.mun.service.dto.CRUnitAddressDTO;
import bh.gov.cio.integration.crs.retrieve.mun.service.dto.MUNServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonMUNBasicInfoService", targetNamespace = "http://service.MUN.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonMUNBasicInfoService"
public class MUNBasicInfoServiceImpl implements MUNBasicInfoServiceInterface, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(MUNBasicInfoServiceImpl.class);
	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getMUNBasicInfo" })
	@WebMethod(operationName = "getMUNBasicInfo")
	public MUNServiceBasicInfoDTO getPersonMUNBasicInfo(SecurityTagObject security, String CountryCode, String idNumber)
			throws ApplicationExceptionInfo {
		if (logger.isDebugEnabled())
			logger.debug("getPersonMUNBasicInfo(Integer, IDType) - start");

		MUNServiceBasicInfoDTO MUNServiceBasicInfoDTO = null;
		PersonService ps = crsService.getPersonServiceRef();
		AddressService as = crsService.getAddressServiceRef();

		Integer cprNumber = 0;

		try {
			cprNumber = validationUtil.getGCCCpr(idNumber, CountryCode);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "001"));
		}

		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "002"));
		}
		try {
			PersonBasicInfo pbi = ps.getPersonBasicInfo(cprNumber);
			PersonSummary psi = ps.getPersonSummary(cprNumber);
//			String nationalityCode = pbi.getNationalityCode();
			Address a = as.getAddressDetailsByCpr(cprNumber);
			String inout = psi.getIoStatusCode();
			String DB_INOUT_STATUS_IN			=	"0";
			String DB_INOUT_STATUS_OUT			=	"2";
			String DB_INOUT_STATUS_RPCAN_IN		=	"4";
			String DB_INOUT_STATUS_RPCAN_OUT	=	"3";
			String DB_INOUT_STATUS_DATAINV_IN	=	"5";
			String DB_INOUT_STATUS_DATAINV_OUT	=	"6";
			String DB_INOUT_STATUS_DEAD			=	"1";
			
			String INOUT_STATUS_IN				=	"01";
			String INOUT_STATUS_OUT				=	"02";
			String INOUT_STATUS_DEAD				=	"03";
			String tempIO = "01";
				if(DB_INOUT_STATUS_DATAINV_IN.equals(inout) || DB_INOUT_STATUS_IN.equals(inout) || DB_INOUT_STATUS_RPCAN_IN.equals(inout))
					tempIO = INOUT_STATUS_IN;
 				else if(DB_INOUT_STATUS_DATAINV_OUT.equals(inout) || DB_INOUT_STATUS_OUT.equals(inout) || DB_INOUT_STATUS_RPCAN_OUT.equals(inout))
 					tempIO = INOUT_STATUS_OUT;
 				else if(DB_INOUT_STATUS_DEAD.equals(inout))
 					tempIO = INOUT_STATUS_DEAD;

			MUNServiceBasicInfoDTO = new MUNServiceBasicInfoDTO(idNumber, pbi.getArabicName(),
					pbi.getEnglishName(), pbi.getNationalityArabicName(), pbi.getNationalityEnglishName(),
					tempIO + "", a.getBlockNumber() + "", a.getRoadNumber() + "",
					a.getRoadNameArabic() + "", a.getRoadNameEnglish() + "", a.getBuildingNumber() + "",
					a.getFlatNumber() + "");
		} catch (final Exception exception) {
			if (logger.isDebugEnabled())
				logger.error("getPersonMUNBasicInfo(Integer, IDType) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Employment Basic Details Not found",
					new ApplicationException(exception.getMessage(), "003"));
		}
		return MUNServiceBasicInfoDTO;
	}
	//
	// @Override
	// @Secured({ "ROLE_getMUNBasicInfo" })
	// @WebMethod(operationName = "getOwnerFlatNumbers")
	// public MUNServiceFlatListDTO getOwnerFlatNumbers(
	// @WebParam(mode = WebParam.Mode.IN, name = "Security", header = true)
	// SecurityTagObject security,
	// @WebParam(name = "CountryCode") @XmlElement(required = true) String
	// CountryCode,
	// @WebParam(name = "idNumber") @XmlElement(required = true) String
	// idNumber,
	// @WebParam(name = "BuildingNumber") @XmlElement(required = true) Integer
	// buildingNumber,
	// @WebParam(name = "BuildingAlpha") @XmlElement(required = true) String
	// buildingAlpha,
	// @WebParam(name = "RoadNumber") @XmlElement(required = true) Integer
	// roadNumber,
	// @WebParam(name = "BlockNumber") @XmlElement(required = true) Integer
	// blockNumber)
	// throws ApplicationExceptionInfo {
	// MUNServiceFlatListDTO result = new MUNServiceFlatListDTO();
	// Integer cprNumber = 0;
	//
	// try {
	// cprNumber = validationUtil.getGCCCpr(idNumber, CountryCode);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "001"));
	// }
	//
	// if (validationUtil.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "002"));
	// }
	// boolean isExpired = false;
	// try {
	// Date cardExpiry = validationUtil.getCPRNumberExpiry(cprNumber);
	// isExpired = cardExpiry.before(new Date());
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// BuildingSearchItems bsi = new BuildingSearchItems(buildingNumber,
	// roadNumber, blockNumber, buildingAlpha);
	// ArrayList<Integer> flatNumbers = new ArrayList<Integer>();
	// ArrayList<AddressOwner> addList = null;
	// ArrayList<Building> bldgs = null;
	// ArrayList<Address> addresses = null;
	// // check if cpr is one of the owners
	// boolean ownerFound = false;
	// try {
	// bldgs = (ArrayList<Building>)
	// getCrsService().getAddressServiceRef().getBuildingDetails(bsi);
	// for (Building building : bldgs) {
	// addresses = (ArrayList<Address>) building.getAddresses();
	// for (Address address : addresses) {
	// addList = (ArrayList<AddressOwner>)
	// getCrsService().getAddressServiceRef()
	// .getAddressOwner(address.getAddressSn());
	//
	// logger.debug("Address Search Size: {}", addList.size());
	// for (Iterator<AddressOwner> iterator = addList.iterator();
	// iterator.hasNext();) {
	// AddressOwner addressOwner = (AddressOwner) iterator.next();
	// logger.debug("Owner Number : {}", addressOwner.getAddressOwnerId());
	// if (addressOwner.getAddressOwnerId().equals(cprNumber + "")) {
	// ownerFound = true;
	// break;
	// }
	//
	// }
	// logger.debug("Flat Number : {}", address.getFlatNumber());
	// flatNumbers.add(address.getFlatNumber());
	// }
	// }
	//
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Address is Not correct",
	// new ApplicationException("Address is Not correct", "003"));
	// }
	//
	// if (!ownerFound)
	// throw new ApplicationExceptionInfo("Owner CPR is Not Match",
	// new ApplicationException("Owner CPR is Not Match", "004"));
	// result.setFlatsNumber(flatNumbers);
	// return result;
	// }

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

	@Override
	@Secured({ "ROLE_getMUNBasicInfo" })
	@WebMethod(operationName = "getCRUnitAddressInfo")
	public CRUnitAddressDTO getCRUnitAddressInfo(SecurityTagObject security, Integer crUnitNumber)
			throws ApplicationExceptionInfo {
		UnitService us = getCrsService().getUnitServiceRef();
		UnitInfo unitBasicInfo = null;
		CRUnitAddressDTO crUnitAddressDTO = new CRUnitAddressDTO();
		try {
			unitBasicInfo = us.getUnitBasicInfo(crUnitNumber);
			final List<bh.gov.cio.crs.model.unit.UnitAddress> addresses = getCrsService()
					.getUnitServiceRef().getUnitAddresses(crUnitNumber);
			if (addresses.size() == 0)
				throw new BusinessException("Unit Address Details Not found");
			final bh.gov.cio.crs.model.unit.UnitAddress returnedAddressRow = addresses
					.get(addresses.size() - 1);
			crUnitAddressDTO = new CRUnitAddressDTO(crUnitNumber,unitBasicInfo.getUnitArabicName(), unitBasicInfo.getUnitEnglishName(), "UNIT", returnedAddressRow.getBlockNumber()+"", returnedAddressRow.getRoadNumber()+"", returnedAddressRow.getRoadArName(), returnedAddressRow.getRoadEnName(), returnedAddressRow.getBuildingNumber()+"", returnedAddressRow.getFlatNumber()+"");
			logger.debug("Unit Address:{}",returnedAddressRow);
		} catch (Exception e) {
			e.printStackTrace();
			try {
				CRDetails crDetails = us.getCrBasicInfo(crUnitNumber);
				if("F".equals(crDetails.getIsActive())){
					throw new ApplicationExceptionInfo("CR is canceled", new ApplicationException("CR is canceled"));
				}
				crUnitAddressDTO = new CRUnitAddressDTO(crUnitNumber,crDetails.getCrArabicName(), crDetails.getCrEnglishName(), "CR", crDetails.getBlock()+"", crDetails.getRoad()+"", crDetails.getRoadName(), crDetails.getRoadName(), crDetails.getBuilding()+"", crDetails.getFlat()+"");
				logger.debug("CR Address:{}",crDetails);
				} catch (Exception ex) {
					ex.printStackTrace();
					throw new ApplicationExceptionInfo("Failed To Retrieve Information", new ApplicationException("Failed To Retrieve Information","001"));
				}
		}
		return crUnitAddressDTO;
	}

}
