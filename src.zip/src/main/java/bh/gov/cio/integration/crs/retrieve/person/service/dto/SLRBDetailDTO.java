package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "cprNumber", "cprNumberExpiry", "blockNumber", "areaArabicName", "areaEnglishName", "arabicName",
		"englishName","alive","nationality"})
public class SLRBDetailDTO {
	private Integer cprNumber;
	private Date cprNumberExpiry;
	private Integer blockNumber;
	private String areaArabicName;
	private String areaEnglishName;
	private String arabicName;
	private String englishName;
	private String nationality;
	private boolean isAlive;

	public SLRBDetailDTO() {
		super();
	}

	public SLRBDetailDTO(Integer cprNumber, String arabicName, String englishName, boolean isAlive, Date cprNumberExpiry, Integer blockNumber, String areaArabicName,
			String areaEnglishName,String nationality) {
		super();
		this.cprNumber = cprNumber != null ? cprNumber : 0;
		this.arabicName = arabicName != null ? arabicName : "";
		this.englishName = englishName != null ? englishName : "";
		this.cprNumberExpiry = cprNumberExpiry;
		this.blockNumber = blockNumber;
		this.areaArabicName = areaArabicName;
		this.areaEnglishName = areaEnglishName;
		this.isAlive = isAlive;
		this.nationality = nationality;
	}

	public Integer getCprNumber() {
		return cprNumber;
	}

	public void setCprNumber(Integer cprNumber) {
		this.cprNumber = cprNumber;
	}

	public Date getCprNumberExpiry() {
		return cprNumberExpiry;
	}

	public void setCprNumberExpiry(Date cprNumberExpiry) {
		this.cprNumberExpiry = cprNumberExpiry;
	}

	public Integer getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}

	public String getAreaArabicName() {
		return areaArabicName;
	}

	public void setAreaArabicName(String areaArabicName) {
		this.areaArabicName = areaArabicName;
	}

	public String getAreaEnglishName() {
		return areaEnglishName;
	}

	public void setAreaEnglishName(String areaEnglishName) {
		this.areaEnglishName = areaEnglishName;
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public boolean isAlive() {
		return isAlive;
	}

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}


}
