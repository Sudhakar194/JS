package bh.gov.cio.integration.crs.validateDependent.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "GetDependentMemberDetails", 
         propOrder = {"idNumber", "dependentFullNameArabic","dependentFullNameArabic"})
public class GetDependentMemberNameDTO {
	
	private String idNumber;
	private String dependentFullNameAr;
	private String dependentFullNameEn;
	
	public GetDependentMemberNameDTO() {
		super();
	}
	
	public GetDependentMemberNameDTO(String idNumber, String dependentFullNameAr, String dependentFullNameEn){
		this.idNumber = idNumber;
		this.dependentFullNameAr = dependentFullNameAr;
		this.dependentFullNameEn = dependentFullNameEn;
	}
	
	@XmlElement(name = "IdNumber")
	public String getIdNumber() {
		return idNumber;
	}
	
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	
	@XmlElement(name = "DependentFullNameArabic")
	public String getDependentFullNameAr() {
		return dependentFullNameAr;
	}
	
	public void setDependentFullNameAr(String dependentFullNameAr) {
		this.dependentFullNameAr = dependentFullNameAr;
	}
	
	@XmlElement(name = "DependentFullNameEn")
	public String getDependentFullNameEn() {
		return dependentFullNameEn;
	}
	
	public void setDependentFullNameEn(String dependentFullNameEn) {
		this.dependentFullNameEn = dependentFullNameEn;
	}
	
	
	

}
