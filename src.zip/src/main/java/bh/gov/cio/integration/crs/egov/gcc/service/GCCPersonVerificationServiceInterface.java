package bh.gov.cio.integration.crs.egov.gcc.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.gcc.service.dto.GCCPersonVerificationDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "ValidateGCCPersonInfoService", targetNamespace = "http://service.gcc.egov.crs.integration.cio.gov.bh/")
public interface GCCPersonVerificationServiceInterface
{
	@WebResult(name = "GCCPersonInfo")
	@WebMethod(operationName = "ValidateGCCPersonInfo")
	GCCPersonVerificationDTO ValidateGCCPersonInfo(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "gender") @XmlElement(required = true) String gender,
			@WebParam(name = "nationality") @XmlElement(required = true) String nationality,
			@WebParam(name = "dob") @XmlElement(required = true) Date dob) throws ApplicationExceptionInfo;

	@WebResult(name = "GCCPersonCPR")
	@WebMethod(operationName = "getGCCPersonCPR")
	Integer getGCCPersonCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "nationality") @XmlElement(required = true) String countryCode) throws ApplicationExceptionInfo;
}
