package bh.gov.cio.integration.crs.nns.service;

import java.util.ArrayList;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import org.apache.cxf.annotations.WSDLDocumentation;

import bh.gov.cio.integration.crs.nns.dto.IdInputParamDTO;
import bh.gov.cio.integration.crs.nns.dto.IdOnlyInputParamDTO;
import bh.gov.cio.integration.crs.nns.dto.NotificationValidationInfoDTO;
import bh.gov.cio.integration.crs.nns.dto.NotificationValidationInfoListDTO;
import bh.gov.cio.integration.crs.nns.dto.StatusResponseDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NnsService", targetNamespace = "http://service.nns.crs.integration.cio.gov.bh/")
public interface NNSServiceInterface {

	//*****************************************************************************************************//
	//																										|
	//			1. Authenticate Citizen	With EKey		|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "authenticatePersonNotificationInfoWithEKey")
	@WSDLDocumentation("Service will allow applicants through bahrain.bh to retrieve notify contact numbers and email by three factor authentication. ")
	NotificationValidationInfoDTO authenticatePersonNotificationInfoWithEKey(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "eKeyIDNumber") @XmlElement(required = true) String eKeyIDNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp)
			throws ApplicationExceptionInfo;

	//*****************************************************************************************************//
	//																										|
	//			2. Authenticate Citizen	With (Block + CardExpiry) for Bahraini  OR Block Only For GCC		|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "authenticatePersonNotificationInfo")
	@WSDLDocumentation("Service will allow applicants through bahrain.bh to retrieve notify contact numbers and email by three factor authentication. ")
	NotificationValidationInfoDTO authenticatePersonNotificationInfo(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate)
			throws ApplicationExceptionInfo;

	//*****************************************************************************************************//
	//																										|
	//			3.(a) Register New With E-Key  Data															|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "registerPersonNoticationInformationWithEKey")
	StatusResponseDTO registerPersonNoticationInformationWithEKey(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "eKeyIDNumber") @XmlElement(required = true) String eKeyIDNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp,
			@WebParam(name = "primaryPhone") @XmlElement(required = true) String primaryPhone,
			@WebParam(name = "secondaryPhone") @XmlElement(required = true) String secondaryPhone,
			@WebParam(name = "primaryEmail") @XmlElement(required = true) String primaryEmail,
			@WebParam(name = "secondaryEmail") @XmlElement(required = true) String secondaryEmail,
			@WebParam(name = "username") @XmlElement(required = true) String username) throws ApplicationExceptionInfo;
	
	//*****************************************************************************************************//
	//																										|
	//			3.(b) Register New With (Block + CardExpiry) for Bahraini  OR Block Only For GCC			|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "registerPersonNoticationInformation")
	StatusResponseDTO registerPersonNoticationInformation(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate,
			@WebParam(name = "primaryPhone") @XmlElement(required = true) String primaryPhone,
			@WebParam(name = "secondaryPhone") @XmlElement(required = true) String secondaryPhone,
			@WebParam(name = "primaryEmail") @XmlElement(required = true) String primaryEmail,
			@WebParam(name = "secondaryEmail") @XmlElement(required = true) String secondaryEmail,
			@WebParam(name = "username") @XmlElement(required = true) String username) throws ApplicationExceptionInfo;

	
	
	//*****************************************************************************************************//
	//																										|
	//			4. Verify And Update Email without check EKey Or 3 Factor									|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "verifyAndUpdatePersonNoticationEmailInformation")
	@WSDLDocumentation("Service for update email by three factor authentication, service used by Bahrain.bh ")
	StatusResponseDTO verifyAndUpdatePersonNoticationEmailInformation(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "primaryPhone") @XmlElement(required = true) String primaryPhone,
			@WebParam(name = "email") @XmlElement(required = true) String email,
			@WebParam(name = "isPrimaryEmail") @XmlElement(required = true) String isPrimaryEmail,
			@WebParam(name = "username") @XmlElement(required = true) String username) throws ApplicationExceptionInfo;

	//*****************************************************************************************************//
	//																										|
	//			5.(a) Fetch Data With E-Key Data																|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "getPersonNotificationInfoWithEkey")
	@WSDLDocumentation("Service will allow applicants through bahrain.bh to update and view notification information ,using ekey ")
	NotificationValidationInfoDTO getPersonNotificationInfoWithEkey(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "eKeyIDNumber") @XmlElement(required = true) String eKeyIDNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp)
			throws ApplicationExceptionInfo;
	
	//*****************************************************************************************************//
	//																										|
	//			5.(b) Fetch Data With E-Key Data																|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "getPersonNotificationInfo")
	@WSDLDocumentation("Service will allow applicants through e-services channel to update and view notification information ,using 3 Factor ")
	NotificationValidationInfoDTO getPersonNotificationInfo(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate)
			throws ApplicationExceptionInfo;
	
	//*****************************************************************************************************//
	//																										|
	//			5.(c) Fetch Data With E-Key Data																|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "getPersonNotificationInfoByID")
	@WSDLDocumentation("Service will allow applicants through e-services channel to update and view notification information ,using 3 Factor ")
	NotificationValidationInfoDTO getPersonNotificationInfoByID(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry
			) throws ApplicationExceptionInfo;


	//*****************************************************************************************************//
	//																										|
	//			6.(a) Update With E-Key Data																|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "updatePersonNoticationInformationWithEkey")
	@WSDLDocumentation("Service for update email using ekey, service used by Bahrain.bh ")
	StatusResponseDTO updatePersonNoticationInformationWithEkey(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "eKeyIDNumber") @XmlElement(required = true) String eKeyIDNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp,
			@WebParam(name = "primaryPhone") @XmlElement(required = true) String primaryPhone,
			@WebParam(name = "isPrimaryPhoneUpdated") @XmlElement(required = true) String isPrimaryPhoneUpdated,
			@WebParam(name = "secondaryPhone") @XmlElement(required = true) String secondaryPhone,
			@WebParam(name = "isSecondaryPhoneUpdated") @XmlElement(required = true) String isSecondaryPhoneUpdated,
			@WebParam(name = "primaryEmail") @XmlElement(required = true) String primaryEmail,
			@WebParam(name = "isPrimaryEmailUpdated") @XmlElement(required = true) String isPrimaryEmailUpdated,
			@WebParam(name = "secondaryEmail") @XmlElement(required = true) String secondaryEmail,
			@WebParam(name = "isSecondaryEmailUpdated") @XmlElement(required = true) String isSecondaryEmailUpdated,
			@WebParam(name = "username") @XmlElement(required = true) String username) throws ApplicationExceptionInfo;

	
	
	//*****************************************************************************************************//
	//																										|
	//			6.(b) Update With (Block + CardExpiry) for Bahraini  OR Block Only For GCC					|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "updatePersonNoticationInformation")
	@WSDLDocumentation("Service for update email by three factor authentication, service used by Bahrain.bh ")
	StatusResponseDTO updatePersonNoticationInformation(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "idType") @XmlElement(required = true) String idType,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate,
			@WebParam(name = "primaryPhone") @XmlElement(required = true) String primaryPhone,
			@WebParam(name = "isPrimaryPhoneUpdated") @XmlElement(required = true) String isPrimaryPhoneUpdated,
			@WebParam(name = "secondaryPhone") @XmlElement(required = true) String secondaryPhone,
			@WebParam(name = "isSecondaryPhoneUpdated") @XmlElement(required = true) String isSecondaryPhoneUpdated,
			@WebParam(name = "primaryEmail") @XmlElement(required = true) String primaryEmail,
			@WebParam(name = "isPrimaryEmailUpdated") @XmlElement(required = true) String isPrimaryEmailUpdated,
			@WebParam(name = "secondaryEmail") @XmlElement(required = true) String secondaryEmail,
			@WebParam(name = "isSecondaryEmailUpdated") @XmlElement(required = true) String isSecondaryEmailUpdated,
			@WebParam(name = "username") @XmlElement(required = true) String username) throws ApplicationExceptionInfo;
	
	//*****************************************************************************************************//
	//																										|
	//		Addition - Not In the Document																	|
	//			7. Retrieve List Of Notification Information By ID Number And Id Type						|
	//																										|
	//*****************************************************************************************************//
	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "getPersonNotificationInfoByIdsList")
	@WSDLDocumentation("Service will allow NNS(National Notification system) to retrieve notify contact numbers and email by List of id numbers. ")
	ArrayList<NotificationValidationInfoListDTO> getPersonNotificationInfoByIdsList(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idsList") @XmlElement(required = true) ArrayList<IdInputParamDTO> idNumbers) throws ApplicationExceptionInfo;

	@WebResult(name = "NotificationInfo")
	@WebMethod(operationName = "getPersonNotificationInfoByIdsOnlyList")
	@WSDLDocumentation("Service will allow NNS(National Notification system) to retrieve notify contact numbers and email by List of id numbers. ")
	ArrayList<NotificationValidationInfoListDTO> getPersonNotificationInfoByIdsOnlyList(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idsList") @XmlElement(required = true) ArrayList<IdOnlyInputParamDTO> idNumbers) throws ApplicationExceptionInfo;



	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	@WebResult(name = "NotificationInfo")
//	@WebMethod(operationName = "getPersonNotificationInfoById")
//	@WSDLDocumentation("Service will allow NNS(National Notification system) to retrieve notify contact numbers and email by id number. ")
//	NotificationInfoDTO getPersonNotificationInfoById(
//			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
//			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
//			@WebParam(name = "idType") @XmlElement(required = true) String idType) throws ApplicationExceptionInfo;
//
//
//	@WebResult(name = "NotificationInfo")
//	@WebMethod(operationName = "getIsPersonRegisteredForNotification")
//	@WSDLDocumentation("Service will check if the person has existing contact numbers and email, service will both used by NNS and Bahrain.bh ")
//	NotificationInfoDTO getIsPersonRegisteredForNotification(
//			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
//			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
//			@WebParam(name = "idType") @XmlElement(required = true) String idType) throws ApplicationExceptionInfo;

//	@WebResult(name = "NotificationInfo")
//	@WebMethod(operationName = "updatePersonNoticationPhoneInformationWithEkey")
//	@WSDLDocumentation("Service for update contact numbers, service used by Bahrain.bh ")
//	NotificationInfoDTO updatePersonNoticationPhoneInformationWithEkey(
//			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
//			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
//			@WebParam(name = "idType") @XmlElement(required = true) String idType,
//			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate,
//			@WebParam(name = "eKeyIDNumber") @XmlElement(required = true) String eKeyIDNumber,
//			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
//			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
//			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp,
//			@WebParam(name = "primaryPhone") @XmlElement(required = true) String primaryPhone,
//			@WebParam(name = "isPrimaryPhoneUpdated") @XmlElement(required = true) String isPrimaryPhoneUpdated,
//			@WebParam(name = "secondaryPhone") @XmlElement(required = true) String secondaryPhone,
//			@WebParam(name = "isSecondaryPhoneUpdated") @XmlElement(required = true) String isSecondaryPhoneUpdated,
//			@WebParam(name = "primaryEmail") @XmlElement(required = true) String primaryEmail,
//			@WebParam(name = "isPrimaryEmailUpdated") @XmlElement(required = true) String isPrimaryEmailUpdated,
//			@WebParam(name = "secondaryEmail") @XmlElement(required = true) String secondaryEmail,
//			@WebParam(name = "isSecondaryEmailUpdated") @XmlElement(required = true) String isSecondaryEmailUpdated,
//			@WebParam(name = "username") @XmlElement(required = true) String username) throws ApplicationExceptionInfo;

//	@WebResult(name = "NotificationInfo")
//	@WebMethod(operationName = "updatePersonNoticationPhoneInformation")
//	@WSDLDocumentation("Service for update contact numbers by three factor authentication, service used by Bahrain.bh ")
//	NotificationInfoDTO updatePersonNoticationPhoneInformation(
//			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
//			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
//			@WebParam(name = "idType") @XmlElement(required = true) String idType,
//			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate,
//			@WebParam(name = "primaryPhone") @XmlElement(required = true) String primaryPhone,
//			@WebParam(name = "isPrimaryPhoneUpdated") @XmlElement(required = true) String isPrimaryPhoneUpdated,
//			@WebParam(name = "secondaryPhone") @XmlElement(required = true) String secondaryPhone,
//			@WebParam(name = "isSecondaryPhoneUpdated") @XmlElement(required = true) String isSecondaryPhoneUpdated,
//			@WebParam(name = "primaryEmail") @XmlElement(required = true) String primaryEmail,
//			@WebParam(name = "isPrimaryEmailUpdated") @XmlElement(required = true) String isPrimaryEmailUpdated,
//			@WebParam(name = "secondaryEmail") @XmlElement(required = true) String secondaryEmail,
//			@WebParam(name = "isSecondaryEmailUpdated") @XmlElement(required = true) String isSecondaryEmailUpdated,
//			@WebParam(name = "username") @XmlElement(required = true) String username) throws ApplicationExceptionInfo;

//
}
