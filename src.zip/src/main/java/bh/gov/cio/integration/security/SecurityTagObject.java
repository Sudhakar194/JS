package bh.gov.cio.integration.security;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

//@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Security", propOrder =
{ "userNameToken" })
public final class SecurityTagObject implements Serializable
{

	/**
	 * 
	 */
	private static final long		serialVersionUID	= -3718311234005696272L;
	private UserNameTokenTagObject	userNameToken;

	@XmlElement(name = "UsernameToken"/* , namespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" */,
			required = true)
	public UserNameTokenTagObject getUserNameToken()
	{
		return userNameToken;
	}

	public void setUserNameToken(UserNameTokenTagObject userNameToken)
	{
		this.userNameToken = userNameToken;
	}

}
