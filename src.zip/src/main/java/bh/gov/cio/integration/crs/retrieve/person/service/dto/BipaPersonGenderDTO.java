package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;




@XmlType(
		propOrder =
		{ "cprNumber", "firstArabicName","middleArabicName","lastArabicName", "firstEnglishName","middleEnglishName","lastEnglishName",	"gender" })
public class BipaPersonGenderDTO
{
	private Integer	cprNumber;
	private String	firstArabicName;
	private String	firstEnglishName;
	private String	middleArabicName;
	private String	middleEnglishName;
	private String	lastArabicName;
	private String	lastEnglishName;
	private String	gender;

	public BipaPersonGenderDTO()
	{
		super();
	}


	@XmlElement(name = "cprNumber",required = true)
	public Integer getCprNumber() {
		return cprNumber;
	}

	public void setCprNumber(Integer cprNumber) {
		this.cprNumber = cprNumber;
	}

	@XmlElement(name = "gender",required = true)
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@XmlElement(name = "firstArabicName",required = true)
	public String getFirstArabicName() {
		return firstArabicName;
	}


	public void setFirstArabicName(String firstArabicName) {
		this.firstArabicName = firstArabicName;
	}


	@XmlElement(name = "firstEnglishName",required = true)
	public String getFirstEnglishName() {
		return firstEnglishName;
	}


	public void setFirstEnglishName(String firstEnglishName) {
		this.firstEnglishName = firstEnglishName;
	}


	@XmlElement(name = "middleArabicName",required = true)
	public String getMiddleArabicName() {
		return middleArabicName;
	}


	public void setMiddleArabicName(String middleArabicName) {
		this.middleArabicName = middleArabicName;
	}


	@XmlElement(name = "middleEnglishName",required = true)
	public String getMiddleEnglishName() {
		return middleEnglishName;
	}


	public void setMiddleEnglishName(String middleEnglishName) {
		this.middleEnglishName = middleEnglishName;
	}


	@XmlElement(name = "lastArabicName",required = true)
	public String getLastArabicName() {
		return lastArabicName;
	}


	public void setLastArabicName(String lastArabicName) {
		this.lastArabicName = lastArabicName;
	}


	@XmlElement(name = "lastEnglishName",required = true)
	public String getLastEnglishName() {
		return lastEnglishName;
	}


	public void setLastEnglishName(String lastEnglishName) {
		this.lastEnglishName = lastEnglishName;
	}


	public BipaPersonGenderDTO(Integer cprNumber, String firstArabicName, String firstEnglishName,
			String middleArabicName, String middleEnglishName, String lastArabicName, String lastEnglishName,
			String gender) {
		super();
		this.cprNumber = cprNumber;
		this.firstArabicName = firstArabicName;
		this.firstEnglishName = firstEnglishName;
		this.middleArabicName = middleArabicName;
		this.middleEnglishName = middleEnglishName;
		this.lastArabicName = lastArabicName;
		this.lastEnglishName = lastEnglishName;
		this.gender = gender;
	}

	

}
