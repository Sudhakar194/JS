package bh.gov.cio.integration.crs.retrieve.person;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.person.Family;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.GOYSPersonBasicInfoInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.GOYSPersonBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/", portName = "GOYSPersonBasicInfoImplPort")
//, serviceName = "GOYSPersonBasicInfoImplService"
public class GOYSPersonBasicInfoImpl implements GOYSPersonBasicInfoInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonBasicInfoServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	@Autowired
	private PropertyServiceImpl	propImpl;
	private boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp)
	{
		ValidateToken eKey = crsService.geteKeyServiceRef();
		String accessPassword = propImpl.geteGOVeKeyPassword();
		String response = null;
		CryptoUtil cryptoUtil = new CryptoUtil();
		try
		{
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber), cryptoUtil.encrypt(eKeyServiceID),
					cryptoUtil.encrypt(eKeyTokenID), cryptoUtil.encrypt(eKeyTimestamp));
			response = cryptoUtil.decrypt(response);
			logger.debug("eKey Response:" + response);
		}
		catch (Exception e)
		{

			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));

	}

	@Override
	@Secured(
	{ "ROLE_getGOYSPersonBasicInfo" })
	@WebMethod(operationName = "getGOYSPersonBasicInfo")
	public GOYSPersonBasicInfoDTO getGOYSPersonBasicInfo(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{

		if (logger.isDebugEnabled())
		{

			logger.debug("getGOYSPersonBasicInfo(Integer)" + ":" + cprNumber);
		}

		GOYSPersonBasicInfoDTO GOYSPersonDTO = new GOYSPersonBasicInfoDTO();

		try
		{
			final PersonBasicInfo personBasicInfo = crsService.getPersonServiceRef().getPersonBasicInfo(cprNumber);

			GOYSPersonDTO.setCprNumber(personBasicInfo.getCprString());
			GOYSPersonDTO.setArabicName(personBasicInfo.getArabicName());
			GOYSPersonDTO.setEnglishName(personBasicInfo.getEnglishName());
			GOYSPersonDTO.setDateOfBirth(DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()));
			GOYSPersonDTO.setGender(personBasicInfo.getGender());
			final boolean isBahraini = (personBasicInfo.getNationalityCode().equals("499") || personBasicInfo.getNationalityCode().equals("900")) ? true
					: false;
			String nationality = isBahraini ? "BH" : "NONBH";
			GOYSPersonDTO.setIsBahraini(nationality);

			/********** get person Address *************/
			List<Integer> cprList = new ArrayList<Integer>();
			cprList.add(cprNumber);
			final List<bh.gov.cio.crs.model.nas.Address> addresses = crsService.getAddressServiceRef().getAddressForListCprNumber(cprList);
			if (addresses.size() == 0)
			{
				throw new ApplicationExceptionInfo("Address Basic Details Not found.", new ApplicationException("Address Basic Details Not found.",
						"003"));
			}

			if (addresses != null)
			{
				final bh.gov.cio.crs.model.nas.Address returnedAddressRow = addresses.get(addresses.size() - 1);
				GOYSPersonDTO.setAreaArabicName(returnedAddressRow.getAreaNameArabic());
				GOYSPersonDTO.setAreaEnglishName(returnedAddressRow.getAreaNameEnglish());
				GOYSPersonDTO.setGovernorateArabicName(returnedAddressRow.getGovernorateNameArabic());
				GOYSPersonDTO.setGovernorateEnglishName(returnedAddressRow.getGovernorateNameEnglish());

			}

		}

		catch (Exception e)
		{

			if (logger.isDebugEnabled())
			{
				logger.error("getGOYSPersonBasicInfo(String, String, String,String) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found.", new ApplicationException("Person Basic Details Not found.", "002"));
		}

		return GOYSPersonDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getGOYSPersonBasicInfoWithEkey" })
	@WebMethod(operationName = "getGOYSPersonBasicInfoWithEkey")
	public GOYSPersonBasicInfoDTO getGOYSPersonBasicInfoWithEkey(SecurityTagObject security, Integer cprNumber, String eKeyCPRNumber,
			String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp) throws ApplicationExceptionInfo
	{
		GOYSPersonBasicInfoDTO GOYSPersonDTO = new GOYSPersonBasicInfoDTO();
		if (!checkeKeyResponse(eKeyCPRNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp))
		{
			throw new ApplicationExceptionInfo("Error in retrieving data...", new ApplicationException("Authentication Failed.", "001"));
		}

		try
		{
			if (logger.isDebugEnabled())
			{

				logger.debug("getGOYSPersonBasicInfoWithEkey(Integer)" + ":" + cprNumber);
			}
			final PersonBasicInfo personBasicInfo = crsService.getPersonServiceRef().getPersonBasicInfo(cprNumber);
			GOYSPersonDTO.setCprNumber(personBasicInfo.getCprString());
			GOYSPersonDTO.setArabicName(personBasicInfo.getArabicName());
			GOYSPersonDTO.setEnglishName(personBasicInfo.getEnglishName());
			GOYSPersonDTO.setDateOfBirth(DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()));
			GOYSPersonDTO.setGender(personBasicInfo.getGender());
			final boolean isBahraini = (personBasicInfo.getNationalityCode().equals("499") || personBasicInfo.getNationalityCode().equals("900")) ? true
					: false;
			String nationality = isBahraini ? "BH" : "NONBH";
			GOYSPersonDTO.setIsBahraini(nationality);

			/********** get person Address *************/
			List<Integer> cprList = new ArrayList<Integer>();
			cprList.add(cprNumber);
			final List<bh.gov.cio.crs.model.nas.Address> addresses = crsService.getAddressServiceRef().getAddressForListCprNumber(cprList);
			if (addresses.size() == 0)
			{
				throw new ApplicationExceptionInfo("Address Basic Details Not found.", new ApplicationException("Address Basic Details Not found.",
						"003"));
			}

			if (addresses != null)
			{
				final bh.gov.cio.crs.model.nas.Address returnedAddressRow = addresses.get(addresses.size() - 1);
				GOYSPersonDTO.setAreaArabicName(returnedAddressRow.getAreaNameArabic());
				GOYSPersonDTO.setAreaEnglishName(returnedAddressRow.getAreaNameEnglish());
				GOYSPersonDTO.setGovernorateArabicName(returnedAddressRow.getGovernorateNameArabic());
				GOYSPersonDTO.setGovernorateEnglishName(returnedAddressRow.getGovernorateNameEnglish());

			}

		}

		catch (Exception e)
		{

			if (logger.isDebugEnabled())
			{
				logger.error("getGOYSPersonBasicInfo(String, String, String,String) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found.", new ApplicationException("Person Basic Details Not found", "002"));
		}

		return GOYSPersonDTO;
	}

	@Override
	@Secured(
	{ "ROLE_isDependentGOYS" })
	@WebMethod(operationName = "isDependent")
	public boolean isDependent(SecurityTagObject security, Integer applicantCprNumber, Integer cprNumber) throws ApplicationExceptionInfo
	{
		boolean isDependent = false;
		if (logger.isDebugEnabled())
		{

			logger.debug("isDependent(Integer,Integer) for GOYS" + ":applicantCprNumber" + applicantCprNumber + " dependent cpr:" + cprNumber);
		}

		try
		{
			List<PersonSummary> personSiblingsList = crsService.getFamilyServiceRef().getPersonSiblings(cprNumber);
			Family family = crsService.getFamilyServiceRef().getPersonFatherMother(cprNumber);

			int count = 0;

			if (personSiblingsList != null)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("personSiblingsList size :" + personSiblingsList.size());
				}

				for (final PersonSummary SbilingsList : personSiblingsList)
				{
					final PersonSummary sbilings = SbilingsList;
					if (sbilings.getCprNumber().equals(applicantCprNumber))
					{
						isDependent = true;

						if (logger.isDebugEnabled())
						{
							logger.debug("isDependent() is true, the applicant :" + applicantCprNumber + " is sister or brother of  " + cprNumber);
						}
					}
					count++;
				}

			}

			if (family != null)
			{

				if (family.getMotherCprNumber().equals(applicantCprNumber))
				{

					isDependent = true;

					if (logger.isDebugEnabled())
					{
						logger.debug("isDependent() is true, the applicant :" + applicantCprNumber + " is mother of  " + cprNumber);
					}
				}

				if (family.getFatherCprNumber().equals(applicantCprNumber))
				{

					isDependent = true;

					if (logger.isDebugEnabled())
					{
						logger.debug("isDependent() is true, the applicant :" + applicantCprNumber + " is father of  " + cprNumber);
					}
				}

			}

		}

		catch (Exception e)
		{
			throw new ApplicationExceptionInfo("Person family details not found", new ApplicationException("Person family details not found.", "004"));
		}

		return isDependent;
	}
}
