package bh.gov.cio.integration.crs.egov.csb.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.egov.csb.service.dto.EmploymentBasicDetailsDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "RetrieveEmploymentBasicDetailsService", targetNamespace = "http://service.csb.egov.crs.integration.cio.gov.bh/")
public interface RetrieveEmploymentBasicDetailsInterface {
	@WebResult(name = "EmploymentBasicDetailsDTO")
	@WebMethod(operationName = "RetrieveEmploymentBasicDetails")
	EmploymentBasicDetailsDTO RetrieveEmploymentBasicDetails(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "idCountryCode") @XmlElement(required = true) String cardCountry,
			@WebParam(name = "eKeyIDNumber") @XmlElement(required = true) String eKeyIDNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp)
			throws ApplicationExceptionInfo;
}
