package bh.gov.cio.integration.crs.retrieve.person;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Contact;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonSpecialContactServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServiceContactDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(
		name = "PersonSpecialContactService",
		targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public class PersonSpecialContactServiceImpl implements
		PersonSpecialContactServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(PersonSpecialContactServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonSpecialContact" })
	@WebMethod(operationName = "getPersonSummery")
	public PersonServiceContactDTO getPersonSpecialContact(
			SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonSummery(Integer) - start");
			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ")");
		}
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted"));

		PersonServiceContactDTO personServiceSpecialContactDTO = null;
		try
		{
			final Contact contact = getCrsService().getPersonServiceRef()
					.getPersonContact(cprNumber);
			personServiceSpecialContactDTO = new PersonServiceContactDTO(
					contact.getMailBox() + "", contact.getContactPhone(),
					contact.getEmail1(), contact.getEmail2(),
					contact.getEmail3(), contact.getFax(),
					contact.getFaxWork(), contact.getMobile(),
					contact.getPhoneWork());

			if (logger.isDebugEnabled())
				logger.debug("getPersonSpecialContact() -  : personServiceSpecialContactDTO = "
						+ personServiceSpecialContactDTO);

			if (logger.isDebugEnabled())
				logger.debug("getPersonSummery(Integer, Integer, Date) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonSpecialContact(Integer, Integer, Date) Error: "
						+ exception.getMessage());
			throw new ApplicationExceptionInfo(
					"Person Special Contact Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personServiceSpecialContactDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
