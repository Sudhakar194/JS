package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "MOHDemographicInfoDTO", propOrder =
{		"idNumber", "nationality","age",
		"arabicFirstName","arabicSecondName","arabicThirdName","arabicFourthName","arabicFifthName","arabicLastName",
		"englishFirstName","englishSecondName","englishThirdName","englishFourthName","englishFifthName","englishLastName",
		 "birthDate",  "gender", "personFullNameArabic", "personFullNameEnglish", "religionCode",
		"occupationCode" ,"maritalStatus" ,"flat" ,"buildingNumber" ,"alpha" ,"roadNumber" ,"blockNumber" ,
		"roadNameAr","roadNameEn", "area","contactNumber","email","occupationAr", "occupationEn"})
public class MOHDemographicInfoDTO
{
	private String idNumber;
	private String nationality;
	private Integer age;
	private String arabicFirstName;
	private String arabicSecondName;
	private String arabicThirdName;
	private String arabicFourthName;
	private String arabicFifthName;
	private String arabicLastName;
	private String englishFirstName;
	private String englishSecondName;
	private String englishThirdName;
	private String englishFourthName;
	private String englishFifthName;
	private String englishLastName;
	private String birthDate;
	private String gender;
	private String personFullNameArabic;
	private String personFullNameEnglish;
	private String religionCode;
	private String maritalStatus;
	private String occupationCode;
	private String contactNumber;
	private String email;
	private String roadNameAr;
	private String roadNameEn;
	private String occupationAr;
	private String occupationEn;

	private Integer flat;
	private Integer buildingNumber;
	private String  alpha;
	private Integer roadNumber;
	private Integer blockNumber;
	private String	area;
	
	
	
	public MOHDemographicInfoDTO()
	{
		super();
	}

	
	
	
	
	public MOHDemographicInfoDTO(Integer age, String arabicFirstName,
			String arabicSecondName, String arabicThirdName,
			String arabicFourthName, String arabicFifthName,
			String arabicLastName, String englishFirstName,
			String englishSecondName, String englishThirdName,
			String englishFourthName, String englishFifthName,
			String englishLastName, String idNumber, String birthDate,
			String gender, String nationality, String personFullNameArabic,
			String personFullNameEnglish, String religionCode,
			String maritalStatus,String occupationCode, String occupationAr,String occupationEn,
			Integer flat,
			Integer buildingNumber,	String  alpha,Integer roadNumber,
			Integer blockNumber, String roadNameAr,String roadNameEn,
			String	area,String contactNumber,String email) {
		super();
		if (age != null)
		{
			setAge(age);
		}
		else
		{
			setAge(0);
		}
		if (birthDate != null)
		{
			setBirthDate(birthDate);
		}
		else
		{
			setBirthDate("");
		}
		if (idNumber != null)
		{
			setIdNumber(idNumber);
		}
		else
		{
			setIdNumber("");
		}
		if (gender != null)
		{
			setGender(gender);
		}
		else
		{
			setGender("");
		}
		if (nationality != null)
		{
			setNationality(nationality);
		}
		else
		{
			setNationality("");
		}
		if (religionCode != null)
		{
			setReligionCode(religionCode);
		}
		else
		{
			setReligionCode("");
		}
		if (maritalStatus != null)
		{
			setMaritalStatus(maritalStatus);
		}
		else
		{
			setMaritalStatus("");
		}
		if (arabicFirstName != null)
		{
			setArabicFirstName(arabicFirstName);
		}
		else
		{
			setArabicFirstName("");
		}
		if (arabicSecondName != null)
		{
			setArabicSecondName(arabicSecondName);
		}
		else
		{
			setArabicSecondName("");
		}
		if (arabicThirdName != null)
		{
			setArabicThirdName(arabicThirdName);
		}
		else
		{
			setArabicThirdName("");
		}
		if (arabicFourthName != null)
		{
			setArabicFourthName(arabicFourthName);
		}
		else
		{
			setArabicFourthName("");
		}
		if (arabicFifthName != null)
		{
			setArabicFifthName(arabicFifthName);
		}
		else
		{
			setArabicFifthName("");
		}
		if (arabicLastName != null)
		{
			setArabicLastName(arabicLastName);
		}
		else
		{
			setArabicLastName("");
		}
		if (englishFirstName != null)
		{
			setEnglishFirstName(englishFirstName);
		}
		else
		{
			setEnglishFirstName("");
		}
		if (englishSecondName != null)
		{
			setEnglishSecondName(englishSecondName);
		}
		else
		{
			setEnglishSecondName("");
		}
		if (englishThirdName != null)
		{
			setEnglishThirdName(englishThirdName);
		}
		else
		{
			setEnglishThirdName("");
		}
		if (englishFourthName != null)
		{
			setEnglishFourthName(englishFourthName);
		}
		else
		{
			setEnglishFourthName("");
		}
		if (englishFifthName != null)
		{
			setEnglishFifthName(englishFifthName);
		}
		else
		{
			setEnglishFifthName("");
		}
		if (englishLastName != null)
		{
			setEnglishLastName(englishLastName);
		}
		else
		{
			setEnglishLastName("");
		}
//		if (personFullNameArabic != null)
//		{
//			setPersonFullNameArabic(personFullNameArabic);
//		}
//		else
//		{
//			setPersonFullNameArabic("");
//		}
//		if (personFullNameEnglish != null)
//		{
//			setPersonFullNameEnglish(personFullNameEnglish);
//		}
//		else
//		{
//			setPersonFullNameEnglish("");
//		}
		if (occupationCode != null)
		{
			setOccupationCode(occupationCode);
		}
		else
		{
			setOccupationCode("");
		}
		
		if (flat != null)
		{
			setFlat(flat);
		}
		else
		{
			setFlat(0);
		}
		if (buildingNumber != null)
		{
			setBuildingNumber(buildingNumber);
		}
		else
		{
			setBuildingNumber(0);
		}
		if (alpha != null)
		{
			setAlpha(alpha);
		}
		else
		{
			setAlpha("");
		}
		if (roadNumber != null)
		{
			setRoadNumber(roadNumber);
		}
		else
		{
			setRoadNumber(0);
		}
		if (blockNumber != null)
		{
			setBlockNumber(blockNumber);
		}
		else
		{
			setBlockNumber(0);
		}
		if (area != null)
		{
			setArea(area);
		}
		else
		{
			setArea("");
		}
		if (contactNumber != null)
		{
			setContactNumber(contactNumber);
		}
		else
		{
			setContactNumber("");
		}
		if (email != null)
		{
			setEmail(email);
		}
		else
		{
			setEmail("");
		}
		if (roadNameAr != null)
		{
			setRoadNameAr(roadNameAr);
		}
		else
		{
			setRoadNameAr("");
		}
		if (roadNameEn != null)
		{
			setRoadNameEn(roadNameEn);
		}
		else
		{
			setRoadNameEn("");
		}
		if (occupationAr != null)
		{
			setOccupationAr(occupationAr);
		}
		else
		{
			setOccupationAr("");
		}
		if (occupationEn != null)
		{
			setOccupationEn(occupationEn);
		}
		else
		{
			setOccupationEn("");
		}
		
	}
	
	
	

	@XmlElement(name = "Age", required = true)
	public Integer getAge()
	{
		return age;
	}


	@XmlElement(name = "BirthDate", required = true)
	public java.lang.String getBirthDate()
	{
		return birthDate;
	}

	@XmlElement(name = "IdNumber", required = true)
	public String getIdNumber()
	{
		return idNumber;
	}



	@XmlElement(name = "Gender", required = true)
	public String getGender()
	{
		return gender;
	}

	@XmlElement(name = "MaritalStatus", required = true)
	public String getMaritalStatus()
	{
		return maritalStatus;
	}

	@XmlElement(name = "Nationality", required = true)
	public String getNationality()
	{
		return nationality;
	}


	@XmlElement(name = "ReligionCode", required = true)
	public String getReligionCode()
	{
		return religionCode;
	}
	
	@XmlElement(name = "ArabicFirstName", required = true)
	public String getArabicFirstName() {
		return arabicFirstName;
	}

	@XmlElement(name = "ArabicSecondName", required = true)
	public String getArabicSecondName() {
		return arabicSecondName;
	}

	@XmlElement(name = "ArabicThirdName", required = true)
	public String getArabicThirdName() {
		return arabicThirdName;
	}

	@XmlElement(name = "ArabicFourthName", required = true)
	public String getArabicFourthName() {
		return arabicFourthName;
	}

	@XmlElement(name = "ArabicFifthName", required = true)
	public String getArabicFifthName() {
		return arabicFifthName;
	}

	@XmlElement(name = "ArabicLastName", required = true)
	public String getArabicLastName() {
		return arabicLastName;
	}

	@XmlElement(name = "EnglishFirstName", required = true)
	public String getEnglishFirstName() {
		return englishFirstName;
	}

	@XmlElement(name = "EnglishSecondName", required = true)
	public String getEnglishSecondName() {
		return englishSecondName;
	}

	@XmlElement(name = "EnglishThirdName", required = true)
	public String getEnglishThirdName() {
		return englishThirdName;
	}

	@XmlElement(name = "EnglishFourthName", required = true)
	public String getEnglishFourthName() {
		return englishFourthName;
	}

	@XmlElement(name = "EnglishFifthName", required = true)
	public String getEnglishFifthName() {
		return englishFifthName;
	}

	@XmlElement(name = "EnglishLastName", required = true)
	public String getEnglishLastName() {
		return englishLastName;
	}

	@XmlElement(name = "PersonFullNameArabic", required = true)
	public String getPersonFullNameArabic() {
		return personFullNameArabic;
	}

	@XmlElement(name = "PersonFullNameEnglish", required = true)
	public String getPersonFullNameEnglish() {
		return personFullNameEnglish;
	}
	
	@XmlElement(name = "Flat", required = true)
	public Integer getFlat() {
		return flat;
	}

	@XmlElement(name = "BuildingNumber", required = true)
	public Integer getBuildingNumber() {
		return buildingNumber;
	}

	@XmlElement(name = "Alpha", required = true)
	public String getAlpha() {
		return alpha;
	}

	@XmlElement(name = "RoadNumber", required = true)
	public Integer getRoadNumber() {
		return roadNumber;
	}

	@XmlElement(name = "BlockNumber", required = true)
	public Integer getBlockNumber() {
		return blockNumber;
	}

	@XmlElement(name = "Area", required = true)
	public String getArea() {
		return area;
	}

	@XmlElement(name = "OccupationCode", required = true)
	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}





	public void setAge(Integer age)
	{
		this.age = age;
	}
	
	public void setArabicFirstName(String arabicFirstName) {
		this.arabicFirstName = arabicFirstName;
	}

	public void setArabicSecondName(String arabicSecondName) {
		this.arabicSecondName = arabicSecondName;
	}

	public void setArabicThirdName(String arabicThirdName) {
		this.arabicThirdName = arabicThirdName;
	}

	public void setArabicFourthName(String arabicFourthName) {
		this.arabicFourthName = arabicFourthName;
	}

	public void setArabicFifthName(String arabicFifthName) {
		this.arabicFifthName = arabicFifthName;
	}

	public void setArabicLastName(String arabicLastName) {
		this.arabicLastName = arabicLastName;
	}

	public void setEnglishFirstName(String englishFirstName) {
		this.englishFirstName = englishFirstName;
	}

	public void setEnglishSecondName(String englishSecondName) {
		this.englishSecondName = englishSecondName;
	}

	public void setEnglishThirdName(String englishThirdName) {
		this.englishThirdName = englishThirdName;
	}

	public void setEnglishFourthName(String englishFourthName) {
		this.englishFourthName = englishFourthName;
	}

	public void setEnglishFifthName(String englishFifthName) {
		this.englishFifthName = englishFifthName;
	}

	public void setEnglishLastName(String englishLastName) {
		this.englishLastName = englishLastName;
	}

	public void setPersonFullNameArabic(String personFullNameArabic) {
		this.personFullNameArabic = personFullNameArabic;
	}

	public void setPersonFullNameEnglish(String personFullNameEnglish) {
		this.personFullNameEnglish = personFullNameEnglish;
	}

	public void setBirthDate(java.lang.String birthDate)
	{
		this.birthDate = birthDate;
	}

	public void setIdNumber(String idNumber)
	{
		this.idNumber = idNumber;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public void setMaritalStatus(String maritalStatus)
	{
		this.maritalStatus = maritalStatus;
	}

	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}

	public void setReligionCode(String religionCode)
	{
		this.religionCode = religionCode;
	}



	public void setFlat(Integer flat) {
		this.flat = flat;
	}



	public void setBuildingNumber(Integer buildingNumber) {
		this.buildingNumber = buildingNumber;
	}



	public void setAlpha(String alpha) {
		this.alpha = alpha;
	}



	public void setRoadNumber(Integer roadNumber) {
		this.roadNumber = roadNumber;
	}



	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}



	public void setArea(String area) {
		this.area = area;
	}

	public String getOccupationCode() {
		return occupationCode;
	}





	public String getContactNumber() {
		return contactNumber;
	}





	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}





	public String getRoadNameAr() {
		return roadNameAr;
	}





	public void setRoadNameAr(String roadNameAr) {
		this.roadNameAr = roadNameAr;
	}





	public String getRoadNameEn() {
		return roadNameEn;
	}





	public void setRoadNameEn(String roadNameEn) {
		this.roadNameEn = roadNameEn;
	}





	public String getEmail() {
		return email;
	}





	public void setEmail(String email) {
		this.email = email;
	}





	public String getOccupationAr() {
		return occupationAr;
	}





	public void setOccupationAr(String occupationAr) {
		this.occupationAr = occupationAr;
	}





	public String getOccupationEn() {
		return occupationEn;
	}





	public void setOccupationEn(String occupationEn) {
		this.occupationEn = occupationEn;
	}





	
	

}
