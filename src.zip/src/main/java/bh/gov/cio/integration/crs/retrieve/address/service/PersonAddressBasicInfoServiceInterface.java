package bh.gov.cio.integration.crs.retrieve.address.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonAddressBasicInfoService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
public interface PersonAddressBasicInfoServiceInterface
{

	@WebResult(name = "AddressBasicInformatoin")
	@WebMethod(operationName = "getPersonAddressBasicInfo")
	AddressServiceBasicInfoDTO getPersonAddressBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security,

	@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber, @WebParam(name = "cardExpiryDate") @XmlElement(
					required = true) Date cardExpiryDate /* yyyyMMdd */) throws ApplicationExceptionInfo;

	@WebResult(name = "AddressBasicInformatoin")
	@WebMethod(operationName = "getPersonAddressBasicInfoByCPR")
	AddressServiceBasicInfoDTO getPersonAddressBasicInfoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security",
	// targetNamespace = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd",
			header = true) SecurityTagObject security,

	@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
