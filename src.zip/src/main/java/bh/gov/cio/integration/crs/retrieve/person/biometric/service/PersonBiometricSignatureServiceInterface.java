package bh.gov.cio.integration.crs.retrieve.person.biometric.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.biometric.service.dto.PersonBiometricSignatureDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonBiometricSignatureService", targetNamespace = "http://service.biometric.person.retrieve.crs.integration.cio.gov.bh/")
public interface PersonBiometricSignatureServiceInterface
{
//	@WebResult(name = "SignatureDetails")
//	@WebMethod(operationName = "getPersonSignature")
//	PersonBiometricSignatureDTO getPersonSignature(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
//			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "SignatureDetails")
	@WebMethod(operationName = "getPersonSignatureByCPR")
	PersonBiometricSignatureDTO getPersonSignatureByCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

	@WebResult(name = "SignatureDetails")
	@WebMethod(operationName = "getPersonSpecialSignatureByCPR")
	PersonBiometricSignatureDTO getPersonSpecialSignatureByCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
