package bh.gov.cio.integration.crs.egov.moe;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.joda.time.LocalDate;
import org.joda.time.Period;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.person.Family;
import bh.gov.cio.crs.model.person.GDNPRDocument;
import bh.gov.cio.crs.model.person.IndMarriageDivorce;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.person.ResidencyPermit;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.GDNPRService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.moe.service.StudentCertificateServiceInterface;
import bh.gov.cio.integration.crs.egov.moe.service.dto.StudentCertificateDTO;
import bh.gov.cio.integration.crs.egov.moe.service.dto.StudentTransferDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "StudentCertificateService", targetNamespace = "http://service.moe.egov.crs.integration.cio.gov.bh/")
public class StudentCertificateServiceImpl implements StudentCertificateServiceInterface {

	private static final Logger	logger	= LoggerFactory.getLogger(StudentCertificateServiceImpl.class);
	@Autowired
	private PropertyServiceImpl	propImpl;

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Autowired
	private ValidationServiceImpl validationUtil;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_retrieveStudentInformation" })
	@WebMethod(operationName = "RetrieveStudentInformation")
	public StudentCertificateDTO retrieveStudentInformation(SecurityTagObject security, String idNumber,
			String nationalityCode, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp)
			throws ApplicationExceptionInfo {
		StudentCertificateDTO returned = null;
		Integer personCPR = null;

		if (!checkeKeyResponse(idNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp))
			throw new ApplicationExceptionInfo("Error Retrieving Student Information ...",
					new ApplicationException("Authentication Failed.", "001"));
		try {

			PersonService ps = getCrsService().getPersonServiceRef();
			AddressService addressService = getCrsService().getAddressServiceRef();

			GDNPRDocument gdnprDocument = null;

			// Check GCC.
			// if (nationalityCode.equalsIgnoreCase("411") ||
			// nationalityCode.equalsIgnoreCase("430")
			// || nationalityCode.equalsIgnoreCase("436") ||
			// nationalityCode.equalsIgnoreCase("440")
			// || nationalityCode.equalsIgnoreCase("930") ||
			// nationalityCode.equalsIgnoreCase("441")
			// || nationalityCode.equalsIgnoreCase("940"))
			// {
			try {
				personCPR = validationUtil.getGCCCpr(idNumber, nationalityCode);
				// gdnprDocument = new GDNPRDocument();
				// GccPerson gccPerson = ps.getGccPerson(idNumber,
				// nationalityCode);
				// logger.debug("GCC PERSON Passport" +
				// gccPerson.getPassportNumber());
				// if (gccPerson.getPassportNumber() != null)
				// gdnprDocument.setDocumentNumber(gccPerson.getPassportNumber());
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				throw new ApplicationExceptionInfo("Error Retrieving Student Information ...",
						new ApplicationException("GCC ID Validation General Exception.", "002"));
			}
			// }
			// else
			// {
			try {
				// personCPR = Integer.parseInt(idNumber);

				gdnprDocument = ps.getPersonLatestGDNPRDocument(personCPR);
			} catch (Exception exception) {
				exception.printStackTrace();
			}
			// }

			final PersonBasicInfo personBasicInfo = ps.getPersonBasicInfo(personCPR);
			final PersonSummary personSummeryInfo = ps.getPersonSummary(personCPR);

			List<Integer> cprList = new ArrayList<Integer>();
			cprList.add(personCPR);
			Integer flatNumber = 0;
			Integer buildingNumber = 0;
			Integer blockNumber = 0;
			String nameAlphaEnglish = "";
			String nameAlphaArabic = "";
			Integer roadNumber = 0;
			String roadNameArabic = "";
			String roadNameEnglish = "";
			Integer areaCode = 0;
			String areaNameArabic = "";
			String areaNameEnglish = "";
			final List<bh.gov.cio.crs.model.nas.Address> addresses = addressService.getAddressForListCprNumber(cprList);
			if (addresses.size() == 0) {
				throw new ApplicationExceptionInfo("Address Basic Details Not found",
						new ApplicationException("Address Basic Details Not found", "003"));
			}

			if (addresses != null) {
				final bh.gov.cio.crs.model.nas.Address returnedAddressRow = addresses.get(addresses.size() - 1);
				flatNumber = returnedAddressRow.getFlatNumber();
				buildingNumber = returnedAddressRow.getBuildingNumber();
				blockNumber = returnedAddressRow.getBlockNumber();
				nameAlphaEnglish = returnedAddressRow.getNameAlphaEnglish();
				nameAlphaArabic = returnedAddressRow.getNameAlphaArabic();
				roadNumber = returnedAddressRow.getRoadNumber();
				roadNameArabic = returnedAddressRow.getRoadNameArabic();
				roadNameEnglish = returnedAddressRow.getRoadNameEnglish();
				areaCode = returnedAddressRow.getAreaCode();
				areaNameArabic = returnedAddressRow.getAreaNameArabic();
				areaNameEnglish = returnedAddressRow.getAreaNameEnglish();
			}
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499")
					|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			// Calendar calendar = Calendar.getInstance();
			Date dateOfBirth = null, passportExpiryDate = null;
			String passportNumber = "";
			if (personBasicInfo.getDateOfBirth() != null) {
				// calendar.setTimeInMillis(personBasicInfo.getDateOfBirth()
				// .getTime());
				// DateTime dateOfBirthD = new DateTime(
				// personBasicInfo.getDateOfBirth().getTime());
				// dateOfBirth = dateOfBirthD.toLocalDate();
				dateOfBirth = new Date(personBasicInfo.getDateOfBirth().getTime()
						+ (personBasicInfo.getDateOfBirth().getNanos() / 1000000));
			}
			if (gdnprDocument != null && gdnprDocument.getExpiryDate() != null) {
				// calendar.setTimeInMillis(gdnprDocument.getExpiryDate()
				// .getTime());
				// DateTime dateOfBirthD = new
				// DateTime(gdnprDocument.getExpiryDate());
				// passportExpiryDate = dateOfBirthD.get(arg0);
				passportExpiryDate = gdnprDocument.getExpiryDate();
				passportNumber = gdnprDocument.getDocumentNumber();
			}
			returned = new StudentCertificateDTO(idNumber, personBasicInfo.getEnglishName(),
					personBasicInfo.getArabicName(), nationality, dateOfBirth, passportNumber, passportExpiryDate,
					flatNumber, buildingNumber, blockNumber, nameAlphaEnglish, nameAlphaArabic, roadNumber,
					roadNameArabic, roadNameEnglish, areaCode, areaNameArabic, areaNameEnglish,
					personBasicInfo.getGender());

		} catch (final Exception exception) {
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Problem occured while retrieving student details",
					new ApplicationException(exception.getMessage(), "000"));
		}
		return returned;
	}

	/**
	 * This is required for the development of a web service for Ministry of
	 * Education (MOE) to enable parents to apply to transfer their children to
	 * another public or private school
	 */
	@Override
	@Secured({ "ROLE_retrieveStudentInformation" })
	@WebMethod(operationName = "RetrieveStudentInformation")
	public StudentTransferDTO transferStudentInformation(SecurityTagObject security, String applicantIdNumber,
			String applicantCardCountry, String studentIdNumber, String studentCardCountry, Integer studentBlockNumber,
			String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp) throws ApplicationExceptionInfo {
		PersonService ps;
		AddressService addressService;
		FamilyService familyService;
		GDNPRService gdnpr;
		StudentTransferDTO returned = null;
		Integer applicantCPR = null;
		Integer studentCPR = null;
		PersonBasicInfo applicantBasicInfo;
		PersonBasicInfo studentBasicInfo;
		PersonSummary studentSummeryInfo;
		List<bh.gov.cio.crs.model.nas.Address> addresses;
		boolean isBahraini;
		boolean isParentMarried = false;
		Integer fathercpr = 0, mothercpr = 0;
		boolean isMotherAlive = false;
		boolean isFatherAlive = false;
		boolean isValidResidency = false;
		Period residencyRemainingPeriod = new Period();
		List<Integer> cprList = new ArrayList<Integer>();
		Integer blockNumber = 0;
		ResidencyPermit rp;

		// if (!checkeKeyResponse(applicantIdNumber, eKeyServiceID, eKeyTokenID,
		// eKeyTimestamp))
		// throw new ApplicationExceptionInfo("Error Retrieving Student Information
		// ...",
		// new ApplicationException("Authentication Failed.", "001"));
		try {
			applicantCPR = validationUtil.getGCCCpr(applicantIdNumber, applicantCardCountry);
			studentCPR = validationUtil.getGCCCpr(studentIdNumber, studentCardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Error Retrieving Student Information ...",
					new ApplicationException("GCC ID Validation General Exception.", "002"));
		}
		try {
			ps = getCrsService().getPersonServiceRef();
			addressService = getCrsService().getAddressServiceRef();
			familyService = getCrsService().getFamilyServiceRef();
			gdnpr = getCrsService().getGDNPRServiceRef();
			applicantBasicInfo = ps.getPersonBasicInfo(applicantCPR);
			studentBasicInfo = ps.getPersonBasicInfo(studentCPR);
			studentSummeryInfo = ps.getPersonSummary(studentCPR);
			List<Integer> x = new ArrayList<Integer>();
			x.add(studentCPR);
			cprList.add(studentCPR);
			addresses = addressService.getAddressForListCprNumber(cprList);
			isBahraini = (studentSummeryInfo.getNationalityCountryCode().equals("499")
					|| studentSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			Date residencyExpiry = new Date();
			if (!isBahraini) {
				rp = gdnpr.getResidencyPermit(studentCPR);
				residencyExpiry = rp.getExpiryDate();
				isValidResidency = rp.getExpiryDate().after(new Date());
				logger.debug("Permit Expiry Date : {} , isValidResidencyFlag : {}", residencyExpiry, isValidResidency);
				residencyRemainingPeriod = new Period(LocalDate.now(), LocalDate.fromDateFields(residencyExpiry));
				logger.debug("Residency Period Remaining: {}", residencyRemainingPeriod.getMonths());
			}
		} catch (final Exception exception) {
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Problem occured while retrieving student details",
					new ApplicationException("General Error Retrieveing Backend Information", "003"));
		}
		// check card expiry for bahraini cards
		if (applicantCardCountry != null && (applicantCardCountry.equals("499") || applicantCardCountry.equals(""))) {
			if (!validationUtil.checkValidCardExpiryDate(applicantCPR)) {
				throw new ApplicationExceptionInfo("Error Retrieving Student Information ...",
						new ApplicationException("Applicant CPR Expired ", "004"));
			}
		}
		if (studentCardCountry != null && (studentCardCountry.equals("499") || studentCardCountry.equals(""))) {
			if (!validationUtil.checkValidCardExpiryDate(studentCPR)) {
				throw new ApplicationExceptionInfo("Error Retrieving Student Information ...",
						new ApplicationException("Student CPR Expired ", "005"));
			}
		}
		// check the relation
		if (!applicantCPR.equals(studentCPR)) {
			try {
				Family f = familyService.getPersonFatherMother(studentCPR);
				fathercpr = f.getFatherCprNumber();
				mothercpr = f.getMotherCprNumber();
				PersonSummary fatherSummaryInfo = ps.getPersonSummary(fathercpr);
				PersonSummary motherSummaryInfo = ps.getPersonSummary(mothercpr);
				isFatherAlive = fatherSummaryInfo.getDateOfDeath() != null ? false : true;
				isMotherAlive = motherSummaryInfo.getDateOfDeath() != null ? false : true;
				List<Integer> marriegesCPR = familyService.getActiveSpouses(fathercpr);
				logger.debug("fathercpr : {} ,isFatherAlive : {}, mothercpr : {} , isMotherAlive : {} ", fathercpr,
						isFatherAlive, mothercpr, isMotherAlive);
				logger.debug("marriegesCPR : {} ", marriegesCPR);
				for (Integer marriage : marriegesCPR) {
					if (marriage.equals(mothercpr)) {
						isParentMarried = true;
					}
					logger.debug("wife : {} ", marriage);
				}
			} catch (Exception e) {
				logger.debug("Problem retrieving familyService : {}", e.getMessage());
			}

			if ((isParentMarried && !isFatherAlive) || (isParentMarried && !isMotherAlive) || (isParentMarried && isMotherAlive && isFatherAlive)) {
				logger.debug("Parent Found.");
			} else {
				throw new ApplicationExceptionInfo("Error Retrieving Student Information ...",
						new ApplicationException("Applicant Relation Not Found With The Student", "006"));
			}
		}

		if (addresses.size() == 0) {
			throw new ApplicationExceptionInfo("Address Basic Details Not found",
					new ApplicationException("Address Basic Details Not found", "007"));
		}

		if (addresses != null) {
			final bh.gov.cio.crs.model.nas.Address returnedAddressRow = addresses.get(addresses.size() - 1);
			blockNumber = returnedAddressRow.getBlockNumber();
		}
		logger.debug("Input Block Number : '{}' , Student Block Number : '{}' ", studentBlockNumber, blockNumber);
		if (!blockNumber.equals(studentBlockNumber)) {
			throw new ApplicationExceptionInfo("Address Basic Details Not accurate",
					new ApplicationException("Block Number Mismatch", "008"));
		}

		if (!isBahraini && !isValidResidency) {
			throw new ApplicationExceptionInfo("Residency Permit Expired ",
					new ApplicationException("Residency Permit Expired", "009"));
		}
		if (!isBahraini && residencyRemainingPeriod.getMonths() < 3) {
			throw new ApplicationExceptionInfo("Residency Permit Expiry in less than 3 monthes ",
					new ApplicationException("Residency Permit Expiry in less than 3 monthes", "010"));
		}
		returned = new StudentTransferDTO(applicantIdNumber, applicantBasicInfo.getEnglishName(),
				applicantBasicInfo.getArabicName(), studentIdNumber, studentBasicInfo.getEnglishName(),
				studentBasicInfo.getArabicName(), blockNumber);

		return returned;
	}

	private boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID,
			String eKeyTimestamp) {
		ValidateToken eKey = getCrsService().geteKeyServiceRef();
		// String accessPassword =
		// "rt74nPTe3dxydVbtIYlde+WdCyfS/w348xDf/sGfkbs=";
		String accessPassword = propImpl.geteGOVeKeyPassword();

		// logger.debug("PASSWORD : "+accessPassword);
		CryptoUtil cryptoUtil = new CryptoUtil();
		String response = null;
		try {
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber),
					cryptoUtil.encrypt(eKeyServiceID), cryptoUtil.encrypt(eKeyTokenID),
					cryptoUtil.encrypt(eKeyTimestamp));
			response = cryptoUtil.decrypt(response);
			logger.debug("eKey Response:" + response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));
	}

}
