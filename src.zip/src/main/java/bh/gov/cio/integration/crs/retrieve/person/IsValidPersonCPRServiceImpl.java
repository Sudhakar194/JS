package bh.gov.cio.integration.crs.retrieve.person;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.IsValidPersonCPRServiceInterface;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsValidPersonCPRService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public class IsValidPersonCPRServiceImpl implements IsValidPersonCPRServiceInterface{
	
	private static final Logger logger = LoggerFactory.getLogger(IsPersonAliveServiceImpl.class);
	
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	
	@Autowired
	private ValidationServiceImpl validationUtil;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}
	
	
	@Override
	@Secured({ "ROLE_getIsValidPersonID" })
	@WebMethod(operationName = "getIsValidPersonCPR")
	public Boolean getIsValidPersonCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo {
		// TODO Auto-generated method stub
		
		boolean result = false;
		try {
			
			PersonBasicInfo basicInfo =  getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			
			if(basicInfo != null && basicInfo.getCprString() != null && !basicInfo.getCprString().trim().equals("")){
				result = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			logger.error(e.getMessage());
			result = false;
		}
		
		return result;
	}

	
	@Override
	@Secured({ "ROLE_getIsValidPersonID" })
	@WebMethod(operationName = "getIsValidPersonID")
	public Boolean getIsValidPersonID(SecurityTagObject security, String idNumber, String nationality)
			throws ApplicationExceptionInfo {
		
		boolean result = false;
		try {
			
			Integer cprNumber = validationUtil.getGCCCpr(idNumber, nationality);
				PersonBasicInfo basicInfo =  getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
				
				if(basicInfo != null && basicInfo.getCprString() != null && !basicInfo.getCprString().trim().equals("")){
					result = true;
				}
				
			//
			// Integer id =
			// getCrsService().getPersonServiceRef().getGccNationalSn(idNumber,
			// nationality);
			//
			// if(id != null && id != null && id > 0){
			// result = true;
			// }else{
			// Integer cprNumber = Integer.parseInt(idNumber);
			// PersonBasicInfo basicInfo =
			// getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			//
			// if(basicInfo != null && basicInfo.getCprString() != null &&
			// !basicInfo.getCprString().trim().equals("")){
			// result = true;
			// }
			//
			// }
		} catch (Exception e) {
			logger.error(e.getMessage());
			result = false;
		}
		
		return result;
	}

}
