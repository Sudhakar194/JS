package bh.gov.cio.integration.crs.retrieve.units.service.dto;

public class UnitAddressServiceBasicInfoDTO
{

	// private java.lang.String electricityAddressFlag;
	// private java.lang.Integer ownerNumber;
	// private java.lang.Integer crNumber;
	// private java.lang.String crNameArabic;
	// private java.lang.Integer unitNumber;
	// private java.lang.String unitNameArabic;
	// private java.lang.Integer cprNumber;
	// private java.lang.Integer addressSn;
	// private java.lang.String isResidential;
	// private java.lang.String isForCard;
	// private java.lang.String isMailing;
	// private java.lang.String phone;
	// private java.lang.String fax;
	// private java.lang.String isMain;
	// private java.lang.Integer headOfHouseholdCpr;
	private java.lang.Integer	blockNumber;

	private java.lang.String	blockNameArabic;
	private java.lang.Integer	buildingNumber;
	private java.lang.String	nameAlphaEnglish;
	private java.lang.String	nameAlphaArabic;
	private java.lang.String	buildingNameArabic;
	private java.lang.String	buildingNameEnglish;

	private java.lang.String	blockNameEnglish;

	private java.lang.Integer	roadNumber;

	private java.lang.String	roadNameArabic;

	private java.lang.String	roadNameEnglish;

	// private java.lang.String addressTypeCode;
	// private java.lang.String addressTypeNameEnglish;
	// private java.lang.String addressTypeNameArabic;
	// private java.lang.String addressUsageCode;
	// private java.lang.String addressUsageNameArabic;
	// private java.lang.String addressUsageNameEnglish;
	// private java.lang.String occupancyStatusCode;
	// private java.lang.String occupancyStsArabicFemale;
	// private java.lang.String occupancyStsArabicMale;
	// private java.lang.String occupancyStsNameEnglish;
	// private java.lang.String householdRelationCode;
	// private java.lang.String householdRelArabicMale;
	// private java.lang.String householdRelArabicFemale;
	// private java.lang.String householdRelNameEnglish;
	private java.lang.Integer	areaCode;

	private java.lang.String	areaNameArabic;

	private java.lang.String	areaNameEnglish;

	private java.lang.Integer	flatNumber;

	// private java.lang.String ioStatusNameArabic;
	// private java.lang.String fullName;
	// private java.lang.String ownershipTypeNameArabic;
	// private java.lang.String nationalityCountryCode;
	// private java.sql.Timestamp dateOfBirth;
	// private java.lang.String addressWatchlistTypeCode;
	// private java.lang.Integer addressWatchlistTypeSn;
	// private java.lang.String electricityAddressField;
	// private boolean isSelected;
	// private java.lang.Integer entityNumber;
	private java.lang.String	regionNameArabic;

	private java.lang.String	regionNameEnglish;

	// private java.lang.String flatBuildingComposite;
	// private java.lang.String flatBuildingCompositeAr;
	// private java.lang.String isDeleted;
	// private java.sql.Timestamp dateLastUpdate;
	// private java.lang.String electricityBuildingUsage;
	// private java.lang.String electricityBuildingType;
	// private java.lang.String accountId;
	// private java.lang.String accountType;
	// private java.lang.String ownerCprNumber;
	// private java.lang.String ownerName;
	// private java.lang.String occupantCprNumber;
	// private java.lang.String occupantName;
	// private java.lang.String rsc;
	// private java.lang.String finalized;
	// private java.lang.String wcons;
	// private java.lang.String ywcons;
	// private java.lang.String wmeter;
	// private java.lang.String econs;
	// private java.lang.String yecons;
	// private java.lang.String emeter;

	public UnitAddressServiceBasicInfoDTO()
	{
		super();
	}

	public UnitAddressServiceBasicInfoDTO(Integer blockNumber,
			String blockNameArabic, Integer buildingNumber,
			String nameAlphaEnglish, String nameAlphaArabic,
			String buildingNameArabic, String buildingNameEnglish,
			String blockNameEnglish, Integer roadNumber, String roadNameArabic,
			String roadNameEnglish, Integer areaCode, String areaNameArabic,
			String areaNameEnglish, Integer flatNumber,
			String regionNameArabic, String regionNameEnglish)
	{
		super();
		this.blockNumber = blockNumber;
		this.blockNameArabic = blockNameArabic;
		this.buildingNumber = buildingNumber;
		this.nameAlphaEnglish = nameAlphaEnglish;
		this.nameAlphaArabic = nameAlphaArabic;
		this.buildingNameArabic = buildingNameArabic;
		this.buildingNameEnglish = buildingNameEnglish;
		this.blockNameEnglish = blockNameEnglish;
		this.roadNumber = roadNumber;
		this.roadNameArabic = roadNameArabic;
		this.roadNameEnglish = roadNameEnglish;
		this.areaCode = areaCode;
		this.areaNameArabic = areaNameArabic;
		this.areaNameEnglish = areaNameEnglish;
		this.flatNumber = flatNumber;
		this.regionNameArabic = regionNameArabic;
		this.regionNameEnglish = regionNameEnglish;
	}

	public java.lang.Integer getAreaCode()
	{
		return areaCode;
	}

	public java.lang.String getAreaNameArabic()
	{
		return areaNameArabic;
	}

	public java.lang.String getAreaNameEnglish()
	{
		return areaNameEnglish;
	}

	public java.lang.String getBlockNameArabic()
	{
		return blockNameArabic;
	}

	public java.lang.String getBlockNameEnglish()
	{
		return blockNameEnglish;
	}

	public java.lang.Integer getBlockNumber()
	{
		return blockNumber;
	}

	public java.lang.String getBuildingNameArabic()
	{
		return buildingNameArabic;
	}

	public java.lang.String getBuildingNameEnglish()
	{
		return buildingNameEnglish;
	}

	public java.lang.Integer getBuildingNumber()
	{
		return buildingNumber;
	}

	public java.lang.Integer getFlatNumber()
	{
		return flatNumber;
	}

	public java.lang.String getNameAlphaArabic()
	{
		return nameAlphaArabic;
	}

	public java.lang.String getNameAlphaEnglish()
	{
		return nameAlphaEnglish;
	}

	public java.lang.String getRegionNameArabic()
	{
		return regionNameArabic;
	}

	public java.lang.String getRegionNameEnglish()
	{
		return regionNameEnglish;
	}

	public java.lang.String getRoadNameArabic()
	{
		return roadNameArabic;
	}

	public java.lang.String getRoadNameEnglish()
	{
		return roadNameEnglish;
	}

	public java.lang.Integer getRoadNumber()
	{
		return roadNumber;
	}

	public void setAreaCode(java.lang.Integer areaCode)
	{
		this.areaCode = areaCode;
	}

	public void setAreaNameArabic(java.lang.String areaNameArabic)
	{
		this.areaNameArabic = areaNameArabic;
	}

	public void setAreaNameEnglish(java.lang.String areaNameEnglish)
	{
		this.areaNameEnglish = areaNameEnglish;
	}

	public void setBlockNameArabic(java.lang.String blockNameArabic)
	{
		this.blockNameArabic = blockNameArabic;
	}

	public void setBlockNameEnglish(java.lang.String blockNameEnglish)
	{
		this.blockNameEnglish = blockNameEnglish;
	}

	public void setBlockNumber(java.lang.Integer blockNumber)
	{
		this.blockNumber = blockNumber;
	}

	public void setBuildingNameArabic(java.lang.String buildingNameArabic)
	{
		this.buildingNameArabic = buildingNameArabic;
	}

	public void setBuildingNameEnglish(java.lang.String buildingNameEnglish)
	{
		this.buildingNameEnglish = buildingNameEnglish;
	}

	public void setBuildingNumber(java.lang.Integer buildingNumber)
	{
		this.buildingNumber = buildingNumber;
	}

	public void setFlatNumber(java.lang.Integer flatNumber)
	{
		this.flatNumber = flatNumber;
	}

	public void setNameAlphaArabic(java.lang.String nameAlphaArabic)
	{
		this.nameAlphaArabic = nameAlphaArabic;
	}

	public void setNameAlphaEnglish(java.lang.String nameAlphaEnglish)
	{
		this.nameAlphaEnglish = nameAlphaEnglish;
	}

	public void setRegionNameArabic(java.lang.String regionNameArabic)
	{
		this.regionNameArabic = regionNameArabic;
	}

	public void setRegionNameEnglish(java.lang.String regionNameEnglish)
	{
		this.regionNameEnglish = regionNameEnglish;
	}

	public void setRoadNameArabic(java.lang.String roadNameArabic)
	{
		this.roadNameArabic = roadNameArabic;
	}

	public void setRoadNameEnglish(java.lang.String roadNameEnglish)
	{
		this.roadNameEnglish = roadNameEnglish;
	}

	public void setRoadNumber(java.lang.Integer roadNumber)
	{
		this.roadNumber = roadNumber;
	}

	@Override
	public String toString() {
		return "UnitAddressServiceBasicInfoDTO [blockNumber=" + blockNumber + ", blockNameArabic=" + blockNameArabic
				+ ", buildingNumber=" + buildingNumber + ", nameAlphaEnglish=" + nameAlphaEnglish + ", nameAlphaArabic="
				+ nameAlphaArabic + ", buildingNameArabic=" + buildingNameArabic + ", buildingNameEnglish="
				+ buildingNameEnglish + ", blockNameEnglish=" + blockNameEnglish + ", roadNumber=" + roadNumber
				+ ", roadNameArabic=" + roadNameArabic + ", roadNameEnglish=" + roadNameEnglish + ", areaCode="
				+ areaCode + ", areaNameArabic=" + areaNameArabic + ", areaNameEnglish=" + areaNameEnglish
				+ ", flatNumber=" + flatNumber + ", regionNameArabic=" + regionNameArabic + ", regionNameEnglish="
				+ regionNameEnglish + "]";
	}

}
