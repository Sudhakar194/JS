package bh.gov.cio.integration.common.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import bh.gov.cio.integration.common.admin.dao.AdminDao;
import bh.gov.cio.integration.common.admin.model.Role;
import bh.gov.cio.integration.common.admin.model.User;
import bh.gov.cio.integration.common.admin.model.UserRole;

@Controller
@Secured({ "ROLE_ADMINISTRATOR" })
@RequestMapping(value = "/rest/users")
public class AdminController {

	@Autowired
	protected AdminDao adminDao;
	Logger log = LoggerFactory.getLogger(AdminController.class.getName());

	@RequestMapping(value = "/addUser.service", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public void addUser(@RequestBody User user) {
		log.debug("Add user: ", user.getEmail());
		adminDao.addUser(user);
	}

	@RequestMapping(value = "/deleteUser.service", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public void deleteUser(@RequestBody User user) {
		adminDao.deleteUser(user);
	}

	@RequestMapping(value = "/getAllUsers.service", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Map<String, Object>> getAllUsers() {
		List<Map<String, Object>> users = adminDao.getAllUsers();
		return users;
	}

	@RequestMapping(value = "/getAllRoles.service", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Map<String, Object>> getAllRoles() {
		List<Map<String, Object>> users = adminDao.getAllRoles();

		return users;
	}

	@RequestMapping(value = "/{username}/getUserRoles.service", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Map<String, Object>> getUserRoles(@PathVariable("username") String username) {
		List<Map<String, Object>> users = adminDao.getUserRoles(username);

		return users;
	}

	@RequestMapping(value = "/{username}/getNonUserRoles.service", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<Map<String, Object>> getNonUserRoles(@PathVariable("username") String username) {
		List<Map<String, Object>> roles = adminDao.getNonUserRoles(username);

		return roles;
	}

	@RequestMapping(value = "/addRole", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public void addRole(@RequestBody Role role) {
		log.debug("Add role: ", role.getRolename());
		adminDao.addRole(role);
	}

	@RequestMapping(value = "/addRolesToUser.service", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public void addRoleToUser(@RequestBody UserRole UserRole) {
		adminDao.addRoleToUser(UserRole);
	}

	@RequestMapping(value = "/removeRoleFromUser.service", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public void removeRoleFromUser(@RequestBody UserRole UserRole) {
		adminDao.removeRoleFromUser(UserRole);
	}

}
