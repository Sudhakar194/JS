package bh.gov.cio.integration.crs.egov.mofa.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import org.apache.cxf.annotations.WSDLDocumentation;

import bh.gov.cio.integration.crs.egov.mofa.service.dto.eRegistrationCitizenAbroadDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "EregistrationCitizenAbroadService", targetNamespace = "http://service.mofa.egov.crs.integration.cio.gov.bh/")
public interface eRegistrationCitizenAbroadInterface
{

	/* MOFA Registration Service for Citizens Abroad */
	@WebResult(name = "personBasicInformation")
	@WebMethod(operationName = "registeredCitizenAbroad")
	@WSDLDocumentation("Service will retrive person arabic and english names and passport number ,using ekey ")
	eRegistrationCitizenAbroadDTO registeredCitizenAbroad(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "eKeyCPRNumber") @XmlElement(required = true) String eKeyCPRNumber,
			@WebParam(name = "eKeyServiceID") @XmlElement(required = true) String eKeyServiceID,
			@WebParam(name = "eKeyTokenID") @XmlElement(required = true) String eKeyTokenID,
			@WebParam(name = "eKeyTimestamp") @XmlElement(required = true) String eKeyTimestamp) throws ApplicationExceptionInfo;

}
