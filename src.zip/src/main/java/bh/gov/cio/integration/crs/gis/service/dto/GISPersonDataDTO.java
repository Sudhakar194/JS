package bh.gov.cio.integration.crs.gis.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "arabicName", "englishName","address" })
public class GISPersonDataDTO {
	private String arabicName;
	private String englishName;
	private PersonAddressInfoDTO address;
	
	public GISPersonDataDTO() {
		super();
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public PersonAddressInfoDTO getAddress() {
		return address;
	}

	public void setAddress(PersonAddressInfoDTO address) {
		this.address = address;
	}

	public GISPersonDataDTO(String arabicName, String englishName, PersonAddressInfoDTO address) {
		super();
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.address = address;
	}
}
