package bh.gov.cio.integration.crs.retrieve.person.service.dto;

public class PersonServiceSpecialSummaryDTO
{
	private java.lang.Integer	cprNumber;
	private java.lang.String	dateOfBirth;
	private java.lang.String	dateOfBirthOld;
	private java.lang.String	nationalityCountryCode;
	private java.lang.String	birthCountryCode;
	private java.lang.String	dateOfDeath;
	private java.lang.String	deathCountryCode;
	private java.lang.String	arabicFullName;
	private java.lang.String	arabicFirstName;
	private java.lang.String	arabicMiddleName1;
	private java.lang.String	arabicMiddleName2;
	private java.lang.String	arabicMiddleName3;
	private java.lang.String	arabicMiddleName4;
	private java.lang.String	arabicFamilyName;
	private java.lang.String	englishFullName;
	private java.lang.String	englishFirstName;
	private java.lang.String	englishMiddleName1;
	private java.lang.String	englishMiddleName2;
	private java.lang.String	englishMiddleName3;
	private java.lang.String	englishMiddleName4;
	private java.lang.String	englishFamilyName;
	private java.lang.String	gender;
	private java.lang.Integer	sponsorIndicator;
	private java.lang.Integer	employerIndicator;
	private java.lang.String	isStudent;
	private java.lang.String	isClearingAgent;
	private java.lang.String	isWatchlisted;
	private java.lang.String	isLostCard;
	private java.lang.String	isDeleted;
	private java.lang.String	isPrisoner;
	private java.lang.String	isSmartcard;
	private java.lang.String	isNationalityConfirmed;
	private java.lang.String	contactPhone;
	private java.lang.String	birthPlaceArabic;
	private java.lang.String	birthPlaceEnglish;
	private java.lang.Integer	fatherCprNumber;
	private java.lang.Integer	motherCprNumber;
	private java.lang.Integer	spouseCpr;
	private java.lang.String	religionCode;
	private java.lang.String	labourParticipationTypeCode;
	private java.lang.String	labourParticipationTypeArabicName;
	private java.lang.String	labourParticipationTypeEnglishName;
	private java.lang.String	highestLevelAchievedCode;
	private java.lang.String	maritalStatusCode;
	private java.lang.String	employmentStatusCode;
	private java.lang.String	ioStatusCode;
	private java.lang.String	smartcardExpiryDate;

	public PersonServiceSpecialSummaryDTO()
	{
		super();
	}

	public PersonServiceSpecialSummaryDTO(Integer cprNumber,
			String dateOfBirth, String dateOfBirthOld,
			String nationalityCountryCode, String birthCountryCode,
			String dateOfDeath, String deathCountryCode, String arabicFullName,
			String arabicFirstName, String arabicMiddleName1,
			String arabicMiddleName2, String arabicMiddleName3,
			String arabicMiddleName4, String arabicFamilyName,
			String englishFullName, String englishFirstName,
			String englishMiddleName1, String englishMiddleName2,
			String englishMiddleName3, String englishMiddleName4,
			String englishFamilyName, String gender, Integer sponsorIndicator,
			Integer employerIndicator, String isStudent,
			String isClearingAgent, String isWatchlisted, String isLostCard,
			String isDeleted, String isPrisoner, String isSmartcard,
			String isNationalityConfirmed, String contactPhone,
			String birthPlaceArabic, String birthPlaceEnglish,
			Integer fatherCprNumber, Integer motherCprNumber,
			Integer spouseCpr, String religionCode,
			String labourParticipationTypeCode,
			String labourParticipationTypeArabicName,
			String labourParticipationTypeEnglishName,
			String highestLevelAchievedCode, String maritalStatusCode,
			String employmentStatusCode, String ioStatusCode,String smartcardExpiryDate)
	{
		super();
		this.cprNumber = cprNumber;
		this.dateOfBirth = dateOfBirth != null ? dateOfBirth : "";
		this.dateOfBirthOld = dateOfBirthOld != null ? dateOfBirthOld : "";
		this.nationalityCountryCode = nationalityCountryCode != null ? nationalityCountryCode
				: "";
		this.birthCountryCode = birthCountryCode != null ? birthCountryCode
				: "";
		this.dateOfDeath = dateOfDeath != null ? dateOfDeath : "";
		this.deathCountryCode = deathCountryCode != null ? deathCountryCode
				: "";
		this.arabicFullName = arabicFullName != null ? arabicFullName : "";
		this.arabicFirstName = arabicFirstName != null ? arabicFirstName : "";
		this.arabicMiddleName1 = arabicMiddleName1 != null ? arabicMiddleName1
				: "";
		this.arabicMiddleName2 = arabicMiddleName2 != null ? arabicMiddleName2
				: "";
		this.arabicMiddleName3 = arabicMiddleName3 != null ? arabicMiddleName3
				: "";
		this.arabicMiddleName4 = arabicMiddleName4 != null ? arabicMiddleName4
				: "";
		this.arabicFamilyName = arabicFamilyName != null ? arabicFamilyName
				: "";
		this.englishFullName = englishFullName != null ? englishFullName : "";
		this.englishFirstName = englishFirstName != null ? englishFirstName
				: "";
		this.englishMiddleName1 = englishMiddleName1 != null ? englishMiddleName1
				: "";
		this.englishMiddleName2 = englishMiddleName2 != null ? englishMiddleName2
				: "";
		this.englishMiddleName3 = englishMiddleName3 != null ? englishMiddleName3
				: "";
		this.englishMiddleName4 = englishMiddleName4 != null ? englishMiddleName4
				: "";
		this.englishFamilyName = englishFamilyName != null ? englishFamilyName
				: "";
		this.gender = gender != null ? gender : "";
		this.sponsorIndicator = sponsorIndicator != null ? sponsorIndicator : 0;
		this.employerIndicator = employerIndicator != null ? employerIndicator
				: 0;
		this.isStudent = isStudent != null ? isStudent : "";
		this.isClearingAgent = isClearingAgent != null ? isClearingAgent : "";
		this.isWatchlisted = isWatchlisted != null ? isWatchlisted : "";
		this.isLostCard = isLostCard != null ? isLostCard : "";
		this.isDeleted = isDeleted != null ? isDeleted : "";
		this.isPrisoner = isPrisoner != null ? isPrisoner : "";
		this.isSmartcard = isSmartcard != null ? isSmartcard : "";
		this.isNationalityConfirmed = isNationalityConfirmed != null ? isNationalityConfirmed
				: "";
		this.contactPhone = contactPhone != null ? contactPhone : "";
		this.birthPlaceArabic = birthPlaceArabic != null ? birthPlaceArabic
				: "";
		this.birthPlaceEnglish = birthPlaceEnglish != null ? birthPlaceEnglish
				: "";
		this.fatherCprNumber = fatherCprNumber != null ? fatherCprNumber : 0;
		this.motherCprNumber = motherCprNumber != null ? motherCprNumber : 0;
		this.spouseCpr = spouseCpr != null ? spouseCpr : 0;
		this.religionCode = religionCode != null ? religionCode : "";
		this.labourParticipationTypeCode = labourParticipationTypeCode != null ? labourParticipationTypeCode
				: "";
		this.labourParticipationTypeArabicName = labourParticipationTypeArabicName != null ? labourParticipationTypeArabicName
				: "";
		this.labourParticipationTypeEnglishName = labourParticipationTypeEnglishName != null ? labourParticipationTypeEnglishName
				: "";
		this.highestLevelAchievedCode = highestLevelAchievedCode != null ? highestLevelAchievedCode
				: "";
		this.maritalStatusCode = maritalStatusCode != null ? maritalStatusCode
				: "";
		this.employmentStatusCode = employmentStatusCode != null ? employmentStatusCode
				: "";
		this.ioStatusCode = ioStatusCode != null ? ioStatusCode : "";
		this.smartcardExpiryDate = smartcardExpiryDate != null ? smartcardExpiryDate : "";
	}

	public java.lang.String getArabicFamilyName()
	{
		return arabicFamilyName;
	}

	public java.lang.String getArabicFirstName()
	{
		return arabicFirstName;
	}

	public java.lang.String getArabicFullName()
	{
		return arabicFullName;
	}

	public java.lang.String getArabicMiddleName1()
	{
		return arabicMiddleName1;
	}

	public java.lang.String getArabicMiddleName2()
	{
		return arabicMiddleName2;
	}

	public java.lang.String getArabicMiddleName3()
	{
		return arabicMiddleName3;
	}

	public java.lang.String getArabicMiddleName4()
	{
		return arabicMiddleName4;
	}

	public java.lang.String getBirthCountryCode()
	{
		return birthCountryCode;
	}

	public java.lang.String getBirthPlaceArabic()
	{
		return birthPlaceArabic;
	}

	public java.lang.String getBirthPlaceEnglish()
	{
		return birthPlaceEnglish;
	}

	public java.lang.String getContactPhone()
	{
		return contactPhone;
	}

	public java.lang.Integer getCprNumber()
	{
		return cprNumber;
	}

	public java.lang.String getDateOfBirth()
	{
		return dateOfBirth;
	}

	public java.lang.String getDateOfBirthOld()
	{
		return dateOfBirthOld;
	}

	public java.lang.String getDateOfDeath()
	{
		return dateOfDeath;
	}

	public java.lang.String getDeathCountryCode()
	{
		return deathCountryCode;
	}

	public java.lang.Integer getEmployerIndicator()
	{
		return employerIndicator;
	}

	public java.lang.String getEmploymentStatusCode()
	{
		return employmentStatusCode;
	}

	public java.lang.String getEnglishFamilyName()
	{
		return englishFamilyName;
	}

	public java.lang.String getEnglishFirstName()
	{
		return englishFirstName;
	}

	public java.lang.String getEnglishFullName()
	{
		return englishFullName;
	}

	public java.lang.String getEnglishMiddleName1()
	{
		return englishMiddleName1;
	}

	public java.lang.String getEnglishMiddleName2()
	{
		return englishMiddleName2;
	}

	public java.lang.String getEnglishMiddleName3()
	{
		return englishMiddleName3;
	}

	public java.lang.String getEnglishMiddleName4()
	{
		return englishMiddleName4;
	}

	public java.lang.Integer getFatherCprNumber()
	{
		return fatherCprNumber;
	}

	public java.lang.String getGender()
	{
		return gender;
	}

	public java.lang.String getHighestLevelAchievedCode()
	{
		return highestLevelAchievedCode;
	}

	public java.lang.String getIoStatusCode()
	{
		return ioStatusCode;
	}

	public java.lang.String getIsClearingAgent()
	{
		return isClearingAgent;
	}

	public java.lang.String getIsDeleted()
	{
		return isDeleted;
	}

	public java.lang.String getIsLostCard()
	{
		return isLostCard;
	}

	public java.lang.String getIsNationalityConfirmed()
	{
		return isNationalityConfirmed;
	}

	public java.lang.String getIsPrisoner()
	{
		return isPrisoner;
	}

	public java.lang.String getIsSmartcard()
	{
		return isSmartcard;
	}

	public java.lang.String getIsStudent()
	{
		return isStudent;
	}

	public java.lang.String getIsWatchlisted()
	{
		return isWatchlisted;
	}

	public java.lang.String getLabourParticipationTypeArabicName()
	{
		return labourParticipationTypeArabicName;
	}

	public java.lang.String getLabourParticipationTypeCode()
	{
		return labourParticipationTypeCode;
	}

	public java.lang.String getLabourParticipationTypeEnglishName()
	{
		return labourParticipationTypeEnglishName;
	}

	public java.lang.String getMaritalStatusCode()
	{
		return maritalStatusCode;
	}

	public java.lang.Integer getMotherCprNumber()
	{
		return motherCprNumber;
	}

	public java.lang.String getNationalityCountryCode()
	{
		return nationalityCountryCode;
	}

	public java.lang.String getReligionCode()
	{
		return religionCode;
	}

	public java.lang.Integer getSponsorIndicator()
	{
		return sponsorIndicator;
	}

	public java.lang.Integer getSpouseCpr()
	{
		return spouseCpr;
	}

	public java.lang.String getSmartcardExpiryDate() {
		return smartcardExpiryDate;
	}

	public void setSmartcardExpiryDate(java.lang.String smartcardExpiryDate) {
		this.smartcardExpiryDate = smartcardExpiryDate;
	}

	public void setArabicFamilyName(java.lang.String arabicFamilyName)
	{
		this.arabicFamilyName = arabicFamilyName;
	}

	public void setArabicFirstName(java.lang.String arabicFirstName)
	{
		this.arabicFirstName = arabicFirstName;
	}

	public void setArabicFullName(java.lang.String arabicFullName)
	{
		this.arabicFullName = arabicFullName;
	}

	public void setArabicMiddleName1(java.lang.String arabicMiddleName1)
	{
		this.arabicMiddleName1 = arabicMiddleName1;
	}

	public void setArabicMiddleName2(java.lang.String arabicMiddleName2)
	{
		this.arabicMiddleName2 = arabicMiddleName2;
	}

	public void setArabicMiddleName3(java.lang.String arabicMiddleName3)
	{
		this.arabicMiddleName3 = arabicMiddleName3;
	}

	public void setArabicMiddleName4(java.lang.String arabicMiddleName4)
	{
		this.arabicMiddleName4 = arabicMiddleName4;
	}

	public void setBirthCountryCode(java.lang.String birthCountryCode)
	{
		this.birthCountryCode = birthCountryCode;
	}

	public void setBirthPlaceArabic(java.lang.String birthPlaceArabic)
	{
		this.birthPlaceArabic = birthPlaceArabic;
	}

	public void setBirthPlaceEnglish(java.lang.String birthPlaceEnglish)
	{
		this.birthPlaceEnglish = birthPlaceEnglish;
	}

	public void setContactPhone(java.lang.String contactPhone)
	{
		this.contactPhone = contactPhone;
	}

	public void setCprNumber(java.lang.Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDateOfBirth(java.lang.String dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}

	public void setDateOfBirthOld(java.lang.String dateOfBirthOld)
	{
		this.dateOfBirthOld = dateOfBirthOld;
	}

	public void setDateOfDeath(java.lang.String dateOfDeath)
	{
		this.dateOfDeath = dateOfDeath;
	}

	public void setDeathCountryCode(java.lang.String deathCountryCode)
	{
		this.deathCountryCode = deathCountryCode;
	}

	public void setEmployerIndicator(java.lang.Integer employerIndicator)
	{
		this.employerIndicator = employerIndicator;
	}

	public void setEmploymentStatusCode(java.lang.String employmentStatusCode)
	{
		this.employmentStatusCode = employmentStatusCode;
	}

	public void setEnglishFamilyName(java.lang.String englishFamilyName)
	{
		this.englishFamilyName = englishFamilyName;
	}

	public void setEnglishFirstName(java.lang.String englishFirstName)
	{
		this.englishFirstName = englishFirstName;
	}

	public void setEnglishFullName(java.lang.String englishFullName)
	{
		this.englishFullName = englishFullName;
	}

	public void setEnglishMiddleName1(java.lang.String englishMiddleName1)
	{
		this.englishMiddleName1 = englishMiddleName1;
	}

	public void setEnglishMiddleName2(java.lang.String englishMiddleName2)
	{
		this.englishMiddleName2 = englishMiddleName2;
	}

	public void setEnglishMiddleName3(java.lang.String englishMiddleName3)
	{
		this.englishMiddleName3 = englishMiddleName3;
	}

	public void setEnglishMiddleName4(java.lang.String englishMiddleName4)
	{
		this.englishMiddleName4 = englishMiddleName4;
	}

	public void setFatherCprNumber(java.lang.Integer fatherCprNumber)
	{
		this.fatherCprNumber = fatherCprNumber;
	}

	public void setGender(java.lang.String gender)
	{
		this.gender = gender;
	}

	public void setHighestLevelAchievedCode(
			java.lang.String highestLevelAchievedCode)
	{
		this.highestLevelAchievedCode = highestLevelAchievedCode;
	}

	public void setIoStatusCode(java.lang.String ioStatusCode)
	{
		this.ioStatusCode = ioStatusCode;
	}

	public void setIsClearingAgent(java.lang.String isClearingAgent)
	{
		this.isClearingAgent = isClearingAgent;
	}

	public void setIsDeleted(java.lang.String isDeleted)
	{
		this.isDeleted = isDeleted;
	}

	public void setIsLostCard(java.lang.String isLostCard)
	{
		this.isLostCard = isLostCard;
	}

	public void setIsNationalityConfirmed(
			java.lang.String isNationalityConfirmed)
	{
		this.isNationalityConfirmed = isNationalityConfirmed;
	}

	public void setIsPrisoner(java.lang.String isPrisoner)
	{
		this.isPrisoner = isPrisoner;
	}

	public void setIsSmartcard(java.lang.String isSmartcard)
	{
		this.isSmartcard = isSmartcard;
	}

	public void setIsStudent(java.lang.String isStudent)
	{
		this.isStudent = isStudent;
	}

	public void setIsWatchlisted(java.lang.String isWatchlisted)
	{
		this.isWatchlisted = isWatchlisted;
	}

	public void setLabourParticipationTypeArabicName(
			java.lang.String labourParticipationTypeArabicName)
	{
		this.labourParticipationTypeArabicName = labourParticipationTypeArabicName;
	}

	public void setLabourParticipationTypeCode(
			java.lang.String labourParticipationTypeCode)
	{
		this.labourParticipationTypeCode = labourParticipationTypeCode;
	}

	public void setLabourParticipationTypeEnglishName(
			java.lang.String labourParticipationTypeEnglishName)
	{
		this.labourParticipationTypeEnglishName = labourParticipationTypeEnglishName;
	}

	public void setMaritalStatusCode(java.lang.String maritalStatusCode)
	{
		this.maritalStatusCode = maritalStatusCode;
	}

	public void setMotherCprNumber(java.lang.Integer motherCprNumber)
	{
		this.motherCprNumber = motherCprNumber;
	}

	public void setNationalityCountryCode(
			java.lang.String nationalityCountryCode)
	{
		this.nationalityCountryCode = nationalityCountryCode;
	}

	public void setReligionCode(java.lang.String religionCode)
	{
		this.religionCode = religionCode;
	}

	public void setSponsorIndicator(java.lang.Integer sponsorIndicator)
	{
		this.sponsorIndicator = sponsorIndicator;
	}

	public void setSpouseCpr(java.lang.Integer spouseCpr)
	{
		this.spouseCpr = spouseCpr;
	}

	@Override
	public String toString()
	{
		return "PersonServiceSummaryDTO [cprNumber=" + cprNumber
				+ ", dateOfBirth=" + dateOfBirth + ", dateOfBirthOld="
				+ dateOfBirthOld + ", nationalityCountryCode="
				+ nationalityCountryCode + ", birthCountryCode="
				+ birthCountryCode + ", dateOfDeath=" + dateOfDeath
				+ ", deathCountryCode=" + deathCountryCode
				+ ", arabicFullName=" + arabicFullName + ", arabicFirstName="
				+ arabicFirstName + ", arabicMiddleName1=" + arabicMiddleName1
				+ ", arabicMiddleName2=" + arabicMiddleName2
				+ ", arabicMiddleName3=" + arabicMiddleName3
				+ ", arabicMiddleName4=" + arabicMiddleName4
				+ ", arabicFamilyName=" + arabicFamilyName
				+ ", englishFullName=" + englishFullName
				+ ", englishFirstName=" + englishFirstName
				+ ", englishMiddleName1=" + englishMiddleName1
				+ ", englishMiddleName2=" + englishMiddleName2
				+ ", englishMiddleName3=" + englishMiddleName3
				+ ", englishMiddleName4=" + englishMiddleName4
				+ ", englishFamilyName=" + englishFamilyName + ", gender="
				+ gender + ", sponsorIndicator=" + sponsorIndicator
				+ ", employerIndicator=" + employerIndicator + ", isStudent="
				+ isStudent + ", isClearingAgent=" + isClearingAgent
				+ ", isWatchlisted=" + isWatchlisted + ", isLostCard="
				+ isLostCard + ", isDeleted=" + isDeleted + ", isPrisoner="
				+ isPrisoner + ", isSmartcard=" + isSmartcard
				+ ", isNationalityConfirmed=" + isNationalityConfirmed
				+ ", contactPhone=" + contactPhone + ", birthPlaceArabic="
				+ birthPlaceArabic + ", birthPlaceEnglish=" + birthPlaceEnglish
				+ ", fatherCprNumber=" + fatherCprNumber + ", motherCprNumber="
				+ motherCprNumber + ", spouseCpr=" + spouseCpr
				+ ", religionCode=" + religionCode
				+ ", labourParticipationTypeCode="
				+ labourParticipationTypeCode
				+ ", labourParticipationTypeArabicName="
				+ labourParticipationTypeArabicName
				+ ", labourParticipationTypeEnglishName="
				+ labourParticipationTypeEnglishName
				+ ", highestLevelAchievedCode=" + highestLevelAchievedCode
				+ ", maritalStatusCode=" + maritalStatusCode
				+ ", employmentStatusCode=" + employmentStatusCode
				+ ", SmartcardExpiryDate=" + smartcardExpiryDate
				+ ", ioStatusCode=" + ioStatusCode + "]";
	}
}
