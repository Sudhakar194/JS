package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


@XmlType(name = "LastMarriageDurationByWifeCpr",propOrder =
{ "cprNumber", "spouseCprNumber", "marriageDuration", "marriageDateRegistered","married"})
public class MarriageDurationDTO{

	String cprNumber;
	String spouseCprNumber;
	Integer marriageDuration;
	String marriageDateRegistered;
	String married;
	
	
	public MarriageDurationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public MarriageDurationDTO(String cprNumber, String spouseCprNumber, Integer marriageDuration,
			String marriageDateRegistered,String married) {
		super();
		this.cprNumber = cprNumber != null ? cprNumber : "";
		this.spouseCprNumber = spouseCprNumber != null ? spouseCprNumber : "";
		this.marriageDuration = marriageDuration != null ? marriageDuration : 0;
		this.marriageDateRegistered = marriageDateRegistered	!= null ? marriageDateRegistered : "";
		this.married = married;
	}



	@XmlElement(name = "cprNumber", required = true)
	public String getCprNumber() {
		return cprNumber;
	}




	public void setCprNumber(String cprNumber) {
		this.cprNumber = cprNumber;
	}




	@XmlElement(name = "spouseCprNumber", required = false)
	public String getSpouseCprNumber() {
		return spouseCprNumber;
	}


	public void setSpouseCprNumber(String spouseCprNumber) {
		this.spouseCprNumber = spouseCprNumber;
	}

	@XmlElement(name = "marriageDuration", required = true)
	public Integer getMarriageDuration() {
		return marriageDuration;
	}


	public void setMarriageDuration(Integer marriageDuration) {
		this.marriageDuration = marriageDuration;
	}

	@XmlElement(name = "marriageDateRegistered", required = true)
	public String getMarriageDateRegistered() {
		return marriageDateRegistered;
	}

	public void setMarriageDateRegistered(String marriageDateRegistered) {
		this.marriageDateRegistered = marriageDateRegistered;
	}






	@XmlElement(name = "married")
	public String getMarried() {
		return married;
	}



	public void setMarried(String married) {
		this.married = married;
	}

	
	
}
