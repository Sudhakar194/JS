package bh.gov.cio.integration.crs.retrieve.person.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonFinancialSupportInfoDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface PersonBasicInfoServiceInterface
{

	@WebResult(name = "PersonBasicInformation")
	@WebMethod(operationName = "getAllPersonBasicInfo")
	PersonServiceBasicInfoDTO getAllPersonBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "PersonBasicInformation")
	@WebMethod(operationName = "getPersonBasicInfo")
	PersonServiceBasicInfoDTO getPersonBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "PersonBasicInformation")
	@WebMethod(operationName = "getPersonBasicInfoByCPR")
	PersonServiceBasicInfoDTO getPersonBasicInfoByCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

	/* Person information for financial support (MOSD) */
	@WebResult(name = "PersonBasicInformation")
	@WebMethod(operationName = "getPersonInfoForFS")
	PersonFinancialSupportInfoDTO getPersonInfoForFS(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
