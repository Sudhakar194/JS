package bh.gov.cio.integration.common.admin.model;

public class User {

	String description;
	String email;
	String mobile;
	String password;
	String username;
	String ministry;
	
	public User(String description, String email, String mobile, String password, String username,String ministry) {
		super();
		this.description = description;
		this.email = email;
		this.mobile = mobile;
		this.password = password;
		this.username = username;
		this.ministry = ministry;
	}

	public String getDescription() {
		return description;
	}

	public String getEmail() {
		return email;
	}

	public String getMobile() {
		return mobile;
	}

	public String getPassword() {
		return password;
	}

	public String getUsername() {
		return username;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMinistry() {
		return ministry;
	}

	public void setMinistry(String ministry) {
		this.ministry = ministry;
	}

}
