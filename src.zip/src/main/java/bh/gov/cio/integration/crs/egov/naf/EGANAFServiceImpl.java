package bh.gov.cio.integration.crs.egov.naf;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.util.StringUtils;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.naf.dto.NAFDTO;
import bh.gov.cio.integration.crs.egov.naf.service.EGANAFServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NAFSoapService", targetNamespace = "http://service.naf.egov.crs.integration.cio.gov.bh/")
public class EGANAFServiceImpl implements EGANAFServiceInterface
{
	/**
	 * Logger for this class 
	 */
	private static final Logger logger = LoggerFactory.getLogger(EGANAFServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	
	@Override
	@Secured({"ROLE_ValidatePersonInfo"})
	@WebMethod(operationName = "checkPersonInfo")
	public NAFDTO checkPersonInfo(SecurityTagObject security,
			Integer cprNumber, Integer blockNumber, Date dateOfBirth,
			Date cardExpiryDate, String cardSerialNumber)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
		{
			logger.debug("checkPersonInfo(Integer, Integer, Date) - start");
		}

		if (!validationUtil.isValidCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("cpr Number", new ApplicationException("InValid cpr Number"));
		}
		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidDateOfBirth(cprNumber, dateOfBirth))
		{
			throw new ApplicationExceptionInfo("Birth Date", new ApplicationException("Wrong Birth Date"));
		}		
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}

		
		if(StringUtils.isNotBlank(cardSerialNumber))
		{
			if (!validationUtil.hasValidCardSerialNumber(cprNumber, cardSerialNumber))
			{
				throw new ApplicationExceptionInfo("card Serial Number", new ApplicationException("Wrong card Serial Number"));
			}
		}
		
		return new NAFDTO(cprNumber+"", true);
	}
	
	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
