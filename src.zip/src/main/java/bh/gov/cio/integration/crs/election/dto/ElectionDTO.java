package bh.gov.cio.integration.crs.election.dto;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.CommonTypes.Gender;
import bh.gov.cio.integration.common.CommonTypes.Nationality;

@XmlType
public class ElectionDTO {

	/*
	 * الرقم الشخصي تاريخ انتهاء بطاقة الهوية اسم حامل البطاقة باللغتين العنوان
	 * الجنسية صورة حامل البطاقة النوع (أنثى، ذكر) تاريخ الميلاد
	 */
	private Integer cprNumber;
	private Long cardExpiryDate;
	private String arabicName;
	private String englishName;

	private CommonTypes.Nationality nationalityType;
	private byte[] photo;
	private CommonTypes.Gender gender;
	private Long birthDate;
	private Integer blockNumber;

	public Integer getCprNumber() {
		return cprNumber;
	}

	public void setCprNumber(Integer cprNumber) {
		this.cprNumber = cprNumber;
	}

	public Long getCardExpiryDate() {
		return cardExpiryDate;
	}

	public void setCardExpiryDate(Long cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public CommonTypes.Nationality getNationalityType() {
		return nationalityType;
	}

	public void setNationalityType(CommonTypes.Nationality nationalityType) {
		this.nationalityType = nationalityType;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public CommonTypes.Gender getGender() {
		return gender;
	}

	public void setGender(CommonTypes.Gender gender) {
		this.gender = gender;
	}

	public Long getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Long birthDate) {
		this.birthDate = birthDate;
	}

	public ElectionDTO() {
		super();
	}

	public ElectionDTO(Integer cprNumber, Long cardExpiryDate, String arabicName, String englishName,
			Nationality nationalityType, byte[] photo, Gender gender, Long birthDate, Integer blockNumber) {
		super();
		this.cprNumber = cprNumber;
		this.cardExpiryDate = cardExpiryDate;
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.nationalityType = nationalityType;
		this.photo = photo;
		this.gender = gender;
		this.birthDate = birthDate;
		this.setBlockNumber(blockNumber);
	}

	public Integer getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}

}
