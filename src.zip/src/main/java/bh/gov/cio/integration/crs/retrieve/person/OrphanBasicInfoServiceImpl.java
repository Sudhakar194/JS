package bh.gov.cio.integration.crs.retrieve.person;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.EmploymentService;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.util.exception.AddressLoadException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.OrphanBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.OrphanApplicantAddressDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.OrphanChildrensDetailsDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.OrphanServiceBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "OrphanBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/", serviceName = "OrphanBasicInfoService")
public class OrphanBasicInfoServiceImpl implements OrphanBasicInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(OrphanBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	private boolean checkEligibility(Integer cprNumber, String checkObjectType) throws ApplicationExceptionInfo,
			bh.gov.cio.crs.util.exception.ApplicationException, BusinessException
	{
		PersonService personService = getCrsService().getPersonServiceRef();
		EmploymentService employmentService = getCrsService().getEmploymentServiceRef();
		final PersonBasicInfo personBasicInfo = personService.getPersonBasicInfo(cprNumber);
		final PersonSummary personSummeryInfo = personService.getPersonSummary(cprNumber);
		boolean isEleigable = false;
		if (personSummeryInfo != null && personBasicInfo != null)
		{
			// (1) CHECK IF THE APPLICANT IS DEAD
			if (personSummeryInfo.isDead())
			{
				throw new ApplicationExceptionInfo("IO Status  Error", new ApplicationException(checkObjectType + " is Dead"));
			}

			// (2) CHECK IF THE APPLICANT IS Bahraini
			if (!personSummeryInfo.isBahraini())
			{
				throw new ApplicationExceptionInfo("Nationality Error", new ApplicationException(checkObjectType + " is non-Bahraini "));
			}

			// (3) CHECK Citizen Age IS > 24
			if (personBasicInfo.getAge() > 24)
			{
				throw new ApplicationExceptionInfo("Age Error", new ApplicationException(checkObjectType + " Age is more than 24 Years Old."));
			}

			// (4) CHECK IF HIS FATHER IS *NOT* DEAD
			Integer fatherCPR = personSummeryInfo.getFatherCprNumber();
			if (fatherCPR != null)
			{
				final PersonSummary personFatherSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(fatherCPR);
				final String gender = personBasicInfo.getGender();
				final String maritalStatus = personSummeryInfo.getMaritalStatusCode();
				if (logger.isDebugEnabled())
				{
					logger.debug("checkEligibility() -  : personFatherSummeryInfo = " + personFatherSummeryInfo);
				}

				if (!personFatherSummeryInfo.isDead())
				{
					throw new ApplicationExceptionInfo("Father IO Status Error", new ApplicationException(checkObjectType + " Father Is Not Dead"));
				}

				// (5) reject non Single Female
				if (gender != null && gender.equalsIgnoreCase("F") && maritalStatus != null
						&& !(maritalStatus.equalsIgnoreCase("001") || maritalStatus.equalsIgnoreCase("000")))
				{
					throw new ApplicationExceptionInfo("Marital Status Error", new ApplicationException(checkObjectType
							+ " Female is NOT (Under 21 years old) OR (Never MArried)"));
				}

				// (6) CHECK Citizen Age IS > 18
				if (personBasicInfo.getAge() > 18) // Already < 24 checked
													// before
				{
					// (7) CHECK Citizen IS *NOT* Employee
					List<Employment> employment = employmentService.getActiveEmployments(cprNumber);
					if (logger.isDebugEnabled())
					{
						logger.debug("checkEligibility() -  : employment = " + employment);
					}
					if (employment != null)
					{
						throw new ApplicationExceptionInfo("Employment Error", new ApplicationException(checkObjectType
								+ " has a valid employment record."));
					}
					else
					{
						isEleigable = true;

					} // End No Valid Employment Record

				}
				else
				// End Age > 18
				{
					isEleigable = true;
				}

			}
			else
			// Father CPR Not Exists
			{
				throw new ApplicationExceptionInfo("Father CPR Read Error", new ApplicationException(checkObjectType
						+ " Father CPR Not Found For this CPR Number"));
			}
		}
		else
		// Data is Does Not Exist
		{
			throw new ApplicationExceptionInfo("General Error", new ApplicationException(checkObjectType + " Data Not Found For this CPR Number"));
		}
		return isEleigable;
	}

	private List<OrphanApplicantAddressDTO> getApplicantAddresses(Integer cprNumber) throws BusinessException,
			bh.gov.cio.crs.util.exception.ApplicationException
	{
		AddressService addressService = getCrsService().getAddressServiceRef();
		List<OrphanApplicantAddressDTO> applicantAddresses = new ArrayList<OrphanApplicantAddressDTO>();
		// Address
		List<Address> appCRSAddresses = null;
		try
		{
			List<Integer> cprList = new ArrayList<Integer>();
			cprList.add(cprNumber);
			appCRSAddresses = addressService.getAddressForListCprNumber(cprList);

			if (appCRSAddresses != null)
			{
				for (Address currentAdd : appCRSAddresses)
				{
					applicantAddresses.add(new OrphanApplicantAddressDTO(currentAdd.getAreaCode(), currentAdd.getAreaNameArabic(), currentAdd
							.getAreaNameEnglish(), currentAdd.getFlatNumber(), currentAdd.getRegionNameArabic(), currentAdd.getRegionNameEnglish(),
							currentAdd.getBlockNumber(), currentAdd.getBlockNameArabic(), currentAdd.getBuildingNumber(), currentAdd
									.getNameAlphaEnglish(), currentAdd.getNameAlphaArabic(), currentAdd.getBuildingNameArabic(), currentAdd
									.getBuildingNameEnglish(), currentAdd.getBlockNameEnglish(), currentAdd.getRoadNumber(), currentAdd
									.getRoadNameArabic(), currentAdd.getRoadNameEnglish(), currentAdd.getGovernorateNameArabic(), currentAdd
									.getGovernorateNameEnglish(), currentAdd.getAddressTypeCode()));
				}
			}
		}
		catch (AddressLoadException e)
		{
			e.printStackTrace();
		}
		return applicantAddresses;
	}

	private List<OrphanChildrensDetailsDTO> getChildrenInformation(Integer cprNumber, Integer fatherCPR, Integer motherCPR)
			throws ApplicationExceptionInfo, BusinessException, bh.gov.cio.crs.util.exception.ApplicationException
	{
		AddressService addressService = getCrsService().getAddressServiceRef();
		PersonService personService = getCrsService().getPersonServiceRef();
		FamilyService familyService = getCrsService().getFamilyServiceRef();

		List<OrphanChildrensDetailsDTO> orphanChildrensDetails = new ArrayList<OrphanChildrensDetailsDTO>();

		if (fatherCPR != null && motherCPR != null)
		{
			final List<PersonSummary> brothersAndSisters = familyService.getCoupleChildren(fatherCPR, motherCPR);
			if (logger.isDebugEnabled())
			{
				logger.debug("getChildrenInformation() -  : brothersAndSisters = " + brothersAndSisters);
			}
			if (brothersAndSisters != null)
			{
				for (PersonSummary brothersAndSistersSummary : brothersAndSisters)
				{
					Integer brotherSisterCPR = brothersAndSistersSummary.getCprNumber();
					checkEligibility(brotherSisterCPR, "Brother/Sister CPR Number: " + brotherSisterCPR);
					final PersonSummary childrenSummeryInfo = personService.getPersonSummary(brotherSisterCPR);
					final PersonBasicInfo childrenBasicInfo = personService.getPersonBasicInfo(brotherSisterCPR);

					List<Address> childrenOwnedAddressList = null;
					try
					{
						childrenOwnedAddressList = addressService.getElectricityAddressByCPR(brotherSisterCPR);
					}
					catch (AddressLoadException e)
					{

					}
					Integer noOfOwnedProperties = childrenOwnedAddressList != null ? childrenOwnedAddressList.size() : 0;

					final boolean isBahraini = (childrenSummeryInfo.getNationalityCountryCode().equals("499") || childrenSummeryInfo
							.getNationalityCountryCode().equals("900")) ? true : false;
					final boolean isGCC = (!isBahraini && childrenSummeryInfo.isGcc()) ? true : false;
					String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";

					orphanChildrensDetails.add(new OrphanChildrensDetailsDTO(childrenBasicInfo.getArabicName(), childrenBasicInfo.getEnglishName(),
							nationality, DateServiceImpl.formatDate(childrenBasicInfo.getDateOfBirth()), childrenBasicInfo.getGender(),
							noOfOwnedProperties, childrenSummeryInfo.getLabourParticipationTypeCode()));
				}
			}
			return orphanChildrensDetails;
		}
		else
		{
			throw new ApplicationExceptionInfo("Father/Mother CPR Error", new ApplicationException("Applicant CPR Number: " + cprNumber
					+ " Father/Mother CPR Doesn't Exist"));
		}

	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getOrphanBasicInfoByCPR" })
	@WebMethod(operationName = "getOrphanBasicInfoByCPR")
	public OrphanServiceBasicInfoDTO getOrphanBasicInfoByCPR(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		PersonService personService = getCrsService().getPersonServiceRef();

		OrphanServiceBasicInfoDTO orphanServiceBasicInfoDTO = null;
		if (logger.isDebugEnabled())
		{
			logger.debug("getOrphanBasicInfoByCPR(Integer, Integer, Date) - start");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try
		{
			// CHECK BROTHERS / SISTERS employment status + education

			final PersonSummary personSummeryInfo = personService.getPersonSummary(cprNumber);
			final PersonBasicInfo personBasicInfo = personService.getPersonBasicInfo(cprNumber);
			Integer motherCPR = personSummeryInfo.getMotherCprNumber();
			Integer fatherCPR = personSummeryInfo.getFatherCprNumber();
			List<OrphanChildrensDetailsDTO> orphanChildrensDetails = null;
			if (checkEligibility(cprNumber, "Applicant CPR Number: " + cprNumber))
			{
				// Number Of Children
				// Children Full Name
				// Children DOB
				// Children Gender
				// Number of properties
				// widow employment status
				// orphans education level (LFP)
				orphanChildrensDetails = getChildrenInformation(cprNumber, fatherCPR, motherCPR);
			}
			List<OrphanApplicantAddressDTO> applicantAddresses = getApplicantAddresses(cprNumber);
			Integer noOfChildren = orphanChildrensDetails != null ? orphanChildrensDetails.size() : 0;

			orphanServiceBasicInfoDTO = new OrphanServiceBasicInfoDTO(personBasicInfo.getArabicName(), personBasicInfo.getEnglishName(),
					personBasicInfo.getGender(), applicantAddresses, personSummeryInfo.getEmploymentStatusCode(),
					DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()), noOfChildren, orphanChildrensDetails);

			if (logger.isDebugEnabled())
			{
				logger.debug("getOrphanBasicInfoByCPR(Integer, Integer, Date) - end");
			}
		}
		catch (final BusinessException exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("checkEligibility(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(exception.getMessage()));
		}
		catch (final bh.gov.cio.crs.util.exception.ApplicationException exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("checkEligibility(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(exception.getMessage()));
		}
		return orphanServiceBasicInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getOrphanBasicInfoByMotherCPR" })
	@WebMethod(operationName = "getOrphanBasicInfoByMotherCPR")
	public OrphanServiceBasicInfoDTO getOrphanBasicInfoByMotherCPR(SecurityTagObject security, Integer motherCPRNumber, Integer fatherCPRNumber,
			Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo
	{
		OrphanServiceBasicInfoDTO orphanServiceBasicInfoDTO = null;
		if (logger.isDebugEnabled())
		{
			logger.debug("getOrphanBasicInfoByMotherCPR(Integer, Integer, Integer, Date) - start");
			logger.debug("getOrphanBasicInfoByMotherCPR(motherCPRNumber = " + motherCPRNumber + "fatherCPRNumber = " + fatherCPRNumber
					+ ", blockNumber = " + blockNumber + ", cardExpiryDate = " + cardExpiryDate + ")");
		}

		if (!validationUtil.hasValidBlock(motherCPRNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(motherCPRNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		if (validationUtil.isDeletedCpr(motherCPRNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try
		{
			PersonService personService = getCrsService().getPersonServiceRef();
			final PersonSummary motherSummeryInfo = personService.getPersonSummary(motherCPRNumber);
			final PersonBasicInfo motherBasicInfo = personService.getPersonBasicInfo(motherCPRNumber);
			final PersonSummary fatherSummeryInfo = personService.getPersonSummary(fatherCPRNumber);

			// check if husband is not dead
			if (!fatherSummeryInfo.isDead())
			{
				throw new ApplicationExceptionInfo("Husband Status Error ",
						new ApplicationException("Father CPR:" + fatherCPRNumber + " Is Not Dead"));
			}
			// check if mother nationality
			if (motherSummeryInfo.isDead())
			{
				throw new ApplicationExceptionInfo("Mother Status Error ", new ApplicationException("Mother CPR:" + motherCPRNumber + " Is Dead"));
			}
			// check if mother nationality
			if (!(motherSummeryInfo.isBahraini() || fatherSummeryInfo.isBahraini()))
			{
				throw new ApplicationExceptionInfo("Mother Nationality Error ", new ApplicationException("Mother CPR:" + motherCPRNumber
						+ " Is Not Bahraini And Her Husband Too"));
			}
			// check if mother is widow
			if (!motherSummeryInfo.getMaritalStatusCode().equals("004"))
			{
				throw new ApplicationExceptionInfo("Mother Marital Status Error ", new ApplicationException("Mother CPR:" + motherCPRNumber
						+ " Marital Status Is Not Widow"));
			}

			List<OrphanChildrensDetailsDTO> orphanChildrensDetails = null;
			if (fatherCPRNumber != null && motherCPRNumber != null)
			{
				orphanChildrensDetails = getChildrenInformation(motherCPRNumber, fatherCPRNumber, motherCPRNumber);
			}
			else
			{
				throw new ApplicationExceptionInfo("Father/Mother CPR Error", new ApplicationException("Applicant CPR Number: " + motherCPRNumber
						+ " Father/Mother CPR Doesn't Exist"));
			}

			List<OrphanApplicantAddressDTO> applicantAddresses = getApplicantAddresses(motherCPRNumber);
			Integer noOfChildren = orphanChildrensDetails != null ? orphanChildrensDetails.size() : 0;

			orphanServiceBasicInfoDTO = new OrphanServiceBasicInfoDTO(motherBasicInfo.getArabicName(), motherBasicInfo.getEnglishName(),
					motherBasicInfo.getGender(), applicantAddresses, motherSummeryInfo.getEmploymentStatusCode(),
					DateServiceImpl.formatDate(motherBasicInfo.getDateOfBirth()), noOfChildren, orphanChildrensDetails);

			if (logger.isDebugEnabled())
			{
				logger.debug("getOrphanBasicInfoByCPR(Integer, Integer, Date) - end");
			}

			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonBasicInfo(Integer, Integer, Date) - end");
			}
			return orphanServiceBasicInfoDTO;

		}
		catch (final BusinessException exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("checkEligibility(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(exception.getMessage()));
		}
		catch (final bh.gov.cio.crs.util.exception.ApplicationException exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("checkEligibility(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(exception.getMessage()));
		}
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
