package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.crs.retrieve.cr.service.dto.PersonActiveCRDTO;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitBasicInfoDTO;

@XmlType(name = "PersonFinancialSupportInfo", propOrder =
{ "cprNumber", "age", "arabicFirstName", "arabicSecondName", "arabicThirdName", "arabicFourthName", "arabicFamilyName", "englishFirstName",
		"englishSecondName", "englishThirdName", "englishFourthName", "englishFamilyName", "birthDate", "deathDate", "gender", "nationality",
		"religionCode", "maritalStatus", "employmentStatus", "ownedCRsList", "ownedUnitsList" })
public class PersonFinancialSupportInfoDTO
{
	private Integer cprNumber;
	private String arabicFirstName;
	private String arabicSecondName;
	private String arabicThirdName;
	private String arabicFourthName;
	private String arabicFamilyName;
	private String englishFirstName;
	private String englishSecondName;
	private String englishThirdName;
	private String englishFourthName;
	private String englishFamilyName;
	private String age;
	private String birthDate;
	private String deathDate;
	private String gender;
	private String nationality;
	private String religionCode;
	private String maritalStatus;
	private String employmentStatus;

	private PersonActiveCRDTO[] ownedCRsList;

	private UnitBasicInfoDTO[] ownedUnitsList;

	public PersonFinancialSupportInfoDTO()
	{
		super();
	}

	public PersonFinancialSupportInfoDTO(Integer cprNumber, String arabicFirstName, String arabicSecondName, String arabicThirdName,
			String arabicFourthName, String arabicFamilyName, String englishFirstName, String englishSecondName, String englishThirdName,
			String englishFourthName, String englishFamilyName, String age, String birthDate, String deathDate, String gender, String nationality,
			String religionCode, String maritalStatus, String employmentStatus, PersonActiveCRDTO[] ownedCRsList, UnitBasicInfoDTO[] ownedUnitsList)
	{
		super();
		this.cprNumber = cprNumber;
		this.arabicFirstName = arabicFirstName;
		this.arabicSecondName = arabicSecondName;
		this.arabicThirdName = arabicThirdName;
		this.arabicFourthName = arabicFourthName;
		this.arabicFamilyName = arabicFamilyName;
		this.englishFirstName = englishFirstName;
		this.englishSecondName = englishSecondName;
		this.englishThirdName = englishThirdName;
		this.englishFourthName = englishFourthName;
		this.englishFamilyName = englishFamilyName;
		this.age = age;
		this.birthDate = birthDate;
		this.deathDate = deathDate;
		this.gender = gender;
		this.nationality = nationality;
		this.religionCode = religionCode;
		this.maritalStatus = maritalStatus;
		this.employmentStatus = employmentStatus;
		this.ownedCRsList = ownedCRsList;
		this.ownedUnitsList = ownedUnitsList;
	}

	public String getAge()
	{
		return age;
	}

	public String getArabicFamilyName()
	{
		return arabicFamilyName;
	}

	public String getArabicFirstName()
	{
		return arabicFirstName;
	}

	public String getArabicFourthName()
	{
		return arabicFourthName;
	}

	public String getArabicSecondName()
	{
		return arabicSecondName;
	}

	public String getArabicThirdName()
	{
		return arabicThirdName;
	}

	public String getBirthDate()
	{
		return birthDate;
	}

	public Integer getCprNumber()
	{
		return cprNumber;
	}

	public String getDeathDate()
	{
		return deathDate;
	}

	public String getEmploymentStatus()
	{
		return employmentStatus;
	}

	public String getEnglishFamilyName()
	{
		return englishFamilyName;
	}

	public String getEnglishFirstName()
	{
		return englishFirstName;
	}

	public String getEnglishFourthName()
	{
		return englishFourthName;
	}

	public String getEnglishSecondName()
	{
		return englishSecondName;
	}

	public String getEnglishThirdName()
	{
		return englishThirdName;
	}

	public String getGender()
	{
		return gender;
	}

	public String getMaritalStatus()
	{
		return maritalStatus;
	}

	public String getNationality()
	{
		return nationality;
	}

	public PersonActiveCRDTO[] getOwnedCRsList()
	{
		return ownedCRsList;
	}

	public UnitBasicInfoDTO[] getOwnedUnitsList()
	{
		return ownedUnitsList;
	}

	public String getReligionCode()
	{
		return religionCode;
	}

	public void setAge(String age)
	{
		this.age = age;
	}

	public void setArabicFamilyName(String arabicFamilyName)
	{
		this.arabicFamilyName = arabicFamilyName;
	}

	public void setArabicFirstName(String arabicFirstName)
	{
		this.arabicFirstName = arabicFirstName;
	}

	public void setArabicFourthName(String arabicFourthName)
	{
		this.arabicFourthName = arabicFourthName;
	}

	public void setArabicSecondName(String arabicSecondName)
	{
		this.arabicSecondName = arabicSecondName;
	}

	public void setArabicThirdName(String arabicThirdName)
	{
		this.arabicThirdName = arabicThirdName;
	}

	public void setBirthDate(String birthDate)
	{
		this.birthDate = birthDate;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDeathDate(String deathDate)
	{
		this.deathDate = deathDate;
	}

	public void setEmploymentStatus(String employmentStatus)
	{
		this.employmentStatus = employmentStatus;
	}

	public void setEnglishFamilyName(String englishFamilyName)
	{
		this.englishFamilyName = englishFamilyName;
	}

	public void setEnglishFirstName(String englishFirstName)
	{
		this.englishFirstName = englishFirstName;
	}

	public void setEnglishFourthName(String englishFourthName)
	{
		this.englishFourthName = englishFourthName;
	}

	public void setEnglishSecondName(String englishSecondName)
	{
		this.englishSecondName = englishSecondName;
	}

	public void setEnglishThirdName(String englishThirdName)
	{
		this.englishThirdName = englishThirdName;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public void setMaritalStatus(String maritalStatus)
	{
		this.maritalStatus = maritalStatus;
	}

	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}

	public void setOwnedCRsList(PersonActiveCRDTO[] ownedCRsList)
	{
		this.ownedCRsList = ownedCRsList;
	}

	public void setOwnedUnitsList(UnitBasicInfoDTO[] ownedUnitsList)
	{
		this.ownedUnitsList = ownedUnitsList;
	}

	public void setReligionCode(String religionCode)
	{
		this.religionCode = religionCode;
	}

}
