package bh.gov.cio.integration.crs.retrieve.family.rco;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.EmploymentService;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.RCOServiceInterface;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.ChildrenRCODetailDTO;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.FatherInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.FatherMotherInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.MotherInfoDTO;
import bh.gov.cio.integration.crs.retrieve.family.rco.service.dto.NextOfKinInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "RCOService", targetNamespace = "http://rco.service.family.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "RCOService"
public class RCOServiceImpl implements RCOServiceInterface, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(RCOServiceImpl.class);
	@Autowired
	private ValidationServiceImpl validationService;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	// @Override
	// @Secured({ "ROLE_RCORetrieve" })
	// @WebMethod(operationName = "getMotherInfo")
	// public MotherInfoDTO getMotherInfo(SecurityTagObject security, Integer
	// motherCPRNumber)
	// throws ApplicationExceptionInfo {
	// if (validationService.isDeletedCpr(motherCPRNumber)) {
	// throw new ApplicationExceptionInfo("Mother CPR Number Deleted",
	// new ApplicationException("Mother CPR Number Deleted", "002"));
	// }
	// final PersonService personService =
	// getCrsService().getPersonServiceRef();
	// final EmploymentService employmentService =
	// getCrsService().getEmploymentServiceRef();
	// MotherInfoDTO fatherInfoDTO = null;
	// try {
	// PersonBasicInfo pbi = personService.getPersonBasicInfo(motherCPRNumber);
	// PersonSummary psi = personService.getPersonSummary(motherCPRNumber);
	// List<Employment> empRecords =
	// employmentService.getActiveEmployments(motherCPRNumber);
	// fatherInfoDTO = new MotherInfoDTO(pbi.getArabicName(),
	// pbi.getEnglishName(),
	// psi.isBahraini() ? Nationality.Bahraini : Nationality.Other,
	// psi.getDateOfDeath(),
	// psi.getMaritalStatusCode(), (empRecords != null && empRecords.size() >
	// 0),
	// psi.getDateOfDeath() != null ? false : true);
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("getMotherInfo(Integer) Error: " + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Mother Details Not found",
	// new ApplicationException(exception.getMessage()));
	// }
	//
	// return fatherInfoDTO;
	// }
	//
	// @Override
	// @Secured({ "ROLE_RCORetrieve" })
	// @WebMethod(operationName = "getFatherInfo")
	// public FatherInfoDTO getFatherInfo(SecurityTagObject security, Integer
	// fatherCPRNumber)
	// throws ApplicationExceptionInfo {
	// if (validationService.isDeletedCpr(fatherCPRNumber)) {
	// throw new ApplicationExceptionInfo("Father CPR Number Deleted",
	// new ApplicationException("Father CPR Number Deleted", "001"));
	// }
	// final PersonService personService =
	// getCrsService().getPersonServiceRef();
	// FatherInfoDTO fatherInfoDTO = null;
	// try {
	// PersonBasicInfo pbi = personService.getPersonBasicInfo(fatherCPRNumber);
	// PersonSummary psi = personService.getPersonSummary(fatherCPRNumber);
	// fatherInfoDTO = new FatherInfoDTO(pbi.getArabicName(),
	// pbi.getEnglishName(), psi.getDateOfDeath(),
	// psi.getDateOfDeath() != null ? false : true);
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("getFatherInfo(Integer) Error: " + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Father Details Not found",
	// new ApplicationException(exception.getMessage()));
	// }
	//
	// return fatherInfoDTO;
	// }

	@Override
	@Secured({ "ROLE_RCORetrieve" })
	@WebMethod(operationName = "getNextOfKinInfo")
	public NextOfKinInfoDTO getNextOfKinInfo(SecurityTagObject security, Integer nextOfKinCPRNumber)
			throws ApplicationExceptionInfo {
		if (validationService.isDeletedCpr(nextOfKinCPRNumber)) {
			throw new ApplicationExceptionInfo("next Of Kin CPRNumber CPR Number Deleted",
					new ApplicationException("next Of Kin CPRNumber CPR Number Deleted", "001"));
		}
		final PersonService personService = getCrsService().getPersonServiceRef();
		final AddressService addressService = getCrsService().getAddressServiceRef();
		NextOfKinInfoDTO nextOfKinInfoDTO = null;
		try {
			PersonBasicInfo pbi = personService.getPersonBasicInfo(nextOfKinCPRNumber);
			PersonSummary psi = personService.getPersonSummary(nextOfKinCPRNumber);
			Address address = addressService.getAddressDetailsByCpr(nextOfKinCPRNumber);
			nextOfKinInfoDTO = new NextOfKinInfoDTO(pbi.getArabicName(), pbi.getEnglishName(),
					psi.getDateOfDeath() != null ? false : true, address.getFlatNumber() + "",
					address.getRoadNumber() + "", address.getBlockNumber() + "", address.getAreaNameEnglish(),
					address.getBuildingNumber() + "", address.getNameAlphaArabic(), address.getNameAlphaEnglish());
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getNextOfKinInfo(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("next Of Kin CPRNumber Details Not found",
					new ApplicationException(exception.getMessage()));
		}

		return nextOfKinInfoDTO;
	}

	@Override
	@Secured({ "ROLE_RCORetrieve" })
	@WebMethod(operationName = "getFatherMotherRelatedInfo")
	public FatherMotherInfoDTO getFatherMotherRelatedInfo(SecurityTagObject security, Integer fatherCPRNumber,
			Integer motherCPRNumber) throws ApplicationExceptionInfo {

		FatherMotherInfoDTO fatherMotherInfoDTO = null;
		FatherInfoDTO fatherInfoDTO = null;
		MotherInfoDTO motherInfoDTO = null;
		ArrayList<ChildrenRCODetailDTO> childrenDetailDTO = null;

		if (validationService.isDeletedCpr(fatherCPRNumber)) {
			throw new ApplicationExceptionInfo("Father Details Not found",
					new ApplicationException("Father Details Not found", "001"));
		}
		if (validationService.isDeletedCpr(motherCPRNumber)) {
			throw new ApplicationExceptionInfo("Mother  Details Not found",
					new ApplicationException("Mother  Details Not found", "002"));
		}

		final PersonService personService = getCrsService().getPersonServiceRef();
		final FamilyService familyService = getCrsService().getFamilyServiceRef();
		final EmploymentService employmentService = getCrsService().getEmploymentServiceRef();
		PersonBasicInfo pbiFa = null;
		PersonSummary psiFa = null;
		PersonBasicInfo pbiMo = null;
		PersonSummary psiMo = null;
		List<Employment> empRecords = null;
		List<PersonSummary> children = null;
		List<Marriage> marrieges = null;
		try {

			pbiFa = personService.getPersonBasicInfo(fatherCPRNumber);
			psiFa = personService.getPersonSummary(fatherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getFatherMotherRelatedInfo(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Father Details Not found",
					new ApplicationException("Father Details Not found", "001"));
		}
		if (pbiFa.getGender() != null && !pbiFa.getGender().equalsIgnoreCase("M"))
			throw new ApplicationExceptionInfo("Fault Occurred While Retrieving Father Details",
					new ApplicationException("Fault Occurred While Retrieving Father Details", "003"));
		try {

			pbiMo = personService.getPersonBasicInfo(motherCPRNumber);
			psiMo = personService.getPersonSummary(motherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getFatherMotherRelatedInfo(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Mother Details Not found",
					new ApplicationException("Mother Details Not found", "002"));
		}
		if (pbiMo.getGender() != null && !pbiMo.getGender().equalsIgnoreCase("F"))
			throw new ApplicationExceptionInfo("Fault Occurred While Retrieving mother Details",
					new ApplicationException("Fault Occurred While Retrieving mother Details", "004"));
		try {
			empRecords = employmentService.getActiveEmployments(motherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getFatherMotherRelatedInfo(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Fault Occured While Retreiving Mother Employment Details",
					new ApplicationException("Fault occurred While Retrieving Mother Employment Details", "005"));
		}
		try {
			children = familyService.getCoupleChildren(fatherCPRNumber, motherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getFatherMotherRelatedInfo(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Fault Occured While Retreiving Children Details",
					new ApplicationException("Fault occurred While Retrieving Children Details", "006"));
		}
		try {
			marrieges = familyService.getPersonMarriageDivorceList(fatherCPRNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getFatherMotherRelatedInfo(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Fault Occured While Retreiving Marriage Details",
					new ApplicationException("Fault occurred While Retrieving Marriage Details", "007"));
		}

		boolean isFatherNotDead = psiFa.getDateOfDeath() != null ? false : true;

		if (isFatherNotDead) {
			throw new ApplicationExceptionInfo("Fault Occurred While Retrieving Father Details",
					new ApplicationException("Fault Occurred While Retrieving Father Details", "008"));
		}

		fatherInfoDTO = new FatherInfoDTO(pbiFa.getArabicName(), pbiFa.getEnglishName(), psiFa.getDateOfDeath(),
				psiFa.getDateOfDeath() != null ? false : true);

		motherInfoDTO = new MotherInfoDTO(pbiMo.getArabicName(), pbiMo.getEnglishName(),
				psiMo.isBahraini() ? Nationality.Bahraini : Nationality.Other, psiMo.getAge() + "",
				psiMo.getMaritalStatusCode(), (empRecords != null && empRecords.size() > 0),
				psiMo.getDateOfDeath() != null ? false : true);

		if (logger.isDebugEnabled()) {
			logger.debug("getFatherMotherRelatedInfo() -  No Of children = " + children);
		}
		childrenDetailDTO = new ArrayList<ChildrenRCODetailDTO>();
		boolean isLastActionMarried = false;
		boolean isWifeMarriedAfter = true;
		boolean relationFound = false;
		ArrayList<Date> marriageDates = new ArrayList<Date>();
		Date currentPartenerMarriageDate = null;
		if (marrieges != null )
		{
			for (Marriage marriage : marrieges) {
				marriageDates.add(marriage.getMarriageDivorceAsDate());
				if (marriage.getPartnerCprNumber().equals(motherCPRNumber)) {
					relationFound = true;
					currentPartenerMarriageDate = marriage.getMarriageDivorceAsDate();
					if (marriage.getLastActionWithPartner().equalsIgnoreCase("MARRIAGE")) {
	
						isLastActionMarried = true;
					}
				}
			}
		}
		else
		{
			throw new ApplicationExceptionInfo("Fault occurred While Retrieving Marriage Details",
					new ApplicationException("Fault occurred While Retrieving Marriage Details", "007"));
		}
		Date lastMarriageDate = Collections.max(marriageDates);
		if((lastMarriageDate!=null) && (currentPartenerMarriageDate!=null) && (lastMarriageDate.equals(currentPartenerMarriageDate))  ) {
			isWifeMarriedAfter = false;
		}
		if (!relationFound)
			throw new ApplicationExceptionInfo("Fault occurred While Retrieving Marriage Details",
					new ApplicationException("Fault occurred While Retrieving Marriage Details", "007"));

		for (PersonSummary personSummary : children) {
			PersonSummary childrenSummary = personSummary;
			PersonBasicInfo childrenPersonBasicInfo = null;
			PersonSummary childrenPersonSummary = null;
			Integer noOfChildren = 0;
			try {
				childrenPersonBasicInfo = personService.getPersonBasicInfo(childrenSummary.getCprNumber());
				childrenPersonSummary = personService.getPersonSummary(childrenSummary.getCprNumber());
				noOfChildren = familyService.getPersonNumberOfChildren(childrenPersonBasicInfo.getCprNumber());
			} catch (final Exception exception) {
				exception.printStackTrace();
				if (logger.isDebugEnabled()) {
					logger.error("getFatherMotherRelatedInfo(Integer) Error: " + exception.getMessage());
				}
				throw new ApplicationExceptionInfo("Fault occurred While Retrieving Marriage Details",
						new ApplicationException("Fault occurred While Retrieving Marriage Details", "009"));
			}

			if (logger.isDebugEnabled()) {
				logger.debug("getFatherMotherRelatedInfo() -  : childrenPersonSummary = " + childrenPersonSummary);
			}
			final boolean isBahraini = (childrenPersonSummary.getNationalityCountryCode().equals("499")
					|| childrenPersonSummary.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isNotDead = (childrenPersonSummary.getIoStatusCode().equals("1")) ? false : true;
			boolean haveChildren = (noOfChildren != null && noOfChildren > 0);

			childrenDetailDTO.add(new ChildrenRCODetailDTO(childrenPersonSummary.getCprNumber(),
					childrenPersonBasicInfo.getArabicName(), childrenPersonBasicInfo.getEnglishName(),
					childrenPersonSummary.getMaritalStatusCode(), childrenPersonSummary.getEmploymentStatusCode(),
					childrenPersonBasicInfo.getAge() + "", childrenPersonBasicInfo.getGender(), isBahraini, isNotDead,
					haveChildren));
		}
		fatherMotherInfoDTO = new FatherMotherInfoDTO(isLastActionMarried,isWifeMarriedAfter, fatherInfoDTO, motherInfoDTO,
				childrenDetailDTO);
		if (logger.isDebugEnabled()) {
			logger.debug("getFatherMotherRelatedInfo(Integer) - end");
		}

		return fatherMotherInfoDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationService() {
		return validationService;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationService(ValidationServiceImpl validationService) {
		this.validationService = validationService;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}
}
