package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonServiceContactInformation", propOrder =
{ "mailBox", "contactPhone", "email1", "email2", "email3", "fax", "faxWork",
		"mobile", "phoneWork" })
public class PersonServiceContactDTO
{
	private String	mailBox, contactPhone, email1, email2, email3, fax,
			faxWork, mobile, phoneWork;

	public PersonServiceContactDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonServiceContactDTO(String mailBox, String contactPhone,
			String email1, String email2, String email3, String fax,
			String faxWork, String mobile, String phoneWork)
	{
		super();
		this.mailBox = mailBox != null ? mailBox : "";
		this.contactPhone = contactPhone != null ? contactPhone : "";
		this.email1 = email1 != null ? email1 : "";
		this.email2 = email2 != null ? email2 : "";
		this.email3 = email3 != null ? email3 : "";
		this.fax = fax != null ? fax : "";
		this.faxWork = faxWork != null ? faxWork : "";
		this.mobile = mobile != null ? mobile : "";
		this.phoneWork = phoneWork != null ? phoneWork : "";
	}

	@XmlElement(name = "ContactPhone", required = true)
	public String getContactPhone()
	{
		return contactPhone;
	}

	@XmlElement(name = "Email1", required = true)
	public String getEmail1()
	{
		return email1;
	}

	@XmlElement(name = "Email2", required = true)
	public String getEmail2()
	{
		return email2;
	}

	@XmlElement(name = "Email3", required = true)
	public String getEmail3()
	{
		return email3;
	}

	@XmlElement(name = "Fax", required = true)
	public String getFax()
	{
		return fax;
	}

	@XmlElement(name = "FaxWork", required = true)
	public String getFaxWork()
	{
		return faxWork;
	}

	@XmlElement(name = "MailBox", required = true)
	public String getMailBox()
	{
		return mailBox;
	}

	@XmlElement(name = "Mobile", required = true)
	public String getMobile()
	{
		return mobile;
	}

	@XmlElement(name = "PhoneWork", required = true)
	public String getPhoneWork()
	{
		return phoneWork;
	}

	public void setContactPhone(String contactPhone)
	{
		this.contactPhone = contactPhone;
	}

	public void setEmail1(String email1)
	{
		this.email1 = email1;
	}

	public void setEmail2(String email2)
	{
		this.email2 = email2;
	}

	public void setEmail3(String email3)
	{
		this.email3 = email3;
	}

	public void setFax(String fax)
	{
		this.fax = fax;
	}

	public void setFaxWork(String faxWork)
	{
		this.faxWork = faxWork;
	}

	public void setMailBox(String mailBox)
	{
		this.mailBox = mailBox;
	}

	public void setMobile(String mobile)
	{
		this.mobile = mobile;
	}

	public void setPhoneWork(String phoneWork)
	{
		this.phoneWork = phoneWork;
	}

	@Override
	public String toString()
	{
		return "PersonServiceContactDTO [mailBox=" + mailBox
				+ ", contactPhone=" + contactPhone + ", email1=" + email1
				+ ", email2=" + email2 + ", email3=" + email3 + ", fax=" + fax
				+ ", faxWork=" + faxWork + ", mobile=" + mobile
				+ ", phoneWork=" + phoneWork + "]";
	}
}
