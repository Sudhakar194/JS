/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package bh.gov.cio.integration.common;

import java.io.ByteArrayOutputStream;
import java.io.StringReader;
import java.net.UnknownHostException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.SOAPMessage;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.http.AbstractHTTPDestination;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import bh.gov.cio.integration.common.dao.LogDao;

/**
 * 
 */
@Configuration(value = "MessageDBLogInInterceptor")
public class MessageDBLogInInterceptor extends AbstractSoapInterceptor// AbstractPhaseInterceptor<Message>
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(MessageDBLogInInterceptor.class);

	@Autowired
	protected LogDao logLoaderDao;

	public MessageDBLogInInterceptor() {
		super(Phase.PRE_PROTOCOL);
		getAfter().add(SAAJInInterceptor.class.getName());
	}

	@Override
	public void handleMessage(SoapMessage message) throws Fault {
		String IN_OR_OUT = "IN";
		String IS_ERROR_MESSAGE = "F";
		String USERNAME = "";
		String MESSAGE_PAYLOAD = "";
		String REMARKS = "";
		String TARGET_APP = "";
		String WEBSERVICE_URL = "";
		String CLIENT_IP = "";
		Integer CPR_NUMBER = null;
		UUID MESSAGE_ID = UUID.randomUUID();
		try {
			Exchange exchange = message != null ? message.getExchange() : null;
			Message inMessage = exchange != null ? exchange.getInMessage() : null;
			// Message outMessage = exchange != null ? exchange.getOutMessage() : null;
			Message inFaultMessage = exchange != null ? message.getExchange().getInFaultMessage() : null;
			// Message outFaultMessage = exchange != null ?
			// message.getExchange().getOutFaultMessage() : null;
			Object path = message.get(Message.PATH_INFO);
			String pathStr = path != null ? (String) path : "";
			TARGET_APP = (pathStr.indexOf("/") != -1 && pathStr.indexOf("/", pathStr.indexOf("/") + 1) != -1)
					? pathStr.substring(pathStr.indexOf("/") + 1, pathStr.indexOf("/", pathStr.indexOf("/") + 1))
					: "";
			WEBSERVICE_URL = exchange.get(Message.WSDL_SERVICE) != null
					? ((QName) exchange.get(Message.WSDL_SERVICE)).getLocalPart()
					: "";
			exchange.put("MESSAGE.TARGET_APP", TARGET_APP);

			Exception exception = message.getContent(Exception.class);
			if (exception != null)

			{
				REMARKS = ExceptionUtils.getStackTrace(exception);
			}
			if (message == inFaultMessage && inFaultMessage != null) {
				IS_ERROR_MESSAGE = "T";
				IN_OR_OUT = "IN";
			}
			if (message == inMessage && inMessage != null) {
				exchange.put("MESSAGE.ID", MESSAGE_ID);
				IN_OR_OUT = "IN";
			}
			SOAPMessage soapMessage = message.getContent(SOAPMessage.class);
			if (soapMessage != null) {
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				soapMessage.writeTo(out);
				MESSAGE_PAYLOAD = new String(out.toByteArray());
				// DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				// DocumentBuilder builder = factory.newDocumentBuilder();
				// InputSource is = new InputSource(new StringReader(MESSAGE_PAYLOAD));
				// Document requestSoap = builder.parse(is);
				// logger.debug("requestSoap.getChildNodes(" +
				// MESSAGE_PAYLOAD.indexOf(""));
			}
			if (MESSAGE_PAYLOAD != null) {
				DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(MESSAGE_PAYLOAD));
				Document doc = db.parse(is);

				NodeList Username = doc.getElementsByTagName("Username");
				if (Username != null) {
					USERNAME = getCharacterDataFromElement((Element) Username.item(0));
					exchange.put("MESSAGE.USERNAME", USERNAME);
				}

			}

			HttpServletRequest request = (HttpServletRequest) message.get(AbstractHTTPDestination.HTTP_REQUEST);

			if (request != null) {
				CLIENT_IP = request.getRemoteAddr();
				exchange.put("MESSAGE.REQUESTIP", CLIENT_IP);
			}
		} catch (final RuntimeException ex) {
			REMARKS = ExceptionUtils.getStackTrace(ex);
			logger.error("handleMessage(SoapMessage)", ex);
			throw ex;
		} catch (Exception e) {
			REMARKS = ExceptionUtils.getStackTrace(e);

		} finally {
			if (IN_OR_OUT.equals("IN"))
				logToDB(IN_OR_OUT, MESSAGE_PAYLOAD, REMARKS, IS_ERROR_MESSAGE, USERNAME, TARGET_APP, WEBSERVICE_URL,
						CLIENT_IP, MESSAGE_ID.toString(), CPR_NUMBER);
		}

		if (logger.isDebugEnabled())
			logger.debug("handleMessage(SoapMessage) - end");

	}

	private void logToDB(String IN_OR_OUT, String MESSAGE_PAYLOAD, String REMARKS, String IS_ERROR_MESSAGE,
			String USERNAME, String TARGET_APP, String WEBSERVICE_URL, String CLIENT_IP, String MESSAGE_ID,
			Integer CPR_NUMBER) {

		try {
			logger.debug("log to db :\n IN_OR_OUT :" + IN_OR_OUT + "\n IS_ERROR_MESSAGE" + IS_ERROR_MESSAGE
					+ "\n USERNAME" + USERNAME + "\n MESSAGE_PAYLOAD" + MESSAGE_PAYLOAD + "\n REMARKS" + REMARKS
					+ "\n TARGET_APP" + TARGET_APP + "\n WEBSERVICE_URL" + WEBSERVICE_URL + "\n CLIENT_IP" + CLIENT_IP
					+ "\n MESSAGE_ID" + MESSAGE_ID);
			logLoaderDao.CreateLogRecord(IN_OR_OUT, MESSAGE_PAYLOAD, REMARKS, IS_ERROR_MESSAGE, USERNAME, TARGET_APP,
					WEBSERVICE_URL, CLIENT_IP, MESSAGE_ID, CPR_NUMBER);
		} catch (CannotGetJdbcConnectionException exception) {
			// exception.printStackTrace();
			logger.error("handleMessage(SoapMessage) - CannotGetJdbcConnectionException", exception);
		} catch (UnknownHostException exception) {
			// exception.printStackTrace();
			logger.error("handleMessage(SoapMessage) - UnknownHostException", exception);
		} catch (Exception exception) {
			// exception.printStackTrace();
			logger.error("handleMessage(SoapMessage)", exception);
		}
	}

	@Override
	public void handleFault(SoapMessage message) {
		super.handleFault(message);
	}

	//
	// private SOAPMessage getSOAPMessage(SoapMessage smsg)
	// {
	//
	// SOAPMessage soapMessage = smsg.getContent(SOAPMessage.class);
	//
	// if (soapMessage == null)
	// {
	//
	// saajIn.handleMessage(smsg);
	//
	// soapMessage = smsg.getContent(SOAPMessage.class);
	//
	// }
	//
	// return soapMessage;
	//
	// }
	public static String getCharacterDataFromElement(Element e) {
		if (e != null) {
			Node child = e.getFirstChild();
			if (child instanceof CharacterData) {
				CharacterData cd = (CharacterData) child;
				return cd.getData();
			} else {
				return "";
			}
		} else {
			return "";
		}
	}
}
