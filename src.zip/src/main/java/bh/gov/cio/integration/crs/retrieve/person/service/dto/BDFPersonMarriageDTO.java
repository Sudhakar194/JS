package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.ArrayList;
import java.util.Date;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "Marriage", propOrder = { "marriage" })
public class BDFPersonMarriageDTO {

	private ArrayList<BDFPersonMarriage> marriage;
	
	public BDFPersonMarriageDTO(ArrayList<BDFPersonMarriage> marriage) {
		super();
		this.marriage = marriage;
	}

	public BDFPersonMarriageDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ArrayList<BDFPersonMarriage> getMarriage() {
		return marriage;
	}

	public void setMarriage(ArrayList<BDFPersonMarriage> marriage) {
		this.marriage = marriage;
	}

	@XmlType(name = "PersonMarriage", propOrder = { "marriageCPRNumber", "marriageNameArabic", "marriageNameEnglish",
			"marriageDate", "divorceDate", "hasCR" })
	public static class BDFPersonMarriage {
		private Integer marriageCPRNumber;
		private String marriageNameArabic;
		private String marriageNameEnglish;
		private Date marriageDate;
		private Date divorceDate;
		private Boolean hasCR;

		public BDFPersonMarriage() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Integer getMarriageCPRNumber() {
			return marriageCPRNumber;
		}

		public BDFPersonMarriage(Integer marriageCPRNumber, String marriageNameArabic, String marriageNameEnglish,
				Date marriageDate, Date divorceDate, Boolean hasCR) {
			super();
			this.marriageCPRNumber = marriageCPRNumber;
			this.marriageNameArabic = marriageNameArabic;
			this.marriageNameEnglish = marriageNameEnglish;
			this.marriageDate = marriageDate;
			this.divorceDate = divorceDate;
			this.hasCR = hasCR;
		}

		public void setMarriageCPRNumber(Integer marriageCPRNumber) {
			this.marriageCPRNumber = marriageCPRNumber;
		}

		public String getMarriageNameArabic() {
			return marriageNameArabic;
		}

		public void setMarriageNameArabic(String marriageNameArabic) {
			this.marriageNameArabic = marriageNameArabic;
		}

		public String getMarriageNameEnglish() {
			return marriageNameEnglish;
		}

		public void setMarriageNameEnglish(String marriageNameEnglish) {
			this.marriageNameEnglish = marriageNameEnglish;
		}

		public Date getMarriageDate() {
			return marriageDate;
		}

		public void setMarriageDate(Date marriageDate) {
			this.marriageDate = marriageDate;
		}

		public Date getDivorceDate() {
			return divorceDate;
		}

		public void setDivorceDate(Date divorceDate) {
			this.divorceDate = divorceDate;
		}

		public Boolean getHasCR() {
			return hasCR;
		}

		public void setHasCR(Boolean hasCR) {
			this.hasCR = hasCR;
		}

	}
}
