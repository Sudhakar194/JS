package bh.gov.cio.integration.crs.retrieve.address;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.address.service.PersonAddressBasicSpecialInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressServiceBasicSpecialInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(
		name = "PersonAddressBasicSpecialInfoService",
		targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")

public class PersonAddressBasicSpecialInfoServiceImpl implements
		PersonAddressBasicSpecialInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(PersonAddressBasicSpecialInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonAddressBasicSpecialInfo" })
	@WebMethod(operationName = "getPersonAddressBasicSpecialInfo")
	public AddressServiceBasicSpecialInfoDTO getPersonAddressBasicSpecialInfo(
			SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo
	{
		if (logger.isDebugEnabled())
			logger.debug("getPersonAddressBasicSpecialInfo(Integer) - start");

		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted"));
		AddressServiceBasicSpecialInfoDTO returnedAddress = null;
		try
		{
			final List<bh.gov.cio.crs.model.nas.Address> addresses = getCrsService()
					.getAddressServiceRef().getPersonAddressByCpr(cprNumber);
			if (addresses.size() == 0)
				throw new ApplicationExceptionInfo(
						"Address Basic Details Not found",
						new ApplicationException(
								"Address Basic Details Not found"));
			if (addresses != null)
			{
				final bh.gov.cio.crs.model.nas.Address returnedAddressRow = addresses
						.get(addresses.size() - 1);
				returnedAddress = new AddressServiceBasicSpecialInfoDTO(
						returnedAddressRow.getBlockNumber(),
						returnedAddressRow.getBlockNameArabic(),
						returnedAddressRow.getBuildingNumber(),
						returnedAddressRow.getNameAlphaEnglish(),
						returnedAddressRow.getNameAlphaArabic(),
						returnedAddressRow.getBuildingNameArabic(),
						returnedAddressRow.getBuildingNameEnglish(),
						returnedAddressRow.getBlockNameEnglish(),
						returnedAddressRow.getRoadNumber(),
						returnedAddressRow.getRoadNameArabic(),
						returnedAddressRow.getRoadNameEnglish(),
						returnedAddressRow.getAreaCode(),
						returnedAddressRow.getAreaNameArabic(),
						returnedAddressRow.getAreaNameEnglish(),
						returnedAddressRow.getFlatNumber(),
						returnedAddressRow.getRegionNameArabic(),
						returnedAddressRow.getRegionNameEnglish(),returnedAddressRow.getGovernorateNameArabic(),
						returnedAddressRow.getGovernorateNameEnglish(),returnedAddressRow.getAddressTypeCode());
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonAddressBasicSpecialInfo(Integer, Integer, Date) Error: "
						+ exception.getMessage());
			throw new ApplicationExceptionInfo(
					"Address Basic Details Not found",
					new ApplicationException("Address Basic Details Not found"));
		}

		if (logger.isDebugEnabled())
			logger.debug("getPersonAddressBasicSpecialInfo(Integer) - end");
		return returnedAddress;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}

}
