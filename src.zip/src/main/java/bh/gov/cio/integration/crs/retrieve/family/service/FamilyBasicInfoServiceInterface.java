package bh.gov.cio.integration.crs.retrieve.family.service;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.family.service.dto.CheckCROwnerRelationDTO;
import bh.gov.cio.integration.crs.retrieve.family.service.dto.FamilyTreeInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "FamilyBasicInfoService", targetNamespace = "http://service.family.retrieve.crs.integration.cio.gov.bh/")
public interface FamilyBasicInfoServiceInterface
{
	@WebMethod(operationName = "checkCROwnerRelation")
	ArrayList<CheckCROwnerRelationDTO> checkCROwnerRelation(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "crNumber") @XmlElement(required = true) Integer crNumber) throws ApplicationExceptionInfo;

//	@WebMethod(operationName = "getAllFamilyBasicInfo")
//	FamilyBasicInfoDTO getAllFamilyBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
//	header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
//			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

//	@WebMethod(operationName = "getFamilyBasicInfo")
//	FamilyBasicInfoDTO getFamilyBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
//	header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
//			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	/**
	 * This method used to return family member tree
	 * 
	 * @return personCPR,personMotherAndFather,personGrandFatherAndMother,
	 *         personChildren ,personWives
	 * @author csdvsbu
	 * */

	@WebMethod(operationName = "getFamilyTreeInfo")
	FamilyTreeInfoDTO getFamilyTreeInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
