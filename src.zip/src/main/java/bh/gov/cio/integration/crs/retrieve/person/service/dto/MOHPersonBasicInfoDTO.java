package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "PersonServiceBasicInfo", propOrder =
{ "age", "arabicName", "cprNumber", "birthDate", "deathDate", "englishName", "gender", "personDisplayName", "nationality", "religionCode",
		"maritalStatus","cardExpiryDate" })
public class MOHPersonBasicInfoDTO
{
	private String age;
	private String arabicName;
	private String cprNumber;
	private String birthDate;
	private String deathDate;
	private String englishName;
	private String gender;
	private String nationality;
	private String personDisplayName;
	private String religionCode;
	private String maritalStatus;
	private String cardExpiryDate;

	public MOHPersonBasicInfoDTO()
	{
		super();
	}

	public MOHPersonBasicInfoDTO(String age, String arabicName, String cprNumber, String birthDate, String deathDate, String englishName,
			String gender, String nationality, String personDisplayName, String religionCode, String maritalStatus)
	{
		super();
		if (age != null)
		{
			setAge(age);
		}
		else
		{
			setAge("");
		}
		if (arabicName != null)
		{
			setArabicName(arabicName);
		}
		else
		{
			setArabicName("");
		}
		if (birthDate != null)
		{
			setBirthDate(birthDate);
		}
		else
		{
			setBirthDate("");
		}
		if (deathDate != null)
		{
			setDeathDate(deathDate);
		}
		else
		{
		}
		if (cprNumber != null)
		{
			setCprNumber(cprNumber);
		}
		else
		{
			setCprNumber("");
		}
		if (englishName != null)
		{
			setEnglishName(englishName);
		}
		else
		{
			setEnglishName("");
		}
		if (gender != null)
		{
			setGender(gender);
		}
		else
		{
			setGender("");
		}
		if (nationality != null)
		{
			setNationality(nationality);
		}
		else
		{
			setNationality("");
		}
		if (personDisplayName != null)
		{
			setPersonDisplayName(personDisplayName);
		}
		else
		{
			setPersonDisplayName("");
		}
		if (religionCode != null)
		{
			setReligionCode(religionCode);
		}
		else
		{
			setReligionCode("");
		}
		if (maritalStatus != null)
		{
			setMaritalStatus(maritalStatus);
		}
		else
		{
			setMaritalStatus("");
		}
	}

	@XmlElement(name = "Age", required = true)
	public String getAge()
	{
		return age;
	}

	@XmlElement(name = "ArabicName", required = true)
	public String getArabicName()
	{
		return arabicName;
	}

	@XmlElement(name = "BirthDate", required = true)
	public java.lang.String getBirthDate()
	{
		return birthDate;
	}

	@XmlElement(name = "CprNumber", required = true)
	public String getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(name = "DeathDate", required = true)
	public java.lang.String getDeathDate()
	{
		return deathDate;
	}

	@XmlElement(name = "EnglishName", required = true)
	public String getEnglishName()
	{
		return englishName;
	}

	@XmlElement(name = "Gender", required = true)
	public String getGender()
	{
		return gender;
	}

	@XmlElement(name = "MaritalStatus", required = true)
	public String getMaritalStatus()
	{
		return maritalStatus;
	}

	@XmlElement(name = "Nationality", required = true)
	public String getNationality()
	{
		return nationality;
	}

	@XmlElement(name = "PersonDisplayName", required = true)
	public String getPersonDisplayName()
	{
		return personDisplayName;
	}

	@XmlElement(name = "ReligionCode", required = true)
	public String getReligionCode()
	{
		return religionCode;
	}

	@XmlElement(name = "CardExpiryDate", required = false)
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}

	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}

	public void setAge(String age)
	{
		this.age = age;
	}

	public void setArabicName(String arabicName)
	{
		this.arabicName = arabicName;
	}

	public void setBirthDate(java.lang.String birthDate)
	{
		this.birthDate = birthDate;
	}

	public void setCprNumber(String cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setDeathDate(java.lang.String deathDate)
	{
		this.deathDate = deathDate;
	}

	public void setEnglishName(String englishName)
	{
		this.englishName = englishName;
	}

	public void setGender(String gender)
	{
		this.gender = gender;
	}

	public void setMaritalStatus(String maritalStatus)
	{
		this.maritalStatus = maritalStatus;
	}

	public void setNationality(String nationality)
	{
		this.nationality = nationality;
	}

	public void setPersonDisplayName(String personDisplayName)
	{
		this.personDisplayName = personDisplayName;
	}

	public void setReligionCode(String religionCode)
	{
		this.religionCode = religionCode;
	}

}
