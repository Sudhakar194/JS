package bh.gov.cio.integration.crs.retrieve.person;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.GDNPRDocument;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PersonPassportInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonServicePassportInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonPassportInfoService",
		targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonPassportInfoService"
public class PersonPassportInfoServiceImpl implements PersonPassportInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger				logger	= LoggerFactory.getLogger(PersonPassportInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;

	@Override
	@Secured(
	{ "ROLE_getPersonPassportInfo" })
	@WebMethod(operationName = "getPersonPassportInfo")
	public PersonServicePassportInfoDTO getPersonPassportInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		PersonServicePassportInfoDTO personPassportInfoDTO = null;
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonPassportInfo(Integer, Integer, Date) - start");
			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ", blockNumber = " + blockNumber + ", cardExpiryDate = " + cardExpiryDate
					+ ")");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		if (validationUtil.isMilitaryCpr(cprNumber))
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		try
		{
			final GDNPRDocument gdnprDocument = getCrsService().getGDNPRServiceRef().getPersonLatestGDNPRDocument(cprNumber);
			personPassportInfoDTO = new PersonServicePassportInfoDTO(gdnprDocument.getDocumentNumber(),
					DateServiceImpl.formatDateAsString(gdnprDocument.getIssueDate()), DateServiceImpl.formatDateAsString(gdnprDocument
							.getExpiryDate()), gdnprDocument.getPlaceOfBirthArabic(), gdnprDocument.getPlaceOfBirthEnglish());
			if (logger.isDebugEnabled())
				logger.debug("getPersonPassportInfo(Integer, Integer, Date) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonPassportInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Passport Details Not found", new ApplicationException(exception.getMessage()));
		}
		return personPassportInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonPassportInfoByCPR" })
	@WebMethod(operationName = "getPersonPassportInfoByCPR")
	public PersonServicePassportInfoDTO getPersonPassportInfoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		PersonServicePassportInfoDTO personPassportInfoDTO = null;
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonPassportInfo(Integer, Integer, Date) - start");
			logger.debug("getPersonSummery(cprNumber = " + cprNumber + ")");
		}

		// if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		// throw new ApplicationExceptionInfo("Block Number",
		// new ApplicationException("Wrong Block Number"));
		// if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		// throw new ApplicationExceptionInfo("Expiry Date",
		// new ApplicationException("Wrong Expiry Date"));
		if (validationUtil.isMilitaryCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Data Problem", new ApplicationException("CPR Data Problem"));
		if (validationUtil.isDeletedCpr(cprNumber))
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		try
		{
			final GDNPRDocument gdnprDocument = getCrsService().getGDNPRServiceRef().getPersonLatestGDNPRDocument(cprNumber);
			personPassportInfoDTO = new PersonServicePassportInfoDTO(gdnprDocument.getDocumentNumber(),
					DateServiceImpl.formatDateAsString(gdnprDocument.getIssueDate()), DateServiceImpl.formatDateAsString(gdnprDocument
							.getExpiryDate()), gdnprDocument.getPlaceOfBirthArabic(), gdnprDocument.getPlaceOfBirthEnglish());
			if (logger.isDebugEnabled())
				logger.debug("getPersonPassportInfo(Integer, Integer, Date) - end");
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
				logger.error("getPersonPassportInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			throw new ApplicationExceptionInfo("Person Passport Details Not found", new ApplicationException(exception.getMessage()));
		}
		return personPassportInfoDTO;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
