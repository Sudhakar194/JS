package bh.gov.cio.integration.crs.retrieve.address;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.nas.AddressOwner;
import bh.gov.cio.crs.util.CRSUtils;
import bh.gov.cio.crs.util.exception.AddressLoadException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.retrieve.address.service.AddressSearchServiceInterface;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressOwnerDTO;
import bh.gov.cio.integration.crs.retrieve.address.service.dto.AddressSearchInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "AddressSearchService", targetNamespace = "http://service.address.retrieve.crs.integration.cio.gov.bh/")
public class AddressSearchServiceImpl implements AddressSearchServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(AddressSearchServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@Override
	@Secured(
	{ "ROLE_getAddressesInfoByBlockAndRoad" })
	@WebMethod(operationName = "getAddressesInfoByBlockAndRoad")
	public List<AddressSearchInfoDTO> getAddressesInfoByBlockAndRoad(SecurityTagObject security, Integer roadNumber, Integer blockNumber)
			throws ApplicationExceptionInfo
	{

		List<AddressSearchInfoDTO> returnAddressList = new ArrayList<AddressSearchInfoDTO>();

		try
		{

			List<Address> addressList = getCrsService().getAddressServiceRef().searchByAddressFields(0, null, "", roadNumber, blockNumber);

			if (addressList.size() == 0)
			{
				throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
			}

			if (addressList != null)
			{
				if (logger.isDebugEnabled())
				{
					logger.error("Address size List: " + addressList.size() + "  road number: " + roadNumber + " Block Number: " + blockNumber);
				}
				Collections.sort(addressList);
				for (final Address address : addressList)
				{
					AddressOwnerDTO addressOwnerDTO = new AddressOwnerDTO();
					List<AddressOwner> addressOwnerList = getCrsService().getAddressServiceRef().getAddressOwner(address.getAddressSn());
					List<AddressOwnerDTO> AddressOwnersList = new ArrayList<AddressOwnerDTO>();
					for (final AddressOwner AddressOwner : addressOwnerList)
					{
						addressOwnerDTO.setOwnerNumber(AddressOwner.getAddressOwnerNumber());
						addressOwnerDTO.setOwnerType(AddressOwner.getAddressOwnerType());
						AddressOwnersList.add(addressOwnerDTO);

					}
					returnAddressList.add(new AddressSearchInfoDTO(address.getBlockNumber(), address.getBlockNameArabic(), address
							.getBuildingNumber(), address.getNameAlphaEnglish(), address.getNameAlphaArabic(), address.getBuildingNameArabic(),
							address.getBuildingNameEnglish(), address.getBlockNameEnglish(), address.getRoadNumber(), address.getRoadNameArabic(),
							address.getRoadNameEnglish(), address.getAreaCode(), address.getAreaNameArabic(), address.getAreaNameEnglish(), address
									.getFlatNumber(), address.getRegionNameArabic(), address.getRegionNameEnglish(), address
									.getGovernorateNameArabic(), address.getGovernorateNameEnglish(), address.getBuildingTypeCode(), address
									.getAddressUsageCode(), CRSUtils.getDateStringFromTimeStamp(address.getDateCreated()), AddressOwnersList));

				}

			}
		}

		catch (AddressLoadException e)
		{

			e.printStackTrace();
		}
		catch (bh.gov.cio.crs.util.exception.ApplicationException e)
		{
			e.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getAddressesInfoByBlockAndRoad(Integer, Integer) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getAddressesInfoByBlockAndRoad(Integer, Integer) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		}
		if (logger.isDebugEnabled())
		{
			logger.debug("getAddressesInfoByBlockAndRoad(Integer, Integer) - start");
		}

		return returnAddressList;
	}

	@Override
	@Secured(
	{ "ROLE_getAddressDetails" })
	@WebMethod(operationName = "getAddressInfo")
	public List<AddressSearchInfoDTO> getAddressInfo(SecurityTagObject security, Integer buildingNumber, Integer roadNumber, Integer blockNumber)
			throws ApplicationExceptionInfo
	{

		List<AddressSearchInfoDTO> addressDTO = new ArrayList<AddressSearchInfoDTO>();
		;

		try
		{

			List<Address> addressList = getCrsService().getAddressServiceRef().searchByAddressFields(null, buildingNumber, null, roadNumber,
					blockNumber);

			if (addressList.size() == 0)
			{
				throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
			}
			Collections.sort(addressList);
			if (addressList != null)
			{
				if (logger.isDebugEnabled())
				{
					logger.error("Address size List: " + addressList.size());
				}

				for (final Address address : addressList)
				{
					AddressOwnerDTO addressOwnerDTO = new AddressOwnerDTO();
					List<AddressOwner> addressOwnerList = getCrsService().getAddressServiceRef().getAddressOwner(address.getAddressSn());
					List<AddressOwnerDTO> AddressOwnersList = new ArrayList<AddressOwnerDTO>();

					for (final AddressOwner AddressOwner : addressOwnerList)
					{
						addressOwnerDTO.setOwnerNumber(AddressOwner.getAddressOwnerNumber());
						addressOwnerDTO.setOwnerType(AddressOwner.getAddressOwnerType());
						AddressOwnersList.add(addressOwnerDTO);

					}

					addressDTO.add(new AddressSearchInfoDTO(address.getBlockNumber(), address.getBlockNameArabic(), address.getBuildingNumber(),
							address.getNameAlphaEnglish(), address.getNameAlphaArabic(), address.getBuildingNameArabic(), address
									.getBuildingNameEnglish(), address.getBlockNameEnglish(), address.getRoadNumber(), address.getRoadNameArabic(),
							address.getRoadNameEnglish(), address.getAreaCode(), address.getAreaNameArabic(), address.getAreaNameEnglish(), address
									.getFlatNumber(), address.getRegionNameArabic(), address.getRegionNameEnglish(), address
									.getGovernorateNameArabic(), address.getGovernorateNameEnglish(), address.getBuildingTypeCode(), address
									.getAddressUsageCode(), CRSUtils.getDateStringFromTimeStamp(address.getDateCreated()), AddressOwnersList));

				}

			}
		}

		catch (AddressLoadException e)
		{

			e.printStackTrace();
		}
		catch (bh.gov.cio.crs.util.exception.ApplicationException e)
		{
			e.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getAddressInfo(Integer, Integer,Integer) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getAddressesInfoByBlockAndRoad(Integer, Integer) Error: " + e.getMessage());
			}
			throw new ApplicationExceptionInfo("Address Not found", new ApplicationException("Address Not found"));
		}
		if (logger.isDebugEnabled())
		{
			logger.debug("getAddressInfo(Integer, Integer,Integer) - start");
		}

		return addressDTO;

	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

}
