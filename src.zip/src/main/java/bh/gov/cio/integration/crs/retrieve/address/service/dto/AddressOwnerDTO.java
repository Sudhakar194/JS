package bh.gov.cio.integration.crs.retrieve.address.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "AddressOwner", propOrder =
{ "ownerNumber", "ownerType" })
public class AddressOwnerDTO
{
	private java.lang.Integer ownerNumber;
	private java.lang.String ownerType;

	public AddressOwnerDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public AddressOwnerDTO(Integer ownerNumber, String ownerType)
	{
		super();
		this.ownerNumber = ownerNumber;
		this.ownerType = ownerType;
	}

	public java.lang.Integer getOwnerNumber()
	{
		return ownerNumber;
	}

	public java.lang.String getOwnerType()
	{
		return ownerType;
	}

	public void setOwnerNumber(java.lang.Integer ownerNumber)
	{
		this.ownerNumber = ownerNumber;
	}

	public void setOwnerType(java.lang.String ownerType)
	{
		this.ownerType = ownerType;
	}

}
