package bh.gov.cio.integration.crs.update.lmra;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Employment;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.Sponsor;
import bh.gov.cio.crs.model.support.CRSConstants.EmploymentTerminationReason;
import bh.gov.cio.crs.service.EmploymentService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.update.lmra.dto.UpdateEmploymentDTO;
import bh.gov.cio.integration.crs.update.lmra.service.UpdateEmploymentServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "UpdateEmploymentService", targetNamespace = "http://service.lmra.update.crs.integration.cio.gov.bh/")
public class UpdateEmploymentServiceImpl implements UpdateEmploymentServiceInterface {
	
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(UpdateEmploymentServiceImpl.class);

	

	@Autowired
	private CRSServicesProviderServiceImpl crsService;	
	
	@Autowired
	private ValidationServiceImpl validationUtil;
	
	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}
	
	
	@Override
	@Secured({ "ROLE_updateEmployment" })
	@WebMethod(operationName = "updateEmployment")
	public UpdateEmploymentDTO updateEmployment (SecurityTagObject security,String idNumber,String nationalityCode,Integer employeeCpr,String occupationCode,Integer WpNumber) throws ApplicationExceptionInfo {
	
		UpdateEmploymentDTO updateEmploymentDTO = new UpdateEmploymentDTO();
		final EmploymentService employmentService = getCrsService().getEmploymentServiceRef();
		final PersonService personService = getCrsService().getPersonServiceRef();

		boolean isSponsor = true;
		Integer employerCPR = null;
		Employment employmentInfo = new Employment();
		List<Employment> employeeList = null;
		Sponsor sponsor = new Sponsor();
		
		if (logger.isDebugEnabled()) {
			logger.debug("Employment Info: IDNumber = "
					+ idNumber
					+ " - Employee = "
					+ employeeCpr
					+ " - nationalityCode = "
					+ nationalityCode
					+ " - occupationCode = "
					+ occupationCode);
		}
		try {
			
			// check ID number if it correct and get SN number in the case of GCC number
			if(employeeCpr == null || idNumber == null || nationalityCode == null || occupationCode == null){
				throw new ApplicationExceptionInfo("Employer Number, Nationality Code, employee and occupation code must be entered.",
						new ApplicationException("Employer Number, Nationality Code, employee and occupation code must be entered."));
			}else{
				PersonBasicInfo employeeInfo = crsService.getPersonServiceRef().getPersonBasicInfo(employeeCpr);
				if(employeeInfo == null){
					logger.debug("Employee Number " +employeeCpr+ " is not correct.");
					throw new ApplicationExceptionInfo("Employee Number " +idNumber+ " is not correct.",new ApplicationException("Employee Number is not correct."));
				}
				updateEmploymentDTO.setEmployeeCPR(employeeCpr);
				updateEmploymentDTO.setWpNumber(WpNumber);
				
				try {
//					if ((nationalityCode != null)
//							&& (nationalityCode.equalsIgnoreCase("411")
//									|| nationalityCode.equalsIgnoreCase("430")
//									|| nationalityCode.equalsIgnoreCase("436")
//									|| nationalityCode.equalsIgnoreCase("440")
//									|| nationalityCode.equalsIgnoreCase("441")
//									|| nationalityCode.equalsIgnoreCase("900")
//									|| nationalityCode.equalsIgnoreCase("930")
//								|| nationalityCode.equalsIgnoreCase("940")))
//					{
//						employerCPR = getCrsService().getPersonServiceRef().getGccNationalSn(idNumber,nationalityCode);
//						
//					}else {
//						PersonBasicInfo personInfo = crsService.getPersonServiceRef().getPersonBasicInfo(Integer.parseInt(idNumber));
//						if (personInfo!= null)
//							employerCPR = Integer.parseInt(idNumber);
//						else{
//							logger.debug("Employer Number " +idNumber+ " is not correct.");
//							throw new ApplicationExceptionInfo("Employer Number " +idNumber+ " is not correct.",new ApplicationException("Employer Number is not correct."));
//						}
					employerCPR = validationUtil.getGCCCpr(idNumber, nationalityCode);
				} catch (Exception e) {
					throw new ApplicationExceptionInfo("Employer Number is not correct.",new ApplicationException("Employer Number is not correct."));
				}
				if(isSponsor){
					sponsor.setSponsorNumber(employerCPR);
					sponsor.setSponsorType("P");//person type only
					sponsor.setEndDate(null);
					sponsor.setStartDate(new Date());
					personService.updatePersonSponsor(employeeCpr, sponsor, "LMRA");
					updateEmploymentDTO.setStatus("Updated");
					logger.debug("details for Sponsor  "+ idNumber +" and employee "+ employeeCpr+" is Updated");
				}
				
				employmentInfo.setCprNumber(employeeCpr);
				employmentInfo.setEmployerNumber(employerCPR);
				employmentInfo.setEmployerType("P");//person type only
				employmentInfo.setEndDate(null);
				employmentInfo.setOccupationCode(occupationCode);
				employmentInfo.setOccupationType("1");
				employmentInfo.setStartDate(new Timestamp(Calendar.getInstance().getTime().getTime()));
				employmentInfo.setIsForCard("T");
				employmentInfo.setIsLocked("F");
				
				employeeList = employmentService.getActiveEmployments(employeeCpr);
				//employee with no  active employment record
	    		if(employeeList.size()== 0 || employeeList == null){
	    			employmentService.addEmploymentRecord(employmentInfo, "LMRA");
	    			updateEmploymentDTO.setStatus("Updated");
	    			logger.debug("new employment record added for employee  "+ employeeCpr +" and employer "+ idNumber);
	    		}else{
	    			//String check = "F"; employee with same active employment record
		    		for (Employment employment : employeeList) {
						if(employment.getEmployerNumber().equals(employerCPR) &&
								employment.getCprNumber().equals(employeeCpr)&& employment.getOccupationCode().equals(occupationCode)){
							logger.debug("employee's employment record is exist");
							break;
							
						}else{
							
							if("1".equals(employment.getOccupationType())){
								employmentService.endEmployment(employment.getCprNumber(), employment.getEmployerType(), employment.getEmployerNumber(),
										employment.getOccupationCode(),new Date(),EmploymentTerminationReason.Change ,"LMRA");
								employmentService.addEmploymentRecord(employmentInfo, "LMRA");
								updateEmploymentDTO.setStatus("Updated");
								logger.debug("update employment record  for employee  "+ employeeCpr +" and employer "+ idNumber);
							}
							//check = "T";
						}
					}
	//	    		
	    		}
				}
		} catch (Exception e) {
			updateEmploymentDTO.setStatus("NotUpdated");
			e.printStackTrace();
			throw new ApplicationExceptionInfo("Record is not updated-Employer or employee Number is not correct.",new ApplicationException("Record is not updated-Employer or employee Number is not correct."));
			
		}
		return updateEmploymentDTO;
   }
}