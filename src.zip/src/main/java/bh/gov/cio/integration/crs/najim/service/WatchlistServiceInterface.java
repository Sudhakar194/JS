package bh.gov.cio.integration.crs.najim.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.najim.service.dto.WatchlistDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "WatchlistService", targetNamespace = "http://service.najim.crs.integration.cio.gov.bh/")
public interface WatchlistServiceInterface {
	@WebResult(name = "WatchlistDetails")
	@WebMethod(operationName = "AddToWatchlist")
	WatchlistDTO AddToWatchlist(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber)
			throws ApplicationExceptionInfo;

	@WebResult(name = "WatchlistDetails")
	@WebMethod(operationName = "RemoveFromWatchlist")
	WatchlistDTO RemoveFromWatchlist(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber)
			throws ApplicationExceptionInfo;
}
