package bh.gov.cio.integration.crs.update.family.service.dto;

import java.sql.Timestamp;
import java.util.ArrayList;

public class DivorceDetailsDTO
{

	private Integer				husbandCprNumber;
	private Integer				wifeCprNumber;
	private Integer				ContractType;
	private Timestamp			returnDate;
	private String				divorceType;
	private String				delayedAmount;
	private Timestamp			marriageDivorceDate;
	private Integer				contractNo;
	private Timestamp			contractDate;
	private String				marriageCountry;
	private Timestamp			registrationDate;
	private Integer				prePaidAmount;
	private Integer				husbandNumberOfwives;
	private Integer				husbandNumberOfDivorce;
	private Integer				husbandNumberOfMarriage;
	private String				husbandPreviousMaritalStatus;
	private Integer				wifeNumberOfMarriage;
	private Integer				wifeNumberOfDivorce;
	private String				wifePreviousMaritalStatus;
	private Integer				noOfMaleChildren;
	private Integer				noOfFemaleChildren;
	private ArrayList<String>	errorList;

	public DivorceDetailsDTO()
	{
		super();

	}

	public DivorceDetailsDTO(Integer husbandCprNumber, Integer wifeCprNumber,
			Integer contractType, Timestamp returnDate, String divorceType,
			String delayedAmount, Timestamp marriageDivorceDate,
			Integer contractNo, Timestamp contractDate, String marriageCountry,
			Timestamp registrationDate, Integer prePaidAmount,
			Integer husbandNumberOfwives, Integer husbandNumberOfDivorce,
			Integer husbandNumberOfMarriage,
			String husbandPreviousMaritalStatus, Integer wifeNumberOfMarriage,
			Integer wifeNumberOfDivorce, String wifePreviousMaritalStatus,
			Integer noOfMaleChildren, Integer noOfFemaleChildren,
			ArrayList<String> errorList)
	{
		super();
		this.husbandCprNumber = husbandCprNumber;
		this.wifeCprNumber = wifeCprNumber;
		ContractType = contractType;
		this.returnDate = returnDate;
		this.divorceType = divorceType;
		this.delayedAmount = delayedAmount;
		this.marriageDivorceDate = marriageDivorceDate;
		this.contractNo = contractNo;
		this.contractDate = contractDate;
		this.marriageCountry = marriageCountry;
		this.registrationDate = registrationDate;
		this.prePaidAmount = prePaidAmount;
		this.husbandNumberOfwives = husbandNumberOfwives;
		this.husbandNumberOfDivorce = husbandNumberOfDivorce;
		this.husbandNumberOfMarriage = husbandNumberOfMarriage;
		this.husbandPreviousMaritalStatus = husbandPreviousMaritalStatus;
		this.wifeNumberOfMarriage = wifeNumberOfMarriage;
		this.wifeNumberOfDivorce = wifeNumberOfDivorce;
		this.wifePreviousMaritalStatus = wifePreviousMaritalStatus;
		this.noOfMaleChildren = noOfMaleChildren;
		this.noOfFemaleChildren = noOfFemaleChildren;
		this.errorList = errorList;
	}

	public Timestamp getContractDate()
	{
		return contractDate;
	}

	public Integer getContractNo()
	{
		return contractNo;
	}

	public Integer getContractType()
	{
		return ContractType;
	}

	public String getDelayedAmount()
	{
		return delayedAmount;
	}

	public String getDivorceType()
	{
		return divorceType;
	}

	public ArrayList<String> getErrorList()
	{
		return errorList;
	}

	public Integer getHusbandCprNumber()
	{
		return husbandCprNumber;
	}

	public Integer getHusbandNumberOfDivorce()
	{
		return husbandNumberOfDivorce;
	}

	public Integer getHusbandNumberOfMarriage()
	{
		return husbandNumberOfMarriage;
	}

	public Integer getHusbandNumberOfwives()
	{
		return husbandNumberOfwives;
	}

	public String getHusbandPreviousMaritalStatus()
	{
		return husbandPreviousMaritalStatus;
	}

	public String getMarriageCountry()
	{
		return marriageCountry;
	}

	public Timestamp getMarriageDivorceDate()
	{
		return marriageDivorceDate;
	}

	public Integer getNoOfFemaleChildren()
	{
		return noOfFemaleChildren;
	}

	public Integer getNoOfMaleChildren()
	{
		return noOfMaleChildren;
	}

	public Integer getPrePaidAmount()
	{
		return prePaidAmount;
	}

	public Timestamp getRegistrationDate()
	{
		return registrationDate;
	}

	public Timestamp getReturnDate()
	{
		return returnDate;
	}

	public Integer getWifeCprNumber()
	{
		return wifeCprNumber;
	}

	public Integer getWifeNumberOfDivorce()
	{
		return wifeNumberOfDivorce;
	}

	public Integer getWifeNumberOfMarriage()
	{
		return wifeNumberOfMarriage;
	}

	public String getWifePreviousMaritalStatus()
	{
		return wifePreviousMaritalStatus;
	}

	public void setContractDate(Timestamp contractDate)
	{
		this.contractDate = contractDate;
	}

	public void setContractNo(Integer contractNo)
	{
		this.contractNo = contractNo;
	}

	public void setContractType(Integer contractType)
	{
		ContractType = contractType;
	}

	public void setDelayedAmount(String delayedAmount)
	{
		this.delayedAmount = delayedAmount;
	}

	public void setDivorceType(String divorceType)
	{
		this.divorceType = divorceType;
	}

	public void setErrorList(ArrayList<String> errorList)
	{
		this.errorList = errorList;
	}

	public void setHusbandCprNumber(Integer husbandCprNumber)
	{
		this.husbandCprNumber = husbandCprNumber;
	}

	public void setHusbandNumberOfDivorce(Integer husbandNumberOfDivorce)
	{
		this.husbandNumberOfDivorce = husbandNumberOfDivorce;
	}

	public void setHusbandNumberOfMarriage(Integer husbandNumberOfMarriage)
	{
		this.husbandNumberOfMarriage = husbandNumberOfMarriage;
	}

	public void setHusbandNumberOfwives(Integer husbandNumberOfwives)
	{
		this.husbandNumberOfwives = husbandNumberOfwives;
	}

	public void setHusbandPreviousMaritalStatus(
			String husbandPreviousMaritalStatus)
	{
		this.husbandPreviousMaritalStatus = husbandPreviousMaritalStatus;
	}

	public void setMarriageCountry(String marriageCountry)
	{
		this.marriageCountry = marriageCountry;
	}

	public void setMarriageDivorceDate(Timestamp marriageDivorceDate)
	{
		this.marriageDivorceDate = marriageDivorceDate;
	}

	public void setNoOfFemaleChildren(Integer noOfFemaleChildren)
	{
		this.noOfFemaleChildren = noOfFemaleChildren;
	}

	public void setNoOfMaleChildren(Integer noOfMaleChildren)
	{
		this.noOfMaleChildren = noOfMaleChildren;
	}

	public void setPrePaidAmount(Integer prePaidAmount)
	{
		this.prePaidAmount = prePaidAmount;
	}

	public void setRegistrationDate(Timestamp registrationDate)
	{
		this.registrationDate = registrationDate;
	}

	public void setReturnDate(Timestamp returnDate)
	{
		this.returnDate = returnDate;
	}

	public void setWifeCprNumber(Integer wifeCprNumber)
	{
		this.wifeCprNumber = wifeCprNumber;
	}

	public void setWifeNumberOfDivorce(Integer wifeNumberOfDivorce)
	{
		this.wifeNumberOfDivorce = wifeNumberOfDivorce;
	}

	public void setWifeNumberOfMarriage(Integer wifeNumberOfMarriage)
	{
		this.wifeNumberOfMarriage = wifeNumberOfMarriage;
	}

	public void setWifePreviousMaritalStatus(String wifePreviousMaritalStatus)
	{
		this.wifePreviousMaritalStatus = wifePreviousMaritalStatus;
	}

}
