package bh.gov.cio.integration.crs.lmra.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "DomesticEmployeeRP", propOrder =
{  "permitNumber" , "firstArrivalDate" , "originCountry"
		, "residenceReason" , "issueDate", "expiryDate" , "isNoc"
		, "residenceReasonNameArabic" , "residenceReasonNameEnglish", "isValid"})
public class GetDomesticEmployeeRPDTO
{

	private String 		 permitNumber;
	 
	private Date 		 firstArrivalDate;
		 
	private String 		 originCountry;
		 
	private String 		 residenceReason;
		 
	private Date 		 issueDate;
		 
	private Date 		 expiryDate;
		 
	private String 		 isNoc;
		 
	private String 		 residenceReasonNameArabic;
		 
	private String 		 residenceReasonNameEnglish;

	private String		 isValid;

	
	
	public GetDomesticEmployeeRPDTO() {
		super();
		// TODO Auto-generated constructor stub
	}



	public GetDomesticEmployeeRPDTO(String permitNumber, Date firstArrivalDate,
			String originCountry, String residenceReason, Date issueDate,
			Date expiryDate, String isNoc, String residenceReasonNameArabic,
			String residenceReasonNameEnglish, String isValid) {
		super();
		this.permitNumber = permitNumber;
		this.firstArrivalDate = firstArrivalDate;
		this.originCountry = originCountry;
		this.residenceReason = residenceReason;
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
		this.isNoc = isNoc;
		this.residenceReasonNameArabic = residenceReasonNameArabic;
		this.residenceReasonNameEnglish = residenceReasonNameEnglish;
		this.isValid = isValid;
	}


	@XmlElement(name = "permitNumber", required = true)
	public String getPermitNumber() {
		return permitNumber;
	}



	public void setPermitNumber(String permitNumber) {
		this.permitNumber = permitNumber;
	}


	@XmlElement(name = "firstArrivalDate", required = true)
	public Date getFirstArrivalDate() {
		return firstArrivalDate;
	}



	public void setFirstArrivalDate(Date firstArrivalDate) {
		this.firstArrivalDate = firstArrivalDate;
	}


	@XmlElement(name = "originCountry", required = true)
	public String getOriginCountry() {
		return originCountry;
	}



	public void setOriginCountry(String originCountry) {
		this.originCountry = originCountry;
	}


	@XmlElement(name = "residenceReason", required = true)
	public String getResidenceReason() {
		return residenceReason;
	}



	public void setResidenceReason(String residenceReason) {
		this.residenceReason = residenceReason;
	}


	@XmlElement(name = "issueDate", required = true)
	public Date getIssueDate() {
		return issueDate;
	}



	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}


	@XmlElement(name = "expiryDate", required = true)
	public Date getExpiryDate() {
		return expiryDate;
	}



	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


	@XmlElement(name = "isNoc", required = true)
	public String getIsNoc() {
		return isNoc;
	}



	public void setIsNoc(String isNoc) {
		this.isNoc = isNoc;
	}


	@XmlElement(name = "residenceReasonNameArabic", required = true)
	public String getResidenceReasonNameArabic() {
		return residenceReasonNameArabic;
	}



	public void setResidenceReasonNameArabic(String residenceReasonNameArabic) {
		this.residenceReasonNameArabic = residenceReasonNameArabic;
	}


	@XmlElement(name = "residenceReasonNameEnglish", required = true)
	public String getResidenceReasonNameEnglish() {
		return residenceReasonNameEnglish;
	}



	public void setResidenceReasonNameEnglish(String residenceReasonNameEnglish) {
		this.residenceReasonNameEnglish = residenceReasonNameEnglish;
	}



	@XmlElement(name = "isValid", required = true)
	public String getIsValid() {
		return isValid;
	}



	public void setIsValid(String isValid) {
		this.isValid = isValid;
	}



	
	
	
	
	
	

	
}
