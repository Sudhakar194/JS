package bh.gov.cio.integration.crs.retrieve.address.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "Building", propOrder =
{ "buildingNumber", "buildingAlphaEnglish", "roadNumber","blockNumber" })
public class CheckActiveBuildingDTO
{
	private java.lang.String buildingNumber;
	private java.lang.String buildingAlphaEnglish;
	private java.lang.String roadNumber;
	private java.lang.String blockNumber;

	public CheckActiveBuildingDTO()
	{
		super();
	}

	public CheckActiveBuildingDTO(String buildingNumber, String buildingAlphaEnglish, String roadNumber,String blockNumber) {
		super();
		this.buildingNumber = buildingNumber;
		this.buildingAlphaEnglish = buildingAlphaEnglish;
		this.roadNumber = roadNumber;
		this.blockNumber = blockNumber;
	}

	public java.lang.String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(java.lang.String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public java.lang.String getBuildingAlphaEnglish() {
		return buildingAlphaEnglish;
	}

	public void setBuildingAlphaEnglish(java.lang.String buildingAlphaEnglish) {
		this.buildingAlphaEnglish = buildingAlphaEnglish;
	}

	public java.lang.String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(java.lang.String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public java.lang.String getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(java.lang.String blockNumber) {
		this.blockNumber = blockNumber;
	}


}
