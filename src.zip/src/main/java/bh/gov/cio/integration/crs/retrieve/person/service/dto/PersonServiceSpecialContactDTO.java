package bh.gov.cio.integration.crs.retrieve.person.service.dto;

public class PersonServiceSpecialContactDTO
{
	private String	mailBox, contactPhone, email1, email2, email3, fax,
			faxWork, mobile, phoneWork;

	public PersonServiceSpecialContactDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonServiceSpecialContactDTO(String mailBox, String contactPhone,
			String email1, String email2, String email3, String fax,
			String faxWork, String mobile, String phoneWork)
	{
		super();
		this.mailBox = mailBox != null ? mailBox : "";
		this.contactPhone = contactPhone != null ? contactPhone : "";
		this.email1 = email1 != null ? email1 : "";
		this.email2 = email2 != null ? email2 : "";
		this.email3 = email3 != null ? email3 : "";
		this.fax = fax != null ? fax : "";
		this.faxWork = faxWork != null ? faxWork : "";
		this.mobile = mobile != null ? mobile : "";
		this.phoneWork = phoneWork != null ? phoneWork : "";
	}

	public String getContactPhone()
	{
		return contactPhone;
	}

	public String getEmail1()
	{
		return email1;
	}

	public String getEmail2()
	{
		return email2;
	}

	public String getEmail3()
	{
		return email3;
	}

	public String getFax()
	{
		return fax;
	}

	public String getFaxWork()
	{
		return faxWork;
	}

	public String getMailBox()
	{
		return mailBox;
	}

	public String getMobile()
	{
		return mobile;
	}

	public String getPhoneWork()
	{
		return phoneWork;
	}

	public void setContactPhone(String contactPhone)
	{
		this.contactPhone = contactPhone;
	}

	public void setEmail1(String email1)
	{
		this.email1 = email1;
	}

	public void setEmail2(String email2)
	{
		this.email2 = email2;
	}

	public void setEmail3(String email3)
	{
		this.email3 = email3;
	}

	public void setFax(String fax)
	{
		this.fax = fax;
	}

	public void setFaxWork(String faxWork)
	{
		this.faxWork = faxWork;
	}

	public void setMailBox(String mailBox)
	{
		this.mailBox = mailBox;
	}

	public void setMobile(String mobile)
	{
		this.mobile = mobile;
	}

	public void setPhoneWork(String phoneWork)
	{
		this.phoneWork = phoneWork;
	}

	@Override
	public String toString()
	{
		return "PersonServiceContactDTO [mailBox=" + mailBox
				+ ", contactPhone=" + contactPhone + ", email1=" + email1
				+ ", email2=" + email2 + ", email3=" + email3 + ", fax=" + fax
				+ ", faxWork=" + faxWork + ", mobile=" + mobile
				+ ", phoneWork=" + phoneWork + "]";
	}
}
