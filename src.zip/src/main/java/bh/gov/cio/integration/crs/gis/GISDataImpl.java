package bh.gov.cio.integration.crs.gis;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.cr.CRDetails;
import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.unit.UnitInfo;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.crs.service.UnitService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.gis.service.GISDataInterface;
import bh.gov.cio.integration.crs.gis.service.dto.CRAddressInfoDTO;
import bh.gov.cio.integration.crs.gis.service.dto.CRBasicInfoWithAddressDTO;
import bh.gov.cio.integration.crs.gis.service.dto.GISPersonDataDTO;
import bh.gov.cio.integration.crs.gis.service.dto.PersonAddressInfoDTO;
import bh.gov.cio.integration.crs.gis.service.dto.UnitAddressInfoDTO;
import bh.gov.cio.integration.crs.gis.service.dto.UnitBasicInfoWithAddressDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


@WebService(name = "GISDataService", targetNamespace = "http://service.gis.crs.integration.cio.gov.bh/")
public class GISDataImpl implements GISDataInterface {

	
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(GISDataImpl.class);
	
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	
	@Autowired
	private ValidationServiceImpl validationUtil;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}
	
	
	@Override
	@Secured(
	{ "ROLE_checkPersonData" })
	@WebMethod(operationName = "checkPersonData")
	public GISPersonDataDTO checkPersonData(SecurityTagObject security,
			Integer cprNumber) throws ApplicationExceptionInfo {
		GISPersonDataDTO  result = new GISPersonDataDTO();		
		if (logger.isDebugEnabled())
		{
			logger.debug("checkPersonData(Integer) - start");
		}
		PersonService personService = getCrsService().getPersonServiceRef();

		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		
		try {
			final PersonBasicInfo personBasicInfo = personService.getPersonBasicInfo(cprNumber);
//			final List<Address> personAddressList = getCrsService().getAddressServiceRef().getAddressDetails(cprNumber);
//			Address personAddress = new Address();
			
//			if(personAddressList != null && personAddressList.size() > 0){
//				personAddress = personAddressList.get(0);
//			}
//			PersonAddressInfoDTO personAddressInfoDTO = new PersonAddressInfoDTO(personAddress.getFlatNumber()+"",personAddress.getBuildingNumber()+"",personAddress.getNameAlphaEnglish(),personAddress.getRoadNumber()+"",personAddress.getBlockNumber()+""); 
			result = new GISPersonDataDTO(personBasicInfo.getArabicName(), personBasicInfo.getEnglishName(), null);//personAddressInfoDTO);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("CPR Info Not found",
					new ApplicationException(e.getMessage()));
		}
		
		return result;
	}

	
	@Override
	@Secured({ "ROLE_getUnitDetailsWithAddress" })
	@WebMethod(operationName = "GetUnitBasicInfoWithAddress")
	public UnitBasicInfoWithAddressDTO getUnitBasicInfoWithAddress(SecurityTagObject security, Integer unitNumber)
			throws ApplicationExceptionInfo {
		UnitService us = getCrsService().getUnitServiceRef();
		UnitInfo unitBasicInfo = null;
		UnitAddressInfoDTO unitAddress = null;
		List<bh.gov.cio.crs.model.unit.UnitAddress> addresses = null;
		String unitArabicName = "";
		String unitEnglishName = "";
		try {
			unitBasicInfo = us.getUnitBasicInfo(unitNumber);
			unitArabicName = unitBasicInfo!= null ? unitBasicInfo.getUnitArabicName():"";
			unitEnglishName = unitBasicInfo != null ? unitBasicInfo.getUnitEnglishName() : "";
			addresses = us.getUnitAddresses(unitNumber);
		} catch (final Exception exception) {
			exception.printStackTrace();
			throw new ApplicationExceptionInfo("Error Fetching Unit Details", new ApplicationException(exception.getMessage()));
			
		}
		if (addresses != null) {
			final bh.gov.cio.crs.model.unit.UnitAddress returnedAddressRow = addresses.get(addresses.size() - 1);
			unitAddress = new UnitAddressInfoDTO(returnedAddressRow.getBlockNumber(),
					returnedAddressRow.getBuildingNumber(), returnedAddressRow.getAlpha(),
					returnedAddressRow.getRoadNumber(), returnedAddressRow.getFlatNumber());
		}
		UnitBasicInfoWithAddressDTO unitBasicInfoWithAddressDTO = new UnitBasicInfoWithAddressDTO(unitNumber,unitArabicName,unitEnglishName,unitAddress);

		return unitBasicInfoWithAddressDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getCRBasicInfoWithAddress" })
	@WebMethod(operationName = "getCRBasicInfoWithAddress")
	public CRBasicInfoWithAddressDTO getCRBasicInfoWithAddress(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security, @WebParam(name = "crNumber") @XmlElement(required = true) Integer crNumber)
			throws ApplicationExceptionInfo{
		CRBasicInfoWithAddressDTO cRServiceBasicInfoWithAddressDTO = new CRBasicInfoWithAddressDTO();
		UnitService unitService = getCrsService().getUnitServiceRef();

		try
		{
			CRDetails crDetails = unitService.getCrBasicInfo(crNumber);
			if("F".equals(crDetails.getIsActive())){
				throw new ApplicationExceptionInfo("CR is canceled", new ApplicationException("CR is canceled"));
			}

			String roadNumber = (crDetails.getRoad() != null) ? crDetails.getRoad() + "" : null;
			String blockNumber = (crDetails.getBlock() != null) ? crDetails.getBlock() + "" : null;
			String flatNumber = (crDetails.getFlat() != null) ? crDetails.getFlat() + "" : null;
			String buildingNumber = (crDetails.getBuilding() != null) ? crDetails.getBuilding() + "" : null;
			String nameAlphaEnglish = (crDetails.getAlpha() != null) ? crDetails.getAlpha() + "" : null;
			CRAddressInfoDTO cRAddressInfoDTO= new CRAddressInfoDTO(flatNumber, buildingNumber, nameAlphaEnglish, roadNumber, blockNumber);
			cRServiceBasicInfoWithAddressDTO = new CRBasicInfoWithAddressDTO(crNumber,crDetails.getCrArabicName(),crDetails.getCrEnglishName(),cRAddressInfoDTO);
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error(" Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Fetching CR Details", new ApplicationException(exception.getMessage()));
		}
			
			return cRServiceBasicInfoWithAddressDTO;
	}
	
	
}
