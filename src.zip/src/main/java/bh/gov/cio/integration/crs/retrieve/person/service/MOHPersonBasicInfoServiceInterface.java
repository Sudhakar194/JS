package bh.gov.cio.integration.crs.retrieve.person.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.MOHPersonBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.MOHPersonInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "MOHPersonBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface MOHPersonBasicInfoServiceInterface
{

//	@WebResult(name = "MOHPersonBasicInformation")
//	@WebMethod(operationName = "getAllPersonBasicInfo")
//	MOHPersonBasicInfoDTO getAllPersonBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
//			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;
//
	@WebResult(name = "MOHPersonBasicInformation")
	@WebMethod(operationName = "getPersonBasicInfo")
	MOHPersonBasicInfoDTO getPersonBasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "MOHPersonInformation")
	@WebMethod(operationName = "checkPersonInfo")
	MOHPersonInfoDTO checkPersonInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "MOHPersonBasicInformation")
	@WebMethod(operationName = "getPersonBasicInfoByCPR")
	MOHPersonBasicInfoDTO getPersonBasicInfoByCPR(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

//	/* Person information for financial support (MOSD) */
//	@WebResult(name = "MOHPersonBasicInformation")
//	@WebMethod(operationName = "getPersonInfoForFS")
//	PersonFinancialSupportInfoDTO getPersonInfoForFS(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
//			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
