package bh.gov.cio.integration.crs.lmra.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.lmra.dto.IsBahrainiSpouseDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsBahrainiSpouseService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public interface IsBahrainiSpouseServiceInterface
{
	@WebResult(name = "SpouseFlags")
	@WebMethod(operationName = "IsBahrainiSpouse")
	IsBahrainiSpouseDTO IsBahrainiSpouse(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
