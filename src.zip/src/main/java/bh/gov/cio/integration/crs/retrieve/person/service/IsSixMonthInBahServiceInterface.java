package bh.gov.cio.integration.crs.retrieve.person.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsSixMonthInBahService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface IsSixMonthInBahServiceInterface
{

	@WebResult(name = "IsSixMonthInBah")
	@WebMethod(operationName = "getIsSixMonthInBah")
	Boolean getIsSixMonthInBah(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
