package bh.gov.cio.integration.crs.retrieve.address.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "RoadSearchInfo", propOrder =
{"roadNumber", "roadNameArabic", "roadNameEnglish","blockNumber","areaNameArabic","areaNameEnglish"})
public class RoadSearchInfoDTO
{



	private java.lang.Integer roadNumber;
	private java.lang.String roadNameArabic;
	private java.lang.String roadNameEnglish;
	private java.lang.Integer blockNumber;
	private java.lang.String areaNameArabic;
	private java.lang.String areaNameEnglish;

	public RoadSearchInfoDTO()
	{
		super();
		// TODO Auto-generated constructor stub
	}



	public RoadSearchInfoDTO(Integer roadNumber, String roadNameArabic,
			String roadNameEnglish,Integer blockNumber, String areaNameArabic,
			String areaNameEnglish) {
		super();
		this.roadNumber = roadNumber != null ? roadNumber : 0;
		this.roadNameArabic = roadNameArabic != null ? roadNameArabic : "";
		this.roadNameEnglish = roadNameEnglish != null ? roadNameEnglish : "";
		this.blockNumber = blockNumber != null ? blockNumber : 0;
		this.areaNameArabic = areaNameArabic != null ? areaNameArabic : "";
		this.areaNameEnglish = areaNameEnglish != null ? areaNameEnglish : "";
	}




	public java.lang.String getRoadNameArabic()
	{
		return roadNameArabic;
	}

	public java.lang.String getRoadNameEnglish()
	{
		return roadNameEnglish;
	}

	public java.lang.Integer getRoadNumber()
	{
		return roadNumber;
	}

	public java.lang.Integer getBlockNumber() {
		return blockNumber;
	}

	public java.lang.String getAreaNameArabic() {
		return areaNameArabic;
	}

	public java.lang.String getAreaNameEnglish() {
		return areaNameEnglish;
	}



	public void setRoadNameArabic(java.lang.String roadNameArabic)
	{
		this.roadNameArabic = roadNameArabic;
	}

	public void setRoadNameEnglish(java.lang.String roadNameEnglish)
	{
		this.roadNameEnglish = roadNameEnglish;
	}

	public void setRoadNumber(java.lang.Integer roadNumber)
	{
		this.roadNumber = roadNumber;
	}



	public void setBlockNumber(java.lang.Integer blockNumber) {
		this.blockNumber = blockNumber;
	}



	public void setAreaNameArabic(java.lang.String areaNameArabic) {
		this.areaNameArabic = areaNameArabic;
	}



	public void setAreaNameEnglish(java.lang.String areaNameEnglish) {
		this.areaNameEnglish = areaNameEnglish;
	}


}
