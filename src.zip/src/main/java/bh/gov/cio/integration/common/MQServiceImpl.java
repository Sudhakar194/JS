package bh.gov.cio.integration.common;

import java.io.ByteArrayOutputStream;
import java.util.Properties;

import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.mq.MQC;
import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;

@WebService
public class MQServiceImpl
{
	/**
	 * Logger for this class
	 */
	private static final Logger	logger			= LoggerFactory.getLogger(MQServiceImpl.class);

	private Properties			properties		= new Properties();
	private MQPutMessageOptions	pmo;
	private MQGetMessageOptions	gmo;
	int							waitForMsgRply	= 1000;
	int							openOptions		= MQC.MQOO_OUTPUT | MQC.MQOO_INQUIRE;
	int							receiverOptions	= MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_FAIL_IF_QUIESCING | MQC.MQOO_SAVE_ALL_CONTEXT;

	private MQQueueManager initializeSender(String queueManagerHost, String queueManagerPort, String queueManagerCCSID, String queueManagerChannel,
			String senderQueueManagerName, String senderQueueName, String replyTimeout)
	{
		MQQueueManager senderQueueManager = null;
		try
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("initializeSender() - ************" + queueManagerHost);
			}
			properties.put("port", queueManagerPort);
			properties.put("CCSID", queueManagerCCSID);
			properties.put("hostname", queueManagerHost);// queueManagerHost());
			properties.put("channel", queueManagerChannel);
			if (logger.isDebugEnabled())
			{
				logger.debug("initializeSender()" + this.toString());
			}
			MQEnvironment.hostname = queueManagerHost;// queueManagerHost(); // host to connect to
			MQEnvironment.port = Integer.valueOf(queueManagerPort); // port to connect to. If not set,
			// this defaults to 1414 for WebSphere MQ
			// client connections.
			MQEnvironment.channel = queueManagerChannel; // the CASE-SENSITIVE name of the SVRCONN
			MQEnvironment.CCSID = Integer.valueOf(queueManagerCCSID); // the CASE-SENSITIVE name of the SVRCONN
			// channel on the queue manager
			senderQueueManager = new MQQueueManager(senderQueueManagerName);

			// senderQueueManager = new MQQueueManager(getSenderQueueManagerName(),properties);
			// /senderQueueManager = new MQQueueManager("DWMB_QM",properties);

			pmo = new MQPutMessageOptions();
			pmo.options = MQC.MQPMO_SYNCPOINT | MQC.MQGMO_FAIL_IF_QUIESCING;

		}
		catch (MQException ex)
		{
			// logger.error("initializeSender()", ex);
			if (ex.reasonCode == 2162)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("initialize() - queue manager " + senderQueueName + " is stopped");
				}
			}
			if (ex.reasonCode == 2009)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("initializeSender() - connection to queue manager " + senderQueueName + " is broken");
				}
			}
			if (ex.reasonCode == 2063)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("initializeSender() - connection to queue manager " + senderQueueName + " is Access Denied");
				}
			}
			if (logger.isDebugEnabled())
			{
				logger.debug("initializeSender() - An MQSeries error occurred on put message: Completion code " + ex.completionCode + " Reason code "
						+ ex.reasonCode);
			}
		}
		catch (Exception e)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("initializeSender() - An General error occurred on put message:" + e.getMessage());
			}
		}
		return senderQueueManager;
	}

	private MQQueueManager initializeReceiver(String queueManagerHost, String queueManagerPort, String queueManagerCCSID, String queueManagerChannel,
			String receiverQueueManagerName, String receiverQueueName, String replyTimeout)
	{
		MQQueueManager receiverQueueManager = null;
		try
		{
			properties.put("port", queueManagerPort);
			properties.put("CCSID", queueManagerCCSID);
			properties.put("hostname", queueManagerHost);
			properties.put("channel", queueManagerChannel);
			if (logger.isDebugEnabled())
			{
				logger.debug("initializeReceiver()" + this.toString());
			}
			MQEnvironment.hostname = queueManagerHost; // host to connect to
			MQEnvironment.port = Integer.valueOf(queueManagerPort); // port to connect to. If not set,
			// this defaults to 1414 for WebSphere MQ
			// client connections.
			MQEnvironment.channel = queueManagerChannel; // the CASE-SENSITIVE name of the SVRCONN
			MQEnvironment.CCSID = Integer.valueOf(queueManagerCCSID); // the CASE-SENSITIVE name of the SVRCONN
			// channel on the queue manager
			receiverQueueManager = new MQQueueManager(receiverQueueManagerName);
			// receiverQueueManager = new MQQueueManager(getSenderQueueManagerName(),properties);

			gmo = new MQGetMessageOptions();
			gmo.options = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQGMO_WAIT | MQC.MQGMO_CONVERT | MQC.MQGMO_FAIL_IF_QUIESCING;
			gmo.matchOptions = MQC.MQMO_MATCH_CORREL_ID;

			waitForMsgRply = Integer.valueOf(replyTimeout).intValue();
			if (waitForMsgRply > -1)
			{
				gmo.waitInterval = waitForMsgRply;
			}
			else
			{
				gmo.waitInterval = MQC.MQWI_UNLIMITED;
			}

		}
		catch (MQException ex)
		{
			// logger.error("initializeReceiver()", ex);
			if (ex.reasonCode == 2162)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("initializeReceiver() - queue manager " + receiverQueueManagerName + " is stopped");
				}
			}
			if (ex.reasonCode == 2009)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("initializeReceiver() - connection to queue manager " + receiverQueueName + " is broken");
				}
			}
			if (logger.isDebugEnabled())
			{
				logger.debug("initializeReceiver() - An MQSeries error occurred on put message: Completion code " + ex.completionCode
						+ " Reason code " + ex.reasonCode);
			}
		}
		catch (Exception e)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("initializeReceiver()" + e.getMessage());
			}
		}
		return receiverQueueManager;
	}

	private MQQueueManager getSynchSenderQueue(String queueManagerHost, String queueManagerPort, String queueManagerCCSID,
			String queueManagerChannel, String senderQueueManagerName, String senderQueueName, String replyTimeout)
	{
		try
		{
			// if (senderQueueManager == null)
			// {
			MQQueueManager senderQueueManager = initializeSender(queueManagerHost, queueManagerPort, queueManagerCCSID, queueManagerChannel,
					senderQueueManagerName, senderQueueName, replyTimeout);
			// }

			return senderQueueManager;

		}
		catch (Exception e)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getSynchSenderQueue()" + e.getMessage());
			}
			// logger.error("getSynchSenderQueue()", e);
			return null;
			// throw new ApplicationException(e.getMessage());
		}
	}

	private MQQueueManager getSynchRevieverQueue(String queueManagerHost, String queueManagerPort, String queueManagerCCSID,
			String queueManagerChannel, String receiverQueueManagerName, String receiverQueueName, String replyTimeout) // throws ApplicationException
	{
		try
		{
			// if (receiverQueueManager == null)
			// {
			MQQueueManager receiverQueueManager = initializeReceiver(queueManagerHost, queueManagerPort, queueManagerCCSID, queueManagerChannel,
					receiverQueueManagerName, receiverQueueName, replyTimeout);
			// }

			return receiverQueueManager;
		}
		catch (Exception e)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("getSynchRevieverQueue()" + e.getMessage());
			}
			return null;
			// throw new ApplicationException(e.getMessage());
		}
	}
//for Egate
	private byte[] sendMessageAndGetMessageID(String requestMessage, String correlationID, String queueManagerHost, String queueManagerPort,
			String queueManagerCCSID, String queueManagerChannel, String senderQueueManagerName, String senderQueueName, String replyTimeout)
	{
		byte[] msg = requestMessage.getBytes();
		if (logger.isDebugEnabled())
		{
			logger.debug("sendMessage(byte[], String) - start");
		}

		byte[] messageId = null;
		try
		{
			MQMessage objMessage = new MQMessage();
			objMessage.persistence = 0;
			objMessage.format = MQC.MQFMT_STRING;

			ByteArrayOutputStream baos = new ByteArrayOutputStream(msg.length);
			baos.write(msg);
			objMessage.characterSet = 1208;
			objMessage.correlationId = correlationID.getBytes();
			objMessage.write(baos.toByteArray());

			MQQueueManager senderQueueManager = getSynchSenderQueue(queueManagerHost, queueManagerPort, queueManagerCCSID, queueManagerChannel,
					senderQueueManagerName, senderQueueName, replyTimeout);
			MQQueue senderQueue = senderQueueManager.accessQueue(senderQueueName, openOptions, null, null, null);

			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(requestMessage = " + requestMessage + ", correlationID = " + correlationID + ", queueManagerHost = "
						+ queueManagerHost + ", queueManagerPort = " + queueManagerPort + ", queueManagerCCSID = " + queueManagerCCSID
						+ ", queueManagerChannel = " + queueManagerChannel + ", senderQueueManagerName = " + senderQueueManagerName
						+ ", senderQueueName = " + senderQueueName + ", replyTimeout = " + replyTimeout + ")");
			}

			int intMaximumDepth = senderQueue.getMaximumDepth();
			int intCurrentDepth = senderQueue.getCurrentDepth();

			if (intCurrentDepth >= intMaximumDepth)
			{
				if (logger.isDebugEnabled())
				{
					logger.error("sendMessage(byte[], String) - intCurrentDepth: Queue is full");
				}
			}

			senderQueue.put(objMessage, pmo);
			messageId = objMessage.messageId;
			logger.debug("Message ID='");
			for (int i = 0; i < objMessage.messageId.length; i++)
			{
				logger.debug(objMessage.messageId[i]+"");
			}
			logger.debug("'");
			senderQueue.close();
			senderQueueManager.commit();
			senderQueueManager.disconnect();
			senderQueue = null;
			senderQueueManager = null;
		}
		catch (MQException ex)
		{
			if (ex.reasonCode == 2162)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("sendMessage(byte[]) - queue manager " + senderQueueManagerName + " is stopped");
				}
			}
			if (ex.reasonCode == 2009)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("sendMessage(byte[]) - connection to queue manager " + senderQueueManagerName + " is broken");
				}
			}
			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(byte[]) - An MQSeries error occurred on put message: Completion code " + ex.completionCode
						+ " Reason code " + ex.reasonCode);
			}
			// throw new ApplicationException("An MQSeries error occurred on put message: Completion code " + ex.completionCode + " Reason code " + ex.reasonCode);
		}
		catch (java.io.IOException ex)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(byte[]) - An error occurred while writing to the message buffer: " + ex);
			}
			// throw new ApplicationException("An MQSeries error occurred while writing to the message buffer: " + ex);
		}
		catch (Exception ex)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(byte[]) - A general error occurred : " + ex);
			}
			// throw new ApplicationException("An MQSeries error occurred while writing to the message buffer: " + ex);
		}

		if (logger.isDebugEnabled())
		{
			logger.debug("sendMessage(byte[], String) - end");
		}
		return messageId;//correlationID.getBytes();
	}
	//For Najim
	private byte[] sendMessageAndGetCorrelationID(String requestMessage, String correlationID, String queueManagerHost, String queueManagerPort,
			String queueManagerCCSID, String queueManagerChannel, String senderQueueManagerName, String senderQueueName, String replyTimeout)
	{
		byte[] msg = requestMessage.getBytes();
		if (logger.isDebugEnabled())
		{
			logger.debug("sendMessage(byte[], String) - start");
		}

		byte[] messageId = null;
		try
		{
			MQMessage objMessage = new MQMessage();
			objMessage.persistence = 0;
			objMessage.format = MQC.MQFMT_STRING;

			ByteArrayOutputStream baos = new ByteArrayOutputStream(msg.length);
			baos.write(msg);
			objMessage.characterSet = 1208;
			objMessage.correlationId = correlationID.getBytes();
			objMessage.write(baos.toByteArray());

			MQQueueManager senderQueueManager = getSynchSenderQueue(queueManagerHost, queueManagerPort, queueManagerCCSID, queueManagerChannel,
					senderQueueManagerName, senderQueueName, replyTimeout);
			MQQueue senderQueue = senderQueueManager.accessQueue(senderQueueName, openOptions, null, null, null);

			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(requestMessage = " + requestMessage + ", correlationID = " + correlationID + ", queueManagerHost = "
						+ queueManagerHost + ", queueManagerPort = " + queueManagerPort + ", queueManagerCCSID = " + queueManagerCCSID
						+ ", queueManagerChannel = " + queueManagerChannel + ", senderQueueManagerName = " + senderQueueManagerName
						+ ", senderQueueName = " + senderQueueName + ", replyTimeout = " + replyTimeout + ")");
			}

			int intMaximumDepth = senderQueue.getMaximumDepth();
			int intCurrentDepth = senderQueue.getCurrentDepth();

			if (intCurrentDepth >= intMaximumDepth)
			{
				if (logger.isDebugEnabled())
				{
					logger.error("sendMessage(byte[], String) - intCurrentDepth: Queue is full");
				}
			}

			senderQueue.put(objMessage, pmo);
			messageId = objMessage.correlationId;//messageId;
			logger.debug("Message ID='");
			for (int i = 0; i < objMessage.messageId.length; i++)
			{
				logger.debug(objMessage.messageId[i]+"");
			}
			logger.debug("'");
			senderQueue.close();
			senderQueueManager.commit();
			senderQueueManager.disconnect();
			senderQueue = null;
			senderQueueManager = null;
		}
		catch (MQException ex)
		{
			if (ex.reasonCode == 2162)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("sendMessage(byte[]) - queue manager " + senderQueueManagerName + " is stopped");
				}
			}
			if (ex.reasonCode == 2009)
			{
				if (logger.isDebugEnabled())
				{
					logger.debug("sendMessage(byte[]) - connection to queue manager " + senderQueueManagerName + " is broken");
				}
			}
			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(byte[]) - An MQSeries error occurred on put message: Completion code " + ex.completionCode
						+ " Reason code " + ex.reasonCode);
			}
			// throw new ApplicationException("An MQSeries error occurred on put message: Completion code " + ex.completionCode + " Reason code " + ex.reasonCode);
		}
		catch (java.io.IOException ex)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(byte[]) - An error occurred while writing to the message buffer: " + ex);
			}
			// throw new ApplicationException("An MQSeries error occurred while writing to the message buffer: " + ex);
		}
		catch (Exception ex)
		{
			if (logger.isDebugEnabled())
			{
				logger.debug("sendMessage(byte[]) - A general error occurred : " + ex);
			}
			// throw new ApplicationException("An MQSeries error occurred while writing to the message buffer: " + ex);
		}

		if (logger.isDebugEnabled())
		{
			logger.debug("sendMessage(byte[], String) - end");
		}
		return messageId;//correlationID.getBytes();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.cio.basic.MQServiceInterface#getCorrelatedMessage(byte[])
	 */
	private String getCorrelatedMessage(byte correlationID[], String queueManagerHost, String queueManagerPort, String queueManagerCCSID,
			String queueManagerChannel, String receiverQueueManagerName, String receiverQueueName, String replyTimeout)
	{
		MQMessage objRetrievedMessage = null;
		String reply = "";
		try
		{

			MQQueueManager receiverMQQueueManager = getSynchRevieverQueue(queueManagerHost, queueManagerPort, queueManagerCCSID, queueManagerChannel,
					receiverQueueManagerName, receiverQueueName, replyTimeout);
			MQQueue receiverQueue = receiverMQQueueManager.accessQueue(receiverQueueName, receiverOptions, null, null, null);

			if (logger.isDebugEnabled())
			{
				logger.debug("getCorrelatedMessage(correlationID = " + correlationID + ", queueManagerHost = " + queueManagerHost
						+ ", queueManagerPort = " + queueManagerPort + ", queueManagerCCSID = " + queueManagerCCSID + ", queueManagerChannel = "
						+ queueManagerChannel + ", receiverQueueManagerName = " + receiverQueueManagerName + ", receiverQueueName = "
						+ receiverQueueName + ", replyTimeout = " + replyTimeout + ")");
			}

			//
			// if (receiverQueue == null || !receiverQueue.isOpen())
			// {
			// receiverMQQueueManager
			//
			// receiverQueue =
			// }
			objRetrievedMessage = new MQMessage();
			objRetrievedMessage.characterSet = 1208;
			objRetrievedMessage.correlationId = correlationID;
			// objRetrievedMessage.messageId = pstrCorelId;
			for (int i = 0; i < objRetrievedMessage.correlationId.length; i++)
			{
				logger.debug(objRetrievedMessage.correlationId[i]+"");
			}

			boolean done = false;
			int count = 0;
			while (!done)
			{
				if (count == 30)
				{
					if (logger.isDebugEnabled())
					{
						logger.debug("getCorrelatedMessage(byte) - time out");
					}
					break;
				}
				try
				{
					receiverQueue.get(objRetrievedMessage, gmo);

					done = true;
					if (logger.isDebugEnabled())
					{
						logger.debug("getCorrelatedMessage(byte) - A message was gotten successfully.");
					}
				}
				catch (MQException mqE)
				{
					if (logger.isDebugEnabled())
					{
						logger.debug("getCorrelatedMessage(byte) - reply msg not available ");
					}
					done = false;
					try
					{
						Thread.sleep(waitForMsgRply);
						count++;
					}
					catch (Exception e)
					{
						logger.error("getCorrelatedMessage(byte)", e);
					}
				}
			}

			receiverQueue.close();
			receiverMQQueueManager.disconnect();
			receiverQueue = null;
			receiverMQQueueManager = null;
			if (objRetrievedMessage != null)
			{
				byte[] bs = new byte[objRetrievedMessage.getTotalMessageLength()];
				objRetrievedMessage.readFully(bs);
				reply = new String(bs, "UTF8");
			}
		}
		catch (Exception e)
		{
			// logger.error("getCorrelatedMessage(byte)", e);
			if (logger.isDebugEnabled())
			{
				logger.debug("getCorrelatedMessage(byte)" + e.getMessage());
			}
			objRetrievedMessage = null;
			// throw new ApplicationException("MQSeries error: " + e.getMessage());
		}

		return reply;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see bh.gov.cio.integration.common.MQServiceInterface#getResponseMsgForRequest(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	//For Najim
	public String getResponseMsgForRequestByCorrelationID(String requestMessage, String queueManagerHost, String queueManagerPort, String queueManagerCCSID,
			String queueManagerChannel, String senderQueueManagerName, String receiverQueueManagerName, String senderQueueName,
			String receiverQueueName, String replyTimeout)
	{
		String responseMessage = "";
		try
		{
			byte[] correlationID = sendMessageAndGetCorrelationID(requestMessage, DateServiceImpl.getCurrentDateTimeMilliSocond(), queueManagerHost, queueManagerPort,
					queueManagerCCSID, queueManagerChannel, senderQueueManagerName, senderQueueName, replyTimeout);

			responseMessage = getCorrelatedMessage(correlationID, queueManagerHost, queueManagerPort, queueManagerCCSID, queueManagerChannel,
					receiverQueueManagerName, receiverQueueName, replyTimeout);
			if (logger.isDebugEnabled())
			{
				logger.debug("MQService() - Request is :" + requestMessage);
				logger.debug("MQService() - Response is :" + responseMessage);

			}

			logger.debug("success response= " + responseMessage);
			return (responseMessage);
		}
		catch (Exception e)
		{
			logger.error("getResponseMsgForRequest(String, String, String, String, String, String, String, String, String)", e);
			return ("");
		}
	}

	//For Egate
	public String getResponseMsgForRequestByMessageID(String requestMessage, String queueManagerHost, String queueManagerPort, String queueManagerCCSID,
			String queueManagerChannel, String senderQueueManagerName, String receiverQueueManagerName, String senderQueueName,
			String receiverQueueName, String replyTimeout)
	{
		String responseMessage = "";
		try
		{
			byte[] correlationID = sendMessageAndGetMessageID(requestMessage, DateServiceImpl.getCurrentDateTimeMilliSocond(), queueManagerHost, queueManagerPort,
					queueManagerCCSID, queueManagerChannel, senderQueueManagerName, senderQueueName, replyTimeout);

			responseMessage = getCorrelatedMessage(correlationID, queueManagerHost, queueManagerPort, queueManagerCCSID, queueManagerChannel,
					receiverQueueManagerName, receiverQueueName, replyTimeout);
			if (logger.isDebugEnabled())
			{
				logger.debug("MQService() - Request is :" + requestMessage);
				logger.debug("MQService() - Response is :" + responseMessage);

			}

			logger.debug("success response= " + responseMessage);
			return (responseMessage);
		}
		catch (Exception e)
		{
			logger.error("getResponseMsgForRequest(String, String, String, String, String, String, String, String, String)", e);
			return ("");
		}
	}
	
}
