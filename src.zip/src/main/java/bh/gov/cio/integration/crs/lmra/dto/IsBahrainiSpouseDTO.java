package bh.gov.cio.integration.crs.lmra.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "WifeFalgs", propOrder =
{ "cprNumber", "haveChildren", "isBahrainiWidow", "isBahrainiSpouse" })
public class IsBahrainiSpouseDTO
{

	private String cprNumber;
	private String isBahrainiSpouse;
	private String isBahrainiWidow;
	private String haveChildren;

	public IsBahrainiSpouseDTO()
	{
		super();

	}

	public IsBahrainiSpouseDTO(String cprNumber, String isBahrainiSpouse, String isBahrainiWidow, String haveChildren)
	{
		super();
		this.cprNumber = cprNumber;
		this.isBahrainiSpouse = isBahrainiSpouse;
		this.isBahrainiWidow = isBahrainiWidow;
		this.haveChildren = haveChildren;
	}

	@XmlElement(name = "cprNumber", required = true)
	public String getCprNumber()
	{
		return cprNumber;
	}

	@XmlElement(name = "haveChildren", required = true)
	public String getHaveChildren()
	{
		return haveChildren;
	}

	@XmlElement(name = "isBahrainiWidow", required = true)
	public String getIsBahrainiWidow()
	{
		return isBahrainiWidow;
	}

	@XmlElement(name = "isBahrainiSpouse", required = true)
	public String getIsBahrainiSpouse() {
		return isBahrainiSpouse;
	}
	
	
	public void setCprNumber(String cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setHaveChildren(String haveChildren)
	{
		this.haveChildren = haveChildren;
	}

	public void setIsBahrainiWidow(String isBahrainiWidow)
	{
		this.isBahrainiWidow = isBahrainiWidow;
	}

	public void setIsBahrainiSpouse(String isBahrainiSpouse) {
		this.isBahrainiSpouse = isBahrainiSpouse;
	}



}
