package bh.gov.cio.integration.crs.retrieve.nhi.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;

@XmlType(name = "NHIBasicInfo", propOrder =
{		"idNumber", "personFullNameArabic","personFullNameEnglish",
		"nationality","isAlive","gender","birthDate","hasValidSmartcard"})
public class NHIBasicInfoDTO
{
	private String idNumber;
	private String personFullNameArabic;
	private String personFullNameEnglish;
	private CommonTypes.Nationality nationality;
	private Boolean isAlive;
	private String gender;
	private String birthDate;
	private Boolean hasValidSmartcard;
	
	
	
	public NHIBasicInfoDTO(String idNumber, String personFullNameArabic, String personFullNameEnglish,
			CommonTypes.Nationality nationality, Boolean isAlive, String gender, String birthDate, Boolean hasValidSmartcard) {
		super();
		this.idNumber = idNumber;
		this.personFullNameArabic = personFullNameArabic;
		this.personFullNameEnglish = personFullNameEnglish;
		this.nationality = nationality;
		this.isAlive = isAlive;
		this.gender = gender;
		this.birthDate = birthDate;
		this.hasValidSmartcard = hasValidSmartcard;
	}



	public NHIBasicInfoDTO()
	{
		super();
	}


	@XmlElement(name = "IdNumber")
	public String getIdNumber() {
		return idNumber;
	}



	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}



	@XmlElement(name = "PersonFullNameArabic")
	public String getPersonFullNameArabic() {
		return personFullNameArabic;
	}



	public void setPersonFullNameArabic(String personFullNameArabic) {
		this.personFullNameArabic = personFullNameArabic;
	}



	@XmlElement(name = "PersonFullNameEnglish")
	public String getPersonFullNameEnglish() {
		return personFullNameEnglish;
	}



	public void setPersonFullNameEnglish(String personFullNameEnglish) {
		this.personFullNameEnglish = personFullNameEnglish;
	}



	@XmlElement(name = "NationalityIndicator")
	public CommonTypes.Nationality getNationality() {
		return nationality;
	}



	public void setNationality(CommonTypes.Nationality nationality) {
		this.nationality = nationality;
	}



	@XmlElement(name = "IsAlive")
	public Boolean getIsAlive() {
		return isAlive;
	}



	public void setIsAlive(Boolean isAlive) {
		this.isAlive = isAlive;
	}



	@XmlElement(name = "Gender")
	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	@XmlElement(name = "BirthDate")
	public String getBirthDate() {
		return birthDate;
	}



	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}



	@XmlElement(name = "HasValidSmartcard")
	public Boolean getHasValidSmartcard() {
		return hasValidSmartcard;
	}



	public void setHasValidSmartcard(Boolean hasValidSmartcard) {
		this.hasValidSmartcard = hasValidSmartcard;
	}



	@Override
	public String toString() {
		return "NHIBasicInfoDTO [idNumber=" + idNumber + ", personFullNameArabic=" + personFullNameArabic
				+ ", personFullNameEnglish=" + personFullNameEnglish + ", nationality=" + nationality + ", isAlive="
				+ isAlive + ", gender=" + gender + ", birthDate=" + birthDate + ", hasValidSmartcard="
				+ hasValidSmartcard + "]";
	}


}
