package bh.gov.cio.integration.crs.retrieve.employment.service.dto;

public class EmploymentServiceBasicSpecialInfoDTO
{
	private static final long	serialVersionUID	= 1L;
	private String				employerNumber;
	private String				employerArabicName;
	private String				employerEnglishName;
	private String				employerType;
	private String				employmentStatus;

	public EmploymentServiceBasicSpecialInfoDTO()
	{
		super();
	}

	public EmploymentServiceBasicSpecialInfoDTO(String employerNumber,
			String employerAN, String employerEN, String employerType,
			String employmentStatus)
	{
		super();
		this.employerNumber = employerNumber;
		this.employerArabicName = employerAN;
		this.employerEnglishName = employerEN;
		this.employerType = employerType;
		this.employmentStatus = employmentStatus;
	}

	public String getEmployerAN()
	{
		return employerArabicName;
	}

	public String getEmployerEN()
	{
		return employerEnglishName;
	}

	public String getEmployerNumber()
	{
		return employerNumber;
	}

	public String getEmployerType()
	{
		return employerType;
	}

	public String getEmploymentStatus()
	{
		return employmentStatus;
	}

	public void setEmployerAN(String employerAN)
	{
		this.employerArabicName = employerAN;
	}

	public void setEmployerEN(String employerEN)
	{
		this.employerEnglishName = employerEN;
	}

	public void setEmployerNumber(String employerNumber)
	{
		this.employerNumber = employerNumber;
	}

	public void setEmployerType(String employerType)
	{
		this.employerType = employerType;
	}

	public void setEmploymentStatus(String employmentStatus)
	{
		this.employmentStatus = employmentStatus;
	}

}
