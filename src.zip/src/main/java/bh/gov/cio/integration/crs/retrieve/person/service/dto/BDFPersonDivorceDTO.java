package bh.gov.cio.integration.crs.retrieve.person.service.dto;

import java.util.ArrayList;
import java.util.Date;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "Divorce", propOrder = { "divorce" })
public class BDFPersonDivorceDTO {

	private ArrayList<BDFPersonDivorce> divorce;
	
	public BDFPersonDivorceDTO(ArrayList<BDFPersonDivorce> divorce) {
		super();
		this.divorce = divorce;
	}

	public BDFPersonDivorceDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ArrayList<BDFPersonDivorce> getDivorce() {
		return divorce;
	}

	public void setDivorce(ArrayList<BDFPersonDivorce> divorce) {
		this.divorce = divorce;
	}

	@XmlType(name = "PersonDivorce", propOrder = { "divorceCPRNumber", "divorceNameArabic", "divorceNameEnglish",
			"marriageDate", "divorceDate", "hasCR" })
	public static class BDFPersonDivorce {
		private Integer divorceCPRNumber;
		private String divorceNameArabic;
		private String divorceNameEnglish;
		private Date marriageDate;
		private Date divorceDate;
		private Boolean hasCR;

		public BDFPersonDivorce() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Integer getDivorceCPRNumber() {
			return divorceCPRNumber;
		}

		public BDFPersonDivorce(Integer divorceCPRNumber, String divorceNameArabic, String divorceNameEnglish,
				Date divorceDate, Date marriageDate, Boolean hasCR) {
			super();
			this.divorceCPRNumber = divorceCPRNumber;
			this.divorceNameArabic = divorceNameArabic;
			this.divorceNameEnglish = divorceNameEnglish;
			this.marriageDate = marriageDate;
			this.divorceDate = divorceDate;
			this.hasCR = hasCR;
		}

		public void setDivorceCPRNumber(Integer divorceCPRNumber) {
			this.divorceCPRNumber = divorceCPRNumber;
		}

		public String getDivorceNameArabic() {
			return divorceNameArabic;
		}

		public void setDivorceNameArabic(String divorceNameArabic) {
			this.divorceNameArabic = divorceNameArabic;
		}

		public String getDivorceNameEnglish() {
			return divorceNameEnglish;
		}

		public void setDivorceNameEnglish(String divorceNameEnglish) {
			this.divorceNameEnglish = divorceNameEnglish;
		}

		public Date getMarriageDate() {
			return marriageDate;
		}

		public void setMarriageDate(Date marriageDate) {
			this.marriageDate = marriageDate;
		}

		public Date getDivorceDate() {
			return divorceDate;
		}

		public void setDivorceDate(Date divorceDate) {
			this.divorceDate = divorceDate;
		}

		public Boolean getHasCR() {
			return hasCR;
		}

		public void setHasCR(Boolean hasCR) {
			this.hasCR = hasCR;
		}

	}
}
