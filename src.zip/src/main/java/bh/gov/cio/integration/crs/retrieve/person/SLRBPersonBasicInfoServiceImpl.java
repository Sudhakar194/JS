package bh.gov.cio.integration.crs.retrieve.person;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.SLRBPersonBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.SLRBDetailDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "SLRBPersonBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "SLRBPersonBasicInfoService"
public class SLRBPersonBasicInfoServiceImpl implements SLRBPersonBasicInfoServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(SLRBPersonBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getSLRBPersonBasicInfo" })
	@WebMethod(operationName = "getSLRBPersonBasicInfo")
	public SLRBDetailDTO getSLRBPersonBasicInfo(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		SLRBDetailDTO personBasicInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonBasicInfo(Integer, Integer, Date) - start");
			logger.debug("getPersonBasicInfo(cprNumber = " + cprNumber + ")");
		}

		if (validationUtil.isMilitaryCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		}
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try {
			PersonService ps = getCrsService().getPersonServiceRef();
			
			
			final PersonBasicInfo personBasicInfo = ps.getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = ps.getPersonSummary(cprNumber);
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499")
					|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			ArrayList<Address> personAddresses = validationUtil.getCPRNumberBlock(cprNumber);
			
			Address firstOne = personAddresses != null ? personAddresses.get(0) : null;
			Integer blockNumber = firstOne != null ? personAddresses.get(0).getBlockNumber() : 0;
			personBasicInfoDTO = new SLRBDetailDTO(cprNumber, personBasicInfo.getArabicName(),
					personBasicInfo.getEnglishName(), !personSummeryInfo.isDead(),
					validationUtil.getCPRNumberExpiry(cprNumber), blockNumber,
					firstOne.getAreaNameArabic(), firstOne.getAreaNameEnglish(),nationality);

			if (logger.isDebugEnabled()) {
				logger.debug("getPersonBasicInfo(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("getPersonBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}
}
