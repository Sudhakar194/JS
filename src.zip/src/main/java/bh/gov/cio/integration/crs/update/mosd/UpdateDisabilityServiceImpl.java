package bh.gov.cio.integration.crs.update.mosd;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Disability;
import bh.gov.cio.crs.service.DisabilityService;
import bh.gov.cio.crs.util.exception.ApplicationException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.crs.util.exception.DisabilityLoadException;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.update.mosd.service.UpdateDisabilityService;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "UpdateDisabilityService", targetNamespace = "http://service.mosd.update.crs.integration.cio.gov.bh/")
public class UpdateDisabilityServiceImpl implements UpdateDisabilityService {

	private static final Logger logger = LoggerFactory.getLogger(UpdateDisabilityServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_UpdateDisability" })
	@WebMethod(operationName = "UpdateDisability")
	public boolean UpdateDisability(SecurityTagObject security, Integer cprNumber, String disabilityCode,
			Date disabilityDate) throws ApplicationExceptionInfo {
		ArrayList<Disability> personDisability = null;
		DisabilityService disabilityService = crsService.getDisabilityServiceRef();
		boolean found = false;
		try {
			personDisability = (ArrayList<Disability>) disabilityService.getDisabilityDetails(cprNumber);
		} catch (DisabilityLoadException | ApplicationException e) {
			logger.debug("Error Retrieving disability :{}", e.getMessage());
		}
		if (personDisability != null) {
			for (Iterator<Disability> iterator = personDisability.iterator(); iterator.hasNext();) {
				Disability disability = (Disability) iterator.next();
				if (disability.getDisabilityCode().equals(disabilityCode))
					found = true;
			}
		}
		Timestamp disabilityTimestamp = new Timestamp(disabilityDate.getTime());
		Disability newDisability = new Disability();
		newDisability.setCprNumber(cprNumber);
		newDisability.setDisabilityCode(disabilityCode);
		newDisability.setDisabilityDate(disabilityTimestamp);

		try {
			if (!found) {
				disabilityService.insertPersonDisability(newDisability, "MOSD");
			} else {
				disabilityService.updatePersonDisability(newDisability, "MOSD");
			}
		} catch (ApplicationException e) {
			logger.debug("Cannot update disability due to application exception:{}", e.getMessage());
		} catch (BusinessException e) {
			logger.debug("Cannot update disability due to business exception:{}", e.getMessage());
		}
		return found;
	}

}
