package bh.gov.cio.integration.crs.lookups.service.dto;

public class CountryCallingLookup {
    String countryCallingCode;
    String countryNameArabic;
    String countryNameEnglish;
    String isActive;

}
