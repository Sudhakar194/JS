package bh.gov.cio.integration.crs.update.lmra.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "UpdateEmploymentStatus", propOrder =
{ "employeeCPR", "wpNumber", "status"})
public class UpdateEmploymentDTO {
	private Integer employeeCPR;
	private Integer wpNumber;
	private String status;
	
	
	public UpdateEmploymentDTO() {
		super();
	}
	
	public UpdateEmploymentDTO(Integer employeeCPR, Integer wpNumber,
			String status) {
		super();
		this.employeeCPR = employeeCPR;
		this.wpNumber = wpNumber;
		this.status = status;
	}
	@XmlElement(name = "employeeCprNumber", required = true)
	public Integer getEmployeeCPR() {
		return employeeCPR;
	}
	public void setEmployeeCPR(Integer employeeCPR) {
		this.employeeCPR = employeeCPR;
	}
	
	@XmlElement(name = "WpNumber", required = false)
	public Integer getWpNumber() {
		return wpNumber;
	}
	public void setWpNumber(Integer wpNumber) {
		this.wpNumber = wpNumber;
	}
	
	@XmlElement(name = "status", required = true)
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
