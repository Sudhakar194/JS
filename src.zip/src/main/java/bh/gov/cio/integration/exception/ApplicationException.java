package bh.gov.cio.integration.exception;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "ApplicationException", propOrder =
{ "code", "message" })
public class ApplicationException
{

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 1L;
	private String				code;
	private String				message;

	public ApplicationException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public ApplicationException(String errorMessage)
	{
		super();
		this.message = errorMessage;
	}

	public ApplicationException(String errorMessage, String code)
	{
		super();
		this.message = errorMessage;
		this.code = code;
	}

	public String getCode()
	{
		return code;
	}

	public String getMessage()
	{
		return message;
	}

	public void setCode(String code)
	{
		this.code = code;
	}

	public void setMessage(String value)
	{
		this.message = value;
	}
}
