package bh.gov.cio.integration.exception;

import javax.xml.ws.WebFault;

@WebFault(name="ApplicationException")
public class ApplicationExceptionInfo extends Exception
{
	   /**
	 * 
	 */
	private static final long	serialVersionUID	= -2381066411773579204L;
	private ApplicationException faultInfo;


	    public ApplicationExceptionInfo(String message, ApplicationException faultInfo) {
	        super(message);
	        this.faultInfo = faultInfo;
	    }

	    public ApplicationExceptionInfo(String message, ApplicationException faultInfo, Throwable cause) {
	        super(message, cause);
	        this.faultInfo = faultInfo;
	    }

	    public ApplicationException getFaultInfo() {
	        return faultInfo;
	    }

		public void setFaultInfo(ApplicationException faultInfo) {
			this.faultInfo = faultInfo;
		}
}
