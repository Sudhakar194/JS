package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "FamilyTreeInfoDTO", propOrder =
{ "personCPR", "personArabicName", "personEnglishName", "fatherCPR", "fatherArabicName", "fatherEnglishName", "motherCPR", "motherArabicName",
		"motherEnglishName", "fatherFatherCPR", "fatherFatherArabicName", "fatherFatherEnglishName", "motherFatherCPR", "motherFatherArabicName",
		"motherFatherEnglishName", "motherMotherCPR", "motherMotherArabicName", "motherMotherEnglishName", "fatherMotherCPR",
		"fatherMotherArabicName", "fatherMotherEnglishName", "spouseDetails", "childrenDetails" })
public class FamilyTreeInfoDTO
{
	private String personCPR;
	private String personArabicName;
	private String personEnglishName;

	private String fatherCPR;
	private String fatherArabicName;
	private String fatherEnglishName;

	private String motherCPR;
	private String motherArabicName;
	private String motherEnglishName;

	private String fatherFatherCPR;
	private String fatherFatherArabicName;
	private String fatherFatherEnglishName;

	private String motherFatherCPR;
	private String motherFatherArabicName;
	private String motherFatherEnglishName;

	private String motherMotherCPR;
	private String motherMotherArabicName;
	private String motherMotherEnglishName;

	private String fatherMotherCPR;
	private String fatherMotherArabicName;
	private String fatherMotherEnglishName;
	private List<SpouseFamilyTreeDTO> spouseDetails;
	private List<ChildrenFamilyTreeDTO> childrenDetails;

	public FamilyTreeInfoDTO()
	{
		super();
	}

	public FamilyTreeInfoDTO(String personCPR, String personArabicName, String personEnglishName, String fatherCPR, String fatherArabicName,
			String fatherEnglishName, String motherCPR, String motherArabicName, String motherEnglishName, String fatherFatherCPR,
			String fatherFatherArabicName, String fatherFatherEnglishName, String motherFatherCPR, String motherFatherArabicName,
			String motherFatherEnglishName, String motherMotherCPR, String motherMotherArabicName, String motherMotherEnglishName,
			String fatherMotherCPR, String fatherMotherArabicName, String fatherMotherEnglishName, List<SpouseFamilyTreeDTO> spouseDetails,
			List<ChildrenFamilyTreeDTO> childrenDetails)
	{
		super();
		this.personCPR = personCPR != null ? personCPR : "";
		this.personArabicName = personArabicName != null ? personArabicName : "";
		this.personEnglishName = personEnglishName != null ? personEnglishName : "";
		this.fatherCPR = fatherCPR != null ? fatherCPR : "";
		this.fatherArabicName = fatherArabicName != null ? fatherArabicName : "";
		this.fatherEnglishName = fatherEnglishName != null ? fatherEnglishName : "";
		this.motherCPR = motherCPR != null ? motherCPR : "";
		this.motherArabicName = motherArabicName != null ? motherArabicName : "";
		this.motherEnglishName = motherEnglishName != null ? motherEnglishName : "";
		this.fatherFatherCPR = fatherFatherCPR != null ? fatherFatherCPR : "";
		this.fatherFatherArabicName = fatherFatherArabicName != null ? fatherFatherArabicName : "";
		this.fatherFatherEnglishName = fatherFatherEnglishName != null ? fatherFatherEnglishName : "";
		this.motherFatherCPR = motherFatherCPR != null ? motherFatherCPR : "";
		this.motherFatherArabicName = motherFatherArabicName != null ? motherFatherArabicName : "";
		this.motherFatherEnglishName = motherFatherEnglishName != null ? motherFatherEnglishName : "";
		this.motherMotherCPR = motherMotherCPR != null ? motherMotherCPR : "";
		this.motherMotherArabicName = motherMotherArabicName != null ? motherMotherArabicName : "";
		this.motherMotherEnglishName = motherMotherEnglishName != null ? motherMotherEnglishName : "";
		this.fatherMotherCPR = fatherMotherCPR != null ? fatherMotherCPR : "";
		this.fatherMotherArabicName = fatherMotherArabicName != null ? fatherMotherArabicName : "";
		this.fatherMotherEnglishName = fatherMotherEnglishName != null ? fatherMotherEnglishName : "";
		this.spouseDetails = spouseDetails != null ? spouseDetails : new ArrayList<SpouseFamilyTreeDTO>();
		this.childrenDetails = childrenDetails != null ? childrenDetails : new ArrayList<ChildrenFamilyTreeDTO>();
	}

	@XmlElement(name = "ChildrenDetails", required = true)
	public List<ChildrenFamilyTreeDTO> getChildrenDetails()
	{
		return childrenDetails;
	}

	@XmlElement(name = "FatherArabicName", required = true)
	public String getFatherArabicName()
	{
		return fatherArabicName;
	}

	@XmlElement(name = "FatherCPR", required = true)
	public String getFatherCPR()
	{
		return fatherCPR;
	}

	@XmlElement(name = "FatherEnglishName", required = true)
	public String getFatherEnglishName()
	{
		return fatherEnglishName;
	}

	@XmlElement(name = "FatherFatherArabicName", required = true)
	public String getFatherFatherArabicName()
	{
		return fatherFatherArabicName;
	}

	@XmlElement(name = "FatherFatherCPR", required = true)
	public String getFatherFatherCPR()
	{
		return fatherFatherCPR;
	}

	@XmlElement(name = "FatherFatherEnglishName", required = true)
	public String getFatherFatherEnglishName()
	{
		return fatherFatherEnglishName;
	}

	@XmlElement(name = "FatherMotherArabicName", required = true)
	public String getFatherMotherArabicName()
	{
		return fatherMotherArabicName;
	}

	@XmlElement(name = "FatherMotherCPR", required = true)
	public String getFatherMotherCPR()
	{
		return fatherMotherCPR;
	}

	@XmlElement(name = "FatherMotherEnglishName", required = true)
	public String getFatherMotherEnglishName()
	{
		return fatherMotherEnglishName;
	}

	@XmlElement(name = "MotherArabicName", required = true)
	public String getMotherArabicName()
	{
		return motherArabicName;
	}

	@XmlElement(name = "MotherCPR", required = true)
	public String getMotherCPR()
	{
		return motherCPR;
	}

	@XmlElement(name = "MotherEnglishName", required = true)
	public String getMotherEnglishName()
	{
		return motherEnglishName;
	}

	@XmlElement(name = "MotherFatherArabicName", required = true)
	public String getMotherFatherArabicName()
	{
		return motherFatherArabicName;
	}

	@XmlElement(name = "MotherFatherCPR", required = true)
	public String getMotherFatherCPR()
	{
		return motherFatherCPR;
	}

	@XmlElement(name = "MotherFatherEnglishName", required = true)
	public String getMotherFatherEnglishName()
	{
		return motherFatherEnglishName;
	}

	@XmlElement(name = "MotherMotherArabicName", required = true)
	public String getMotherMotherArabicName()
	{
		return motherMotherArabicName;
	}

	@XmlElement(name = "MotherMotherCPR", required = true)
	public String getMotherMotherCPR()
	{
		return motherMotherCPR;
	}

	@XmlElement(name = "MotherMotherEnglishName", required = true)
	public String getMotherMotherEnglishName()
	{
		return motherMotherEnglishName;
	}

	@XmlElement(name = "PersonArabicName", required = true)
	public String getPersonArabicName()
	{
		return personArabicName;
	}

	@XmlElement(name = "PersonCPR", required = true)
	public String getPersonCPR()
	{
		return personCPR;
	}

	@XmlElement(name = "PersonEnglishName", required = true)
	public String getPersonEnglishName()
	{
		return personEnglishName;
	}

	@XmlElement(name = "SpouseDetails", required = true)
	public List<SpouseFamilyTreeDTO> getSpouseDetails()
	{
		return spouseDetails;
	}

	public void setChildrenDetails(List<ChildrenFamilyTreeDTO> childrenDetails)
	{
		this.childrenDetails = childrenDetails;
	}

	public void setFatherArabicName(String fatherArabicName)
	{
		this.fatherArabicName = fatherArabicName;
	}

	public void setFatherCPR(String fatherCPR)
	{
		this.fatherCPR = fatherCPR;
	}

	public void setFatherEnglishName(String fatherEnglishName)
	{
		this.fatherEnglishName = fatherEnglishName;
	}

	public void setFatherFatherArabicName(String fatherFatherArabicName)
	{
		this.fatherFatherArabicName = fatherFatherArabicName;
	}

	public void setFatherFatherCPR(String fatherFatherCPR)
	{
		this.fatherFatherCPR = fatherFatherCPR;
	}

	public void setFatherFatherEnglishName(String fatherFatherEnglishName)
	{
		this.fatherFatherEnglishName = fatherFatherEnglishName;
	}

	public void setFatherMotherArabicName(String fatherMotherArabicName)
	{
		this.fatherMotherArabicName = fatherMotherArabicName;
	}

	public void setFatherMotherCPR(String fatherMotherCPR)
	{
		this.fatherMotherCPR = fatherMotherCPR;
	}

	public void setFatherMotherEnglishName(String fatherMotherEnglishName)
	{
		this.fatherMotherEnglishName = fatherMotherEnglishName;
	}

	public void setMotherArabicName(String motherArabicName)
	{
		this.motherArabicName = motherArabicName;
	}

	public void setMotherCPR(String motherCPR)
	{
		this.motherCPR = motherCPR;
	}

	public void setMotherEnglishName(String motherEnglishName)
	{
		this.motherEnglishName = motherEnglishName;
	}

	public void setMotherFatherArabicName(String motherFatherArabicName)
	{
		this.motherFatherArabicName = motherFatherArabicName;
	}

	public void setMotherFatherCPR(String motherFatherCPR)
	{
		this.motherFatherCPR = motherFatherCPR;
	}

	public void setMotherFatherEnglishName(String motherFatherEnglishName)
	{
		this.motherFatherEnglishName = motherFatherEnglishName;
	}

	public void setMotherMotherArabicName(String motherMotherArabicName)
	{
		this.motherMotherArabicName = motherMotherArabicName;
	}

	public void setMotherMotherCPR(String motherMotherCPR)
	{
		this.motherMotherCPR = motherMotherCPR;
	}

	public void setMotherMotherEnglishName(String motherMotherEnglishName)
	{
		this.motherMotherEnglishName = motherMotherEnglishName;
	}

	public void setPersonArabicName(String personArabicName)
	{
		this.personArabicName = personArabicName;
	}

	public void setPersonCPR(String personCPR)
	{
		this.personCPR = personCPR;
	}

	public void setPersonEnglishName(String personEnglishName)
	{
		this.personEnglishName = personEnglishName;
	}

	public void setSpouseDetails(List<SpouseFamilyTreeDTO> spouseDetails)
	{
		this.spouseDetails = spouseDetails;
	}

}
