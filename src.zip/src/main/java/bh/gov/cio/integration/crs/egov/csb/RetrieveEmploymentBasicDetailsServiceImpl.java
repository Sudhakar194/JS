package bh.gov.cio.integration.crs.egov.csb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.nas.Address;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.AddressService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.egov.csb.service.RetrieveEmploymentBasicDetailsInterface;
import bh.gov.cio.integration.crs.egov.csb.service.dto.EmploymentBasicDetailsDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "RetrieveEmploymentBasicDetailsService", targetNamespace = "http://service.csb.egov.crs.integration.cio.gov.bh/")
public class RetrieveEmploymentBasicDetailsServiceImpl implements RetrieveEmploymentBasicDetailsInterface {

	private static final Logger logger = LoggerFactory.getLogger(RetrieveEmploymentBasicDetailsServiceImpl.class);

	@Autowired
	private ValidationServiceImpl			validationService;
	@Autowired
	private CRSServicesProviderServiceImpl	crsService;
	@Autowired
	private PropertyServiceImpl				propImpl;

	@Override
	@Secured({ "ROLE_RetrieveEmploymentBasicDetails" })
	@WebMethod(operationName = "RetrieveEmploymentBasicDetails")
	public EmploymentBasicDetailsDTO RetrieveEmploymentBasicDetails(SecurityTagObject security, String idNumber,
			String cardCountry, String eKeyIDNumber, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp)
			throws ApplicationExceptionInfo {

		if (!checkeKeyResponse(eKeyIDNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp)) {
			throw new ApplicationExceptionInfo("Error in retrieving data...",
					new ApplicationException("Authentication Failed.", "001"));
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(eKeyIDNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "003"));
		}
		PersonService ps = crsService.getPersonServiceRef();
		AddressService as = crsService.getAddressServiceRef();
//		Address add;
		PersonBasicInfo pbi;
		PersonSummary psummary;
		ArrayList<Address> addList,addList1; 
		String block = "" ,governorate= "",area = "";
		boolean isExpired = false;
		boolean isDead = false;
		try {

			pbi = ps.getPersonBasicInfo(cprNumber);
			psummary = ps.getPersonSummary(cprNumber);
//			add = as.getAddressDetailsByCpr(cprNumber);
			addList = (ArrayList<Address>)  as.getAddressForListCprNumber(new ArrayList<Integer> (Arrays.asList(cprNumber)));
			addList1 = (ArrayList<Address>)  as.getAddressDetails(cprNumber);
			isDead = psummary.isDead();
		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("RetrieveEmploymentBasicDetails(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Error Retrieving Data",
					new ApplicationException("Error Retrieving Data From Backend", "004"));
		}
		
		if (isDead) {
			throw new ApplicationExceptionInfo("Person is Dead", new ApplicationException("Person is Dead", "005"));
		}

		EmploymentBasicDetailsDTO employmentBasicDetailsDTO;

		
		if (validationService.getNationalityCategory(pbi.getNationalityCode()).equals(CommonTypes.Nationality.Other)) {
			throw new ApplicationExceptionInfo("Person is Bahraini Or GCC", new ApplicationException("Person is Not Bahraini Or GCC", "006"));
		}		
		
		try {
			Date cardExpiry = validationService.getCPRNumberExpiry(cprNumber);
			isExpired = cardExpiry.before(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (isExpired) {
			throw new ApplicationExceptionInfo("Person Smartcard Expired", new ApplicationException("Person Smartcard Expired", "007"));
		}
		if(addList != null && addList.size() > 0 )
		{
			block = addList.get(0).getBlockNumber()+"";
			governorate = addList.get(0).getGovernorateNameEnglish();
			area = addList1.get(0).getAreaCode()+"";
		}
//		System.out.println("pbi.getNationalityCode() = "+pbi.getNationalityCode());
		CommonTypes.Nationality nationalityGroup = validationService.getNationalityCategory(pbi.getNationalityCode());
		employmentBasicDetailsDTO = new EmploymentBasicDetailsDTO( 
				new Date(pbi.getDateOfBirth().getTime()), pbi.getGender() ,psummary.getBirthPlaceEnglish(), pbi.getEnglishName(),
				pbi.getArabicName(),nationalityGroup, block,governorate,area);
		return employmentBasicDetailsDTO;
	}

	private boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID,
			String eKeyTimestamp) {
		ValidateToken eKey = crsService.geteKeyServiceRef();
		String accessPassword = propImpl.geteGOVeKeyPassword();
		String response = null;
		CryptoUtil cryptoUtil = new CryptoUtil();
		try {
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber),
					cryptoUtil.encrypt(eKeyServiceID), cryptoUtil.encrypt(eKeyTokenID),
					cryptoUtil.encrypt(eKeyTimestamp));

			response = cryptoUtil.decrypt(response);

			logger.debug("eKey Response:" + response);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));

	}

}
