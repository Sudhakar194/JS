package bh.gov.cio.integration.crs.update.family.service;

import java.net.UnknownHostException;

import bh.gov.cio.crs.util.exception.ApplicationException;
import bh.gov.cio.crs.util.exception.BusinessException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;

public interface UpdateMarriageServiceInterface
{

	String deleteMarriage(Integer husbandCPR, Integer wifeCPR, String marriageDate) throws ApplicationException, ApplicationExceptionInfo,
			BusinessException, UnknownHostException;

	String deleteMarriage(String husbandID, String husbandNationalityCode, String wifeID, String wifeNationalityCode, String marriageDate)
			throws ApplicationException, ApplicationExceptionInfo, BusinessException, UnknownHostException;

	String getMarriageDates(Integer CPRNumber) throws ApplicationExceptionInfo, UnknownHostException, ApplicationException, BusinessException;

	String getMarriageDates(String IDNumber, String nationalityCode) throws ApplicationExceptionInfo, UnknownHostException, ApplicationException,
			BusinessException;

	String updateMarriage(Integer cprNumber, Integer spouseCPR, String marriageDate) throws ApplicationException, ApplicationExceptionInfo,
			BusinessException, UnknownHostException;

	String updateMarriage(String husbandID, String husbandNationalityCode, String wifeID, String wifeNationalityCode, String marriageDate)
			throws ApplicationException, ApplicationExceptionInfo, BusinessException, UnknownHostException;

	String getCPRsByName(String citizenName) throws ApplicationException, BusinessException, ApplicationExceptionInfo, UnknownHostException;
}
