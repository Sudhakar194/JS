package bh.gov.cio.integration.crs.egov.gcc.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "GCCPersonVerification", propOrder = { "idNumber","GCC"})
public class GCCPersonVerificationDTO {

	public GCCPersonVerificationDTO() {
	}

	private String idNumber;
	private boolean isGCC;


	public GCCPersonVerificationDTO(String idNumber, boolean isGCC) {
		super();
		this.idNumber = idNumber;
		this.isGCC = isGCC;
	}



	@XmlElement(name = "idNumber")
	public String getIdNumber() {
		return idNumber;
	}



	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}


	@XmlElement(name = "GCC")
	public boolean isGCC() {
		return isGCC;
	}



	public void setGCC(boolean isGCC) {
		this.isGCC = isGCC;
	}


}
