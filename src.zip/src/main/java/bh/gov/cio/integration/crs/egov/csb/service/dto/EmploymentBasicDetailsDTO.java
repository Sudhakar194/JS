package bh.gov.cio.integration.crs.egov.csb.service.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;

@XmlType(name = "EmploymentBasicDetailsDTO", propOrder = { "dateOfBirth","gender",
		"placeOfBirth", "applicantNameEnglish", "applicantNameArabic", "nationalityCategory", "block" ,"governorate","area"})
public class EmploymentBasicDetailsDTO {

	private Date						dateOfBirth;
	private String						gender;
	private String						placeOfBirth;
	private String						applicantNameEnglish;
	private String						applicantNameArabic;
	private CommonTypes.Nationality		nationalityCategory;
	private String	block;
	private String	governorate;
	private String	area;

	public EmploymentBasicDetailsDTO() {
		super();
	}

	public EmploymentBasicDetailsDTO(Date dateOfBirth, String gender ,String placeOfBirth, String applicantNameEnglish,
			String applicantNameArabic, CommonTypes.Nationality nationalityCategory, String block, String governorate,
			String area) {
		super();
		this.dateOfBirth = dateOfBirth;
		this.placeOfBirth = placeOfBirth;
		this.applicantNameEnglish = applicantNameEnglish;
		this.applicantNameArabic = applicantNameArabic;
		this.nationalityCategory = nationalityCategory;
		this.block = block;
		this.governorate = governorate;
		this.area = area;
		this.gender = gender;
	}

	@XmlElement(name = "DateOfBirth")
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@XmlElement(name = "PlaceOfBirth")
	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

	@XmlElement(name = "ApplicantEnglishName")
	public String getApplicantNameEnglish() {
		return applicantNameEnglish;
	}

	public void setApplicantNameEnglish(String applicantNameEnglish) {
		this.applicantNameEnglish = applicantNameEnglish;
	}

	@XmlElement(name = "ApplicantArabicName")
	public String getApplicantNameArabic() {
		return applicantNameArabic;
	}

	public void setApplicantNameArabic(String applicantNameArabic) {
		this.applicantNameArabic = applicantNameArabic;
	}

	@XmlElement(name = "nationalityCategory")
	public CommonTypes.Nationality getNationalityCategory() {
		return nationalityCategory;
	}

	public void setNationalityCategory(CommonTypes.Nationality nationalityCategory) {
		this.nationalityCategory = nationalityCategory;
	}

	@XmlElement(name = "BlockNumber")
	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	@XmlElement(name = "Governorate")
	public String getGovernorate() {
		return governorate;
	}

	public void setGovernorate(String governorate) {
		this.governorate = governorate;
	}

	@XmlElement(name = "Area")
	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	@XmlElement(name = "Gender")
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

}
