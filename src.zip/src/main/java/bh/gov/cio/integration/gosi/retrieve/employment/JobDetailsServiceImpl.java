package bh.gov.cio.integration.gosi.retrieve.employment;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.HTTPServiceImpl;
import bh.gov.cio.integration.common.NumberServiceImpl;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.XMLServiceImpl;
import bh.gov.cio.integration.gosi.retrieve.employment.service.JobDetailsServiceInterface;
import bh.gov.cio.integration.gosi.retrieve.employment.service.dto.JobDetailsDTO;

@WebService(
		name = "JobDetailsService",
		targetNamespace = "http://bh.gov.cio.integration.gosi.retrieve.employment.service/")
//serviceName = "JobDetailsService",
public class JobDetailsServiceImpl implements JobDetailsServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger	logger	= LoggerFactory.getLogger(JobDetailsServiceImpl.class);
	@Autowired
	private PropertyServiceImpl	propImpl;

	@Override
	@WebMethod(operationName = "getJobDetails")
	@Secured({"ROLE_getJobDetails" })
	public JobDetailsDTO getJobDetails(Integer cprNumber)
	{
		if (logger.isDebugEnabled())
			logger.debug("getJobDetails(Integer) - start");
		final String URL = propImpl.getGosiServiceURL();
		// https://www.sio.bh/ws/SIOWSCIOWr1?Td=2012-03-05&Tt=Request&Ti=SIOWSCIOWr1&CPR=100004776&K1=1140

		final JobDetailsDTO personJobDTO = new JobDetailsDTO();
		try
		{
			final String cprStr = String.valueOf(cprNumber.intValue());
			final String validationFormula = (Integer.parseInt(DateServiceImpl
					.getCurrentDate().substring(4, 6))
					* Integer.parseInt(DateServiceImpl.getCurrentDate()
							.substring(6, 8)) * (Integer.parseInt(cprStr
					.substring((cprStr.length() - 2), cprStr.length())) + 1)

			)
					+ "";
			if (logger.isDebugEnabled())
			{
				logger.debug("currentDate:" + DateServiceImpl.getCurrentDate());
				logger.debug("k1 Fromula:"
						+ DateServiceImpl.getCurrentDate().substring(4, 6)
						+ "*"
						+ DateServiceImpl.getCurrentDate().substring(6, 8)
						+ "*"
						+ cprStr.substring((cprStr.length() - 2),
								cprStr.length()) + "+1");
			}
			final String url = URL + "?Td="
					+ DateServiceImpl.getCurrentDateDash()
					+ "&Tt=Request&Ti=SIOWSCIOWr1&CPR=" + cprNumber + "&K1="
					+ validationFormula;
			final String responseBody = HTTPServiceImpl.invokeURL(url);
			// Create a response handler
			Integer cprNoXML = new Integer(0), workStatusXML = new Integer(0), crEmpNoXML = new Integer(
					0), unitEmpNoXML = new Integer(0), unitJobCode = new Integer(
					0), crJobCode = new Integer(0);
			try
			{
				cprNoXML = Integer.parseInt(XMLServiceImpl
						.getXMLTagValueByName(responseBody, "CPRNo"));
				crEmpNoXML = Integer.parseInt(XMLServiceImpl
						.getXMLTagValueByName(responseBody, "EmplCrNo"));
				crJobCode = Integer.parseInt(XMLServiceImpl
						.getXMLTagValueByName(responseBody, "JOBDJOBC"));
				unitEmpNoXML = Integer.parseInt(XMLServiceImpl
						.getXMLTagValueByName(responseBody, "EmplEmNo_Pub"));
				unitJobCode = Integer.parseInt(XMLServiceImpl
						.getXMLTagValueByName(responseBody, "JOBDJOBC_Pub"));
				workStatusXML = Integer.parseInt(XMLServiceImpl
						.getXMLTagValueByName(responseBody, "WorkStatus"));
			}
			catch (final NumberFormatException e)
			{
				logger.error("getJobDetails(Integer)", e);
			}
			personJobDTO.setCprNumber(cprNoXML);
			personJobDTO.setCrEmployerNumber(crEmpNoXML);
			personJobDTO.setUnitEmployerNumber(unitEmpNoXML);
			personJobDTO.setCrJobCode(NumberServiceImpl
					.getFormattedSixCharactersStringFromInteger(crJobCode));
			personJobDTO.setUnitJobCode(NumberServiceImpl
					.getFormattedSixCharactersStringFromInteger(unitJobCode));
			personJobDTO.setWorkStatus(workStatusXML);

		}
		catch (final Exception e)
		{
			logger.error("getJobDetails(Integer)", e);

			logger.error("getJobDetails(Integer)", e);
		}

		if (logger.isDebugEnabled())
			logger.debug("getJobDetails(Integer) - end");
		return personJobDTO;
	}
}
