package bh.gov.cio.integration.crs.retrieve.mun.service.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlType;

import bh.gov.cio.integration.common.CommonTypes;

@XmlType(name = "CRUnitAddressInformation", propOrder = {

		"crUnitNumber", "arabicName", "englishName", "idType", "block", "roadNumber", "roadArabicName",
		"roadEnglishName", "buildingNumber", "flat" })
public class CRUnitAddressDTO implements Serializable, CommonTypes {

	/**
	 * 
	 */
	private static final long	serialVersionUID	= -4983293620155213821L;
	private Integer				crUnitNumber;
	private String				arabicName;
	private String				englishName;
	private String				idType;
	private String				block;
	private String				roadNumber;
	private String				roadArabicName;
	private String				roadEnglishName;
	private String				buildingNumber;
	private String				flat;

	public CRUnitAddressDTO() {
		super();
	}

	public CRUnitAddressDTO(Integer crUnitNumber, String arabicName, String englishName, String idType, String block,
			String roadNumber, String roadArabicName, String roadEnglishName, String buildingNumber, String flat) {
		super();
		this.crUnitNumber = crUnitNumber;
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.idType = idType;
		this.block = block;
		this.roadNumber = roadNumber;
		this.roadArabicName = roadArabicName;
		this.roadEnglishName = roadEnglishName;
		this.buildingNumber = buildingNumber;
		this.flat = flat;
	}

	public Integer getCrUnitNumber() {
		return crUnitNumber;
	}

	public void setCrUnitNumber(Integer crUnitNumber) {
		this.crUnitNumber = crUnitNumber;
	}

	public String getArabicName() {
		return arabicName;
	}

	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public String getRoadArabicName() {
		return roadArabicName;
	}

	public void setRoadArabicName(String roadArabicName) {
		this.roadArabicName = roadArabicName;
	}

	public String getRoadEnglishName() {
		return roadEnglishName;
	}

	public void setRoadEnglishName(String roadEnglishName) {
		this.roadEnglishName = roadEnglishName;
	}

	public String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getFlat() {
		return flat;
	}

	public void setFlat(String flat) {
		this.flat = flat;
	}
}
