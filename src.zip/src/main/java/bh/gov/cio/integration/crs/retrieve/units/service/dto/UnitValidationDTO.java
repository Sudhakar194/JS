package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlType;

/**
 * @author cspomlh
 * 
 */
@XmlType(name = "UnitValidation", propOrder =
{ "crArabicName", "crEnglishName", "crExpiryDate","crStatus"})
public class UnitValidationDTO
{

	private	String crArabicName;
	private	String crEnglishName;
	private	Date crExpiryDate;
	private	String crStatus;
	
	
	public UnitValidationDTO() {
		super();
	}
	public UnitValidationDTO(String crArabicName, String crEnglishName, Date crExpiryDate, String crStatus) {
		super();
		this.crArabicName = crArabicName;
		this.crEnglishName = crEnglishName;
		this.crExpiryDate = crExpiryDate;
		this.crStatus = crStatus;
	}
	public String getCrArabicName() {
		return crArabicName;
	}
	public String getCrEnglishName() {
		return crEnglishName;
	}
	public Date getCrExpiryDate() {
		return crExpiryDate;
	}
	public String getCrStatus() {
		return crStatus;
	}
	public void setCrArabicName(String crArabicName) {
		this.crArabicName = crArabicName;
	}
	public void setCrEnglishName(String crEnglishName) {
		this.crEnglishName = crEnglishName;
	}
	public void setCrExpiryDate(Date crExpiryDate) {
		this.crExpiryDate = crExpiryDate;
	}
	public void setCrStatus(String crStatus) {
		this.crStatus = crStatus;
	}

}
