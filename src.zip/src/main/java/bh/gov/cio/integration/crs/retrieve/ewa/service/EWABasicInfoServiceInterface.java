package bh.gov.cio.integration.crs.retrieve.ewa.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.crs.retrieve.ewa.service.dto.EWAServiceBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.ewa.service.dto.EWAServiceFlatListDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "EWABasicInfoService", targetNamespace = "http://service.ewa.retrieve.crs.integration.cio.gov.bh/")
public interface EWABasicInfoServiceInterface extends CommonTypes
{
	@WebResult(name = "EWABasicInformatoin")
	@WebMethod(operationName = "getPersonEWABasicInfo")
	EWAServiceBasicInfoDTO getPersonEWABasicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security,@WebParam(name = "CountryCode") @XmlElement(required = true)  String CountryCode ,@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber
			) throws ApplicationExceptionInfo;

	@WebResult(name = "EWAFlatInformatoin")
	@WebMethod(operationName = "getOwnerFlatNumbers")
	EWAServiceFlatListDTO getOwnerFlatNumbers(@WebParam(mode = WebParam.Mode.IN, name = "Security",
			header = true) SecurityTagObject security,@WebParam(name = "CountryCode") @XmlElement(required = true)  String CountryCode ,@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber
			,@WebParam(name = "BuildingNumber") @XmlElement(required = true) Integer buildingNumber,@WebParam(name = "BuildingAlpha") @XmlElement(required = true) String buildingAlpha
			,@WebParam(name = "RoadNumber") @XmlElement(required = true) Integer roadNumber ,@WebParam(name = "BlockNumber") @XmlElement(required = true) Integer blockNumber
			) throws ApplicationExceptionInfo;

}
