package bh.gov.cio.integration.crs.nns.dto;

public class NotificationInfoDTO {

	private String idNumber;
	private String idCountryCode;
	private String primaryPhoneNumber;
	private String secondaryPhoneNumber;
	private String primaryEmail;
	private String secondaryEmail;
	private String statusCode;
	private String statusMessage;

	public String getIdNumber() {
		return idNumber;
	}

	public NotificationInfoDTO(String idNumber, String idCountryCode, String primaryPhoneNumber,
			String secondaryPhoneNumber, String primaryEmail,String secondaryEmail, String statusCode, String statusMessage) {
		super();
		this.idNumber = idNumber;
		this.idCountryCode = idCountryCode;
		this.primaryPhoneNumber = primaryPhoneNumber;
		this.secondaryPhoneNumber = secondaryPhoneNumber;
		this.setPrimaryEmail(primaryEmail);
		this.setSecondaryEmail(secondaryEmail);
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
	}

	public NotificationInfoDTO() {
		super();

	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getIdCountryCode() {
		return idCountryCode;
	}

	public void setIdCountryCode(String idCountryCode) {
		this.idCountryCode = idCountryCode;
	}

	public String getPrimaryPhoneNumber() {
		return primaryPhoneNumber;
	}

	public void setPrimaryPhoneNumber(String primaryPhoneNumber) {
		this.primaryPhoneNumber = primaryPhoneNumber;
	}

	public String getSecondaryPhoneNumber() {
		return secondaryPhoneNumber;
	}

	public void setSecondaryPhoneNumber(String secondaryPhoneNumber) {
		this.secondaryPhoneNumber = secondaryPhoneNumber;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getPrimaryEmail() {
		return primaryEmail;
	}

	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	public String getSecondaryEmail() {
		return secondaryEmail;
	}

	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}

}
