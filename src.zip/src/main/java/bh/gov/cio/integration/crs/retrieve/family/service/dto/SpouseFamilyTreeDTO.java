package bh.gov.cio.integration.crs.retrieve.family.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder =
{ "cprNumber", "arabicName", "englishName" })
public class SpouseFamilyTreeDTO
{
	private Integer cprNumber;
	private String arabicName;
	private String englishName;

	public SpouseFamilyTreeDTO()
	{
		super();

	}

	public SpouseFamilyTreeDTO(Integer cprNumber, String arabicName, String englishName)
	{
		super();
		this.cprNumber = cprNumber != null ? cprNumber : 0;
		this.arabicName = arabicName != null ? arabicName : "";
		this.englishName = englishName != null ? englishName : "";
	}

	public String getArabicName()
	{
		return arabicName;
	}

	public Integer getCprNumber()
	{
		return cprNumber;
	}

	public String getEnglishName()
	{
		return englishName;
	}

	public void setArabicName(String arabicName)
	{
		this.arabicName = arabicName;
	}

	public void setCprNumber(Integer cprNumber)
	{
		this.cprNumber = cprNumber;
	}

	public void setEnglishName(String englishName)
	{
		this.englishName = englishName;
	}

}
