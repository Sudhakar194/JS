package bh.gov.cio.integration.common.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.EmptySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.admin.model.Role;
import bh.gov.cio.integration.common.admin.model.User;
import bh.gov.cio.integration.common.admin.model.UserRole;
import bh.gov.cio.integration.common.admin.reports.service.dto.ServiceDetailsInfoDTO;

@Repository(value = "AdminDao")
public class AdminDao {
	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	PropertyServiceImpl prop;

	public List<Map<String, Object>> getAllUsers() {
		List<Map<String, Object>> returnedUsers = jdbcTemplate.query("select * from " + prop.getSchemaName() + ".users",
				new MapSqlParameterSource(), new RowMapper<Map<String, Object>>() {
					public Map<String, Object> mapRow(ResultSet rs, int i) throws SQLException {
						Map<String, Object> results = new HashMap<String, Object>();
						results.put("user_id", rs.getInt("user_id"));
						results.put("username", rs.getString("username"));
						results.put("enabled", rs.getBoolean("enabled"));
						results.put("email", rs.getString("email"));
						results.put("mobile", rs.getString("mobile"));
						results.put("description", rs.getString("description"));
						return results;
					}
				});

		return returnedUsers;
	}

	
	public ArrayList<String> getAllUsersPF() {
		ArrayList<String> returnedUsers = new ArrayList<String>(jdbcTemplate.query("select * from " + prop.getSchemaName() + ".users",
				new MapSqlParameterSource(), new RowMapper<String>() {
					public String mapRow(ResultSet rs, int i) throws SQLException {
						String results = rs.getString("username");
						return results;
					}
				}));

		return returnedUsers;
	}

	public void addUser(User user) {
		SqlParameterSource sqlparams = new BeanPropertySqlParameterSource(user);
		jdbcTemplate.update("INSERT INTO " + prop.getSchemaName() + ".users(\r\n"
				+ "	username, password, enabled, description, email, mobile)\r\n"
				+ "	VALUES (:username, :password, :enabled, :description, :email, :mobile);", sqlparams);
	}

	public void deleteUser(User user) {
		SqlParameterSource sqlparams = new BeanPropertySqlParameterSource(user);
		jdbcTemplate.update("Delete From " + prop.getSchemaName() + ".user_role Where "
				+ "	USER_ID = (SELECT USER_ID FROM " + prop.getSchemaName() + ".USERS WHERE USERNAME=:username) ",
				sqlparams);
		jdbcTemplate.update("Delete From " + prop.getSchemaName() + ".users Where " + "	username = :username ",
				sqlparams);
	}

	public List<Map<String, Object>> getAllRoles() {
		List<Map<String, Object>> returnedUsers = jdbcTemplate.query("select * from " + prop.getSchemaName() + ".roles",
				new MapSqlParameterSource(), new RowMapper<Map<String, Object>>() {
					public Map<String, Object> mapRow(ResultSet rs, int i) throws SQLException {
						Map<String, Object> results = new HashMap<String, Object>();
						results.put("role_id", rs.getInt("role_id"));
						String role = rs.getString("rolename");
						role = role.replace("ROLE_","");
						results.put("rolename", role);
						results.put("description", rs.getString("DESC"));
						return results;
					}
				});

		return returnedUsers;
	}

	public void addRole(Role role) {
		SqlParameterSource sqlparams = new BeanPropertySqlParameterSource(role);
		jdbcTemplate.update("INSERT INTO " + prop.getSchemaName() + ".roles(\r\n" + "	rolename, DESC)\r\n"
				+ "	VALUES (:rolename, :description);", sqlparams);
	}

	public List<Map<String, Object>> getUserRoles(String username) {
		List<Map<String, Object>> returnedUsers = jdbcTemplate.query(
				"select  r.role_id role_id,r.rolename rolename,r.desc description,u.username username from " + prop.getSchemaName()
						+ ".roles r " + "inner join " + prop.getSchemaName()
						+ ".user_role ur on ur.role_id = r.role_id " + "inner join " + prop.getSchemaName()
						+ ".users u on u.user_id = ur.user_id " + "where u.username = '" + username + "'",
				new MapSqlParameterSource(), new RowMapper<Map<String, Object>>() {
					public Map<String, Object> mapRow(ResultSet rs, int i) throws SQLException {
						Map<String, Object> results = new HashMap<String, Object>();
						results.put("role_id", rs.getInt("role_id"));
						String role = rs.getString("rolename");
						role = role.replace("ROLE_","");
						results.put("rolename", role);
						results.put("description", rs.getString("description"));
						return results;
					}
				});

		return returnedUsers;
	}

	public List<Map<String, Object>> getUserRoles(Integer user_id) {
		List<Map<String, Object>> returnedUsers = jdbcTemplate.query(
				"select r.role_id role_id,r.rolename rolename,r.desc description,u.username username from " + prop.getSchemaName()
						+ ".roles r " + "inner join " + prop.getSchemaName()
						+ ".user_role ur on ur.role_id = r.role_id " + "inner join " + prop.getSchemaName()
						+ ".users u on u.user_id = ur.user_id " + "where u.user_id = " + user_id + "",
				new MapSqlParameterSource(), new RowMapper<Map<String, Object>>() {
					public Map<String, Object> mapRow(ResultSet rs, int i) throws SQLException {
						Map<String, Object> results = new HashMap<String, Object>();
						results.put("description", rs.getString("description"));
						results.put("role_id", rs.getInt("role_id"));
						String role = rs.getString("rolename");
						role = role.replace("ROLE_","");
						results.put("rolename", role);
						return results;
					}
				});

		return returnedUsers;
	}

	public List<Map<String, Object>> getNonUserRoles(String username) {
		List<Map<String, Object>> returnedUsers = jdbcTemplate.query(

				"select roles.role_id role_id,roles.rolename,roles.desc description from " + prop.getSchemaName()
						+ ".roles roles where roles.role_id not in (" + "    	select ur.role_id from "
						+ prop.getSchemaName() + ".user_role ur " + "        inner join (select user_id from "
						+ prop.getSchemaName() + ".users where username = '" + username
						+ "') u on u.user_id = ur.user_id " + "        inner join " + prop.getSchemaName()
						+ ".roles r on ur.role_id = r.role_id) ",
				new MapSqlParameterSource(), new RowMapper<Map<String, Object>>() {
					public Map<String, Object> mapRow(ResultSet rs, int i) throws SQLException {
						Map<String, Object> results = new HashMap<String, Object>();
						results.put("role_id", rs.getInt("role_id"));
						String role = rs.getString("rolename");
						role = role.replace("ROLE_","");
						results.put("rolename", role);
						results.put("description", rs.getString("description"));
						return results;
					}
				});

		return returnedUsers;
	}

	public List<Map<String, Object>> getNonUserRoles(Integer user_id) {
		List<Map<String, Object>> returnedUsers = jdbcTemplate.query(

				"select roles.role_id,roles.rolename,roles.desc description from " + prop.getSchemaName()
						+ ".roles roles where roles.role_id not in (" + "    	select ur.role_id from "
						+ prop.getSchemaName() + ".user_role ur " + "        inner join (select user_id from "
						+ prop.getSchemaName() + ".users where user_id = " + user_id
						+ ") u on u.user_id = ur.user_id " + "        inner join " + prop.getSchemaName()
						+ ".roles r on ur.role_id = r.role_id) ",
				new MapSqlParameterSource(), new RowMapper<Map<String, Object>>() {
					public Map<String, Object> mapRow(ResultSet rs, int i) throws SQLException {
						Map<String, Object> results = new HashMap<String, Object>();
						results.put("role_id", rs.getInt("role_id"));
						String role = rs.getString("rolename");
						role = role.replace("ROLE_","");
						results.put("rolename", role);
						results.put("description", rs.getString("description"));
						return results;
					}
				});

		return returnedUsers;
	}

	public void addRoleToUser(UserRole uroles) {
		SqlParameterSource sqlparams = new BeanPropertySqlParameterSource(uroles);
		jdbcTemplate.update("INSERT INTO " + prop.getSchemaName()
				+ ".user_role(	USER_ID, ROLE_ID)	VALUES ((SELECT USER_ID FROM " + prop.getSchemaName()
				+ ".USERS WHERE USERNAME=:username),(SELECT ROLE_ID FROM " + prop.getSchemaName()
				+ ".ROLES WHERE ROLENAME =:rolename))", sqlparams);
	}

	public void addRoleToUser(Integer user_id,Integer role_id) {
		SqlParameterSource sqlparams = new EmptySqlParameterSource();
		jdbcTemplate.update("INSERT INTO " + prop.getSchemaName()
				+ ".user_role(	USER_ID, ROLE_ID)	VALUES ("+user_id+","+role_id+")", sqlparams);
	}

	public void removeRoleFromUser(UserRole uroles) {
		SqlParameterSource sqlparams = new BeanPropertySqlParameterSource(uroles);
		jdbcTemplate.update("DELETE FROM " + prop.getSchemaName() + ".user_role WHERE  user_id = (SELECT USER_ID FROM "
				+ prop.getSchemaName() + ".USERS WHERE USERNAME=:username) AND  role_id = (SELECT ROLE_ID FROM "
				+ prop.getSchemaName() + ".ROLES WHERE ROLENAME =:rolename)", sqlparams);
	}

	public void removeRoleFromUser(Integer user_id,Integer role_id) {
		SqlParameterSource sqlparams =new EmptySqlParameterSource();
		jdbcTemplate.update("DELETE FROM " + prop.getSchemaName() + ".user_role WHERE  user_id = "+user_id
				+" AND  role_id ="+role_id,sqlparams );
	}
	/**
	 * GET SERVICE NAME/URL BY MINISTRY
	 * 
	 * @param ministry
	 * @return
	 */
	public ArrayList<ServiceDetailsInfoDTO> getServiceInformationByMinistry(String ministry) {
		ArrayList<ServiceDetailsInfoDTO> returnedUsers = (ArrayList<ServiceDetailsInfoDTO>) jdbcTemplate.query(
				"SELECT DISTINCT SERVICENAME,CREATION_DATE FROM " + prop.getSchemaName() + ".ROLES WHERE ROLE_ID IN ("
						+ "    SELECT ROLE_ID FROM " + prop.getSchemaName() + ".USER_ROLE WHERE USER_ID IN ("
						+ "        SELECT USER_ID FROM " + prop.getSchemaName() + ".USERS WHERE MINISTRY='" + ministry
						+ "'))",
				new MapSqlParameterSource(), new RowMapper<ServiceDetailsInfoDTO>() {
					public ServiceDetailsInfoDTO mapRow(ResultSet rs, int i) throws SQLException {
						ServiceDetailsInfoDTO serviceDetailsInfoDTO = new ServiceDetailsInfoDTO(
								rs.getString("SERVICENAME"), rs.getString("SERVICENAME"), rs.getString("SERVICENAME"),
								rs.getString("SERVICENAME"), rs.getDate("CREATION_DATE"), ministry);
						return serviceDetailsInfoDTO;
					}
				});
		return returnedUsers;
	}

	/**
	 * GET NUMBWER OF SERVICES
	 * 
	 * @param ministry
	 * @return
	 */
	public Integer getNumberOfServiceByMinistry(String ministry) {
		Integer returnedUsers = jdbcTemplate.queryForObject("SELECT COUNT(DISTINCT SERVICENAME) AS \"SERVICECOUNT\" FROM "
				+ prop.getSchemaName() + ".ROLES WHERE ROLE_ID IN (" + "    SELECT ROLE_ID FROM " + prop.getSchemaName()
				+ ".USER_ROLE WHERE USER_ID IN (" + "        SELECT USER_ID FROM " + prop.getSchemaName()
				+ ".USERS WHERE MINISTRY='" + ministry + "'))", new MapSqlParameterSource(),Integer.class);
		return returnedUsers;

	}

	/**
	 * GET TOTAL NUMBWER OF SERVICES
	 * 
	 * @param ministry
	 * @return
	 */
	public Integer getTotalNumberOfServiceByMinistry() {
		Integer returnedUsers = jdbcTemplate.queryForObject("SELECT COUNT(DISTINCT SERVICENAME) AS \"SERVICECOUNT\" FROM "
				+ prop.getSchemaName() + ".ROLES WHERE ROLE_ID IN (" + "    SELECT ROLE_ID FROM " + prop.getSchemaName()
				+ ".USER_ROLE WHERE USER_ID IN (" + "        SELECT USER_ID FROM " + prop.getSchemaName() + ".USERS))",
				new MapSqlParameterSource(),Integer.class);
		return returnedUsers;

	}

	/**
	 * GET TOTAL NUMBWER OF SERVICES BY YEAR
	 * 
	 * @param YEAR
	 * @return
	 */
	public Integer getTotalNumberOfServiceByYear(String year) {
		Integer returnedUsers = jdbcTemplate.queryForObject("SELECT COUNT(DISTINCT SERVICENAME) AS \"SERVICECOUNT\" FROM "
				+ prop.getSchemaName() + ".ROLES WHERE ROLE_ID IN (" + "    SELECT ROLE_ID FROM " + prop.getSchemaName()
				+ ".USER_ROLE WHERE USER_ID IN (" + "        SELECT USER_ID FROM " + prop.getSchemaName()
				+ ".USERS WHERE YEAR(CREATION_DATE) = " + year + "))", new MapSqlParameterSource(),Integer.class);
		return returnedUsers;

	}

	/**
	 * GET TOTAL NUMBWER OF SERVICES BY YEAR AND MONTH
	 * 
	 * @param YEAR
	 * @return
	 */
	public Integer getTotalNumberOfServiceByYearMonth(String year, String month) {
		Integer returnedUsers = jdbcTemplate.queryForObject(
				"SELECT COUNT(DISTINCT SERVICENAME) AS \"SERVICECOUNT\" FROM " + prop.getSchemaName()
						+ ".ROLES WHERE ROLE_ID IN (" + "    SELECT ROLE_ID FROM " + prop.getSchemaName()
						+ ".USER_ROLE WHERE USER_ID IN (" + "        SELECT USER_ID FROM " + prop.getSchemaName()
						+ ".USERS WHERE YEAR(CREATION_DATE) = " + year + " AND MONTH(CREATION_DATE) = " + month + " ))",
				new MapSqlParameterSource(),Integer.class);
		return returnedUsers;

	}

	/**
	 * GET TOTAL NUMBWER OF HITS BY SERVICE NAME
	 * 
	 * @param YEAR
	 * @return
	 */
	public Integer getNumberOfHits(String serviceName) {
		Integer returnedUsers = jdbcTemplate.queryForObject(

				"select count(1) from " + prop.getSchemaName() + ".SOAPLOG WHERE WEBSERVICE_URL = '" + serviceName
						+ "'",
				new MapSqlParameterSource(),Integer.class);

		return returnedUsers;

	}

	/**
	 * GET ALL SERVICES NAME
	 * 
	 * @return
	 */
	public ArrayList<ServiceDetailsInfoDTO> getAllServicesName() {
		ArrayList<ServiceDetailsInfoDTO> returnedUsers = (ArrayList<ServiceDetailsInfoDTO>) jdbcTemplate.query(
				"SELECT DISTINCT SERVICENAME,CREATION_DATE ,MINISTRY " + "FROM " + prop.getSchemaName() + ".ROLES R "
						+ "INNER JOIN " + prop.getSchemaName() + ".USER_ROLE UR On R.ROLE_ID = UR.ROLE_ID "
						+ "INNER JOIN " + prop.getSchemaName() + ".USERS U ON UR.USER_ID = U.USER_ID ",
				new MapSqlParameterSource(), new RowMapper<ServiceDetailsInfoDTO>() {
					public ServiceDetailsInfoDTO mapRow(ResultSet rs, int i) throws SQLException {
						ServiceDetailsInfoDTO serviceDetailsInfoDTO = new ServiceDetailsInfoDTO(
								rs.getString("SERVICENAME"), rs.getString("SERVICENAME"), rs.getString("SERVICENAME"),
								rs.getString("SERVICENAME"), rs.getDate("CREATION_DATE"), rs.getString("MINISTRY"));
						return serviceDetailsInfoDTO;
					}
				});
		return returnedUsers;
	}

	/**
	 * GET ALL Ministies NAMEs
	 * 
	 * @return
	 */
	public ArrayList<String> getAllMinistriesName() {
		ArrayList<String> returnedUsers = (ArrayList<String>) jdbcTemplate.query(
				"SELECT NAME FROM " + prop.getSchemaName() + ".MINISTRY ",
				new MapSqlParameterSource(), new RowMapper<String>() {
					public String mapRow(ResultSet rs, int i) throws SQLException {
						return rs.getString("NAME");
					}
				});
		return returnedUsers;

	}

	
	/**
	 * GET ALL SERVICES NAME
	 * 
	 * @return
	 */
	public ArrayList<ServiceDetailsInfoDTO> getServicesInformationByName(String servicename) {
		ArrayList<ServiceDetailsInfoDTO> returnedUsers = (ArrayList<ServiceDetailsInfoDTO>) jdbcTemplate.query(
				"SELECT DISTINCT SERVICENAME,CREATION_DATE ,MINISTRY " + "FROM " + prop.getSchemaName() + ".ROLES R "
						+ "INNER JOIN " + prop.getSchemaName() + ".USER_ROLE UR On R.ROLE_ID = UR.ROLE_ID "
						+ "INNER JOIN " + prop.getSchemaName() + ".USERS U ON UR.USER_ID = U.USER_ID "
						+ "WHERE  SERVICENAME = '" + servicename + "'",
				new MapSqlParameterSource(), new RowMapper<ServiceDetailsInfoDTO>() {
					public ServiceDetailsInfoDTO mapRow(ResultSet rs, int i) throws SQLException {
						ServiceDetailsInfoDTO serviceDetailsInfoDTO = new ServiceDetailsInfoDTO(
								rs.getString("SERVICENAME"), rs.getString("SERVICENAME"), rs.getString("SERVICENAME"),
								rs.getString("SERVICENAME"), rs.getDate("CREATION_DATE"), rs.getString("MINISTRY"));
						return serviceDetailsInfoDTO;
					}
				});
		return returnedUsers;
	}
}
