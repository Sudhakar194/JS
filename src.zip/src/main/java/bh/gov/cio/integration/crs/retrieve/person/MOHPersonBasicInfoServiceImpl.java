package bh.gov.cio.integration.crs.retrieve.person;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.CRSEntity;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.model.person.Smartcard;
import bh.gov.cio.crs.model.unit.UnitActivity;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes.AgeGroup;
import bh.gov.cio.integration.common.DateServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.CRActivityInfoDTO;
import bh.gov.cio.integration.crs.retrieve.cr.service.dto.PersonActiveCRDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.MOHPersonBasicInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.MOHPersonBasicInfoDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.MOHPersonInfoDTO;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PersonFinancialSupportInfoDTO;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitActivityDTO;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitBasicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "MOHPersonBasicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "MOHPersonBasicInfoService"
public class MOHPersonBasicInfoServiceImpl implements MOHPersonBasicInfoServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(MOHPersonBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	// @Override
	@Secured({ "ROLE_getAllPersonBasicInfo" })
	@WebMethod(operationName = "getAllPersonBasicInfo")
	public MOHPersonBasicInfoDTO getAllPersonBasicInfo(SecurityTagObject security, Integer cprNumber,
			Integer blockNumber, Date cardExpiryDate) throws ApplicationExceptionInfo {
		MOHPersonBasicInfoDTO personBasicInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getAllPersonBasicInfo(Integer, Integer, Date) - start");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber)) {
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate)) {
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		// if (validationUtil.isMilitaryCpr(cprNumber))
		// {
		// throw new ApplicationExceptionInfo("UNAUTHORIZED",
		// new ApplicationException("UNAUTHORIZED"));
		// }
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try {
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499")
					|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			personBasicInfoDTO = new MOHPersonBasicInfoDTO(personBasicInfo.getAge() + "",
					personBasicInfo.getArabicName(), personBasicInfo.getCprNumber() + "",
					DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()),
					personSummeryInfo.getDateOfDeath() != null
							? DateServiceImpl.formatDate(personSummeryInfo.getDateOfDeath()) : "",
					personBasicInfo.getEnglishName(), personBasicInfo.getGender(), nationality,
					personBasicInfo.getPersonDisplayName(), personBasicInfo.getReligionCode(),
					personSummeryInfo.getMaritalStatusCode());

			if (logger.isDebugEnabled()) {
				logger.debug("getAllPersonBasicInfo(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("getAllPersonBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personBasicInfoDTO;
	}

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getPersonBasicInfoByCPR" })
	@WebMethod(operationName = "getPersonBasicInfo")
	public MOHPersonBasicInfoDTO getPersonBasicInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber,
			Date cardExpiryDate) throws ApplicationExceptionInfo {
		MOHPersonBasicInfoDTO personBasicInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonBasicInfo(Integer, Integer, Date) - start");
			logger.debug("getPersonBasicInfo(cprNumber = " + cprNumber + ", blockNumber = " + blockNumber
					+ ", cardExpiryDate = " + cardExpiryDate + ")");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber)) {
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate)) {
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
		}
		// if (validationUtil.isMilitaryCpr(cprNumber))
		// {
		// throw new ApplicationExceptionInfo("UNAUTHORIZED", new
		// ApplicationException("UNAUTHORIZED"));
		// }
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try {
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499")
					|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			personBasicInfoDTO = new MOHPersonBasicInfoDTO(personBasicInfo.getAge() + "",
					personBasicInfo.getArabicName(), personBasicInfo.getCprNumber() + "",
					DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()),
					personSummeryInfo.getDateOfDeath() != null
							? DateServiceImpl.formatDate(personSummeryInfo.getDateOfDeath()) : "",
					personBasicInfo.getEnglishName(), personBasicInfo.getGender(), nationality,
					personBasicInfo.getPersonDisplayName(), personBasicInfo.getReligionCode(),
					personSummeryInfo.getMaritalStatusCode());

			if (logger.isDebugEnabled()) {
				logger.debug("getPersonBasicInfo(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("getPersonBasicInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personBasicInfoDTO;
	}

	@Override
	@Secured(
	{ "ROLE_checkPersonInfo" })
	@WebMethod(operationName = "checkPersonInfo")
	public MOHPersonInfoDTO checkPersonInfo(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo
	{
		MOHPersonInfoDTO personBasicInfoDTO = null;
		if (logger.isDebugEnabled())
		{
			logger.debug("checkPersonInfo(Integer, Integer, Date) - start");
			logger.debug("checkPersonInfo(cprNumber = " + cprNumber + ", blockNumber = " + blockNumber + ", cardExpiryDate = " + cardExpiryDate
					+ ")");
		}

		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		{
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number","001"));
		}
		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
		{
			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date","002"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted","003"));
		}
		try
		{
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			personBasicInfoDTO = new MOHPersonInfoDTO(personBasicInfo.getArabicName(), personBasicInfo.getEnglishName(),
					personBasicInfo.getAge() <= 6 ? AgeGroup.Child : personBasicInfo.getAge() >= 60 ? AgeGroup.Elder : AgeGroup.Youth);

			if (logger.isDebugEnabled())
			{
				logger.debug("checkPersonInfo(Integer, Integer, Date) - end");
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("checkPersonInfo(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(exception.getMessage()));
		}
		return personBasicInfoDTO;
	}

	@Override
	@Secured({ "ROLE_getPersonBasicInfoByCPR" })
	@WebMethod(operationName = "getPersonBasicInfoByCPR")
	public MOHPersonBasicInfoDTO getPersonBasicInfoByCPR(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		MOHPersonBasicInfoDTO personBasicInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonBasicInfoByCPR(Integer, Integer, Date) - start");
			logger.debug("getPersonBasicInfoByCPR(cprNumber = " + cprNumber + ")");
		}
		if (validationUtil.isMilitaryCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Data Problem", new ApplicationException("CPR Data Problem"));
		}
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try {
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final Smartcard personSmartcard = getCrsService().getPersonServiceRef().getPersonLastSmartcard(cprNumber);
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499")
					|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";
			personBasicInfoDTO = new MOHPersonBasicInfoDTO(personBasicInfo.getAge() + "",
					personBasicInfo.getArabicName(), personBasicInfo.getCprNumber() + "",
					DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()),
					personSummeryInfo.getDateOfDeath() != null
							? DateServiceImpl.formatDate(personSummeryInfo.getDateOfDeath()) : "",
					personBasicInfo.getEnglishName(), personBasicInfo.getGender(), nationality,
					personBasicInfo.getPersonDisplayName(), personBasicInfo.getReligionCode(),
					personSummeryInfo.getMaritalStatusCode());

			String cardExpiryDate = null;
			if (personSmartcard != null && personSmartcard.getExpiryDate() != null) {

				SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd");
				cardExpiryDate = dt1.format(personSmartcard.getExpiryDate());
				personBasicInfoDTO.setCardExpiryDate(cardExpiryDate);
				logger.info("Card expiry " + personBasicInfoDTO.getCardExpiryDate());
			}
			// else
			// {
			// personBasicInfoDTO.setCardExpiryDate(" ");
			// }

			if (logger.isDebugEnabled()) {
				logger.debug("getPersonBasicInfoByCPR(Integer, Integer, Date) - end");
			}
		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("getPersonBasicInfoByCPR(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personBasicInfoDTO;
	}

	// @Override
	@Secured({ "ROLE_getPersonInfoForFS" })
	@WebMethod(operationName = "getPersonInfoForFS")
	public PersonFinancialSupportInfoDTO getPersonInfoForFS(SecurityTagObject security, Integer cprNumber)
			throws ApplicationExceptionInfo {
		PersonFinancialSupportInfoDTO personFSDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("getPersonInfoForFS(Integer) - start");
			logger.debug("getPersonInfoForFS(cprNumber = " + cprNumber + ")");
		}

		// if (validationUtil.isMilitaryCpr(cprNumber))
		// {
		// throw new ApplicationExceptionInfo("CPR Data Problem", new
		// ApplicationException("CPR Data Problem"));
		// }
		if (validationUtil.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try {
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			List<CRSEntity> ownedCRs = getCrsService().getPersonServiceRef().getPersonActiveOwnedCRs(cprNumber);
			List<CRSEntity> ownedUnits = getCrsService().getPersonServiceRef().getPersonOwnedUnits(cprNumber);

			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499")
					|| personSummeryInfo.getNationalityCountryCode().equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";

			// //Retrieving CR details

			if (logger.isDebugEnabled()) {
				logger.debug("getPersonInfoForFS() -  : ownedCRs.size() = " + ownedCRs.size());
			}
			PersonActiveCRDTO[] ownedCRsList = new PersonActiveCRDTO[ownedCRs.size()];

			int CRCount = 0;

			for (CRSEntity crsEntity : ownedCRs) {
				CRSEntity cr = (crsEntity);

				List<UnitActivity> unitActivity = getCrsService().getUnitServiceRef()
						.getCrActivities(cr.getEntityNumber());

				List<CRActivityInfoDTO> crActivityDTO = new ArrayList<CRActivityInfoDTO>();
				for (UnitActivity unitActivity2 : unitActivity) {
					UnitActivity tempUnitActivity = (unitActivity2);
					CRActivityInfoDTO tempUnitActivityDTO = new CRActivityInfoDTO();
					tempUnitActivityDTO.setActivityCode(tempUnitActivity.getMainActivityCode());
					tempUnitActivityDTO.setActivityArNm(tempUnitActivity.getMainActivityArNm());
					tempUnitActivityDTO.setActivityEnNm(tempUnitActivity.getMainActivityEnNm());

					crActivityDTO.add(tempUnitActivityDTO);
				}
				if (logger.isDebugEnabled()) {
					logger.debug("getPersonInfoForFS() -  : ownedCRsList = " + ownedCRsList);
				}

				ownedCRsList[CRCount] = new PersonActiveCRDTO(cr.getEntityNumber(), cr.getEntityName(),
						cr.getEntityEnglishName(), crActivityDTO);

				CRCount++;

			}

			UnitBasicInfoDTO[] ownedUnitssList = new UnitBasicInfoDTO[ownedUnits.size()];

			if (logger.isDebugEnabled()) {
				logger.debug("getPersonInfoForFS() -  : ownedUnits = " + ownedUnits.size());
			}

			// //Retrieving unit details
			int unitCount = 0;

			for (CRSEntity crsEntity : ownedUnits) {
				CRSEntity unit = (crsEntity);

				List<UnitActivity> unitActivity = getCrsService().getUnitServiceRef()
						.getUnitActivities(unit.getEntityNumber());
				List<UnitActivityDTO> unitActivityDTO = new ArrayList<UnitActivityDTO>();
				for (UnitActivity unitActivity2 : unitActivity) {
					UnitActivity tempUnitActivity = (unitActivity2);
					UnitActivityDTO tempUnitActivityDTO = new UnitActivityDTO();
					tempUnitActivityDTO.setActivityCode(tempUnitActivity.getMainActivityCode());
					tempUnitActivityDTO.setActivityArabicName(tempUnitActivity.getMainActivityArNm());

					tempUnitActivityDTO.setActivityEnglishName(tempUnitActivity.getMainActivityEnNm());

					unitActivityDTO.add(tempUnitActivityDTO);
				}
				if (logger.isDebugEnabled()) {
					logger.debug("getPersonInfoForFS() -  : unit = " + unit);
				}

				ownedUnitssList[unitCount] = new UnitBasicInfoDTO(unit.getEntityNumber(), unit.getEntityName(),
						unit.getEntityEnglishName(), unitActivityDTO);
				unitCount++;

			}

			personFSDTO = new PersonFinancialSupportInfoDTO(cprNumber, personSummeryInfo.getArabicFirstName(),
					personSummeryInfo.getArabicMiddleName1(), personSummeryInfo.getArabicMiddleName2(),
					personSummeryInfo.getArabicMiddleName3(), personSummeryInfo.getArabicFamilyName(),
					personSummeryInfo.getEnglishFirstName(), personSummeryInfo.getEnglishMiddleName1(),
					personSummeryInfo.getEnglishMiddleName2(), personSummeryInfo.getEnglishMiddleName3(),
					personSummeryInfo.getEnglishFamilyName(), personBasicInfo.getAge() + "",
					DateServiceImpl.formatDate(personBasicInfo.getDateOfBirth()),
					personSummeryInfo.getDateOfDeath() != null
							? DateServiceImpl.formatDate(personSummeryInfo.getDateOfDeath()) : "",
					personBasicInfo.getGender(), nationality, personBasicInfo.getReligionCode(),
					personSummeryInfo.getMaritalStatusCode(), personSummeryInfo.getLabourParticipationTypeCode(),
					ownedCRsList, ownedUnitssList);

			if (logger.isDebugEnabled()) {
				logger.debug("getPersonInfoForFS(Integer) - end");
			}
		} catch (final Exception exception) {
			if (logger.isDebugEnabled()) {
				logger.error("getPersonInfoForFS(Integer Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found",
					new ApplicationException(exception.getMessage()));
		}
		return personFSDTO;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}
}
