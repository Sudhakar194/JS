package bh.gov.cio.integration.crs.retrieve.family.rco.service.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "FatherInfoDTO", propOrder =
{ "arabicName", "englishName", "dateOfDeath",
		"isAlive" })
public class FatherInfoDTO
{
	String arabicName,englishName; 
	Date dateOfDeath;
	Boolean isAlive;
	public FatherInfoDTO() {
		super();
	}
	public FatherInfoDTO(String arabicName, String englishName, Date dateOfDeath, Boolean isAlive) {
		super();
		this.arabicName = arabicName;
		this.englishName = englishName;
		this.dateOfDeath = dateOfDeath;
		this.isAlive = isAlive;
	}
	public String getArabicName() {
		return arabicName;
	}
	public void setArabicName(String arabicName) {
		this.arabicName = arabicName;
	}
	public String getEnglishName() {
		return englishName;
	}
	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}
	public Date getDateOfDeath() {
		return dateOfDeath;
	}
	public void setDateOfDeath(Date dateOfDeath) {
		this.dateOfDeath = dateOfDeath;
	}
	public Boolean getIsAlive() {
		return isAlive;
	}
	public void setIsAlive(Boolean isAlive) {
		this.isAlive = isAlive;
	}
}
