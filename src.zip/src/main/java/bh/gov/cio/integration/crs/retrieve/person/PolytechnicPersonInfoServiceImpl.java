package bh.gov.cio.integration.crs.retrieve.person;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;

import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.service.PolytechnicPersonInfoServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.service.dto.PolytechnicPersonInfoDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PolytechnicPersonInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonBasicInfoService"
public class PolytechnicPersonInfoServiceImpl implements PolytechnicPersonInfoServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PolytechnicPersonInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;


	@Override
	@Secured(
	{ "ROLE_getPersonInfoByCPR" })
	@WebMethod(operationName = "getPersonInfoByCPR")
	public PolytechnicPersonInfoDTO getPersonInfoByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{
		PolytechnicPersonInfoDTO polytechnicPersonInfoDTO = null;
		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonInfoByCPR(Integer) - start");
			logger.debug("getPersonInfoByCPR(cprNumber = " + cprNumber + ")");
		}

		// if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
		// throw new ApplicationExceptionInfo("Block Number",
		// new ApplicationException("Wrong Block Number"));
		// if (!validationUtil.hasValidExpiryCardData(cprNumber,
		// cardExpiryDate))
		// throw new ApplicationExceptionInfo("Expiry Date",
		// new ApplicationException("Wrong Expiry Date"));
		if (validationUtil.isMilitaryCpr(cprNumber))
		{
			logger.debug("MILITARY");
			throw new ApplicationExceptionInfo("CPR Data Problem", new ApplicationException("CPR Data Problem"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			logger.debug("DELETED");
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		try
		{
			final PersonBasicInfo personBasicInfo = getCrsService().getPersonServiceRef().getPersonBasicInfo(cprNumber);
			final PersonSummary personSummeryInfo = getCrsService().getPersonServiceRef().getPersonSummary(cprNumber);
			final boolean isBahraini = (personSummeryInfo.getNationalityCountryCode().equals("499") || personSummeryInfo.getNationalityCountryCode()
					.equals("900")) ? true : false;
			final boolean isGCC = (!isBahraini && personSummeryInfo.isGcc()) ? true : false;
			String nationality = isBahraini ? "BH" : isGCC ? "GCC" : "NONGCC";

			String arabicFirstName = StringUtils.hasText(personSummeryInfo.getArabicFirstName())? personSummeryInfo.getArabicFirstName() : "";
			String arabicFamilyName = StringUtils.hasText(personSummeryInfo.getArabicFamilyName() ) ? personSummeryInfo.getArabicFamilyName() : "";
			String arabicMiddlename = (StringUtils.hasText(personSummeryInfo.getArabicMiddleName1()) ?  personSummeryInfo.getArabicMiddleName1().trim()+ " " : "" ) +
										(StringUtils.hasText(personSummeryInfo.getArabicMiddleName2()) ?  personSummeryInfo.getArabicMiddleName2().trim()+" " : "" ) +
										(StringUtils.hasText(personSummeryInfo.getArabicMiddleName3()) ?  personSummeryInfo.getArabicMiddleName3().trim()+" " : "" ) +
										(StringUtils.hasText(personSummeryInfo.getArabicMiddleName4()) ?  personSummeryInfo.getArabicMiddleName4().trim() : "" );
			
			String englishFirstName = StringUtils.hasText(personSummeryInfo.getEnglishFirstName() ) ? personSummeryInfo.getEnglishFirstName() : "";
			String englishFamilyName = StringUtils.hasText(personSummeryInfo.getEnglishFamilyName() ) ? personSummeryInfo.getEnglishFamilyName() : "";
			String englishMiddlename = (StringUtils.hasText(personSummeryInfo.getEnglishMiddleName1()) ?  personSummeryInfo.getEnglishMiddleName1().trim()+" " : "" ) +
										(StringUtils.hasText(personSummeryInfo.getEnglishMiddleName2()) ?  personSummeryInfo.getEnglishMiddleName2().trim()+" " : "" ) +
										(StringUtils.hasText(personSummeryInfo.getEnglishMiddleName3()) ?  personSummeryInfo.getEnglishMiddleName3().trim()+" " : "" ) +
										(StringUtils.hasText(personSummeryInfo.getEnglishMiddleName4()) ?  personSummeryInfo.getEnglishMiddleName4().trim()+" " : "" );
			
			polytechnicPersonInfoDTO = new PolytechnicPersonInfoDTO(cprNumber,arabicFirstName,englishFirstName, arabicMiddlename ,
					englishMiddlename,arabicFamilyName,englishFamilyName, personBasicInfo.getGender(), nationality);
			
			
			
			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonInfoByCPR(Integer) - end");
			}
		}
		catch (final Exception exception)
		{
			exception.printStackTrace();
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonInfoByCPR(Integer,) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Basic Details Not found", new ApplicationException(exception.getMessage()));
		}
		return polytechnicPersonInfoDTO;
	}
	
	
	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}


	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil()
	{
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService)
	{
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil)
	{
		this.validationUtil = validationUtil;
	}
}
