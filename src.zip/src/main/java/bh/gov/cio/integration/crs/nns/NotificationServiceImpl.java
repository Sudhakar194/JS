package bh.gov.cio.integration.crs.nns;

import java.util.ArrayList;
import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import com.bnaf.validate.token.ws.ValidateToken;
import com.bnaf.validate.token.ws.util.CryptoUtil;

import bh.gov.cio.crs.model.person.NotificationInformation;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.CommonTypes;
import bh.gov.cio.integration.common.PropertyServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.nns.dto.IdInputParamDTO;
import bh.gov.cio.integration.crs.nns.dto.IdOnlyInputParamDTO;
import bh.gov.cio.integration.crs.nns.dto.NotificationValidationInfoDTO;
import bh.gov.cio.integration.crs.nns.dto.NotificationValidationInfoListDTO;
import bh.gov.cio.integration.crs.nns.dto.StatusResponseDTO;
import bh.gov.cio.integration.crs.nns.service.NNSServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "NnsService", targetNamespace = "http://service.nns.crs.integration.cio.gov.bh/") // ,
																										// serviceName
																										// =
																										// "NnsService"
public class NotificationServiceImpl implements NNSServiceInterface, CommonTypes {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(NotificationServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationService;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;
	@Autowired
	private PropertyServiceImpl propImpl;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	// *****************************************************************************************************//
	// |
	// 1. Authenticate Citizen With EKey |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "authenticatePersonNotificationInfoWithEKey")
	public NotificationValidationInfoDTO authenticatePersonNotificationInfoWithEKey(SecurityTagObject security,
			String idNumber, String cardCountry, String idType, String eKeyIDNumber, String eKeyServiceID,
			String eKeyTokenID, String eKeyTimestamp) throws ApplicationExceptionInfo {
		NotificationValidationInfoDTO notificationValidationInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("authenticatePersonNotificationInfo(String, String, String) - start");
		}
		if (!checkeKeyResponse(eKeyIDNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp)) {
			throw new ApplicationExceptionInfo("Error in retrieving data...",
					new ApplicationException("Authentication Failed.", "001"));
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}
		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.getIsPersonRegisteredForNotificationService(idNumber, cardCountry, idType);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getPersonNotificationInfoById(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0011")) {
			throw new ApplicationExceptionInfo("PERSON ALREADY REGISTERED",
					new ApplicationException("PERSON ALREADY REGISTERED", "011"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		notificationValidationInfoDTO = new NotificationValidationInfoDTO(notificationInfo.getIsRegistered(),
				notificationInfo.getNameArabic(), notificationInfo.getNameEnglish(),
				notificationInfo.getPrimaryPhoneNumber(), notificationInfo.getSecondaryPhoneNumber(),
				notificationInfo.getPrimaryEmail(), notificationInfo.getPrimaryEmailStatus(),
				notificationInfo.getSecondaryEmail(), notificationInfo.getSecondaryEmailStatus());

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNotificationInfoById(String, String, String) - End");
		}
		return notificationValidationInfoDTO;
	}

	// *****************************************************************************************************//
	// |
	// 2. Authenticate Citizen With (Block + CardExpiry) for Bahraini OR Block
	// Only For GCC |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "authenticatePersonNotificationInfo")
	public NotificationValidationInfoDTO authenticatePersonNotificationInfo(SecurityTagObject security, String idNumber,
			String cardCountry, String idType, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo {
		NotificationValidationInfoDTO notificationValidationInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("authenticatePersonNotificationInfo(String, String, String) - start");
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}
		if (!validationService.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number", "007"));

		// Validate Card Expiry Only For Bahraini
		if (cardCountry == null || "".equals(cardCountry.trim()) || cardCountry.equalsIgnoreCase("499")) {
			if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date", "013"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.getIsPersonRegisteredForNotificationService(idNumber, cardCountry, idType);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getPersonNotificationInfoById(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		notificationValidationInfoDTO = new NotificationValidationInfoDTO(notificationInfo.getIsRegistered(),
				notificationInfo.getNameArabic(), notificationInfo.getNameEnglish(),
				notificationInfo.getPrimaryPhoneNumber(), notificationInfo.getSecondaryPhoneNumber(),
				notificationInfo.getPrimaryEmail(), notificationInfo.getPrimaryEmailStatus(),
				notificationInfo.getSecondaryEmail(), notificationInfo.getSecondaryEmailStatus());

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNotificationInfoById(String, String, String) - End");
		}
		return notificationValidationInfoDTO;
	}

	// *****************************************************************************************************//
	// |
	// 3.(a) Register New With E-Key Data |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "registerPersonNoticationInformationWithEKey")
	public StatusResponseDTO registerPersonNoticationInformationWithEKey(SecurityTagObject security, String cardCountry,
			String idType, String eKeyIDNumber, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp,
			String primaryPhone, String secondaryPhone, String primaryEmail, String secondaryEmail, String username)
			throws ApplicationExceptionInfo {
		StatusResponseDTO registerationResponseDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("registerPersonNoticationInformationWithEKey(String, String, String) - start");
		}
		if (!checkeKeyResponse(eKeyIDNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp)) {
			throw new ApplicationExceptionInfo("Error in retrieving data...",
					new ApplicationException("Authentication Failed.", "001"));
		}

		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(eKeyIDNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.registerPersonNoticationInformation(eKeyIDNumber, cardCountry, idType, primaryPhone,
					secondaryPhone, primaryEmail, secondaryEmail, username);

			logger.debug("primary phone update: " + primaryPhone + "secondary phone: " + secondaryPhone);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("updatePersonNoticationPhoneInformation(Integer,String, String, String) Error: "
						+ exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		registerationResponseDTO = new StatusResponseDTO("000", "SUCCESS");

		if (logger.isDebugEnabled()) {
			logger.debug("updatePersonNoticationPhoneInformation(Integer,String, String, String) - End");
		}
		return registerationResponseDTO;
	}

	// *****************************************************************************************************//
	// |
	// 3.(b) Register New With (Block + CardExpiry) for Bahraini OR Block Only
	// For GCC |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "registerPersonNoticationInformation")
	public StatusResponseDTO registerPersonNoticationInformation(SecurityTagObject security, String idNumber,
			String cardCountry, String idType, Integer blockNumber, Date cardExpiryDate, String primaryPhone,
			String secondaryPhone, String primaryEmail, String secondaryEmail, String username)
			throws ApplicationExceptionInfo {
		StatusResponseDTO registerationResponseDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("registerPersonNoticationInformation(String, String, String) - start");
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}
		if (!validationService.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number", "007"));

		// Validate Card Expiry Only For Bahraini
		if (cardCountry == null || "".equals(cardCountry.trim()) || cardCountry.equalsIgnoreCase("499")) {
			if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date", "013"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.registerPersonNoticationInformation(idNumber, cardCountry, idType, primaryPhone,
					secondaryPhone, primaryEmail, secondaryEmail, username);

			logger.debug("primary phone update: " + primaryPhone + "secondary phone: " + secondaryPhone);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("updatePersonNoticationPhoneInformation(Integer,String, String, String) Error: "
						+ exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		registerationResponseDTO = new StatusResponseDTO("000", "SUCCESS");

		if (logger.isDebugEnabled()) {
			logger.debug("updatePersonNoticationPhoneInformation(Integer,String, String, String) - End");
		}
		return registerationResponseDTO;
	}

	// *****************************************************************************************************//
	// |
	// 4. Verify And Update Email without check EKey Or 3 Factor |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "verifyAndUpdatePersonNoticationEmailInformation")
	public StatusResponseDTO verifyAndUpdatePersonNoticationEmailInformation(SecurityTagObject security,
			String idNumber, String cardCountry, String idType, String primaryPhone, String email,
			String isPrimaryEmail, String username) throws ApplicationExceptionInfo {
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.updatePersonNoticationEmailInformation(idNumber, cardCountry, idType, primaryPhone,
					email, isPrimaryEmail, username);

			logger.debug("primary phone update: " + primaryPhone);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("updatePersonNoticationPhoneInformation(Integer,String, String, String) Error: "
						+ exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-9999")) {
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		StatusResponseDTO statusResponseDTO = new StatusResponseDTO("000", "SUCCESS");

		return statusResponseDTO;
	}

	// *****************************************************************************************************//
	// |
	// 5.(a) Fetch Data With E-Key Data |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "getPersonNotificationInfoWithEkey")
	public NotificationValidationInfoDTO getPersonNotificationInfoWithEkey(SecurityTagObject security, String idType,
			String cardCountry, String eKeyIDNumber, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp)
			throws ApplicationExceptionInfo {
		NotificationValidationInfoDTO notificationValidationInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("authenticatePersonNotificationInfo(String, String, String) - start");
		}
		if (!checkeKeyResponse(eKeyIDNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp)) {
			throw new ApplicationExceptionInfo("Error in retrieving data...",
					new ApplicationException("Authentication Failed.", "001"));
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(eKeyIDNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.getPersonNotificationInformation(eKeyIDNumber, cardCountry, idType);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getPersonNotificationInfoById(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		notificationValidationInfoDTO = new NotificationValidationInfoDTO(notificationInfo.getIsRegistered(),
				notificationInfo.getNameArabic(), notificationInfo.getNameEnglish(),
				notificationInfo.getPrimaryPhoneNumber(), notificationInfo.getSecondaryPhoneNumber(),
				notificationInfo.getPrimaryEmail(), notificationInfo.getPrimaryEmailStatus(),
				notificationInfo.getSecondaryEmail(), notificationInfo.getSecondaryEmailStatus());

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNotificationInfoById(String, String, String) - End");
		}
		return notificationValidationInfoDTO;
	}

	// *****************************************************************************************************//
	// |
	// 5.(B) Fetch Data With 3 Factor Data |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "getPersonNotificationInfo")
	public NotificationValidationInfoDTO getPersonNotificationInfo(SecurityTagObject security, String idNumber,
			String idType, String cardCountry, Integer blockNumber, Date cardExpiryDate)
			throws ApplicationExceptionInfo {
		NotificationValidationInfoDTO notificationValidationInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("authenticatePersonNotificationInfo(String, String, String) - start");
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}
		if (!validationService.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number", "007"));

		// Validate Card Expiry Only For Bahraini
		if (cardCountry == null || "".equals(cardCountry.trim()) || cardCountry.equalsIgnoreCase("499")) {
			if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date", "013"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.getPersonNotificationInformation(cprNumber + "", cardCountry, idType);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getPersonNotificationInfoById(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		notificationValidationInfoDTO = new NotificationValidationInfoDTO(notificationInfo.getIsRegistered(),
				notificationInfo.getNameArabic(), notificationInfo.getNameEnglish(),
				notificationInfo.getPrimaryPhoneNumber(), notificationInfo.getSecondaryPhoneNumber(),
				notificationInfo.getPrimaryEmail(), notificationInfo.getPrimaryEmailStatus(),
				notificationInfo.getSecondaryEmail(), notificationInfo.getSecondaryEmailStatus());

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNotificationInfoById(String, String, String) - End");
		}
		return notificationValidationInfoDTO;
	}

	// *****************************************************************************************************//
	// |
	// 5.(C) Fetch Data With ID Only upon ammar request with different role |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccessByID" })
	@WebMethod(operationName = "getPersonNotificationInfoByID")
	public NotificationValidationInfoDTO getPersonNotificationInfoByID(SecurityTagObject security, String idNumber,
			String idType, String cardCountry) throws ApplicationExceptionInfo {
		NotificationValidationInfoDTO notificationValidationInfoDTO = null;
		if (logger.isDebugEnabled()) {
			logger.debug("authenticatePersonNotificationInfo(String, String, String) - start");
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.getPersonNotificationInformation(cprNumber + "", cardCountry, idType);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getPersonNotificationInfoById(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		notificationValidationInfoDTO = new NotificationValidationInfoDTO(notificationInfo.getIsRegistered(),
				notificationInfo.getNameArabic(), notificationInfo.getNameEnglish(),
				notificationInfo.getPrimaryPhoneNumber(), notificationInfo.getSecondaryPhoneNumber(),
				notificationInfo.getPrimaryEmail(), notificationInfo.getPrimaryEmailStatus(),
				notificationInfo.getSecondaryEmail(), notificationInfo.getSecondaryEmailStatus());

		if (logger.isDebugEnabled()) {
			logger.debug("getPersonNotificationInfoById(String, String, String) - End");
		}
		return notificationValidationInfoDTO;
	}

	// *****************************************************************************************************//
	// |
	// 6.(a) Update With E-Key Data |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "updatePersonNoticationInformationWithEkey")
	public StatusResponseDTO updatePersonNoticationInformationWithEkey(SecurityTagObject security, String cardCountry,
			String idType, String eKeyIDNumber, String eKeyServiceID, String eKeyTokenID, String eKeyTimestamp,
			String primaryPhone, String isPrimaryPhoneUpdated, String secondaryPhone, String isSecondaryPhoneUpdated,
			String primaryEmail, String isPrimaryEmailUpdated, String secondaryEmail, String isSecondaryEmailUpdated,
			String username) throws ApplicationExceptionInfo {
		if (!checkeKeyResponse(eKeyIDNumber, eKeyServiceID, eKeyTokenID, eKeyTimestamp)) {
			throw new ApplicationExceptionInfo("Error in retrieving data...",
					new ApplicationException("Authentication Failed.", "001"));
		}
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(eKeyIDNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.updatePersonNoticationInformation(eKeyIDNumber, cardCountry, idType, primaryPhone,
					isPrimaryPhoneUpdated, secondaryPhone, isSecondaryPhoneUpdated, primaryEmail, isPrimaryEmailUpdated,
					secondaryEmail, isSecondaryEmailUpdated, username);
			logger.debug("primary phone update: " + primaryPhone + "secondary phone: " + secondaryPhone);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("updatePersonNoticationPhoneInformation(Integer,String, String, String) Error: "
						+ exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		StatusResponseDTO statusResponseDTO = new StatusResponseDTO("000", "SUCCESS");
		return statusResponseDTO;
	}

	// *****************************************************************************************************//
	// |
	// 6.(b) Update With (Block + CardExpiry) for Bahraini OR Block Only For GCC
	// |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "updatePersonNoticationInformation")
	public StatusResponseDTO updatePersonNoticationInformation(SecurityTagObject security, String idNumber,
			String cardCountry, String idType, Integer blockNumber, Date cardExpiryDate, String primaryPhone,
			String isPrimaryPhoneUpdated, String secondaryPhone, String isSecondaryPhoneUpdated, String primaryEmail,
			String isPrimaryEmailUpdated, String secondaryEmail, String isSecondaryEmailUpdated, String username)
			throws ApplicationExceptionInfo {
		Integer cprNumber = 0;
		try {
			cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
		} catch (Exception e) {
			throw new ApplicationExceptionInfo("Entered ID Not Valid",
					new ApplicationException("Entered ID Not Valid", "002"));
		}

		if (validationService.isDeletedCpr(cprNumber)) {
			throw new ApplicationExceptionInfo("CPR Number Deleted",
					new ApplicationException("CPR Number Deleted", "014"));
		}
		if (!validationService.hasValidBlock(cprNumber, blockNumber))
			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number", "007"));

		// Validate Card Expiry Only For Bahraini
		if (cardCountry == null || "".equals(cardCountry.trim()) || cardCountry.equalsIgnoreCase("499")) {
			if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
				throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date", "013"));
		}

		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;

		try {

			notificationInfo = ps.updatePersonNoticationInformation(idNumber, cardCountry, idType, primaryPhone,
					isPrimaryPhoneUpdated, secondaryPhone, isSecondaryPhoneUpdated, primaryEmail, isPrimaryEmailUpdated,
					secondaryEmail, isSecondaryEmailUpdated, username);
			logger.debug("primary phone update: " + primaryPhone + "secondary phone: " + secondaryPhone);

		} catch (final Exception exception) {
			exception.printStackTrace();
			if (logger.isDebugEnabled()) {
				logger.error("getPersonNotificationInfoById(String, String, String) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Notification Info  Not found",
					new ApplicationException("Notification Info  Not found", "012"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
			throw new ApplicationExceptionInfo("MISSING DETAILS", new ApplicationException("MISSING DETAILS", "004"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
			throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
					new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
			throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
					new ApplicationException("PERSON IS NOT ALIVE", "006"));
		}
		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
			throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
					new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
		}

		if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
			throw new ApplicationExceptionInfo("EMAIL NOT FOUND", new ApplicationException("EMAIL NOT FOUND", "010"));
		}
		StatusResponseDTO statusResponseDTO = new StatusResponseDTO("000", "SUCCESS");

		return statusResponseDTO;
	}

	// *****************************************************************************************************//
	// |
	// Addition - Not In the Document |
	// 7. Retrieve List Of Notification Information By ID Number And Id Type |
	// |
	// *****************************************************************************************************//
	@Override
	@Secured({ "ROLE_hasNotificationAccess" })
	@WebMethod(operationName = "getPersonNotificationInfoByIdsList")
	public ArrayList<NotificationValidationInfoListDTO> getPersonNotificationInfoByIdsList(SecurityTagObject security,
			ArrayList<IdInputParamDTO> ids) throws ApplicationExceptionInfo {
		ArrayList<NotificationValidationInfoListDTO> NotificationInfoList = new ArrayList<NotificationValidationInfoListDTO>();
		NotificationValidationInfoListDTO notificationValidationInfoListDTO = new NotificationValidationInfoListDTO();
		for (IdInputParamDTO idInputParamDTO : ids) {

			try {
				NotificationValidationInfoDTO notificationValidationInfoDTO = new NotificationValidationInfoDTO();
				notificationValidationInfoDTO = authenticatePersonNotificationInfo(security,
						idInputParamDTO.getIdNumber(), idInputParamDTO.getCardCountryCode(),
						idInputParamDTO.getIdType(), idInputParamDTO.getBlockNumber(), idInputParamDTO.getExpiryDate());
				notificationValidationInfoListDTO = new NotificationValidationInfoListDTO(idInputParamDTO.getIdNumber(),
						notificationValidationInfoDTO.getIsRegistered(), notificationValidationInfoDTO.getArabicName(),
						notificationValidationInfoDTO.getEnglishName(),
						notificationValidationInfoDTO.getPrimaryMobile(),
						notificationValidationInfoDTO.getSecondaryMobile(),
						notificationValidationInfoDTO.getPrimaryEmail(),
						notificationValidationInfoDTO.getPrimaryEmailStatus(),
						notificationValidationInfoDTO.getSecondaryEmail(),
						notificationValidationInfoDTO.getSecondaryEmailStatus(), "000", "SUCCESS");
			} catch (ApplicationExceptionInfo e) {
				// notificationValidationInfoDTO = new
				// NotificationValidationInfoDTO();
				notificationValidationInfoListDTO = new NotificationValidationInfoListDTO(idInputParamDTO.getIdNumber(),
						"", "", "", "", "", "", "", "", "", e.getFaultInfo().getCode(), e.getFaultInfo().getMessage());
			}
			NotificationInfoList.add(notificationValidationInfoListDTO);
		}

		return NotificationInfoList;
	}

	@Override
	@Secured({ "ROLE_hasNotificationAccessByID" })
	@WebMethod(operationName = "getPersonNotificationInfoByIdsOnlyList")
	public ArrayList<NotificationValidationInfoListDTO> getPersonNotificationInfoByIdsOnlyList(
			SecurityTagObject security, ArrayList<IdOnlyInputParamDTO> ids) throws ApplicationExceptionInfo {
		ArrayList<NotificationValidationInfoListDTO> NotificationInfoList = new ArrayList<NotificationValidationInfoListDTO>();
		NotificationValidationInfoListDTO notificationValidationInfoListDTO = new NotificationValidationInfoListDTO();
		PersonService ps = crsService.getPersonServiceRef();
		NotificationInformation notificationInfo = null;
		NotificationValidationInfoDTO notificationValidationInfoDTO = new NotificationValidationInfoDTO();
		for (IdOnlyInputParamDTO idInputParamDTO : ids) {

			try {

				try {
					// notificationValidationInfoDTO =
					// getPersonNotificationInfoByID(security,
					// idInputParamDTO.getIdNumber(),idInputParamDTO.getIdType()
					// ,idInputParamDTO.getCardCountryCode() );
					notificationInfo = ps.getIsPersonRegisteredForNotificationService(idInputParamDTO.getIdNumber(),
							idInputParamDTO.getCardCountryCode(), idInputParamDTO.getIdType());

				} catch (final Exception exception) {
					exception.printStackTrace();
					if (logger.isDebugEnabled()) {
						logger.error("getPersonNotificationInfoById(String, String, String) Error: "
								+ exception.getMessage());
					}
					throw new ApplicationExceptionInfo("Notification Info  Not found",
							new ApplicationException("Notification Info  Not found", "012"));
				}
				if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0004")) {
					throw new ApplicationExceptionInfo("MISSING DETAILS",
							new ApplicationException("MISSING DETAILS", "004"));
				}
				if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0005")) {
					throw new ApplicationExceptionInfo("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)",
							new ApplicationException("PERSON ID NUMBER IS INVALID (NO PERSON/DELETED)", "005"));
				}
				if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0006")) {
					throw new ApplicationExceptionInfo("PERSON IS NOT ALIVE",
							new ApplicationException("PERSON IS NOT ALIVE", "006"));
				}
				if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0008")) {
					throw new ApplicationExceptionInfo("MOBILE NOT FOUND/ NOT REGISTERED",
							new ApplicationException("MOBILE NOT FOUND/ NOT REGISTERED", "008"));
				}
				if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0011")) {
					throw new ApplicationExceptionInfo("PERSON ALREADY REGISTERED",
							new ApplicationException("PERSON ALREADY REGISTERED", "011"));
				}

				if (notificationInfo.getStatusCode().equalsIgnoreCase("NGINS-0010")) {
					throw new ApplicationExceptionInfo("EMAIL NOT FOUND",
							new ApplicationException("EMAIL NOT FOUND", "010"));
				}

				notificationValidationInfoDTO = new NotificationValidationInfoDTO(notificationInfo.getIsRegistered(),
						notificationInfo.getNameArabic(), notificationInfo.getNameEnglish(),
						notificationInfo.getPrimaryPhoneNumber(), notificationInfo.getSecondaryPhoneNumber(),
						notificationInfo.getPrimaryEmail(), notificationInfo.getPrimaryEmailStatus(),
						notificationInfo.getSecondaryEmail(), notificationInfo.getSecondaryEmailStatus());

				notificationValidationInfoListDTO = new NotificationValidationInfoListDTO(idInputParamDTO.getIdNumber(),
						notificationValidationInfoDTO.getIsRegistered(), notificationValidationInfoDTO.getArabicName(),
						notificationValidationInfoDTO.getEnglishName(),
						notificationValidationInfoDTO.getPrimaryMobile(),
						notificationValidationInfoDTO.getSecondaryMobile(),
						notificationValidationInfoDTO.getPrimaryEmail(),
						notificationValidationInfoDTO.getPrimaryEmailStatus(),
						notificationValidationInfoDTO.getSecondaryEmail(),
						notificationValidationInfoDTO.getSecondaryEmailStatus(), "000", "SUCCESS");
			} catch (ApplicationExceptionInfo e) {
				notificationValidationInfoListDTO = new NotificationValidationInfoListDTO(idInputParamDTO.getIdNumber(),
						"", "", "", "", "", "", "", "", "", e.getFaultInfo().getCode(), e.getFaultInfo().getMessage());
			}
			NotificationInfoList.add(notificationValidationInfoListDTO);
		}

		return NotificationInfoList;
	}

	// @Override
	// @Secured({ "ROLE_getPersonNotificationInfo" })
	// @WebMethod(operationName = "getPersonNotificationInfoById")
	//
	// public NotificationInfoDTO
	// getPersonNotificationInfoById(SecurityTagObject security, String
	// idNumber,
	// String cardCountry, String idType) throws ApplicationExceptionInfo {
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfoById(String, String, String) -
	// start");
	// }
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (validationService.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "014"));
	// }
	//
	// PersonService ps = crsService.getPersonServiceRef();
	// NotificationInformation notificationInfo = null;
	//
	// try {
	//
	// notificationInfo = ps.getPersonNotificationInformation(idNumber,
	// cardCountry, idType);
	//
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("getPersonNotificationInfoById(String, String, String)
	// Error: " + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// notificationInfoDTO = new NotificationInfoDTO(idNumber, cardCountry,
	// notificationInfo.getPrimaryPhoneNumber(),
	// notificationInfo.getSecondaryPhoneNumber(),
	// notificationInfo.getPrimaryEmail(),
	// notificationInfo.getSecondaryEmail(), notificationInfo.getStatusCode(),
	// notificationInfo.getStatusMessage());
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfoById(String, String, String) -
	// End");
	// }
	// return notificationInfoDTO;
	// }
	//
	// @Override
	// @Secured({ "ROLE_getPersonNotificationInfo" })
	// @WebMethod(operationName = "getPersonNotificationInfoListById")
	// public ArrayList<NotificationInfoDTO>
	// getPersonNotificationInfoListById(SecurityTagObject security,
	// ArrayList<IdInputParamDTO> ids, String idType) throws
	// ApplicationExceptionInfo {
	//
	// ArrayList<NotificationInfoDTO> NotificationInfoList = new
	// ArrayList<NotificationInfoDTO>();
	//
	// for (IdInputParamDTO idInputParamDTO : ids) {
	// NotificationInfoList.add(getPersonNotificationInfoById(security,
	// idInputParamDTO.getIdNumbers(),
	// idInputParamDTO.getCardCountryCodes(), idType));
	// }
	//
	// return NotificationInfoList;
	// }
	//
	// @Override
	// @Secured({ "ROLE_getPersonNotificationInfo" })
	// @WebMethod(operationName = "getPersonNotificationInfo")
	//
	// public NotificationInfoDTO getPersonNotificationInfo(SecurityTagObject
	// security, String idNumber,
	// String cardCountry, String idType, Integer blockNumber, Date
	// cardExpiryDate)
	// throws ApplicationExceptionInfo {
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfo(String, String, String) -
	// start");
	// }
	//
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (validationService.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "014"));
	// }
	//
	// if (!validationService.hasValidBlock(cprNumber, blockNumber))
	// throw new ApplicationExceptionInfo("Block Number", new
	// ApplicationException("Wrong Block Number", "007"));
	//
	// if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
	// throw new ApplicationExceptionInfo("Expiry Date", new
	// ApplicationException("Wrong Expiry Date", "013"));
	//
	// PersonService ps = crsService.getPersonServiceRef();
	// NotificationInformation notificationInfo = null;
	//
	// try {
	//
	// notificationInfo = ps.getPersonNotificationInformation(idNumber,
	// cardCountry, idType);
	//
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("getPersonNotificationInfoBy(String, String, String) Error:
	// " + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// notificationInfoDTO = new NotificationInfoDTO(cprNumber.toString(), "",
	// notificationInfo.getPrimaryPhoneNumber(),
	// notificationInfo.getSecondaryPhoneNumber(),
	// notificationInfo.getPrimaryEmail(), notificationInfo.getSecondaryEmail(),
	// notificationInfo.getStatusCode(), notificationInfo.getStatusMessage());
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfo(String, String, String) - End");
	// }
	// return notificationInfoDTO;
	// }
	//
	// @Override
	// @Secured({ "ROLE_getPersonNotificationInfo" })
	// @WebMethod(operationName = "getIsPersonRegisteredForNotification")
	// public NotificationInfoDTO
	// getIsPersonRegisteredForNotification(SecurityTagObject security, String
	// idNumber,
	// String cardCountry, String idType) throws ApplicationExceptionInfo {
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfoById(String, String, String) -
	// start");
	// }
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (validationService.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "014"));
	// }
	//
	// PersonService ps = crsService.getPersonServiceRef();
	// NotificationInformation notificationInfo = null;
	//
	// try {
	//
	// notificationInfo =
	// ps.getIsPersonRegisteredForNotificationService(idNumber, cardCountry,
	// idType);
	//
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error(
	// "getIsPersonRegisteredForNotificationService(String, String) Error: " +
	// exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// notificationInfoDTO = new NotificationInfoDTO(idNumber, cardCountry,
	// notificationInfo.getPrimaryPhoneNumber(),
	// notificationInfo.getSecondaryPhoneNumber(),
	// notificationInfo.getPrimaryEmail(),
	// notificationInfo.getSecondaryEmail(), notificationInfo.getStatusCode(),
	// notificationInfo.getStatusMessage());
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("getIsPersonRegisteredForNotificationService(String, String,
	// String) - End");
	// }
	// return notificationInfoDTO;
	// }
	//
	// @Override
	// @Secured({ "ROLE_updatePersonNotificationInfo" })
	// @WebMethod(operationName =
	// "updatePersonNoticationPhoneInformationWithEkey")
	// public NotificationInfoDTO
	// updatePersonNoticationPhoneInformationWithEkey(
	//
	// SecurityTagObject security, String idNumber, String cardCountry, String
	// idType, Integer blockNumber,
	// Date cardExpiryDate, String eKeyCPRNumber, String eKeyServiceID, String
	// eKeyTokenID, String eKeyTimestamp,
	// String primaryPhone, String isPrimaryPhoneUpdated, String secondaryPhone,
	// String isSecondaryPhoneUpdated,
	// String primaryEmail, String isPrimaryEmailUpdated, String secondaryEmail,
	// String isSecondaryEmailUpdated,
	// String username) throws ApplicationExceptionInfo {
	//
	// if (!checkeKeyResponse(eKeyCPRNumber, eKeyServiceID, eKeyTokenID,
	// eKeyTimestamp)) {
	// throw new ApplicationExceptionInfo("Error in retrieving data...",
	// new ApplicationException("Authentication Failed.", "001"));
	// }
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (validationService.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "014"));
	// }
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// notificationInfoDTO = updatePersonNoticationPhoneInfo(idNumber,
	// cardCountry, idType, primaryPhone,
	// isPrimaryPhoneUpdated, secondaryPhone, isSecondaryPhoneUpdated,
	// primaryEmail, isPrimaryEmailUpdated,
	// secondaryEmail, isSecondaryEmailUpdated, username);
	// return notificationInfoDTO;
	//
	// }
	//
	// @Override
	// @Secured({ "ROLE_updatePersonNotificationInfo" })
	// @WebMethod(operationName =
	// "updatePersonNoticationEmailInformationWithEkey")
	// public NotificationInfoDTO
	// updatePersonNoticationEmailInformationWithEkey(SecurityTagObject
	// security,
	// String idNumber, String cardCountry, String idType, String eKeyCPRNumber,
	// String eKeyServiceID,
	// String eKeyTokenID, String eKeyTimestamp, String primaryPhone, String
	// email, String isPrimaryEmail,
	// String username) throws ApplicationExceptionInfo {
	//
	// if (!checkeKeyResponse(eKeyCPRNumber, eKeyServiceID, eKeyTokenID,
	// eKeyTimestamp)) {
	// throw new ApplicationExceptionInfo("Error in retrieving data...",
	// new ApplicationException("Authentication Failed.", "001"));
	// }
	// NotificationInfoDTO notificationInfoDTO = null;
	// notificationInfoDTO = updatePersonNoticationEmailInfo(idNumber,
	// cardCountry, idType, primaryPhone, email,
	// isPrimaryEmail, username);
	// return notificationInfoDTO;
	// }
	//
	// @Override
	// @Secured({ "ROLE_updatePersonNotificationInfo" })
	// @WebMethod(operationName = "updatePersonNoticationPhoneInformation")
	// public NotificationInfoDTO
	// updatePersonNoticationPhoneInformation(SecurityTagObject security, String
	// idNumber,
	// String cardCountry, String idType, Integer blockNumber, Date
	// cardExpiryDate, String primaryPhone,
	// String isPrimaryPhoneUpdated, String secondaryPhone, String
	// isSecondaryPhoneUpdated, String primaryEmail,
	// String isPrimaryEmailUpdated, String secondaryEmail, String
	// isSecondaryEmailUpdated, String username)
	// throws ApplicationExceptionInfo {
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfo(String, String, String) -
	// start");
	// }
	//
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (validationService.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "014"));
	// }
	//
	// if (!validationService.hasValidBlock(cprNumber, blockNumber))
	// throw new ApplicationExceptionInfo("Block Number", new
	// ApplicationException("Wrong Block Number", "007"));
	//
	// if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
	// throw new ApplicationExceptionInfo("Expiry Date", new
	// ApplicationException("Wrong Expiry Date", "013"));
	//
	// try {
	//
	// notificationInfoDTO = updatePersonNoticationPhoneInfo(idNumber,
	// cardCountry, idType, primaryPhone,
	// isPrimaryPhoneUpdated, secondaryPhone, isSecondaryPhoneUpdated,
	// primaryEmail, isPrimaryEmailUpdated,
	// secondaryEmail, isSecondaryEmailUpdated, username);
	//
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("getPersonNotificationInfoBy(String, String, String) Error:
	// " + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfo(String, String, String) - End");
	// }
	// return notificationInfoDTO;
	//
	// }
	//
	// @Override
	// @Secured({ "ROLE_updatePersonNotificationInfo" })
	// @WebMethod(operationName = "updatePersonNoticationEmailInformation")
	// public NotificationInfoDTO
	// updatePersonNoticationEmailInformation(SecurityTagObject security, String
	// idNumber,
	// String cardCountry, String idType, Integer blockNumber, Date
	// cardExpiryDate, String primaryPhone,
	// String email, String isPrimaryEmail, String username) throws
	// ApplicationExceptionInfo {
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfo(String, String, String) -
	// start");
	// }
	//
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (!validationService.hasValidBlock(cprNumber, blockNumber))
	// throw new ApplicationExceptionInfo("Block Number", new
	// ApplicationException("Wrong Block Number", "007"));
	//
	// if (!validationService.hasValidExpiryCardData(cprNumber, cardExpiryDate))
	// throw new ApplicationExceptionInfo("Expiry Date", new
	// ApplicationException("Wrong Expiry Date", "013"));
	//
	// try {
	//
	// notificationInfoDTO = updatePersonNoticationEmailInfo(idNumber,
	// cardCountry, idType, primaryPhone, email,
	// isPrimaryEmail, username);
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("getPersonNotificationInfoBy(String, String, String) Error:
	// " + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfo(String, String, String) - End");
	// }
	// return notificationInfoDTO;
	//
	// }
	//
	// @Override
	// @Secured({ "ROLE_getPersonNotificationInfoByEkey" })
	// @WebMethod(operationName = "getPersonNotificationInfoWithEkey")
	// public NotificationInfoDTO
	// getPersonNotificationInfoWithEkey(SecurityTagObject security, String
	// idNumber,
	// String cardCountry, String eKeyCPRNumber, String eKeyServiceID, String
	// eKeyTokenID, String eKeyTimestamp)
	// throws ApplicationExceptionInfo {
	//
	// if (!checkeKeyResponse(eKeyCPRNumber, eKeyServiceID, eKeyTokenID,
	// eKeyTimestamp)) {
	// throw new ApplicationExceptionInfo("Error in retrieving data...",
	// new ApplicationException("Authentication Failed.", "001"));
	// }
	// NotificationInfoDTO notificationInfoDTO = null;
	//
	// // notificationInfoDTO = getPersonNotificationInfoById(security,
	// // idNumber, cardCountry);
	//
	// return notificationInfoDTO;
	// }

	// @Override
	// @Secured({ "ROLE_registerPersonNoticationInformation" })
	// @WebMethod(operationName = "registerPersonNoticationInformation")
	// public NotificationInfoDTO
	// registerPersonNoticationInformation(SecurityTagObject security,String
	// idNumber,String cardCountry, String idType , Integer blockNumber, Date
	// cardExpiryDate , String primaryPhone,
	// String secondaryPhone, String primaryEmail,String secondaryEmail,String
	// username) throws ApplicationExceptionInfo {
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("register(String, String, String) - start");
	// }
	//
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (validationService.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "014"));
	// }
	//
	// PersonService ps = crsService.getPersonServiceRef();
	// NotificationInformation notificationInfo = null;
	//
	// try {
	//
	// notificationInfo = ps.registerPersonNoticationInformation( idNumber,
	// cardCountry, idType , primaryPhone,
	// secondaryPhone, primaryEmail, secondaryEmail, username);
	//
	//
	// logger.debug("primary phone update: " + primaryPhone + "secondary phone:
	// " + secondaryPhone);
	//
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("updatePersonNoticationPhoneInformation(Integer,String,
	// String, String) Error: "
	// + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// notificationInfoDTO = new NotificationInfoDTO(idNumber, cardCountry,
	// notificationInfo.getPrimaryPhoneNumber(),
	// notificationInfo.getSecondaryPhoneNumber(),
	// notificationInfo.getPrimaryEmail(),
	// notificationInfo.getSecondaryEmail(), notificationInfo.getStatusCode(),
	// notificationInfo.getStatusMessage());
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("updatePersonNoticationPhoneInformation(Integer,String,
	// String, String) - End");
	// }
	// return notificationInfoDTO;
	//
	// }

	// public NotificationInfoDTO updatePersonNoticationPhoneInfo(String
	// idNumber, String cardCountry, String idType,
	// String primaryPhone, String isPrimaryPhoneUpdated, String secondaryPhone,
	// String isSecondaryPhoneUpdated,
	// String primaryEmail, String isPrimaryEmailUpdated, String secondaryEmail,
	// String isSecondaryEmailUpdated,
	// String username) throws ApplicationExceptionInfo {
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("getPersonNotificationInfoById(String, String, String) -
	// start");
	// }
	//
	// PersonService ps = crsService.getPersonServiceRef();
	// NotificationInformation notificationInfo = null;
	//
	// try {
	//
	// notificationInfo = ps.updatePersonNoticationInformation(idNumber,
	// cardCountry, idType, primaryPhone,
	// isPrimaryPhoneUpdated, secondaryPhone, isSecondaryPhoneUpdated,
	// primaryEmail, isPrimaryEmailUpdated,
	// secondaryEmail, isSecondaryEmailUpdated, username);
	// logger.debug("primary phone update: " + primaryPhone + "secondary phone:
	// " + secondaryPhone);
	//
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("updatePersonNoticationPhoneInformation(Integer,String,
	// String, String) Error: "
	// + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// notificationInfoDTO = new NotificationInfoDTO(idNumber, cardCountry,
	// notificationInfo.getPrimaryPhoneNumber(),
	// notificationInfo.getSecondaryPhoneNumber(),
	// notificationInfo.getPrimaryEmail(),
	// notificationInfo.getSecondaryEmail(), notificationInfo.getStatusCode(),
	// notificationInfo.getStatusMessage());
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("updatePersonNoticationPhoneInformation(Integer,String,
	// String, String) - End");
	// }
	// return notificationInfoDTO;
	//
	// }
	//
	// public NotificationInfoDTO updatePersonNoticationEmailInfo(String
	// idNumber, String cardCountry, String idType,
	// String primaryPhone, String email, String isPrimary, String username)
	// throws ApplicationExceptionInfo {
	//
	// NotificationInfoDTO notificationInfoDTO = null;
	// if (logger.isDebugEnabled()) {
	// logger.debug("updatePersonNoticationEmailInformation(Integer,String,
	// String) - start");
	// }
	// if (cardCountry == null || "".equals(cardCountry.trim())) {
	// cardCountry = "499";
	// }
	// Integer cprNumber = 0;
	// try {
	// cprNumber = validationService.getGCCCpr(idNumber, cardCountry);
	// } catch (Exception e) {
	// throw new ApplicationExceptionInfo("Entered ID Not Valid",
	// new ApplicationException("Entered ID Not Valid", "002"));
	// }
	//
	// if (validationService.isDeletedCpr(cprNumber)) {
	// throw new ApplicationExceptionInfo("CPR Number Deleted",
	// new ApplicationException("CPR Number Deleted", "014"));
	// }
	//
	// PersonService ps = crsService.getPersonServiceRef();
	// NotificationInformation notificationInfo = null;
	//
	// try {
	//
	// notificationInfo = ps.updatePersonNoticationEmailInformation(idNumber,
	// cardCountry, idType, primaryPhone,
	// email, isPrimary, username);
	//
	// notificationInfoDTO = new NotificationInfoDTO(idNumber, cardCountry,
	// notificationInfo.getPrimaryPhoneNumber(),
	// notificationInfo.getSecondaryPhoneNumber(),
	// notificationInfo.getPrimaryEmail(), notificationInfo.getSecondaryEmail(),
	// notificationInfo.getStatusCode(), notificationInfo.getStatusMessage());
	// logger.debug("email should update: " + email);
	//
	// } catch (final Exception exception) {
	// exception.printStackTrace();
	// if (logger.isDebugEnabled()) {
	// logger.error("updatePersonNoticationEmailInformation(Integer,String,
	// String) Error: "
	// + exception.getMessage());
	// }
	// throw new ApplicationExceptionInfo("Notification Info Not found",
	// new ApplicationException(exception.getMessage(), "012"));
	// }
	//
	// if (logger.isDebugEnabled()) {
	// logger.debug("updatePersonNoticationEmailInformation(Integer, String,
	// String) - End");
	// }
	// return notificationInfoDTO;
	//
	// }
	//
	private boolean checkeKeyResponse(String eKeyCPRNumber, String eKeyServiceID, String eKeyTokenID,
			String eKeyTimestamp) {
		ValidateToken eKey = crsService.geteKeyServiceRef();
		String accessPassword = propImpl.geteGOVeKeyPassword();
		String response = null;
		CryptoUtil cryptoUtil = new CryptoUtil();
		try {
			response = eKey.getTokenValidate(accessPassword, cryptoUtil.encrypt(eKeyCPRNumber),
					cryptoUtil.encrypt(eKeyServiceID), cryptoUtil.encrypt(eKeyTokenID),
					cryptoUtil.encrypt(eKeyTimestamp));

			response = cryptoUtil.decrypt(response);

			logger.debug("eKey Response:" + response);
		} catch (Exception e) {

			e.printStackTrace();
		}
		return (response != null && response.equals("10000"));

	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationService() {
		return validationService;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationService(ValidationServiceImpl validationService) {
		this.validationService = validationService;
	}
}
