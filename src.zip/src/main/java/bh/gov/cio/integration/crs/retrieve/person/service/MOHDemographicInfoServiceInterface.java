package bh.gov.cio.integration.crs.retrieve.person.service;

import java.util.Date;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.service.dto.MOHDemographicInfoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "MOHDemographicInfoService", targetNamespace = "http://service.person.retrieve.crs.integration.cio.gov.bh/")
public interface MOHDemographicInfoServiceInterface
{


	@WebResult(name = "MOHDemographicInfo")
	@WebMethod(operationName = "getMOHDemographicInfo")
	MOHDemographicInfoDTO getMOHDemographicInfo(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "nationalityCode") @XmlElement(required = true) String nationalityCode,
			@WebParam(name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	@WebResult(name = "MOHDemographicInfo")
	@WebMethod(operationName = "getMOHDemographicInfoByIdNumber")
	MOHDemographicInfoDTO getMOHDemographicInfoByIdNumber(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
			@WebParam(name = "nationalityCode") @XmlElement(required = true) String nationalityCode) throws ApplicationExceptionInfo;

}