package bh.gov.cio.integration.crs.retrieve.address.service.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "BuildingStatus", propOrder =
{ "buildingNumber", "buildingAlphaEnglish", "roadNumber","blockNumber","isActive"})
public class CheckActiveBuildingReturnDTO
{
	private java.lang.String buildingNumber;
	private java.lang.String buildingAlphaEnglish;
	private java.lang.String roadNumber;
	private java.lang.String blockNumber;
	private java.lang.String isActive;

	public CheckActiveBuildingReturnDTO()
	{
		super();
	}

	public CheckActiveBuildingReturnDTO(String buildingNumber, String buildingAlphaEnglish, String roadNumber,String blockNumber,String isActive) {
		super();
		this.buildingNumber = buildingNumber;
		this.buildingAlphaEnglish = buildingAlphaEnglish;
		this.roadNumber = roadNumber;
		this.blockNumber = blockNumber;
		this.setIsActive(isActive);
	}

	public java.lang.String getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(java.lang.String buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public java.lang.String getBuildingAlphaEnglish() {
		return buildingAlphaEnglish;
	}

	public void setBuildingAlphaEnglish(java.lang.String buildingAlphaEnglish) {
		this.buildingAlphaEnglish = buildingAlphaEnglish;
	}

	public java.lang.String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(java.lang.String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public java.lang.String getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(java.lang.String blockNumber) {
		this.blockNumber = blockNumber;
	}

	public java.lang.String getIsActive() {
		return isActive;
	}

	public void setIsActive(java.lang.String isActive) {
		this.isActive = isActive;
	}


}
