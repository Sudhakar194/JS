package bh.gov.cio.integration.crs.retrieve.person.biometric;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.AuditDetails;
import bh.gov.cio.crs.util.CRSUtils;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.PersonBasicInfoServiceImpl;
import bh.gov.cio.integration.crs.retrieve.person.biometric.service.PersonBiometricSignatureServiceInterface;
import bh.gov.cio.integration.crs.retrieve.person.biometric.service.dto.PersonBiometricSignatureDTO;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonBiometricSignatureService", targetNamespace = "http://service.biometric.person.retrieve.crs.integration.cio.gov.bh/")
//, serviceName = "PersonBiometricSignatureService"
public class PersonBiometricSignatureServiceImpl implements PersonBiometricSignatureServiceInterface
{
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(PersonBasicInfoServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService()
	{
		return crsService;
	}

//	@Override
//	@Secured(
//	{ "ROLE_getPersonSignture" })
//	@WebMethod(operationName = "getPersonSignature")
//	public PersonBiometricSignatureDTO getPersonSignature(SecurityTagObject security, Integer cprNumber, Integer blockNumber, Date cardExpiryDate)
//			throws ApplicationExceptionInfo
//	{
//		if (logger.isDebugEnabled())
//		{
//			logger.debug("getPersonSignature(Integer, Integer, Date) - start");
//			logger.debug("getPersonSignature(cprNumber = " + cprNumber + ", blockNumber = " + blockNumber + ", cardExpiryDate = " + cardExpiryDate
//					+ ")");
//		}
//
//		if (!validationUtil.hasValidBlock(cprNumber, blockNumber))
//		{
//			throw new ApplicationExceptionInfo("Block Number", new ApplicationException("Wrong Block Number"));
//		}
//		if (!validationUtil.hasValidExpiryCardData(cprNumber, cardExpiryDate))
//		{
//			throw new ApplicationExceptionInfo("Expiry Date", new ApplicationException("Wrong Expiry Date"));
//		}
//		if (validationUtil.isMilitaryCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
//		}
//		if (validationUtil.isDeletedCpr(cprNumber))
//		{
//			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
//		}
//		PersonBiometricSignatureDTO signatureDTO = null;
//		try
//		{
//
//			AuditDetails signatureDetails = getCrsService().getBiometricServiceRef().getPersonBiometricAuditDetails(cprNumber);
//
//			signatureDTO = new PersonBiometricSignatureDTO(cprNumber, getCrsService().getBiometricServiceRef().getPersonSignature(cprNumber),
//					CRSUtils.getDateStringFromTimeStamp(signatureDetails.getSignatureDate()));
//
//			if (logger.isDebugEnabled())
//			{
//				logger.debug("getPersonSignature(Integer, Integer, Date) - end");
//			}
//		}
//		catch (final Exception exception)
//		{
//			if (logger.isDebugEnabled())
//			{
//				logger.error("getPersonSignature(Integer, Integer, Date) Error: " + exception.getMessage());
//			}
//			throw new ApplicationExceptionInfo("Person Signature Not found", new ApplicationException(exception.getMessage()));
//		}
//
//		return signatureDTO;
//	}

	@Override
	@Secured(
	{ "ROLE_getPersonSignatureByCPR" })
	@WebMethod(operationName = "getPersonSignatureByCPR")
	public PersonBiometricSignatureDTO getPersonSignatureByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{

		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonSignatureByCPR(Integer) - start");
			logger.debug("getPersonSignatureByCPR(cprNumber = " + cprNumber + ")");
		}
		if (validationUtil.isMilitaryCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("UNAUTHORIZED", new ApplicationException("UNAUTHORIZED"));
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		PersonBiometricSignatureDTO signatureDTO = null;
		try
		{
			AuditDetails signatureDetails = getCrsService().getBiometricServiceRef().getPersonBiometricAuditDetails(cprNumber);

			signatureDTO = new PersonBiometricSignatureDTO(cprNumber, getCrsService().getBiometricServiceRef().getPersonSignature(cprNumber),
					CRSUtils.getDateStringFromTimeStamp(signatureDetails.getSignatureDate()));

			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonPhoto(Integer) - end");
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonSignatureByCPR(Integer) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Signature Not found", new ApplicationException(exception.getMessage()));
		}

		return signatureDTO;
	}

	@Override
	@Secured(
	{ "ROLE_getPersonSpecialSignatureByCPR" })
	@WebMethod(operationName = "getPersonSpecialSignatureByCPR")
	public PersonBiometricSignatureDTO getPersonSpecialSignatureByCPR(SecurityTagObject security, Integer cprNumber) throws ApplicationExceptionInfo
	{

		if (logger.isDebugEnabled())
		{
			logger.debug("getPersonSpecialSignatureByCPR(Integer, Integer, Date) - start");
			logger.debug("getPersonSpecialSignatureByCPR(cprNumber = " + cprNumber + ")");
		}
		if (validationUtil.isDeletedCpr(cprNumber))
		{
			throw new ApplicationExceptionInfo("CPR Number Deleted", new ApplicationException("CPR Number Deleted"));
		}
		PersonBiometricSignatureDTO signatureDTO = null;
		try
		{

			AuditDetails signatureDetails = getCrsService().getBiometricServiceRef().getPersonBiometricAuditDetails(cprNumber);

			signatureDTO = new PersonBiometricSignatureDTO(cprNumber, getCrsService().getBiometricServiceRef().getPersonSignature(cprNumber),
					CRSUtils.getDateStringFromTimeStamp(signatureDetails.getSignatureDate()));

			if (logger.isDebugEnabled())
			{
				logger.debug("getPersonPhoto(Integer, Integer, Date) - end");
			}
		}
		catch (final Exception exception)
		{
			if (logger.isDebugEnabled())
			{
				logger.error("getPersonSpecialSignatureByCPR(Integer, Integer, Date) Error: " + exception.getMessage());
			}
			throw new ApplicationExceptionInfo("Person Signature Not found", new ApplicationException(exception.getMessage()));
		}

		return signatureDTO;

	}

}
