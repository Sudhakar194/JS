package bh.gov.cio.integration.crs.retrieve.cr.service.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "CRDetails", propOrder =
{ "crNumber", "crArabicName", "crEnglishName", "crActivity" })
public class PersonActiveCRDTO
{
	private Integer crNumber;
	private String crArabicName;
	private String crEnglishName;
	private List<CRActivityInfoDTO> crActivity;
	private final String crIsActiveStatus = "T";

	public PersonActiveCRDTO()
	{
		super();
	}

	public PersonActiveCRDTO(Integer crNumber, String crArabicName, String crEnglishName, List<CRActivityInfoDTO> crActivity)
	{
		super();
		this.crNumber = crNumber;
		this.crArabicName = crArabicName;
		this.crEnglishName = crEnglishName;
		this.crActivity = crActivity;
	}

	public List<CRActivityInfoDTO> getCrActivity()
	{
		return crActivity;
	}

	public String getCrArabicName()
	{
		return crArabicName;
	}

	public String getCrEnglishName()
	{
		return crEnglishName;
	}

	public String getCrIsActiveStatus()
	{
		return crIsActiveStatus;
	}

	public Integer getCrNumber()
	{
		return crNumber;
	}

	public void setCrActivity(List<CRActivityInfoDTO> crActivity)
	{
		this.crActivity = crActivity;
	}

	public void setCrArabicName(String crArabicName)
	{
		this.crArabicName = crArabicName;
	}

	public void setCrEnglishName(String crEnglishName)
	{
		this.crEnglishName = crEnglishName;
	}

	public void setCrNumber(Integer crNumber)
	{
		this.crNumber = crNumber;
	}

}
