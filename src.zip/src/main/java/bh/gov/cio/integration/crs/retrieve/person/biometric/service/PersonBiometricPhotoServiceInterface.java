package bh.gov.cio.integration.crs.retrieve.person.biometric.service;

import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.person.biometric.service.dto.PersonBiometricPhotoDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "PersonBiometricPhotoService", targetNamespace = "http://service.biometric.person.retrieve.crs.integration.cio.gov.bh/")
public interface PersonBiometricPhotoServiceInterface
{
//	@WebResult(name = "PhotoDetails")
//	@WebMethod(operationName = "getPersonPhoto")
//	PersonBiometricPhotoDTO getPersonPhoto(@WebParam(mode = WebParam.Mode.IN, name = "Security",
//			header = true) SecurityTagObject security, @WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber, @WebParam(
//			name = "blockNumber") @XmlElement(required = true) Integer blockNumber,
//			@WebParam(name = "cardExpiryDate") @XmlElement(required = true) Date cardExpiryDate) throws ApplicationExceptionInfo;

	PersonBiometricPhotoDTO getPersonPhotoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security",header = true) SecurityTagObject security,
			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

//	PersonBiometricPhotoDTO getPersonSpecialPhotoByCPR(@WebParam(mode = WebParam.Mode.IN, name = "Security",header = true) SecurityTagObject security,
//			@WebParam(name = "cprNumber") @XmlElement(required = true) Integer cprNumber) throws ApplicationExceptionInfo;

}
