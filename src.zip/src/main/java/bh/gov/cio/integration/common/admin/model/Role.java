package bh.gov.cio.integration.common.admin.model;

public class Role {
	String description;
	String rolename;
	
	public String getDescription() {
		return description;
	}
	public String getRolename() {
		return rolename;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
}
