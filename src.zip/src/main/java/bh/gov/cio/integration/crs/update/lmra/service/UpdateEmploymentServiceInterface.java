package bh.gov.cio.integration.crs.update.lmra.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.update.lmra.dto.UpdateEmploymentDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "UpdateEmploymentService", targetNamespace = "http://service.lmra.update.crs.integration.cio.gov.bh/")
public interface UpdateEmploymentServiceInterface {
	
		@WebResult(name = "UpdateEmploymentStatus")
		@WebMethod(operationName = "updateEmployment")
		UpdateEmploymentDTO updateEmployment(@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true)
				SecurityTagObject security,@WebParam(name = "idNumber") @XmlElement(required = true) String idNumber,
				@WebParam(name = "nationality") @XmlElement(required = true) String nationalityCode,
				@WebParam(name = "employeeCpr") @XmlElement(required = true) Integer employeeCpr,
				@WebParam(name = "occupationCode") @XmlElement(required = true) String occupationCode,
				@WebParam(name = "WpNumber") @XmlElement(required = false) Integer WpNumber) throws ApplicationExceptionInfo;

}
