package bh.gov.cio.integration.crs.lmra;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.person.Marriage;
import bh.gov.cio.crs.model.person.PersonBasicInfo;
import bh.gov.cio.crs.model.person.PersonSummary;
import bh.gov.cio.crs.service.FamilyService;
import bh.gov.cio.crs.service.PersonService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.crs.lmra.dto.IsBahrainiWifeDTO;
import bh.gov.cio.integration.crs.lmra.service.IsBahrainiWifeServiceInterface;
import bh.gov.cio.integration.exception.ApplicationException;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

@WebService(name = "IsBahrainiWifeService", targetNamespace = "http://service.lmra.crs.integration.cio.gov.bh/")
public class IsWifeOfBahrainiServiceImpl implements
		IsBahrainiWifeServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(IsWifeOfBahrainiServiceImpl.class);

	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_IsBahrainiWife" })
	@WebMethod(operationName = "IsBahrainiWife")
	public IsBahrainiWifeDTO IsBahrainiWife(SecurityTagObject security,Integer cprNumber) throws ApplicationExceptionInfo {

		IsBahrainiWifeDTO isBahrainiWifeDTO = new IsBahrainiWifeDTO();
		final FamilyService familyService = getCrsService()
				.getFamilyServiceRef();
//		final bh.gov.cio.crs.esb.service.PersonService personService = getCrsService()
//				.getNewPersonServiceRef();

		final PersonService personService = getCrsService()
				.getPersonServiceRef();
		
		isBahrainiWifeDTO.setHaveChildren("F");
		isBahrainiWifeDTO.setIsBahrainiWife("F");
		isBahrainiWifeDTO.setIsBahrainiWidow("F");
		isBahrainiWifeDTO.setCprNumber(Integer.toString(cprNumber));
		PersonBasicInfo wifePersonBasicInfo = null;
		PersonSummary wifePersonSummary = null;
		List<Marriage> hm = new ArrayList<Marriage>();
		HashMap<Integer, List<PersonSummary>> hm2 = null;
		boolean isMOISponsor = true;
		 Integer spouseCPR= 0;
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("IsBahrainiWife() - started..........");
			}

			wifePersonBasicInfo = personService.getPersonBasicInfo(cprNumber);
			wifePersonSummary =personService.getPersonSummary(cprNumber);
			isMOISponsor = personService.isMOISponsor(cprNumber);
			spouseCPR = familyService.getPersonPrimarySpouse(cprNumber);
			hm = familyService.getPersonMarriageDivorceList(cprNumber);
			hm2 = familyService.getPersonChildrenBySpouse(cprNumber);

		}
		catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.debug("IsBahrainiWife() - ended..........");
			}
			e.printStackTrace();
//			 throw new ApplicationExceptionInfo("General Error", new
//			 ApplicationException( " Data Not Found For this CPR Number"));
		} 
		
		/*********************** check if the cpr sent in the request is Female *******************/
			if (logger.isDebugEnabled()) {
				logger.debug("wifePersonBasicInfo.getGender(): "
						+ wifePersonBasicInfo.getGender());
			}

			if (wifePersonBasicInfo.getGender().equals("F")) {
				/*********************** check if the cpr is *******************/
				final boolean foreignerWife = (wifePersonSummary
						.getNationalityCountryCode().equals("499") || wifePersonSummary
						.getNationalityCountryCode().equals("900")) ? false
						: true;

				if (foreignerWife==true) {

					/********************* Check if wife under LMRA employees ************************/


					if (isMOISponsor == false) {

						
						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiWife() - familyService.getPersonPrimarySpouse(cprNumber) = "
									+ spouseCPR);
						}
//						final List<Marriage> hm = familyService
//								.getPersonMarriageDivorceList(cprNumber);
						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiWife() - familyService.getPersonMarriageDivorceList(cprNumber) = "
									+ hm);
						}

						int count = 0;

						/**************** Check if wife married Bahraini or widow bahraini **************/
						if (hm != null) {
							for (final Marriage marriage : hm) {
								final Marriage spouse = marriage;
								
								
								try{
								final PersonSummary spousePersonSummary = personService
										.getPersonSummary(spouse
												.getPartnerCprNumber());
								if (logger.isDebugEnabled()) {
									logger.debug("IsBahrainiWife()"
											+ spouse.getPartnerCprNumber()
											+ " -  spouse = "
											+ spouse.getLastActionWithPartner()
											+ "spouse.isAlive() "
											+ spouse.isAlive());
								}

								final boolean isBahraini = (spousePersonSummary
										.getNationalityCountryCode().equals(
												"499") || spousePersonSummary
										.getNationalityCountryCode().equals(
												"900")) ? true : false;

								if (!spouse.getLastActionWithPartner().equals(
										"DIVORCE")) {
									if (isBahraini == true) {
										if (spousePersonSummary
												.getDateOfDeath() != null) {
											isBahrainiWifeDTO
													.setIsBahrainiWidow("T");
										} else {
											isBahrainiWifeDTO
													.setIsBahrainiWife("T");
										}

									}

									if (isBahraini == false) {

										throw new ApplicationExceptionInfo(
												"Not under LMRA umbrella.",
												new ApplicationException(
														"Not under LMRA umbrella."));

									}

								}

								count++;
							
							}
							catch (Exception e) {
								throw new ApplicationExceptionInfo("Spouse recored not found.",new ApplicationException("Spouse recored not found."));
							}
						}}

						else {
							throw new ApplicationExceptionInfo("Marriage record not found.",new ApplicationException("Marriage record not found."));
						}

						/******************* check if she has bahraini children *********************/
//						final HashMap<Integer, List<PersonSummary>> hm2 = familyService
//								.getPersonChildrenBySpouse(cprNumber);
						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiWife() -  No Of Wives = "
									+ hm2);
						}
						
						if (hm2 != null) {
						final Collection<List<PersonSummary>> wivesList = hm2
								.values();

						int currentChild = 0;
						int noOfBahrainichildren = 0;
						for (final List<PersonSummary> list : wivesList) {
							final List<PersonSummary> childrenList = list;
							for (final PersonSummary personSummary : childrenList) {
								final PersonSummary childrenSummary = personSummary;
								try{
								final PersonSummary childrenPersonSummary = personService
										.getPersonSummary(childrenSummary
												.getCprNumber());
								
								logger.debug("Child CPR Number = "+childrenPersonSummary.getCprNumber());
								
								final boolean isBahraini = (childrenPersonSummary
										.getNationalityCountryCode().equals(
												"499") || childrenPersonSummary
										.getNationalityCountryCode().equals(
												"900")) ? true : false;
								final boolean isNotDead = (childrenPersonSummary
										.getIoStatusCode().equals("1")) ? false
										: true;

								if (isNotDead && isBahraini) {
									noOfBahrainichildren++;

								}
								
								logger.debug("Number of Children ="+noOfBahrainichildren);

								currentChild++;

							}
							
						catch (Exception e) {
							throw new ApplicationExceptionInfo(
									"Women with out child.",
									new ApplicationException(
											"Women with out child."));
						}
						}
						

						if (logger.isDebugEnabled()) {
							logger.debug("IsBahrainiWife() -  noOfBahrainichildren= "
									+ noOfBahrainichildren);
						}

						if (noOfBahrainichildren >= 1) {

							isBahrainiWifeDTO.setHaveChildren("T");
						}
						}
						
					} 
				}
					else {
						throw new ApplicationExceptionInfo(
								"Unauthorized display/insert/update for specified sponsor number or employer number.",
								new ApplicationException(
										"Unauthorized display/insert/update for specified sponsor number or employer number."));
					}

			} 	
				 else {
						throw new ApplicationExceptionInfo("Not Bahraini wife.",new ApplicationException("Not Bahraini wife."));

					}
	
	}
			else
			{
		
			throw new ApplicationExceptionInfo("CPR number is not for Female.",new ApplicationException("CPR number is not for Female."));

			}
						
			return isBahrainiWifeDTO;
			
	}
}
