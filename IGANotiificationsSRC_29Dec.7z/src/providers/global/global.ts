//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { LoadingController } from 'ionic-angular';
import { CallserverProvider } from './../../providers/callserver/callserver';



@Injectable()
export class GlobalProvider {

	    public gLocale: boolean;
	    public gSearch: boolean;

	    loader: any ;

	    items: Array<{NameEN: String, NameAR:String}>;   
    

		 constructor(public loadingCtrl: LoadingController, public callserver: CallserverProvider) {
		    console.log('Hello GlobalProvider Provider');
		    
			    // english = true , arabic = flase
			    this.gLocale = true;	

			    // hide search for ID cards
			    this.gSearch = false;

		  }



/** Loading controler  start *************************************************************************** */

		 presentLoading(loadingMsg: String) {
		      console.log('Home # presentLoading start: '  + loadingMsg);
		    
		      this.loader = this.loadingCtrl.create({
		           // spinner: 'hide',
		           // content: '<div class="custom-spinner-container"><div class="custom-spinner-box"></div></div>',      
		          content: loadingMsg,
		          //  duration: 3000
		      });
		      
		      this.loader.present();

		      this.loader.onDidDismiss(() => {
		         // console.log('Home # Dismissed loading');
		      });
		        

		       // need to handle later  
		      /** setTimeout(() => {
		          //this.nav.push(Page2);
		          console.log('Home # setTimeout close: ' );
		          this.loader.dismiss();        
		          // add boolean variable , to check varibale to load the response 
		      }, 5000); */
		     
		}

              
        dismissLoader(){
 			 this.loader.dismiss();    
        }

/** Loading controler end *************************************************************************** */



/** Loading Lookups  start *************************************************************************** */

     loadMinistryList(){
	      console.log('GlobalProvider#loadMinistryList ');	      

	      this.callserver.callServerGet ('/action/ministryList').subscribe(
            data => {
                 console.log('GlobalProvider#loadMinistryList DATA STATUS: ' +  data.status);

                   console.log('CallserverProvider Entry # 5 : ' +  data.errorCode);       
				   console.log('CallserverProvider Entry # 5 : ' +  data.errorMsgEn);
				   console.log('CallserverProvider Entry # 5 : ' +  data.responseObject);

                 this.items = [];
				   for (let i = 1;  i<= 5 ; i++){
				      console.log('CallserverProvider Entry # 5 : ' +  data.responseObject[i].NameEN);       
				      console.log('CallserverProvider Entry # 5 : ' +  data.responseObject[i].NameAR);
				    }

            }, err => {
                 console.log('GlobalProvider#loadMinistryList ERROR STATUS: ' +  err.status);
                 console.log('GlobalProvider#loadMinistryList ERROR: ' +  err);
              
                 // if any validation error from server 
                if (err.status == 1000){

                   this.items = [];
				   for (let i = 1;  i<= 5 ; i++){
				      console.log('CallserverProvider Entry # 5 : ' +  err[i].NameEN);       
				      console.log('CallserverProvider Entry # 5 : ' +  err[i].NameAR);
				    }
                    
                }else{                     
                    // this.toast.presentToast("Check internet connection");                             
                }        

	        });
    }


/** Loading Lookups end *************************************************************************** */

}
