import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';


/**
 * Generated class for the PopupcardPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-popupcard',
  templateUrl: 'popupcard.html',
})
export class PopupcardPage {

codes: string [];
	headlineText: string [];
	messageText: string [];
  minstryName: string [];
	items: Array<{code: string, htxt: string, mtxt:string,minName: string}>;


  constructor(public navCtrl: NavController, public navParams: NavParams) {

	//  this.items =  navCtrl.get('items');
	  //this.idCode =  navCtrl.get('idCode1');

	  //console.log ("popupcard " + items);
	  //console.log ("popupcard " + idCode);

	  this.codes = ['1','2','3','4','5','1','2','3','4','5','1','2','3','4','5'];
   
    this.headlineText = ['Notification Headline1','Notification Headline2','Notification Headline3','Notification Headline4','Notification Headline5','Notification Headline1','Notification Headline2','Notification Headline3','Notification Headline4','Notification Headline5','Notification Headline1','Notification Headline2','Notification Headline3','Notification Headline4','Notification Headline5'];
    
    this.messageText = ['Cards can be used to achieve a multitude of designs. We provide many of the elements to achieve common designs, but sometimes it will be necessary to add custom styles. Adding background images to cards is a perfect example of how adding custom styles can achieve a completely different look.','A wiki is run using wiki software, otherwise known as a wiki engine. A wiki engine is a type of content management system, but it differs from most other such systems, including blog software, in that the content is created without any defined owner or leader, and wikis have little inherent structure, allowing structure to emerge according to the needs of the users.[2] There are dozens of different wiki engines in use, both standalone and part of other software, such as bug tracking systems. Some wiki engines are open source, whereas others are proprietary. Some permit control over different functions (levels of access); for example, editing rights may permit changing, adding, or removing material. Others may permit access without enforcing access control. Other rules may be imposed to organize content.','A wiki is run using wiki software, otherwise known as a wiki engine. A wiki engine is a type of content management system, but it differs from most other such systems, including blog software, in that the content is created without any defined owner or leader, and wikis have little inherent structure, allowing structure to emerge according to the needs of the users.[2] There are dozens of different wiki engines in use, both standalone and part of other software, such as bug tracking systems. Some wiki engines are open source, whereas others are proprietary. Some permit control over different functions (levels of access); for example, editing rights may permit changing, adding, or removing material. Others may permit access without enforcing access control. Other rules may be imposed to organize content.','messageText4','messageText5','messageText1','messageText2','A wiki is run using wiki software, otherwise known as a wiki engine. A wiki engine is a type of content management system, but it differs from most other such systems, including blog software, in that the content is created without any defined owner or leader, and wikis have little inherent structure, allowing structure to emerge according to the needs of the users.[2] There are dozens of different wiki engines in use, both standalone and part of other software, such as bug tracking systems. Some wiki engines are open source, whereas others are proprietary. Some permit control over different functions (levels of access); for example, editing rights may permit changing, adding, or removing material. Others may permit access without enforcing access control. Other rules may be imposed to organize content.','messageText4','messageText5','messageText1','A wiki is run using wiki software, otherwise known as a wiki engine. A wiki engine is a type of content management system, but it differs from most other such systems, including blog software, in that the content is created without any defined owner or leader, and wikis have little inherent structure, allowing structure to emerge according to the needs of the users.[2] There are dozens of different wiki engines in use, both standalone and part of other software, such as bug tracking systems. Some wiki engines are open source, whereas others are proprietary. Some permit control over different functions (levels of access); for example, editing rights may permit changing, adding, or removing material. Others may permit access without enforcing access control. Other rules may be imposed to organize content.','messageText3','messageText4','A wiki is run using wiki software, otherwise known as a wiki engine. A wiki engine is a type of content management system, but it differs from most other such systems, including blog software, in that the content is created without any defined owner or leader, and wikis have little inherent structure, allowing structure to emerge according to the needs of the users.[2] There are dozens of different wiki engines in use, both standalone and part of other software, such as bug tracking systems. Some wiki engines are open source, whereas others are proprietary. Some permit control over different functions (levels of access); for example, editing rights may permit changing, adding, or removing material. Others may permit access without enforcing access control. Other rules may be imposed to organize content.'];

    this.minstryName = ['GDT','MOT','MOH','MOE','IGA','GDT','MOT','MOH','MOE','IGA','GDT','MOT','MOH','MOE','IGA']
    this.items =  [];
     
     for (let i = 0; i < 15; i++){
    		this.items.push({
    			code: this.codes[i],
    			htxt: this.headlineText[i],
    			mtxt: this.messageText[i],
          minName: this.minstryName[i]
    		});
     }



  }

  
}
