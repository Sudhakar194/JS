import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { PopoverController } from 'ionic-angular';

import { PopupcardPage } from '../popupcard/popupcard';

/**
 * Generated class for the NotificationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-notification',
  templateUrl: 'notification.html',
})
export class NotificationPage {

   hideMessage: boolean;
   

   nav: NavController;

	codes: string [];
	headlineText: string [];
	messageText: string [];
  minstryName: string [];
	items: Array<{code: string, htxt: string, mtxt:string,minName: string}>;

   // @ViewChild('myNav') nav: 

  constructor(public navCtrl: NavController, public navParams: NavParams, public popoverCtrl: PopoverController) {
    
    this.hideMessage  = true;
    
    this.nav = navCtrl;

    this.codes = ['1','2','3','4','5'];
    this.headlineText = ['Notification Headline1','Notification Headline2','Notification Headline3','Notification Headline4','Notification Headline5','Notification Headline1','Notification Headline2','Notification Headline3','Notification Headline4','Notification Headline5','Notification Headline1','Notification Headline2','Notification Headline3','Notification Headline4','Notification Headline5'];
    this.messageText = ['messageText1','messageText2','messageText3','messageText4','messageText5','messageText1','messageText2','messageText3','messageText4','messageText5','messageText1','messageText2','messageText3','messageText4','messageText5'];
    this.minstryName = ['GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT','GDT']
    this.items =  [];
     
     for (let i = 0; i < 15; i++){
    		this.items.push({
    			code: this.codes[i],
    			htxt: this.headlineText[i],
    			mtxt: this.messageText[i],
          minName: this.minstryName[i]
    		});
     }



  }


/**
        presentPopover(event,code){
            
           this.nav.setRoot(PopupcardPage);
            this.nav.push(PopupcardPage, {
              items: this.items,
              idCode1: code
            }); 
           
        }
*/


OpenMessage(){
  if (this.hideMessage){
     this.hideMessage = false;
  }else{

  this.hideMessage = true;
  }

}

  delete(item) {

  }

  favorite(item){


  }

  share(item){
  	
  	
  }

}
