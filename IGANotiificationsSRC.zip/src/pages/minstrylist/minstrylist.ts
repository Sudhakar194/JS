import { Component } from '@angular/core';
import { App, NavController, NavParams } from 'ionic-angular';
import { NotificationPage } from '../notification/notification';

import { CallserverProvider } from './../../providers/callserver/callserver';


import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'page-minstrylist',
  templateUrl: 'minstrylist.html',
})

export class MinstrylistPage {
  //selectedItem: any;

	icons: string [];
	titles: string [];
	codes: string [];
	items: Array<{ icon: string , title: string, code: string}>;

    appObject: any ;

    ministries: Observable<any>;

  constructor(public navCtrl: NavController, public navParams: NavParams, public appObject1: App,
  public callserver: CallserverProvider) {

  
	console.log('MinstrylistPage Entry # 1 :');

 //   this.selectedItem = navParams.get('item');

    this.icons = ['md-radio-button-on','md-radio-button-on','md-radio-button-on','md-radio-button-on','md-radio-button-on'];
    this.titles = ['Minister of Education','Minister of Electricity and Water Affairs','Minister of Justice, Islamic Affairs and Endowment','Minister of Information Affairs','Minister of Oil'];
	this.codes = ['1','2','3','4','5'];

		this.items = [];
		for (let i = 0; i < 5 ; i ++){
			this.items.push({
			icon: this.icons[i],
		    title: this.titles[i],
		    code: this.codes[i]
			});
		}

      this.appObject =  appObject1;	  
     
      console.log('MinstrylistPage Entry # 2 :' + this.appObject);

      //this.ministries = this.callserver.callServerGet();     
     this.callserver.callServerGet('/action/ml');
      console.log('MinstrylistPage callServerGet Entry # 3 : ');
     // console.log(this.ministries.data.status);
    //  console.log(this.ministries.data.data);
    //  console.log(this.ministries.data.headers);

  }


	getNotifications (event , item){
		 console.log('call getNotifications  ' + event);
		 console.log('call getNotifications  ' + item.code);
		 console.log('call getNotifications  ' + item.title);

	  	// That's right, we're pushing to ourselves!
	    //this.appObject.getRootNav().push(NotificationPage, {item: item} );

		this.navCtrl.setRoot(NotificationPage);
		this.navCtrl.push(NotificationPage, {item: item}); 


	}



  /** ionViewDidLoad() {
    console.log('ionViewDidLoad MinstrylistPage ');
  } */




}
