import { Component } from '@angular/core';
import { App, NavController, NavParams } from 'ionic-angular';

import { CallserverProvider } from './../../providers/callserver/callserver';

import { TabsPage } from '../../pages/tabs/tabs';


import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})


export class HomePage {

  loginForm: FormGroup;
  userData = { "userid": "", "password": ""};

   loginUserid: string;
   loginPassword: string;

   appObject: any ;


   langChangeArHidden: boolean;
   langChangeEnHidden: boolean;

   loginFormHidden: boolean;
   newUserFormHidden: boolean;
   forgotDetailsFormHidden: boolean;
   loginButtonHidden: boolean;
   newUserButtonHidden: boolean;
   forgotDetailsButtonHidden: boolean;
   otpHidden: boolean;


   useridRegx: any;

/**   // Validation error messages that will be displayed for each form field with errors.
    validation_messages = {
        'myField': [
        { type: 'pattern', message: 'Please enter a number like 0123456789.' }
      ]
    } */


 
  constructor(public navCtrl: NavController, public navParams: NavParams,public callserver: CallserverProvider, public appObject1: App ) {
        this.appObject =  appObject1;   


        this.langChangeArHidden = false;
        this.langChangeEnHidden = true;

        this.loginFormHidden = false;
        this.newUserFormHidden = true;
        this.forgotDetailsFormHidden = true;

        this.loginButtonHidden = true;
        this.newUserButtonHidden = false;
        this.forgotDetailsButtonHidden = false;

        this.otpHidden = true;
 
  }


  ngOnInit() {
    this.loginForm = new FormGroup({
       userid: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'),Validators.maxLength(9)]),
       password: new FormControl()
     });
  }//ngOnInit


  showForm (showForm){
        console.log('Home # showForm : ' + showForm);
      if (showForm == 'loginUser'){         
         this.loginFormHidden = false;
         this.newUserFormHidden = true;
         this.forgotDetailsFormHidden = true;

          this.loginButtonHidden = true;
          this.newUserButtonHidden = false;
          this.forgotDetailsButtonHidden = false;
      }else if (showForm == 'forgotDetails'){    
          this.loginFormHidden = true;
          this.newUserFormHidden = true;
          this.forgotDetailsFormHidden = false;

          this.loginButtonHidden = false;
          this.newUserButtonHidden = false;
          this.forgotDetailsButtonHidden = true;

      }else if (showForm == 'newUser'){    
          this.loginFormHidden = true;
          this.newUserFormHidden = false;
          this.forgotDetailsFormHidden = true;

          this.loginButtonHidden = false;
          this.newUserButtonHidden = true;
          this.forgotDetailsButtonHidden = false;
      }
  } //showForm




  loginUser(loginForm){
  	console.log('HomePage logForm # 1 : ');
  	console.log('HomePage logForm # 1 : ' + this.loginPassword);
  	console.log('HomePage logForm # 1 : ' + this.loginUserid);

    this.callserver.callServerGet ('/action/login').subscribe(
           data => {
               console.log('CallserverProvider Entry # 5 DATA STATUS: ' +  data.status);
          }, err => {
               console.log('CallserverProvider Entry # 4 ERROR STATUS: ' +  err.status);
               console.log('CallserverProvider Entry # 4 ERROR: ' +  err);
              // this.toast.presentToast("Check internet connection");
               if (err.status = "1000"){
                    console.log('CallserverProvider Entry # 4 push toTabsPage : ');
                    // That's right, we're pushing to ourselves!
                    this.appObject.getRootNav().push(TabsPage);
               }else{
                    console.log('CallserverProvider Entry # 4 display error message: ');
               }
          });
  } //close logForm
   


  newUser (newUserForm){
    console.log('HomePage logForm #  2 newUserForm : ');

    this.loginFormHidden = true;
    this.newUserFormHidden = true;
    this.forgotDetailsFormHidden = true;

    this.loginButtonHidden = true;
    this.newUserButtonHidden = true;
    this.forgotDetailsButtonHidden = true;

    this.otpHidden = false;
 
  }



  forgotDetails (forgotDetailsForm){
      console.log('HomePage logForm #  3 forgotDetailsForm : ');
  }

  next(otp){  
    //otp.setFocus();
  }

  submitRegistrationOTP(){
     console.log('HomePage logForm #  9 submitRegistrationOTP : ');
  } //submitRegistrationOTP
      

  closeOTP(){
    this.otpHidden = true;

    this.loginFormHidden = true;
    this.newUserFormHidden = false;
    this.forgotDetailsFormHidden = true;

    this.loginButtonHidden = false;
    this.newUserButtonHidden = true;
    this.forgotDetailsButtonHidden = false;
   

  }//closeOTP


  // header
  langChange(){
      if (!this.langChangeArHidden){
             this.langChangeEnHidden = false;
             this.langChangeArHidden = true;
      }else if(!this.langChangeEnHidden){
             this.langChangeEnHidden = true;
             this.langChangeArHidden = false;
      }
  } //langChange


  isValidNumber(event){  
      console.log('HomePage logForm #  9 submitRegistrationOTP : '+ event.keyCode);
      console.log('HomePage logForm #  9 submitRegistrationOTP : '+ event.key);

  }


  


} //  Close Home
