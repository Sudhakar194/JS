import { Component } from '@angular/core';

import { FavNotificationPage } from '../fav-notification/fav-notification';
import { MinstrylistPage } from '../minstrylist/minstrylist';




@Component({
	 selector: 'page-tabs',
     templateUrl: 'tabs.html'
})


export class TabsPage {

  minstryPagTab = MinstrylistPage;
  mainFavPageTab = FavNotificationPage;
 
 // tab3Root = ContactPage;

  constructor() {

  }



}
