//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';


 //  FileParserProvider.setInstance(this.file);
 //  FileParserProvider.instance.doFileInteractions();

@Injectable()
export class FileParserProvider {

 static instance: FileParserProvider;
    jsonData: {} = {};
    nativeURL: string;
    fileName = 'data.json';


  constructor(public http: Http) {
    console.log('Hello FileParserProvider Provider');


  }

/**

 doFileInteractions() {
        let that = this;
        let writeDataCompletionHandler = function (success, data) {
            if (success) {
                console.log('Final jsonData');
                console.log(that.jsonData);
            }
            else {

            }
        }
        let readDataCompletionHandler = function (success, data) {
            if (success) {
                that.jsonData = JSON.parse(data);
                console.log('JSON data...');
                console.log(that.jsonData);
                that.writeJsonData(writeDataCompletionHandler)
            }
            else {

            }
        }
        this.readJsonData(readDataCompletionHandler)
    }

    readJsonData(completionHandler) {
        let dirName = 'www/assets/data';
        console.log('this.file.applicationDirectory>>');
        console.log(this.file.applicationDirectory);

        this.file.listDir(this.file.applicationDirectory, dirName)
            .then((list) => {
                console.log('Success: listDir');
                console.log(list);
                list.forEach(element => {
                    if (element.name == this.fileName) {
                        // READ FILE
                        this.nativeURL = element.nativeURL.replace('/' + this.fileName, '')
                        this.file.readAsText(this.nativeURL, this.fileName)
                            .then((result) => {
                                console.log('Success: readAsText');
                                console.log(result);
                                completionHandler(true, result);
                            })
                            .catch((error) => {
                                console.log('Failure: readAsText');
                                console.log(error);
                                completionHandler(false, error);
                            })
                        console.log('nativeURL: ');
                        console.log(this.nativeURL);
                    }
                });
            })
            .catch((error) => {
                console.log('Failure: listDir');
                console.log(error)
            })

    }


    writeJsonData(completionHandler) {
        // WRITE FILE
        this.jsonData['data']['newData'] = 'X1234';
        let stringyfiedJson = JSON.stringify(this.jsonData);
        this.file.writeFile(this.nativeURL, this.fileName, stringyfiedJson, { append: false, replace: true })
            .then((result) => {
                console.log('Success: Writefile');
                console.log(result);
                completionHandler(true, result);
            })
            .catch((error) => {
                console.log('Failure: WriteFile');
                console.log(error);
                completionHandler(false, error);
            })
    }

   
    static setInstance(file: File) {
    if (!this.instance) {
        //this.instance = new Util_Parser(file);
        this.instance = file;
    }

}

*/

}
