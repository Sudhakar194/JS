import { HttpHeaders  } from '@angular/common/http';
import { Http } from '@angular/http';

import { RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';

import { File } from '@ionic-native/file';



@Injectable()
export class CallserverProvider {
  

  nativeURL: string ;
  jsonData: {} = {};

 // mainURL: string="http://localhost:5555/IGANotifications_java";
  //mainURL: string="http://localhost:8080/IGANotifications_java";
  mainURL: string="http://192.168.1.102:8080/IGANotifications_java"

  constructor(public http: Http, public file: File) {
    	console.log('CallserverProvider Entry # 1 : ');
    
       // this.setLocaldata();
  
        
  }

                

  public callServer_Get(reqPath){
      console.log('CallserverProvider callServerGet Entry # 2 : '+ this.mainURL + reqPath);
      return this.http.get(this.mainURL + reqPath).map(res => res.json());
  } //callServerGet


  public getLocaldata(path: string) : any {
      console.log('CallserverProvider callLocalGet Entry # 3 : ');
      return this.http.get(path).map(res => res.json());
  } 

  public setLocaldata() {
      console.log('CallserverProvider setLocaldata writeExistingFile # 3 : ' );
      
      //file write externalApplicationStorageDirectory :::  file:///storage/emulated/0/Android/data/com.iga.notifications/",
      //file write externalDataDirectory :::  file:///storage/emulated/0/Android/data/com.iga.notifications/files/", source:
      //file write externalRootDirectory :::  file:///storage/emulated/0/", source: http://localhost:8080/build/main.js (101
      //file write documentsDirectory :::  null", source: http://localhost:8080/build/main.js (1017)


      let dirName = 'www/assets/data';
      let fileName = 'test.json';

  
      // file:///android_asset/www/assets/data
       this.file.listDir(this.file.applicationDirectory , dirName)
          .then((list)=> {        
                  list.forEach(element => {
                    console.log('nativeURL2 : '  + element.name);
                    if (element.name == fileName) {
                          this.nativeURL = element.nativeURL.replace('/' + fileName, '')
                          console.log('nativeURL3 : '  + this.nativeURL);      
                          console.log('fileName : '  + fileName); 

                       }
                  });
            }).catch((error) => {
                      console.log('Failure2: listDir');
                      console.log(error);
            });



              this.getLocaldata('').subscribe(
                  data => {                                     
                          console.log('getGCCList Entry # 2 : ' +  data.errorCode);
                          let stringyfiedJson = JSON.stringify(data);
                          console.log('getGCCList Entry # 2 : ' +  stringyfiedJson);
                        
                          console.log('getGCCList externalApplicationStorageDirectory # 3 : ' +  this.file.externalApplicationStorageDirectory);

                           this.file.writeFile(this.file.externalApplicationStorageDirectory, fileName, stringyfiedJson, { append: false, replace: true })
                              .then(data => console.log(' file write success1' + JSON.stringify(data)))
                              .catch(err => console.log(' filr write err1 : ' + JSON.stringify(err))
                          );

                          let filepath =  this.file.externalApplicationStorageDirectory + fileName;
                          console.log(' getGCCList file read filepath :  ' + filepath);
                          this.http.get(filepath).map(res => res.json()).subscribe(
                              data=>{
                               console.log(' file read success1 :  ' +  JSON.stringify(data));

                              }, err=>{
                                  console.log(' filr write err1 : ' + JSON.stringify(err));
                              }) ;      
                          

                     }, err => {
                         console.log('getGCCList ERROR STATUS: ' +  err.status);
                         console.log('getGCCList ERROR: ' +  err);        
                  });



                         



      

}


/**
    public callServer_Post(){
    	  var headers = new HttpHeaders();    
    	  headers.append("Accept","application/json");
        headers.append('Content-type','application/json');

        let requestOptions = new RequestOptions({headers: headers })

        let postReqData = {"userid": "sudhakar", "password":"sudhakar"}       


        this.http.post("http://localhost:5555/IGANotifications_java/action/test", postReqData, requestOptions).subscribe(
           data => {
             console.log('CallserverProvider Entry # 4 : ' +  data.status);
              this.items = [];
              for (let i = 0;  i<= 1 ; i++){
                console.log('CallserverProvider Entry # 10 : ' +  data[i].lname);       
                console.log('CallserverProvider Entry # 11 : ' +  data[i].fname);
              }

          }, err => {
               console.log('CallserverProvider Entry # 4 : ' +  err.status);
               console.log('CallserverProvider Entry # 4 : ' +  err);
              // this.toast.presentToast("Check internet connection");
          });
    }

   */



}
