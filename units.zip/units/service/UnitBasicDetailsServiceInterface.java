package bh.gov.cio.integration.crs.retrieve.units.service;

import javax.jws.WebMethod;

import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitBasicDetailsDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;

/**
 * @author thpbsm
 * 
 */

@WebService(name = "UnitBasicDetailsService", targetNamespace = "http://service.units.retrieve.crs.integration.sio.gov.bh/")
public interface UnitBasicDetailsServiceInterface
{
	@WebResult(name = "UnitBasicDetails")
	@WebMethod(operationName = "GetUnitBasicDetails")
	UnitBasicDetailsDTO getUnitDetails(
			@WebParam(mode = WebParam.Mode.IN, name = "Security", header = true) SecurityTagObject security,
			@WebParam(name = "UnitNumber") @XmlElement(required = true) Integer unitNumber)
			throws ApplicationExceptionInfo;

}