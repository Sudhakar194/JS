package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author thpbsm
 * 
 */
@XmlType(name = "UnitMainActivityDetails", propOrder = { "unitMainActivityCode","unitMainActivityNameAr", "unitMainActivityNameEn" })
public class UnitMainActivityDetailsDTO {
	private String unitMainActivityCode;
	private String unitMainActivityNameAr;
	private String unitMainActivityNameEn;

	public UnitMainActivityDetailsDTO(String unitMainActivityCode, String unitMainActivityNameAr, String unitMainActivityNameEn) {
		super();
		this.unitMainActivityCode   = unitMainActivityCode;
		this.unitMainActivityNameAr = unitMainActivityNameAr;
		this.unitMainActivityNameEn = unitMainActivityNameEn;
	}
    
	@XmlElement(name = "UnitMainActivityCode", required = true)
	public String getUnitMainActivityCode() {
		return unitMainActivityCode;
	}

	public void setUnitMainActivityCode(String unitMainActivityCode) {
		this.unitMainActivityCode = unitMainActivityCode;
	}

	@XmlElement(name = "UnitMainActivityNameAr", required = true)
	public String getUnitMainActivityNameAr() {
		return unitMainActivityNameAr;
	}

	public void setUnitMainActivityNameAr(String unitMainActivityNameAr) {
		this.unitMainActivityNameAr = unitMainActivityNameAr;
	}

	@XmlElement(name = "UnitMainActivityNameEn", required = true)
	public String getUnitMainActivityNameEn() {
		return unitMainActivityNameEn;
	}

	public void setUnitMainActivityNameEn(String unitMainActivityNameEn) {
		this.unitMainActivityNameEn = unitMainActivityNameEn;
	}

	public UnitMainActivityDetailsDTO() {
		super();

	}

}
