package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author thpbsm
 * 
 */
@XmlType(name = "UnitOwnerNumbersAndTypeDTO", propOrder ={ "unitOwnerNumber", "unitOwnerType"})
public class UnitOwnerNumbersAndTypeDTO
{
	private Integer unitOwnerNumber;
	private String unitOwnerType;

	
	public UnitOwnerNumbersAndTypeDTO()
	{
		super();
	}

	public UnitOwnerNumbersAndTypeDTO(Integer unitOwnerNumber, String unitOwnerType)
	{
		super();
		this.unitOwnerNumber = unitOwnerNumber;
		this.unitOwnerType = unitOwnerType;
	}

	@XmlElement(name = "UnitOwnerNumber", required = true)
	public Integer getUnitOwnerNumber() {
		return unitOwnerNumber;
	}

	public void setUnitOwnerNumber(Integer unitOwnerNumber) {
		this.unitOwnerNumber = unitOwnerNumber;
	}

	@XmlElement(name = "UnitOwnerType", required = true)
	public String getUnitOwnerType() {
		return unitOwnerType;
	}

	public void setUnitOwnerType(String unitOwnerType) {
		this.unitOwnerType = unitOwnerType;
	}

	

}
