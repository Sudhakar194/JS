package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "UnitAddressDetails", propOrder = { "flatNumber", "buildingNumber", "roadNumber", "blockNumber",
		"region", "poBox", "phoneNumber", "email"})
public class UnitAddressDetailsDTO {

	private Integer blockNumber;
	private Integer buildingNumber;
	private Integer roadNumber;
	private Integer flatNumber;

	private String region;
	private Integer poBox;
	private String phoneNumber;
	private String email;
	

	public UnitAddressDetailsDTO() {
		super();
	}
	
	public UnitAddressDetailsDTO(Integer flatNumber, Integer buildingNumber, Integer roadNumber,  Integer blockNumber
			, String region, Integer poBox, String phoneNumber, String email) {
		super();
		this.blockNumber = blockNumber;
		this.buildingNumber = buildingNumber;
		
		this.roadNumber = roadNumber;
		this.flatNumber = flatNumber;
		
		this.region = region;
		this.poBox = poBox;
		this.phoneNumber = phoneNumber;
		this.email = email;
		
	}
  
	@XmlElement(name = "Region", required = true)
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	@XmlElement(name = "POBox", required = true)
	public Integer getPoBox() {
		return poBox;
	}

	public void setPoBox(Integer poBox) {
		this.poBox = poBox;
	}

	@XmlElement(name = "PhoneNumber", required = true)
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@XmlElement(name = "Email", required = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	@XmlElement(name = "BlockNumber", required = true)
	public Integer getBlockNumber() {
		return blockNumber;
	}

	public void setBlockNumber(Integer blockNumber) {
		this.blockNumber = blockNumber;
	}

	@XmlElement(name = "BuildingNumber", required = true)
	public Integer getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(Integer buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	@XmlElement(name = "RoadNumber", required = true)
	public Integer getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(Integer roadNumber) {
		this.roadNumber = roadNumber;
	}

	@XmlElement(name = "FlatNumber", required = true)
	public Integer getFlatNumber() {
		return flatNumber;
	}

	public void setFlatNumber(Integer flatNumber) {
		this.flatNumber = flatNumber;
	}
	
	



}