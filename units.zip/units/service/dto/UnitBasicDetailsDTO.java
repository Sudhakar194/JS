package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
/**
 * @author thpbsm
 * 
 */

@XmlType(name = "UnitBasicDetails", propOrder ={ "unitNumber", "unitNameAr", "unitNameEn", "unitSectorCode", "unitSectorNameAr", "unitSectorNameEn", 
  "unitMainActivityDetails", "unitOwnerNumbersAndType", "unitOperationDate", "unitClosingDate", "unitAddressDetails"})
public class UnitBasicDetailsDTO
{
	private Integer unitNumber;
	private String unitNameAr;
	private String unitNameEn;
	private UnitAddressDetailsDTO unitAddressDetails;
	private String unitSectorCode;
	private String unitSectorNameAr;
	private String unitSectorNameEn;
	private List<UnitMainActivityDetailsDTO> unitMainActivityDetails;
	private List<UnitOwnerNumbersAndTypeDTO> unitOwnerNumbersAndType;
	private Date unitOperationDate;
	private Date unitClosingDate;
	
	

	public UnitBasicDetailsDTO()
	{
		super();
	}
	
	public UnitBasicDetailsDTO(Integer unitNumber, String unitNameAr, String unitNameEn, String unitSectorCode, String unitSectorNameAr, String unitSectorNameEn,
			List<UnitMainActivityDetailsDTO> unitMainActivityDetails, List<UnitOwnerNumbersAndTypeDTO> unitOwnerNumbersAndType,
			Date unitOperationDate, Date unitClosingDate,UnitAddressDetailsDTO unitAddressDetails)
	{
		super();
		this.unitAddressDetails = unitAddressDetails;
		
		this.unitNumber = unitNumber;
		this.unitNameAr = unitNameAr;
		this.unitNameEn = unitNameEn;
		this.unitSectorCode = unitSectorCode;
		this.unitSectorNameAr = unitSectorNameAr;
		this.unitSectorNameEn = unitSectorNameEn;
		
		this.unitMainActivityDetails = unitMainActivityDetails;
		this.unitOwnerNumbersAndType = unitOwnerNumbersAndType;
		
		this.unitOperationDate = unitOperationDate;
		this.unitClosingDate = unitClosingDate;
	}
	
	@XmlElement(name = "UnitOwnerDetails", required = true)
	public List<UnitOwnerNumbersAndTypeDTO> getUnitOwnerNumbersAndType() {
		return unitOwnerNumbersAndType;
	}

	public void setUnitOwnerNumbersAndType(List<UnitOwnerNumbersAndTypeDTO> unitOwnerNumbersAndType) {
		this.unitOwnerNumbersAndType = unitOwnerNumbersAndType;
	}

	@XmlElement(name = "UnitMainActivityDetails", required = true)
	public List<UnitMainActivityDetailsDTO> getUnitMainActivityDetails() {
		return unitMainActivityDetails;
	}

	public void setUnitMainActivityDetails(List<UnitMainActivityDetailsDTO> unitMainActivityDetails) {
		this.unitMainActivityDetails = unitMainActivityDetails;
	}

	@XmlElement(name = "UnitNumber", required = true)
	public Integer getUnitNumber() {
		return unitNumber;
	}

	public void setUnitNumber(Integer unitNumber) {
		this.unitNumber = unitNumber;
	}

	@XmlElement(name = "UnitNameAr", required = true)
	public String getUnitNameAr() {
		return unitNameAr;
	}

	public void setUnitNameAr(String unitNameAr) {
		this.unitNameAr = unitNameAr;
	}

	@XmlElement(name = "UnitNameEn", required = true)
	public String getUnitNameEn() {
		return unitNameEn;
	}

	public void setUnitNameEn(String unitNameEn) {
		this.unitNameEn = unitNameEn;
	}
	
	@XmlElement(name = "UnitSectorCode", required = true)
	public String getUnitSectorCode() {
		return unitSectorCode;
	}

	public void setUnitSectorCode(String unitSectorCode) {
		this.unitSectorCode = unitSectorCode;
	}

	@XmlElement(name = "UnitSectorNameAr", required = true)
	public String getUnitSectorNameAr() {
		return unitSectorNameAr;
	}

	public void setUnitSectorNameAr(String unitSectorNameAr) {
		this.unitSectorNameAr = unitSectorNameAr;
	}
	
	@XmlElement(name = "UnitSectorNameEn", required = true)
	public String getUnitSectorNameEn() {
		return unitSectorNameEn;
	}

	public void setUnitSectorNameEn(String unitSectorNameEn) {
		this.unitSectorNameEn = unitSectorNameEn;
	}

	@XmlElement(name = "UnitOperationStartDate", required = true)
	public Date getUnitOperationDate() {
		return unitOperationDate;
	}

	public void setUnitOperationDate(Date unitOperationDate) {
		this.unitOperationDate = unitOperationDate;
	}
	
	@XmlElement(name = "UnitClosingDate", required = true)
	public Date getUnitClosingDate() {
		return unitClosingDate;
	}

	public void setUnitClosingDate(Date unitClosingDate) {
		this.unitClosingDate = unitClosingDate;
	}

	@XmlElement(name = "UnitAddressDetails", required = true)
	public UnitAddressDetailsDTO getUnitAddressDetails() {
		return unitAddressDetails;
	}

	public void setUnitAddressDetails(UnitAddressDetailsDTO unitAddressDetails) {
		this.unitAddressDetails = unitAddressDetails;
	}

	

}





