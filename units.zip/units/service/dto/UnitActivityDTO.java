package bh.gov.cio.integration.crs.retrieve.units.service.dto;

import javax.xml.bind.annotation.XmlType;

/**
 * @author csdvsbu
 * 
 */
@XmlType(name = "UnitActivity", propOrder =
{ "activityCode", "activityArabicName", "activityEnglishName" })
public class UnitActivityDTO
{
	private String activityCode;
	private String activityArabicName;
	private String activityEnglishName;

	public UnitActivityDTO()
	{
		super();

	}

	public UnitActivityDTO(String activityCode, String activityArabicName, String activityEnglishName)
	{
		super();
		this.activityCode = activityCode;
		this.activityArabicName = activityArabicName;
		this.activityEnglishName = activityEnglishName;
	}

	public String getActivityArabicName()
	{
		return activityArabicName;
	}

	public String getActivityCode()
	{
		return activityCode;
	}

	public String getActivityEnglishName()
	{
		return activityEnglishName;
	}

	public void setActivityArabicName(String activityArabicName)
	{
		this.activityArabicName = activityArabicName;
	}

	public void setActivityCode(String activityCode)
	{
		this.activityCode = activityCode;
	}

	public void setActivityEnglishName(String activityEnglishName)
	{
		this.activityEnglishName = activityEnglishName;
	}

}
