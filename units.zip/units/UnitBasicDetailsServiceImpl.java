package bh.gov.cio.integration.crs.retrieve.units;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;

import bh.gov.cio.crs.model.unit.UnitActivity;
import bh.gov.cio.crs.model.unit.UnitContact;
import bh.gov.cio.crs.model.unit.UnitEntity;
import bh.gov.cio.crs.model.unit.UnitInfo;
import bh.gov.cio.crs.service.UnitService;
import bh.gov.cio.integration.common.CRSServicesProviderServiceImpl;
import bh.gov.cio.integration.common.ValidationServiceImpl;
import bh.gov.cio.integration.crs.retrieve.units.service.UnitBasicDetailsServiceInterface;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitAddressDetailsDTO;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitBasicDetailsDTO;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitMainActivityDetailsDTO;
import bh.gov.cio.integration.crs.retrieve.units.service.dto.UnitOwnerNumbersAndTypeDTO;
import bh.gov.cio.integration.exception.ApplicationExceptionInfo;
import bh.gov.cio.integration.security.SecurityTagObject;


/**
 * @author thpbsm
 * 
 */

@WebService(name = "UnitBasicDetailsService", targetNamespace = "http://service.units.retrieve.crs.integration.sio.gov.bh/")
public class UnitBasicDetailsServiceImpl implements UnitBasicDetailsServiceInterface {
	/**
	 * Logger for this class
	 */
	private static final Logger logger = LoggerFactory.getLogger(UnitBasicDetailsServiceImpl.class);

	@Autowired
	private ValidationServiceImpl validationUtil;
	@Autowired
	private CRSServicesProviderServiceImpl crsService;

	@WebMethod(exclude = true)
	public CRSServicesProviderServiceImpl getCrsService() {
		return crsService;
	}

	@Override
	@Secured({ "ROLE_getUnitBasicDetails" })
	@WebMethod(operationName = "GetUnitBasicDetails")
	public UnitBasicDetailsDTO getUnitDetails(SecurityTagObject security, Integer unitNumber)
			throws ApplicationExceptionInfo {
		
		if (logger.isDebugEnabled())
			logger.debug("GetUnitBasicDetails(Integer) - start" + unitNumber);
		
		UnitBasicDetailsDTO returnedDetails = null;
		

		if ((unitNumber >= 70000000  && unitNumber <= 79999999)) {
			
			ArrayList<UnitMainActivityDetailsDTO> unitMainActivity = null;
			ArrayList<UnitOwnerNumbersAndTypeDTO> unitOwnerNumbers = null;
			UnitAddressDetailsDTO unitAddress = null;
			
			ArrayList<UnitActivity> unitActivities = null;
			ArrayList<UnitEntity>   ownerNumbers   = null;
			UnitInfo unitBasicInfo  = null;
			UnitContact unitContact = null;
			List<bh.gov.cio.crs.model.unit.UnitAddress> addresses = null;
			
			try {
				UnitService us = getCrsService().getUnitServiceRef();
				unitBasicInfo = us.getUnitBasicInfo(unitNumber);
				addresses   = us.getUnitAddresses(unitNumber);
				unitContact = us.getUnitContact(unitNumber);
				unitActivities = (ArrayList<UnitActivity>) us.getUnitActivities(unitNumber);
				ownerNumbers   = (ArrayList<UnitEntity>) us.getUnitOwner(unitNumber);
				
				/*if (logger.isDebugEnabled())
					logger.debug("GetUnitBasicDetails-SIO  - unitBasicInfo: ",unitBasicInfo);
					logger.debug("GetUnitBasicDetails-SIO  - addresses: ",addresses);
					logger.debug("GetUnitBasicDetails-SIO  - unitContact: ",unitContact);
				    logger.debug("GetUnitBasicDetails-SIO  - Owners:  ",ownerNumbers);
					logger.debug("GetUnitBasicDetails-SIO  - MainActivities: ", unitActivities);*/
				
				
			} catch (final Exception exception) {
				//logger.debug("GetUnitBasicDetails-SIO  - Exception: ", exception.getMessage());
				exception.printStackTrace();
			}
			

			unitMainActivity = new ArrayList<UnitMainActivityDetailsDTO>();
			if (unitActivities != null) {
				for (UnitActivity unitActivity : unitActivities) {
					UnitMainActivityDetailsDTO mainActivity = new UnitMainActivityDetailsDTO(unitActivity.getMainActivityCode(),
							unitActivity.getMainActivityEnNm(), unitActivity.getMainActivityEnNm());
					unitMainActivity.add(mainActivity);
				}
			}else
				unitMainActivity.add(new UnitMainActivityDetailsDTO(" "," ", " "));
			
			unitOwnerNumbers = new ArrayList<UnitOwnerNumbersAndTypeDTO>();
			if (ownerNumbers != null) {
				for (UnitEntity owner : ownerNumbers) {
					UnitOwnerNumbersAndTypeDTO unitOwnerNumbersAndTypeDTO = new UnitOwnerNumbersAndTypeDTO(owner.getEntityNumber(), owner.getEntityType());
					unitOwnerNumbers.add(unitOwnerNumbersAndTypeDTO);
				}
			}else unitOwnerNumbers.add(new UnitOwnerNumbersAndTypeDTO(0, " "));
			
			
			String unitArabicName   = unitBasicInfo.getUnitArabicName();
			String unitEnglishName  = unitBasicInfo.getUnitEnglishName();
			
		    String unitSectorCode   = unitBasicInfo.getUnitSectorCode();
		    String unitSectorNameAr = unitBasicInfo.getSectorArName();
		    String unitSectorNameEn = unitBasicInfo.getSectorEnName();
		    
		    Date unitOperationDate = unitBasicInfo.getOperationStartDateAsDate();
		    Date unitClosingDate = unitBasicInfo.getOperationEndDateAsDate(); 
		    
		    String phoneNumber = unitContact.getPhoneContact();  
		    Integer poBoxNumber = unitContact.getPoBox(); 
		    String email = unitContact.getEmail(); 

			if (addresses != null) {
				final bh.gov.cio.crs.model.unit.UnitAddress returnedAddressRow = addresses.get(addresses.size() - 1);
				unitAddress = new UnitAddressDetailsDTO(returnedAddressRow.getFlatNumber(),returnedAddressRow.getBuildingNumber(),returnedAddressRow.getRoadNumber(),
						returnedAddressRow.getBlockNumber(),returnedAddressRow.getRegionEnName(),poBoxNumber,phoneNumber,email);
			}

			returnedDetails = new UnitBasicDetailsDTO(unitNumber, unitArabicName, unitEnglishName, unitSectorCode, unitSectorNameAr, unitSectorNameEn, 
					unitMainActivity, unitOwnerNumbers, unitOperationDate, unitClosingDate, unitAddress);
			
			
			if (logger.isDebugEnabled())
				logger.debug("GetUnitBasicDetails-SIO  - end");
		} else {
			throw new ApplicationExceptionInfo("Unit Number Out Of Range",
					new bh.gov.cio.integration.exception.ApplicationException("Unit Number Out Of Range", "001"));
		}

		return returnedDetails;
	}

	@WebMethod(exclude = true)
	public ValidationServiceImpl getValidationUtil() {
		return validationUtil;
	}

	@WebMethod(exclude = true)
	public void setCrsService(CRSServicesProviderServiceImpl crsService) {
		this.crsService = crsService;
	}

	@WebMethod(exclude = true)
	public void setValidationUtil(ValidationServiceImpl validationUtil) {
		this.validationUtil = validationUtil;
	}

}