import { Component } from '@angular/core';
import { App, NavController, NavParams } from 'ionic-angular';
import { NotificationPage } from '../notification/notification';

import { GlobalProvider } from './../../providers/global/global';


@Component({
  selector: 'page-minstrylist',
  templateUrl: 'minstrylist.html',
})

export class MinstrylistPage {	  

	  constructor(public navCtrl: NavController, public navParams: NavParams, public appObject: App,
	  		      public g: GlobalProvider) {
	   
			console.log('MinstrylistPage#constructor : ');
	  }

		pushMinistryNotificationPage(item){		
			console.log('MinstrylistPage#pushMinistryNotificationPage : ' + item.code);	   
			this.navCtrl.push(NotificationPage, {item: item}); 
		}



}
