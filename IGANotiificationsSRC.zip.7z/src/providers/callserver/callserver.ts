import { HttpHeaders  } from '@angular/common/http';
import { Http } from '@angular/http';

import { RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';


@Injectable()
export class CallserverProvider {
  

  //mainURL: String="http://localhost:5555/IGANotifications_java";
  mainURL: String="http://localhost:8080/IGANotifications_java";

  constructor(public http: Http) {
    	console.log('CallserverProvider Entry # 1 : ');
  }


 /**  
                items: Array<{fname: String, lname:String}>;   
                this.items = [];
                for (let i = 0;  i<= 1 ; i++){
                  console.log('CallserverProvider Entry # 5 : ' +  data[i].lname);       
                  console.log('CallserverProvider Entry # 5 : ' +  data[i].fname);
                } */

                

  public callServerGet(reqPath){
      console.log('CallserverProvider callServerGet Entry # 2 : '+ this.mainURL + reqPath);
      return this.http.get(this.mainURL + reqPath).map(res => res.json());
  } //callServerGet


/**public callServerPost(){
    	  var headers = new HttpHeaders();    
    	  headers.append("Accept","application/json");
        headers.append('Content-type','application/json');

        let requestOptions = new RequestOptions({headers: headers })

        let postReqData = {"userid": "sudhakar", "password":"sudhakar"}       

        this.http.post("http://localhost:5555/IGANotifications_java/action/test", postReqData, requestOptions).subscribe(
           data => {
             console.log('CallserverProvider Entry # 4 : ' +  data.status);
              this.items = [];
              for (let i = 0;  i<= 1 ; i++){
                console.log('CallserverProvider Entry # 10 : ' +  data[i].lname);       
                console.log('CallserverProvider Entry # 11 : ' +  data[i].fname);
              }

          }, err => {
               console.log('CallserverProvider Entry # 4 : ' +  err.status);
               console.log('CallserverProvider Entry # 4 : ' +  err);
              // this.toast.presentToast("Check internet connection");
          });


  } */



}
