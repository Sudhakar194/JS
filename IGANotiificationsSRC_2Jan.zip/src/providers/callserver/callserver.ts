import { HttpHeaders  } from '@angular/common/http';
import { Http } from '@angular/http';

import { RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';

import { File } from '@ionic-native/file';


import { FileParserProvider } from './../../providers/file-parser/file-parser';


@Injectable()
export class CallserverProvider {
  

  mainURL: String="http://localhost:5555/IGANotifications_java";
  //mainURL: String="http://localhost:8080/IGANotifications_java";

  constructor(public http: Http, public file: File) {
    	console.log('CallserverProvider Entry # 1 : ');
    
      this.setLocaldata();

        
      //  FileParserProvider.setInstance(this.file);
       //  FileParserProvider.instance.doFileInteractions();
  }

                

  public callServer_Get(reqPath){
      console.log('CallserverProvider callServerGet Entry # 2 : '+ this.mainURL + reqPath);
      return this.http.get(this.mainURL + reqPath).map(res => res.json());
  } //callServerGet


  public getLocaldata() : any {
      console.log('CallserverProvider callLocalGet Entry # 3 : ');
      return this.http.get('assets/data/gcclist.json').map(res => res.json());
  } 


  public setLocaldata() {
      console.log('CallserverProvider setLocaldata writeExistingFile # 3 : ' );
      

       // var parser: any = new X2JS();
        var temp: any;

        temp = { "FILES":  { "FILE": { "FileName": 'test.txt'  } } }
      //  let content = parser.js2xml(temp);
        let content = temp;
        this.file.writeFile('www/assets/data/', 'file.xml', content, { append: true, replace: false })
            .then(_ => alert('success'))
            .catch(err => alert('err : ' + err));



       this.file.writeExistingFile('www/assets/data/','test.json','{test:100}')
       .then(data => console.log('Directory exists' + data))
       .catch(err => console.log('Directory doesn\'t exist' + err));

  }


/**
    public callServer_Post(){
    	  var headers = new HttpHeaders();    
    	  headers.append("Accept","application/json");
        headers.append('Content-type','application/json');

        let requestOptions = new RequestOptions({headers: headers })

        let postReqData = {"userid": "sudhakar", "password":"sudhakar"}       

        this.http.post("http://localhost:5555/IGANotifications_java/action/test", postReqData, requestOptions).subscribe(
           data => {
             console.log('CallserverProvider Entry # 4 : ' +  data.status);
              this.items = [];
              for (let i = 0;  i<= 1 ; i++){
                console.log('CallserverProvider Entry # 10 : ' +  data[i].lname);       
                console.log('CallserverProvider Entry # 11 : ' +  data[i].fname);
              }

          }, err => {
               console.log('CallserverProvider Entry # 4 : ' +  err.status);
               console.log('CallserverProvider Entry # 4 : ' +  err);
              // this.toast.presentToast("Check internet connection");
          });
    }

   */



}
