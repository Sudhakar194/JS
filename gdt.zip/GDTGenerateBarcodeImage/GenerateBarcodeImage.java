import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;

import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;

import com.sun.org.apache.xml.internal.security.utils.Base64;

/**
 * This class use to create a barcode image byte array with one input parameter "Alphanumeric"

 */
public class GenerateBarcodeImage {
	
	    public String BarcodeImageGenerator(String barcodeNum) {
	    	String responseMsg ;
	        try {
	        	//System.out.println("GenerateBarcodeImage 1: " + barcodeNum );
	            //Create the barcode bean
	            Code39Bean bean = new Code39Bean();
	            final int dpi = 150;
	            //Configure the barcode generator
	            bean.setModuleWidth(UnitConv.in2mm(1.0f / dpi)); //makes the narrow bar 
	                                                             //width exactly one pixel
	            bean.setWideFactor(3);
	            bean.doQuietZone(false);
	            //Open output file
	            // File outputFile = new File("c:/gdt_barcode.png");
	            //OutputStream out = new FileOutputStream(outputFile);
	            ByteArrayOutputStream out = new ByteArrayOutputStream();  // production line
	            BitmapCanvasProvider canvas = null;
	            try {
	                //Set up the canvas provider for monochrome JPEG output 
	                canvas = new BitmapCanvasProvider(out, "image/png", dpi, BufferedImage.TYPE_BYTE_BINARY, false, 0);
	                //Generate the barcode
	                bean.generateBarcode(canvas, barcodeNum);
	                /*System.out.println("RESULT001::" + canvas.getBufferedImage().getHeight());
	                System.out.println("RESULT001::" + canvas.getBufferedImage().getWidth());
	                System.out.println("RESULT001::" + canvas.getDimensions().getWidth());
	                System.out.println("RESULT001::" + canvas.getDimensions().getHeight());*/
	                //Signal end of generation
	               
	            } catch (Exception e) {
	            	//e.printStackTrace();
	            	responseMsg = "RESULT001::" + e.getMessage();
	            	System.out.println("RESULT001:: "+ barcodeNum+ ", " + e.getMessage());
				}finally{
					if(canvas!=null)
						canvas.finish();					
				}
				
				//System.out.println("GenerateBarcodeImage 2: " + barcodeNum );
				
	            responseMsg= "RESULT000::" + Base64.encode(out.toByteArray());;
	        } catch (Exception e) {
	        	e.printStackTrace();
	        	responseMsg = "RESULT001::" + e.getMessage();
	        	System.out.println("RESULT001:: "+ barcodeNum + ", " + e.getMessage());
	        }
	        return responseMsg;
	    }
	    public static void main(String[] args) {
		    	try{		    	
		    		//System.err.println("GenerateBarcodeImage main: start " + args[0] );
		    		String encodeImg = new GenerateBarcodeImage().BarcodeImageGenerator(args[0]);
		    		BufferedWriter log = new BufferedWriter(new OutputStreamWriter(System.out));  // production line
		    	    log.write(encodeImg);  // production line		    	    
		    	    log.flush();  // production line
			    	// System.out.println("image :: " + encodeImg);
			    	// BufferedImage image = ImageIO.read(new ByteArrayInputStream(Base64.decode(encodeImg.replaceAll("RESULT000::", "").getBytes())));
			    	// ImageIO.write(image, "png", new File("c:/gdt_barcode1.png"));	    	
		    	   // System.out.println("GenerateBarcodeImage main: finish " + args[0] );
		    	}catch (Exception e) {
					e.printStackTrace();
					System.out.println("RESULT001:: "+args[0]+", " + e.getMessage());
				}
			}

		
}