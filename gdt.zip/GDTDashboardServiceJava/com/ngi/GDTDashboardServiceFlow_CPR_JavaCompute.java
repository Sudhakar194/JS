/********************************************************************************************
 * 																							*
 * File Name : GDTDashboardServiceFlow_CPR_JavaCompute.java									*
 * 																							*
 * Purpose   : Constructs final response structure for retrieve CPR contraventions			*
 * 																							*
 * Authors	 : Thiyaneswaran R																*
 * 			   Umashankar Reddy GR															*
 * 																							*
 * Date      : 20 January 2015																*
 * 																							*
 * Version   : 1.0																			*
 * 																							*
 *******************************************************************************************/

// Declare PAckage name
package com.ngi;

// Import the required packages
import java.util.List;
import java.util.StringTokenizer;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbUserException;
import com.ibm.broker.plugin.MbXMLNSC;

// GDTDashboardServiceFlow_CPR_JavaCompute class
public class GDTDashboardServiceFlow_CPR_JavaCompute extends MbJavaComputeNode 
{
	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		MbMessage inMessage = inAssembly.getMessage();
		MbMessage outMessage = new MbMessage(); // create an empty output message
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);
		copyMessageHeaders(inMessage, outMessage); // copy headers from the input message
		
		try 
		{
			// ----------------------------------------------------------
			// Add user code below
			
			MbElement inRoot = inMessage.getRootElement();
			MbElement outRoot = outMessage.getRootElement();
			MbElement outBody = outRoot.createElementAsLastChild("XMLNSC"); // create the 'Body' XMLNSC element

			MbMessage globalMessage = inAssembly.getGlobalEnvironment();
			
			final MbElement variableElement = globalMessage.getRootElement().getFirstElementByPath("Variables");

			// Declare the class to loop the Contraventions in outRoot for matching ticketNumber
			final ForEachChildOperation createCD = new ForEachChildOperation("Contravention") 
			{
				String cprNumber = "";
				MbElement outContraventionElementParent = null;
				int counter = 0;
				
				@Override
				protected void before() throws MbException 
				{
					System.out.println("*************************************************");
					counter = 0;
					System.out.println("Resetting the Environment variable Flags");
					variableElement.getFirstElementByPath("isMatchFound").setValue(false);
					variableElement.getFirstElementByPath("insertPosition").setValue(0);
				}

				protected void forEachElement(MbElement outContraventionElement) throws MbException 
				{
					counter++;
					System.out.println("Counter Value : " + counter);
					String ticketNumberSrc = "";
					
					// Will be executed for every Contravention Element in outRoot.
					outContraventionElementParent = outContraventionElement.getParent();
					String csvValue = outContraventionElementParent.getFirstElementByPath("CPRNumber").getValueAsString();
					System.out.println("Comma Seperated Value : " + csvValue);
					StringTokenizer strToken = new StringTokenizer(csvValue, ",");
					System.out.println(strToken.countTokens());
					while (strToken.hasMoreTokens()) 
					{
						cprNumber = strToken.nextToken();
						ticketNumberSrc = strToken.nextToken();
					}
					System.out.println("Ticket Number from inRoot : " + ticketNumberSrc);
					String contraventionNumber = outContraventionElement.getFirstElementByPath("TicketNumber").getValueAsString();
					System.out.println("Ticket Number in outRoot: "+ contraventionNumber);

					if (ticketNumberSrc.equalsIgnoreCase(contraventionNumber)) 
					{
						// Put it as last child
						System.out.println("Match Found");
						
						variableElement.getFirstElementByPath("isMatchFound").setValue(true);
						variableElement.getFirstElementByPath("insertPosition").setValue(counter - 1);
						System.out.println("Match Found : isMatchFound - " + variableElement.getFirstElementByPath("isMatchFound"));
						System.out.println("Match Found : insertPosition - " + variableElement.getFirstElementByPath("insertPosition"));
					} 
					else 
					{
						// Create a new Contravention Object.
						System.out.println("Match Not Found");
					}
				}
				
				@Override
				protected void after() throws MbException 
				{
					System.out.println("Completed looping the out XML, Now CPR Value set to original for next iteration");
					outContraventionElementParent.getFirstElementByPath("CPRNumber").setValue(cprNumber);
					System.out.println("*************************************************");
				}
			};

			// Declare the class to create the output Contraventions for each similar input contraventions

			final ForEachChildOperation createContraventions = new ForEachChildOperation("Contravention") 
			{
				int countIndex = 0;
				//double totalAmount = 0.0;
				MbElement outContrFolder = null;
				MbElement retrieveContrResponse = null;
				
				@Override
				protected void before() throws MbException 
				{
					System.out.println("=========================START======================================");
				}
				
				@Override
				protected void after() throws MbException 
				{
					System.out.println("==========================END======================================");
				}
				
				@SuppressWarnings("unchecked")
				protected void forEachElement(MbElement contraventionElement) throws MbException 
				{
					System.out.println("#####################################################");
					countIndex++;
					System.out.println("Index Value : " + countIndex);
					MbElement cursor_inRoot = contraventionElement;

					String cprNumber = cursor_inRoot.getParent().getFirstElementByPath("CPRNumber").getValueAsString();
					String statusCode = cursor_inRoot.getParent().getFirstElementByPath("StatusCode").getValueAsString();
					String statusMessage = cursor_inRoot.getParent().getFirstElementByPath("StatusMessage").getValueAsString();
					
					System.out.println("CPR from inRoot:  " + cprNumber);
					String ticketNumber = cursor_inRoot.getFirstElementByPath("TicketNumber").getValueAsString();
					System.out.println("ticketNumber from inRoot:  " + ticketNumber);
					
					String isPayableFromInRoot = cursor_inRoot.getFirstElementByPath("isPayable").getValueAsString();
					System.out.println("isPayableFromInRoot :  " + isPayableFromInRoot);

					if (countIndex == 1) 
					{
						retrieveContrResponse = getOutputElement();
						
						retrieveContrResponse.createElementAsLastChild(MbXMLNSC.FIELD, "StatusCode", statusCode);
						retrieveContrResponse.createElementAsLastChild(MbXMLNSC.FIELD, "StatusMessage", statusMessage);
						
						MbElement outCPRField = retrieveContrResponse.createElementAsLastChild(MbXMLNSC.FIELD, "CPRNumber", cprNumber);

						outContrFolder = outCPRField.createElementAfter(MbXMLNSC.FOLDER, "Contravention", null);
						outContrFolder.copyElementTree(contraventionElement);
					} 
					else 
					{
						// Other than 1st iteration
						retrieveContrResponse.getFirstElementByPath("CPRNumber").setValue(retrieveContrResponse.getFirstElementByPath("CPRNumber").getValueAsString()+ "," + ticketNumber);
						
						//Looping Start
						System.out.println("Calling ForEach to loop and evaluate");
						createCD.setOutputElement(retrieveContrResponse);
						createCD.evaluate(retrieveContrResponse);
						//Looping End
						
						// check for Environment tree variable
						// If last, Call the XPATH method to put the inputElement in out's Last child.
						boolean isMatchFound = Boolean.parseBoolean(variableElement.getFirstElementByPath("isMatchFound").getValue().toString());
						int insertPosition = Integer.parseInt(variableElement.getFirstElementByPath("insertPosition").getValueAsString());
						System.out.println("XML Constructor: isMatchFound - "+ isMatchFound);
						System.out.println("XML Constructor: insertPosition - "+ insertPosition);

						if (!isMatchFound) 
						{
							// Match Not Found
							System.out.println("Match Not found, so creating new Contravention element and copying the element.");
							MbElement retriveResponse = retrieveContrResponse.createElementAsLastChild(MbXMLNSC.FOLDER, "Contravention", null);
							retriveResponse.copyElementTree(contraventionElement);
							System.out.println("Element Copied");
						} 
						else 
						{
							// Match Found
							System.out.println("Match found, so fetching the Contravention element in the position and copying the element.");
							System.out.println("Match Found at position-" + (insertPosition)+", "+ retrieveContrResponse.evaluateXPath("Contravention"));
							List<MbElement> contraventionElementsList = (List<MbElement>) retrieveContrResponse.evaluateXPath("Contravention");
							System.out.println("total contravention size: " + contraventionElementsList.size());
							
							MbElement matchElementOutRoot = contraventionElementsList.get((insertPosition));
							System.out.println("Match Element : "+matchElementOutRoot);
							
							MbElement contrDetTobeCopiedFromInRoot = contraventionElement.getFirstElementByPath("ContraventionDetails");
							String offenceType = contrDetTobeCopiedFromInRoot.getFirstElementByPath("OffenceType").getValueAsString();
							System.out.println("offenceType from inRoot : "+offenceType);
							
							String isPayableFromOutRoot = matchElementOutRoot.getFirstElementByPath("isPayable").getValueAsString();
							System.out.println("isPayableFromOutRoot : "+isPayableFromOutRoot);
							
							if(!isPayableFromInRoot.trim().equalsIgnoreCase("T")){								
								matchElementOutRoot.getFirstElementByPath("isPayable").setValue("F");								
							}
							
							double offenceItemAmtInRoot = Double.parseDouble(contrDetTobeCopiedFromInRoot.getFirstElementByPath("OffenceAmount").getValue()+"");
							System.out.println("offenceItemAmtInRoot : "+offenceItemAmtInRoot);
							double totalAmountOutRoot = Double.parseDouble(matchElementOutRoot.getFirstElementByPath("TotalAmount").getValue()+"");
							System.out.println("totalAmountOutRoot : "+totalAmountOutRoot);
							
							if(offenceType.equalsIgnoreCase("COURT") || offenceType.equalsIgnoreCase("GCC") )
							{
								matchElementOutRoot.getFirstElementByPath("TotalAmount").setValue("0.0");
							}
							else
							{
								if(totalAmountOutRoot <= Double.parseDouble("0.0"))
									matchElementOutRoot.getFirstElementByPath("TotalAmount").setValue("0.0");
								else
									matchElementOutRoot.getFirstElementByPath("TotalAmount").setValue((totalAmountOutRoot+offenceItemAmtInRoot)+"");
							}
							MbElement newElement = matchElementOutRoot.createElementAsLastChild(MbXMLNSC.FOLDER, "ContraventionDetails", null);
							System.out.println("Copying the ContraventionDetails as the last child in the matching Contravention Element");
							newElement.copyElementTree(contrDetTobeCopiedFromInRoot);
						}
					}
					System.out.println("#####################################################");
				}
			};

			// Now do the message transformation - Create the output structure
			MbElement outContraventions = outBody.createElementAsFirstChild(MbXMLNSC.FOLDER, "RetrieveOtherContraventionsForCPRResponse", null);
			outContraventions.setNamespace("http://GDTService/com/ngi/bpel/NGI_GDTBpelInterface");
			MbElement retrieveOtherContraventionsForCPRResponse = outContraventions.createElementAsLastChild(MbXMLNSC.FOLDER, "RetrieveOtherContraventionsForCPRResponse", null);
			createContraventions.setOutputElement(retrieveOtherContraventionsForCPRResponse);
			MbElement inRootElement = inRoot.getLastChild().getFirstChild().getFirstElementByPath("RetrieveOtherContraventionsForCPRResponse");
			
			//Setting status code and message if there are no contraventions
			MbElement contraventionElement = null;
			if(inRootElement != null)
				contraventionElement = inRootElement.getFirstElementByPath("Contravention");
			if(contraventionElement == null){
				retrieveOtherContraventionsForCPRResponse.createElementAsLastChild(MbXMLNSC.FIELD, "StatusCode", "GDT-0003");
				retrieveOtherContraventionsForCPRResponse.createElementAsLastChild(MbXMLNSC.FIELD, "StatusMessage", "FAILURE, NO RECORDS FETCHED");
			}
			
			createContraventions.evaluate(inRootElement);
			System.out.println("****************************************");
			
			// End of user code
			// ----------------------------------------------------------

			// The following should only be changed if not propagating message to the 'out' terminal
			getOutputTerminal("out").propagate(outAssembly);
		} 
		catch (Throwable e) 
		{
			// Example Exception handling
			MbUserException mbue = new MbUserException(this, "evaluate()", "", "", e.toString(), null);
			throw mbue;
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException 
	{
		MbElement outRoot = outMessage.getRootElement();
		MbElement header = inMessage.getRootElement().getFirstChild();

		while (header != null && header.getNextSibling() != null) 
		{
			outRoot.addAsLastChild(header.copy());
			header = header.getNextSibling();
		}
	}

	/**
	 * ForEachChildOperation is an abstract helper class allowing a method to be
	 * repeatedly applied to named children of an element. The user can
	 * optionally access the output message tree allowing message
	 * transformations to be defined based on repeating elements in the input
	 * tree.
	 */
	abstract class ForEachChildOperation 
	{
		private String name = null;
		private MbElement outputElement = null;

		/**
		 * Constructor taking the name of the repeating child.
		 */
		public ForEachChildOperation(String name) throws MbException 
		{
			this.name = name;
		}

		/**
		 * Must be called prior to the evaluate method if the user wishes to
		 * work with the output tree (eg for message transformation).
		 */
		
		public void setOutputElement(MbElement out) 
		{
			outputElement = out;
		}

		/**
		 * Allows the user to access the output tree in the forEachElement()
		 * method
		 */
		
		public MbElement getOutputElement() 
		{
			return outputElement;
		}

		/**
		 * Can be overridden by the user to do initialisation processing before
		 * iterating over the children
		 */
		
		protected void before() throws MbException 
		{
		
		}

		/**
		 * This gets called once for each named child element. The current
		 * element is passed in as the only argument. This method is abstract
		 * and must be implemented in the derived class.
		 */
		
		protected abstract void forEachElement(MbElement element) throws MbException;

		/**
		 * Can be overridden by the user to do post-processing after iterating
		 * over the children
		 */
		
		protected void after() throws MbException 
		{
		
		}

		/**
		 * Called by the user to iterate over the XPath nodeset.
		 * 
		 * @param element
		 *            The context element to which the XPath expression will be
		 *            applied.
		 */
		
		public void evaluate(MbElement element) throws MbException 
		{
			before();

			MbElement child = element.getFirstChild();
			while (child != null) 
			{
				String childName = (String) child.getName();
				if (childName.equals(name))
					forEachElement(child);
				child = child.getNextSibling();
			}
			after();
		}
	}
}
