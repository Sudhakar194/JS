package com.ngi;

import java.util.List;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class SourceTypeAdditionFlow_JavaCompute extends MbJavaComputeNode 
{

	@SuppressWarnings("unchecked")
	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		MbOutputTerminal out = getOutputTerminal("out");
		//MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage(inMessage);
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

		try 
		{
			MbElement envRoot = inAssembly.getMessage().getRootElement();
			String userName = envRoot.getFirstChild().getFirstElementByPath("IdentitySourceToken").getValueAsString();
			String sourceType = "";
			if(userName != null) {
				if(userName.startsWith("ngi") || userName.startsWith("egov"))
				{
					sourceType="EGOVPORTAL";
				} 
				else if (userName.startsWith("mob"))
				{
						sourceType="MOBILE";
				} 
				else if(userName.startsWith("kk")) 
				{
						sourceType="KIOSK";
				} 
				else 
				{
					sourceType = "ANONYMOUS";
				}
			} 
			else 
			{
				sourceType = "ANONYMOUS";
			}
			
			List valueList = (List)outAssembly.getMessage().evaluateXPath("//*");
			MbElement[] elementArray = (MbElement[])valueList.toArray();
			
			boolean bSourceTypeFound = false;
			
			for(int j=0; j < elementArray.length; j++) 
			{
				if(elementArray[j].getName().equalsIgnoreCase("SourceType"))
				{						
					elementArray[j].setValue(sourceType);
					bSourceTypeFound = true;
					break;
				}
			}
			if(!bSourceTypeFound) 
			{
				// add the SourceType element							 
				for(int z=0; z < elementArray.length; z++) 
				{
					if(elementArray[z].getName().endsWith("Request"))
					{						
						elementArray[z].createElementAsLastChild(MbElement.TYPE_NAME, "SourceType", sourceType);
						break;
					}
				}
			}		
			// The following should only be changed
			// if not propagating message to the 'out' terminal
			out.propagate(outAssembly);

		} 
		finally 
		{
			// Clear the outMessage
			outMessage.clearMessage();
		}
	}

}
