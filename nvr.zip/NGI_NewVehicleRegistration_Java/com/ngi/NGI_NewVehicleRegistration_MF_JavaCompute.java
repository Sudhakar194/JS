/*
 * FTPScript.sh
 * 
 * #!/bin/bash
 * #FOLDER_NAME=WDDLJ6FBXFA148884
 * #FILE_NAME=WDDLJ6FBXFA148884_InsuranceCopy.pdf
 * #NFS_PATH=/eComplains/Staging/GDTAttachments/NVR/ToFTP/
 * #UPLOADED_PATH=/eComplains/Staging/GDTAttachments/NVR/Uploaded/
 * #
 * #Get the parameters from Java code
 * FOLDER_NAME=$1
 * FILE_NAME=$2
 * NFS_PATH=$3
 * FTP_PATH=$5
 * lftp -u vehiclereg,gdt.VReg#PK -e "binary;mkdir $FTP_PATH/$FOLDER_NAME;cd $FTP_PATH/$FOLDER_NAME;lcd $NFS_PATH;mput $FILE_NAME;quit" 10.44.60.174
 * mv -f $NFS_PATH/$FILE_NAME $UPLOADED_PATH
 * #
 * #cp -f $NFS_PATH/$FILE_NAME $UPLOADED_PATH
 * #find /path/to/files* -mtime +30 -exec rm {} \; -- Delete files older than 30 days
 * echo "Files Sent to GDT Successfully...!!!"
 * 
 */

package com.ngi;

import java.io.IOException;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

public class NGI_NewVehicleRegistration_MF_JavaCompute extends MbJavaComputeNode 
{
	public void evaluate(MbMessageAssembly inAssembly) throws MbException 
	{
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();

		// create new message
		MbMessage outMessage = new MbMessage();
		MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

		try 
		{
			// optionally copy message headers
			copyMessageHeaders(inMessage, outMessage);

			// --------------------------------------------------------------------------------------------------------------------------------------
			// Add user code below
			
			MbMessage globalMessage = inAssembly.getGlobalEnvironment();
			final MbElement variableElement = globalMessage.getRootElement().getFirstElementByPath("Variables");
			
			String FolderName = variableElement.getFirstElementByPath("FolderName").getValueAsString();
			String FileName   = variableElement.getFirstElementByPath("FileName").getValueAsString();
			String ScriptPath = variableElement.getFirstElementByPath("ScriptPath").getValueAsString();
			String AttachmentDirectoryNFS      = variableElement.getFirstElementByPath("AttachmentDirectoryNFS").getValueAsString();
			String AttachmentDirectoryUploaded = variableElement.getFirstElementByPath("AttachmentDirectoryUploaded").getValueAsString();
			String FTPPath 	  = variableElement.getFirstElementByPath("FTPPath").getValueAsString();
			
			String ScriptName = "sh "+ScriptPath+"FTPScript.sh "+FolderName+" "+FileName+" "+AttachmentDirectoryNFS+" "+AttachmentDirectoryUploaded+" "+FTPPath;
			System.out.println("Command:::: "+ScriptName);
			Runtime.getRuntime().exec(ScriptName);
			
			System.out.println("Command Executed Successfully...!!!");
			
			// End of user code
			// ---------------------------------------------------------------------------------------------------------------------------------------

			// The following should only be changed
			// if not propagating message to the 'out' terminal
			out.propagate(outAssembly);

		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally 
		{

			// clear the outMessage even if there's an exception
			outMessage.clearMessage();
		}
	}

	public void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage)
			throws MbException 
			{
		MbElement outRoot = outMessage.getRootElement();

		// iterate though the headers starting with the first child of the root
		// element
		MbElement header = inMessage.getRootElement().getFirstChild();
		while (header != null && header.getNextSibling() != null) // stop before
		// the last
		// child
		// (body)
		{
			// copy the header and add it to the out message
			outRoot.addAsLastChild(header.copy());
			// move along to next header
			header = header.getNextSibling();
		}
	}
}
