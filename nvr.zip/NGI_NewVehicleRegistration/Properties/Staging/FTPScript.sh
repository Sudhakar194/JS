#!/bin/bash
#FOLDER_NAME=WDDLJ6FBXFA148884
#FILE_NAME=WDDLJ6FBXFA148884_InsuranceCopy.pdf
#NFS_PATH=/eComplains/Staging/GDTAttachments/NVR/ToFTP/
#UPLOADED_PATH=/eComplains/Staging/GDTAttachments/NVR/Uploaded/
#
#Get the parameters from Java code
FOLDER_NAME=$1
FILE_NAME=$2
NFS_PATH=$3
UPLOADED_PATH=$4
lftp -u vehiclereg,gdt.VReg#PK -e "binary;mkdir /NVR/Staging/$FOLDER_NAME;cd /NVR/Staging/$FOLDER_NAME;lcd $NFS_PATH;mput $FILE_NAME;quit" 10.44.60.174
mv -f $NFS_PATH/$FILE_NAME $UPLOADED_PATH
#
#cp -f $NFS_PATH/$FILE_NAME $UPLOADED_PATH
#find /path/to/files* -mtime +30 -exec rm {} \; -- Delete files older than 30 days
echo "Files Sent to GDT Successfully...!!!"